<?php
/**
 * Plugin Name: Replanta Site Audit
 * Description: Panel premium de auditoria SEO y rendimiento con auto-fix. Diagnostico Cloudflare, deteccion de auto-bloqueo servidor, RankMath, headers HTTP, base de datos y correccion automatica.
 * Version: 3.2.0
 * Author: Replanta
 * Requires at least: 6.0
 * Tested up to: 7.0
 * Requires PHP: 8.0
 *
 * ── DEPENDENCIAS INTER-PLUGIN (todas soft/opcionales) ───────────────────────
 *
 *  dominios-reseller         — Token y servicio CF. Habilita: CF Audit, CF Auto-Fix,
 *                              Cache Rules, Hit Ratio. Sin él, solo SEO + Rendimiento.
 *                              Clase: Dominios_Reseller_Cloudflare_Service::get_instance()
 *                              Token: dominios_reseller_options['cf_api_token']
 *                              Acceso centralizado via RSA_DR_Bridge (class-dr-bridge.php)
 *
 *  polylang                  — Habilita: hreflang sitemap check, Translation Sync.
 *
 *  seo-by-rank-math          — Habilita: meta tags, Schema, robots, sitemap XML checks.
 *
 *  replanta-sitemap-hreflang — Habilita: inyección xhtml:link en sitemap, fix activar.
 *
 *  litespeed-cache           — Habilita: Object Cache profundo, Critical CSS check.
 *
 * ────────────────────────────────────────────────────────────────────────────
 */

if (!defined('ABSPATH')) {
    exit;
}

define('RSA_VERSION', '3.2.0');
define('RSA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RSA_PLUGIN_URL', plugin_dir_url(__FILE__));

// Auto-detect domain
define('RSA_DOMAIN', wp_parse_url(home_url(), PHP_URL_HOST) ?: 'localhost');

// Cargar infraestructura de dependencias antes que cualquier otro módulo.
// RSA_DR_Bridge es el único punto de acceso al servicio CF de Dominios Reseller.
require_once RSA_PLUGIN_DIR . 'includes/class-dr-bridge.php';
require_once RSA_PLUGIN_DIR . 'includes/class-dependencies.php';

/**
 * Carga principal del plugin
 */
add_action('plugins_loaded', function () {

    // Mostrar aviso si CF no está disponible (la comprobación se delega al bridge)
    if (!RSA_DR_Bridge::is_configured()) {
        add_action('admin_notices', function () {
            $screen = get_current_screen();
            if ($screen && $screen->id === 'toplevel_page_replanta-site-audit') {
                $dr = RSA_Dependencies::get_all()[RSA_Dependencies::DEP_DOMINIOS_RESELLER];
                if (!$dr['active']) {
                    echo '<div class="notice notice-warning is-dismissible"><p>'
                        . '<strong>Replanta Site Audit:</strong> Instala y activa <em>Dominios Reseller</em> '
                        . 'para habilitar la auditoría y auto-fix de Cloudflare.</p></div>';
                } elseif (!$dr['configured']) {
                    $link = '<a href="' . esc_url(admin_url('admin.php?page=dominios-reseller')) . '">Dominios Reseller → Configuración → Cloudflare</a>';
                    echo '<div class="notice notice-warning is-dismissible"><p>'
                        . '<strong>Replanta Site Audit:</strong> Cloudflare deshabilitado. '
                        . "Introduce tu API Token en {$link} para activar los checks CF.</p></div>";
                }
            }
        });
    }

    require_once RSA_PLUGIN_DIR . 'includes/class-cloudflare-audit.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-seo-audit.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-performance-audit.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-accessibility-audit.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-core-web-vitals.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-auto-fixer.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-bot-healer.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-translation-sync.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-schema-audit.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-audit-engine.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-admin-page.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-rest-api.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-gsc-client.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-dataforseo-client.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-claude-seo-agent.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-seo-agent.php';
    // SEO Autopilot classes (v3.0.0)
    require_once RSA_PLUGIN_DIR . 'includes/class-seo-snapshot.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-seo-proposal-engine.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-seo-executor.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-serp-tracker.php';
    require_once RSA_PLUGIN_DIR . 'includes/class-seo-approval.php';

    RSA_Bot_Healer::get_instance();
    RSA_Translation_Sync::get_instance();
    RSA_Schema_Audit::get_instance();
    RSA_Admin_Page::get_instance();
    RSA_Rest_Api::get_instance();
    RSA_GSC_Client::get_instance();
    RSA_SEO_Agent::get_instance();
    // SEO Autopilot singletons
    RSA_SEO_Snapshot::get_instance();
    RSA_SEO_Approval::get_instance();
    // DB version guard — auto-migrate on version bump (dev/staging environments skip activation hook)
    $rsa_db_ver = get_option( 'rsa_db_version', '0.0.0' );
    if ( version_compare( $rsa_db_ver, RSA_VERSION, '<' ) ) {
        RSA_SEO_Snapshot::create_tables();
        update_option( 'rsa_db_version', RSA_VERSION );
    }
    // Executor cron
    add_action( 'rsa_seo_execute_approved', [ 'RSA_SEO_Executor', 'run' ] );
    // Polylang meta propagation — async, fires 5s after each approved meta change
    add_action( 'rsa_propagate_meta_translation', [ 'RSA_SEO_Executor', 'propagate_meta_translation' ], 10, 5 );
});

register_activation_hook(__FILE__, function () {
    require_once plugin_dir_path(__FILE__) . 'includes/class-bot-healer.php';
    RSA_Bot_Healer::on_activate();
    require_once plugin_dir_path(__FILE__) . 'includes/class-seo-snapshot.php';
    RSA_SEO_Snapshot::on_activate();
});

register_deactivation_hook(__FILE__, function () {
    require_once plugin_dir_path(__FILE__) . 'includes/class-bot-healer.php';
    RSA_Bot_Healer::on_deactivate();
    require_once plugin_dir_path(__FILE__) . 'includes/class-seo-snapshot.php';
    RSA_SEO_Snapshot::on_deactivate();
});

/**
 * Sitemap XML Clean Output
 * Elimina BOM y whitespace del inicio de sitemaps para evitar errores XML en GSC.
 * Usa template_redirect p.0 — antes de que RankMath (p.1) emita el sitemap,
 * evitando el conflicto que ocurría con plugins_loaded p.1.
 */
add_action('template_redirect', function () {
    if (!isset($_SERVER['REQUEST_URI']) || strpos($_SERVER['REQUEST_URI'], 'sitemap') === false) {
        return;
    }

    ob_start(function ($buffer) {
        $buffer = preg_replace('/^\xEF\xBB\xBF/', '', $buffer);
        if (preg_match('/(<\?xml.*)$/s', $buffer, $matches)) {
            $buffer = $matches[1];
        }
        return $buffer;
    });

    register_shutdown_function(function () {
        while (ob_get_level() > 0) {
            ob_end_flush();
        }
    });
}, 0); // Prioridad 0 = antes que RankMath (p.1) emita el sitemap
