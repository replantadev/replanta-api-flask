<?php
/**
 * Audit Engine — Orquestador v2.1
 *
 * Ejecuta módulos de auditoría, gestiona cache/historial
 * y expone endpoint AJAX para auto-fix.
 *
 * @package Replanta_Site_Audit
 * @version 2.4.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Audit_Engine {

    const TRANSIENT_KEY  = 'rsa_audit_result';
    const TRANSIENT_TTL  = 3600;
    const OPTION_HISTORY = 'rsa_audit_history';

    /**
     * Ejecutar auditoría completa (o devolver cache)
     */
    public static function run(bool $force = false): array {
        if (!$force) {
            $cached = get_transient(self::TRANSIENT_KEY);
            if ($cached !== false) {
                $cached['from_cache'] = true;
                return $cached;
            }
        }

        $start = microtime(true);

        // Core audits
        $cf_result     = (new RSA_Cloudflare_Audit())->run();
        $seo_result    = (new RSA_SEO_Audit())->run();
        $perf_result   = (new RSA_Performance_Audit())->run();
        $access_result = (new RSA_Accessibility_Audit())->run();

        // Core Web Vitals — solo desde caché (el Bot de Salud refresca diariamente)
        $cwv_result = (new RSA_Core_Web_Vitals())->run();

        $all_checks = array_merge(
            $access_result['checks'] ?? [], // Accessibility first (most critical)
            $cf_result['checks']    ?? [],
            $seo_result['checks'],
            $perf_result['checks'],
            $cwv_result['checks']   ?? []
        );

        // Filter out any non-array entries (can appear if a module returns malformed data
        // or a transient was stored from an older plugin version)
        $all_checks = array_values(array_filter($all_checks, fn($c) => is_array($c)));

        $total    = count($all_checks);
        $passed   = count(array_filter($all_checks, fn($c) => ($c['status'] ?? '') === 'pass'));
        $critical = count(array_filter($all_checks, fn($c) => ($c['status'] ?? '') === 'critical'));
        $warnings = count(array_filter($all_checks, fn($c) => ($c['status'] ?? '') === 'warning'));
        $info     = count(array_filter($all_checks, fn($c) => ($c['status'] ?? '') === 'info'));

        $score_sum    = ($passed * 100) + ($info * 80) + ($warnings * 40);
        $global_score = $total > 0 ? round($score_sum / ($total * 100) * 100) : 0;

        // Count fixable issues
        $fixable = array_filter($all_checks, fn($c) => !empty($c['fixable']));

        $result = [
            'timestamp'    => current_time('mysql'),
            'duration'     => round(microtime(true) - $start, 2),
            'global_score' => $global_score,
            'from_cache'   => false,
            'modules'      => [
                'accessibility' => [
                    'score'   => $access_result['score'] ?? 0,
                    'summary' => $access_result['summary'] ?? [],
                ],
                'cloudflare'  => [
                    'score'     => $cf_result['score'] ?? 0,
                    'zone_id'   => $cf_result['zone_id'] ?? null,
                    'zone_name' => $cf_result['zone_name'] ?? null,
                    'ok'        => $cf_result['ok'] ?? false,
                    'error'     => $cf_result['error'] ?? null,
                    'summary'   => $cf_result['summary'] ?? [],
                ],
                'seo'              => ['score' => $seo_result['score'],  'summary' => $seo_result['summary']],
                'performance'      => ['score' => $perf_result['score'], 'summary' => $perf_result['summary']],
                'core_web_vitals'  => ['score' => $cwv_result['score'] ?? 0, 'summary' => $cwv_result['summary'] ?? []],
            ],
            'summary' => [
                'total' => $total, 'passed' => $passed,
                'critical' => $critical, 'warnings' => $warnings, 'info' => $info,
                'fixable' => count($fixable),
            ],
            'checks' => $all_checks,
        ];

        set_transient(self::TRANSIENT_KEY, $result, self::TRANSIENT_TTL);
        self::save_to_history($result);

        return $result;
    }

    /* ─────────── Fix Execution ─────────── */

    /**
     * Execute a single auto-fix by ID.
     */
    public static function execute_fix(string $fix_id): array {
        $fixer  = RSA_Auto_Fixer::get_instance();
        $result = $fixer->execute($fix_id);

        // Write to the persistent bot log so the user can see what was fixed
        // and when (visible in the Bot de Salud → log table).
        $bot    = RSA_Bot_Healer::get_instance();
        $bot->log(
            $result['success'] ? 'success' : 'error',
            'audit_fix',
            sprintf('Fix %s [%s]: %s', $result['success'] ? 'aplicado' : 'fallido', $fix_id, $result['message'] ?? '')
        );

        // Clear audit cache so next display shows updated state.
        // The JS will trigger a re-audit automatically after this call.
        delete_transient(self::TRANSIENT_KEY);

        return $result;
    }

    /**
     * Execute all fixable issues from the last audit.
     */
    public static function execute_all_fixes(): array {
        $cached = get_transient(self::TRANSIENT_KEY);
        if (!$cached || empty($cached['checks'])) {
            return ['success' => false, 'message' => 'No hay auditoría. Ejecuta una primero.'];
        }

        $fixable = array_filter($cached['checks'], fn($c) => is_array($c) && !empty($c['fixable']));
        if (empty($fixable)) {
            return ['success' => true, 'message' => 'No hay problemas corregibles.', 'results' => []];
        }

        $fixer   = RSA_Auto_Fixer::get_instance();
        $fix_ids = array_unique(array_column($fixable, 'fix_id'));
        $results = $fixer->execute_batch($fix_ids);

        delete_transient(self::TRANSIENT_KEY);

        $ok    = count(array_filter($results, fn($r) => is_array($r) && !empty($r['success'])));
        $total = count($results);

        return [
            'success' => $ok > 0,
            'message' => "Ejecutados {$total} fixes: {$ok} exitosos, " . ($total - $ok) . " fallidos.",
            'results' => $results,
        ];
    }

    /* ─────────── History ─────────── */

    private static function save_to_history(array $result): void {
        $history   = get_option(self::OPTION_HISTORY, []);
        $history[] = [
            'timestamp'    => $result['timestamp'],
            'global_score' => $result['global_score'],
            'cf_score'     => $result['modules']['cloudflare']['score'],
            'seo_score'    => $result['modules']['seo']['score'],
            'perf_score'   => $result['modules']['performance']['score'],
            'critical'     => $result['summary']['critical'],
            'warnings'     => $result['summary']['warnings'],
        ];
        $history = array_slice($history, -30);
        update_option(self::OPTION_HISTORY, $history, false);
    }

    public static function get_history(): array {
        return get_option(self::OPTION_HISTORY, []);
    }

    public static function group_checks(array $checks): array {
        $groups = [];
        foreach ($checks as $check) {
            if (!is_array($check)) {
                continue;
            }
            $groups[$check['category'] ?? 'general'][] = $check;
        }
        return $groups;
    }

    public static function get_issues(array $checks): array {
        return array_filter($checks, fn($c) => is_array($c) && in_array($c['status'] ?? '', ['critical', 'warning']));
    }
}
