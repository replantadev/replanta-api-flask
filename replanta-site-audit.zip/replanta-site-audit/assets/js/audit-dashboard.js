/**
 * Replanta Site Audit — Dashboard JS v2.0
 * Run audit + auto-fix handlers.
 */
(function ($) {
    'use strict';

    /* ── Run Audit ── */
    $('#rsa-run-audit').on('click', function () {
        var $btn = $(this);
        var $loading = $('#rsa-loading');
        $btn.prop('disabled', true).find('.dashicons').addClass('rsa-spinning');
        $loading.fadeIn(200);

        /* Progress steps animation */
        var _progressSteps = ['#rsp-cf', '#rsp-seo', '#rsp-perf', '#rsp-done'];
        var _pIdx = 0;
        var _progressTimer = setInterval(function () {
            if (_pIdx < _progressSteps.length) {
                $(_progressSteps[_pIdx]).addClass('rsp-active');
                if (_pIdx > 0) $(_progressSteps[_pIdx - 1]).addClass('rsp-done').removeClass('rsp-active');
                _pIdx++;
            }
        }, 4000);

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_run_audit', _nonce: rsaAjax.nonce },
            timeout: 120000,
            success: function (resp) {
                clearInterval(_progressTimer);
                if (resp.success) {
                    window.location.reload();
                } else {
                    alert('Error: ' + (resp.data || 'Error desconocido'));
                    $loading.fadeOut(200);
                    $btn.prop('disabled', false).find('.dashicons').removeClass('rsa-spinning');
                }
            },
            error: function (xhr) {
                clearInterval(_progressTimer);
                var msg = 'Error de conexión.';
                try { msg = JSON.parse(xhr.responseText).data || msg; } catch (e) {}
                alert(msg);
                $loading.fadeOut(200);
                $btn.prop('disabled', false).find('.dashicons').removeClass('rsa-spinning');
            },
        });
    });

    /* ── Single Fix ── */
    $(document).on('click', '.rsa-fix-btn', function (e) {
        e.stopPropagation();
        var $btn = $(this);
        var fixId = $btn.data('fix-id');
        if (!fixId) return;

        $btn.prop('disabled', true).addClass('rsa-fixing');
        var origText = $btn.html();
        $btn.html('<span class="dashicons dashicons-update rsa-spinning"></span> Corrigiendo…');

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_run_fix', _nonce: rsaAjax.nonce, fix_id: fixId },
            timeout: 30000,
            success: function (resp) {
                if (resp.success) {
                    $btn.html('<span class="dashicons dashicons-yes"></span> Corregido')
                        .addClass('rsa-fix-done').removeClass('rsa-fixing');
                    $btn.closest('.rsa-issue, .rsa-check-row').addClass('rsa-fixed-row');
                    showFixNotice('success', (resp.data.message || 'Fix aplicado.') + ' Re-auditando…');

                    // Re-run the audit silently so fresh results are ready on reload.
                    // This ensures the fix is verified and the log reflects current state.
                    $btn.html('<span class="dashicons dashicons-update rsa-spinning"></span> Re-auditando…');
                    $.ajax({
                        url: rsaAjax.url,
                        method: 'POST',
                        data: { action: 'rsa_run_audit', _nonce: rsaAjax.nonce },
                        timeout: 60000,
                        complete: function () {
                            // Reload regardless of outcome — fresh results will display
                            window.location.reload();
                        }
                    });
                } else {
                    $btn.html(origText).prop('disabled', false).removeClass('rsa-fixing');
                    showFixNotice('error', resp.data || 'Error al aplicar el fix.');
                }
            },
            error: function () {
                $btn.html(origText).prop('disabled', false).removeClass('rsa-fixing');
                showFixNotice('error', 'Error de conexión al aplicar el fix.');
            },
        });
    });

    /* ── Fix All ── */
    $('#rsa-fix-all').on('click', function () {
        var $btn = $(this);
        if (!confirm('¿Aplicar TODAS las correcciones automáticas? Esto modificará configuración de CF, WP y .htaccess.')) return;

        $btn.prop('disabled', true);
        $btn.html('<span class="dashicons dashicons-update rsa-spinning"></span> Corrigiendo todo…');

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_run_fix_all', _nonce: rsaAjax.nonce },
            timeout: 120000,
            success: function (resp) {
                if (resp.success && resp.data) {
                    showFixNotice('success', resp.data.message || 'Fixes aplicados.');
                    // Show individual results
                    if (resp.data.results) {
                        var details = [];
                        $.each(resp.data.results, function (id, r) {
                            details.push((r.success ? '[OK] ' : '[Error] ') + id + ': ' + r.message);
                        });
                        if (details.length) showFixNotice('info', details.join('\n'));
                    }
                    // Re-run audit to update scores
                    setTimeout(function () { window.location.reload(); }, 2000);
                } else {
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-tools"></span> Corregir Todo');
                    showFixNotice('error', resp.data || 'Error.');
                }
            },
            error: function () {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-tools"></span> Corregir Todo');
                showFixNotice('error', 'Error de conexión.');
            },
        });
    });

    /* ── Toggle Category ── */
    $(document).on('click', '.rsa-category-header', function () {
        var $header = $(this);
        var target = $header.data('toggle');
        $header.toggleClass('rsa-open');
        $('#' + target).toggleClass('rsa-open');
    });

    /* ── Auto-expand critical + fixable ── */
    $(function () {
        $('.rsa-card-category').each(function () {
            var $card = $(this);
            if ($card.find('.rsa-check-critical, .rsa-fix-btn').length > 0) {
                $card.find('.rsa-category-header').addClass('rsa-open');
                $card.find('.rsa-category-checks').addClass('rsa-open');
            }
        });
    });

    /* ── Notice helper ── */
    function showFixNotice(type, msg) {
        var cls = type === 'success' ? 'notice-success' : type === 'error' ? 'notice-error' : 'notice-info';
        var $notice = $('<div class="notice ' + cls + ' is-dismissible rsa-fix-notice"><p>' +
            msg.replace(/\n/g, '<br>') + '</p></div>');
        $('.rsa-summary-bar').after($notice);
        setTimeout(function () { $notice.fadeOut(400, function () { $(this).remove(); }); }, 8000);
    }

    /* ── Spinning animation ── */
    var style = document.createElement('style');
    style.textContent = '.rsa-spinning { animation: rsa-spin 0.8s linear infinite; }';
    document.head.appendChild(style);

})(jQuery);

/* ══════════════════════════════════════════════════
 *  Bot de Salud — JS handlers
 * ══════════════════════════════════════════════════ */
(function ($) {
    'use strict';

    /* ── JS Tab Switcher (no page reload, no scan interruption) ── */
    $('.rsa-tab[data-tab]').on('click', function () {
        var target = $(this).data('tab');
        $('.rsa-tab').removeClass('rsa-tab-active');
        $(this).addClass('rsa-tab-active');
        $('.rsa-tab-content').hide();
        $('#rsa-tab-' + target).show();
        // Show audit header buttons only on audit tab
        $('#rsa-header-audit-btns').toggle(target === 'audit');
        // Lazy-load translations when bot tab first becomes visible
        if (target === 'bot') {
            loadTranslationsOnce();
        }
    });

    var _translationsLoaded = false;
    function loadTranslationsOnce() {
        if (!_translationsLoaded && rsaBot.polylang_active) {
            _translationsLoaded = true;
            loadTranslations();
        }
    }

    /* ── Toggle On/Off ── */
    $('#rsa-bot-toggle').on('change', function () {
        var $toggle = $(this);
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_bot_toggle', _nonce: rsaAjax.nonce },
            success: function (resp) {
                if (resp.success) {
                    var enabled = resp.data.enabled;
                    var $label  = $('#rsa-bot-toggle-label');
                    $label.html(enabled
                        ? '<strong style="color:#00a32a">Activo</strong>'
                        : '<strong style="color:#999">Inactivo</strong>'
                    );
                    $('#rsa-bot-next-run').text(resp.data.next_run);
                    botNotice('success', enabled ? 'Bot activado' : 'Bot desactivado');
                } else {
                    $toggle.prop('checked', !$toggle.prop('checked')); // revert
                    botNotice('error', 'Error al cambiar estado del bot.');
                }
            },
            error: function () {
                $toggle.prop('checked', !$toggle.prop('checked'));
                botNotice('error', 'Error de conexión.');
            },
        });
    });

    /* ── Scan Only ── */
    $('#rsa-bot-scan-only').on('click', function () {
        var $btn     = $(this);
        var $results = $('#rsa-bot-scan-results');
        var $loading = $('#rsa-bot-loading');

        $btn.prop('disabled', true);
        $loading.fadeIn(200);
        $results.hide();

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_bot_scan_only', _nonce: rsaAjax.nonce },
            timeout: 120000,
            success: function (resp) {
                $loading.fadeOut(200);
                $btn.prop('disabled', false);

                if (!resp.success) {
                    botNotice('error', 'Error en scan: ' + (resp.data || 'Error desconocido'));
                    return;
                }

                var d = resp.data;
                var scoreColor = d.score >= 80 ? '#00a32a' : d.score >= 50 ? '#dba617' : '#c02b0a';
                var html = '<div class="rsa-scan-summary">' +
                    '<div class="rsa-scan-score" style="color:' + scoreColor + '">' + d.score + '%</div>' +
                    '<div class="rsa-scan-metrics">' +
                        '<span class="rsa-scan-metric rsa-metric-critical">Criticos: <strong>' + (d.critical || 0) + '</strong></span>' +
                        '<span class="rsa-scan-metric rsa-metric-warning">Avisos: <strong>' + (d.warnings || 0) + '</strong></span>' +
                        '<span class="rsa-scan-metric rsa-metric-fixable">Corregibles: <strong>' + (d.fixable || 0) + '</strong></span>' +
                        (rsaBot.polylang_active ? '<span class="rsa-scan-metric rsa-metric-translations">Traducciones: <strong>' + (d.outdated_translations || 0) + '</strong></span>' : '') +
                    '</div>' +
                    '<a href="?page=replanta-site-audit&rsa_tab=audit" class="rsa-scan-link">Ver informe completo</a>' +
                    '</div>';

                $results.html(html).fadeIn(300);

                // Refresh translations list if polylang available
                if (rsaBot.polylang_active) {
                    loadTranslations();
                }
            },
            error: function () {
                $loading.fadeOut(200);
                $btn.prop('disabled', false);
                botNotice('error', 'Error de conexion al ejecutar el scan.');
            },
        });
    });

    /* ── Run Now ── */
    $('#rsa-bot-run-now').on('click', function () {
        if (!confirm('Ejecutar el Bot de Salud ahora?\n\nSe ejecutará la auditoría, se aplicarán fixes automáticos y se rellenarán metas vacíos. Puede tardar 30-60 segundos.')) return;

        var $btn     = $(this);
        var $loading = $('#rsa-bot-loading');

        $btn.prop('disabled', true);
        $loading.fadeIn(200);

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_bot_run_now', _nonce: rsaAjax.nonce },
            timeout: 180000,
            success: function (resp) {
                $loading.fadeOut(200);
                $btn.prop('disabled', false);
                if (resp.success) {
                    botNotice('success', 'Bot ejecutado correctamente. Recargando log…');
                    loadLog('all');
                } else {
                    botNotice('error', 'Error: ' + (resp.data || 'Error desconocido'));
                }
            },
            error: function () {
                $loading.fadeOut(200);
                $btn.prop('disabled', false);
                botNotice('error', 'Error de conexión al ejecutar el bot.');
            },
        });
    });

    /* ── Save Settings ── */
    $('#rsa-bot-save-settings').on('click', function () {
        var $btn    = $(this);
        var $msg    = $('#rsa-bot-settings-msg');
        var postTypes = [];
        $('input[name="rsa_bot_post_types[]"]:checked').each(function () {
            postTypes.push($(this).val());
        });

        $btn.prop('disabled', true);
        $msg.hide();

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action:                  'rsa_bot_save_settings',
                _nonce:                  rsaAjax.nonce,
                schedule:                $('#rsa-bot-schedule').val(),
                fill_metas:              $('#rsa-bot-fill-metas').is(':checked') ? 1 : 0,
                max_per_run:             $('#rsa-bot-max-per-run').val(),
                post_types:              postTypes,
                sync_translations:       $('#rsa-bot-sync-translations').is(':checked') ? 1 : 0,
                translations_max_per_run: $('#rsa-bot-translations-max').val() || 2,
                notify_email:            $('#rsa-bot-notify-email').val(),
                notify_on_critical:      $('#rsa-bot-notify-critical').is(':checked') ? 1 : 0,
                notify_weekly_digest:    $('#rsa-bot-notify-weekly').is(':checked') ? 1 : 0,
            },
            success: function (resp) {
                $btn.prop('disabled', false);
                if (resp.success) {
                    $msg.text(resp.data.message).css('color', '#00a32a').show();
                    $('#rsa-bot-next-run').text(resp.data.next_run);
                    setTimeout(function () { $msg.fadeOut(); }, 4000);
                } else {
                    $msg.text('Error al guardar').css('color', '#c02b0a').show();
                }
            },
            error: function () {
                $btn.prop('disabled', false);
                $msg.text('Error de conexión').css('color', '#c02b0a').show();
            },
        });
    });

    /* ── Clear Log ── */
    $('#rsa-bot-clear-log').on('click', function () {
        if (!confirm('¿Borrar todo el registro de actividad del bot?')) return;

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_bot_clear_log', _nonce: rsaAjax.nonce },
            success: function (resp) {
                if (resp.success) {
                    $('#rsa-bot-log-container').html('<p class="rsa-bot-log-empty">Log borrado.</p>');
                    botNotice('success', 'Log borrado correctamente.');
                }
            },
        });
    });

    /* ── Filter Log ── */
    $('#rsa-bot-log-filter').on('change', function () {
        loadLog($(this).val());
    });

    function loadLog(filter) {
        var $container = $('#rsa-bot-log-container');
        $container.css('opacity', '0.5');

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_bot_get_log', _nonce: rsaAjax.nonce, filter: filter || 'all' },
            success: function (resp) {
                $container.css('opacity', '1');
                if (resp.success && resp.data.log) {
                    if (resp.data.log.length === 0) {
                        $container.html('<p class="rsa-bot-log-empty">No hay entradas con este filtro.</p>');
                        return;
                    }
                    var rows = resp.data.log.map(function (e) {
                        var icons = { success: '', error: '', info: '' };
                        var typeLabels = {
                            bot_run: 'Ciclo', audit: 'Auditoria', audit_fix: 'Fix',
                            meta_fill: 'Meta', config: 'Config', translation_sync: 'Traduccion EN'
                        };
                        var postLink = e.post_id
                            ? ' <a href="' + window.location.origin + '/wp-admin/post.php?post=' + e.post_id + '&action=edit" target="_blank" class="rsa-log-post-link">#' + e.post_id + '</a>'
                            : '';
                        return '<tr class="rsa-log-row rsa-log-' + e.status + '">' +
                            '<td class="rsa-log-time">'    + e.time + '</td>' +
                            '<td class="rsa-log-status">'  + (icons[e.status] || '?') + '</td>' +
                            '<td class="rsa-log-type"><span class="rsa-log-type-badge">' + (typeLabels[e.type] || e.type) + '</span></td>' +
                            '<td class="rsa-log-message">' + $('<div>').text(e.message).html() + postLink + '</td>' +
                            '</tr>';
                    }).join('');

                    $container.html(
                        '<table class="rsa-bot-log-table widefat striped">' +
                        '<thead><tr>' +
                        '<th style="width:140px">Fecha/Hora</th>' +
                        '<th style="width:80px">Estado</th>' +
                        '<th style="width:90px">Tipo</th>' +
                        '<th>Mensaje</th>' +
                        '</tr></thead><tbody>' + rows + '</tbody></table>'
                    );
                }
            },
        });
    }

    /* ── Bot notice helper ── */
    function botNotice(type, msg) {
        var cls     = type === 'success' ? 'notice-success' : type === 'error' ? 'notice-error' : 'notice-info';
        var $notice = $('<div class="notice ' + cls + ' is-dismissible" style="margin:10px 0"><p>' + msg + '</p></div>');
        $('.rsa-bot-status-card').before($notice);
        var timeout = type === 'error' ? 15000 : 6000;
        setTimeout(function () { $notice.fadeOut(400, function () { $(this).remove(); }); }, timeout);
    }

    /* ── Translations list ── */
    function loadTranslations() {
        var $container = $('#rsa-bot-translations-container');
        if (!$container.length) return;

        $container.html('<p class="rsa-bot-log-empty">Cargando&hellip;</p>');

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_translation_get_outdated', _nonce: rsaAjax.nonce },
            success: function (resp) {
                if (!resp.success) {
                    $container.html('<p class="rsa-bot-log-empty">Error al cargar traducciones.</p>');
                    return;
                }

                var items = resp.data.outdated || [];
                if (items.length === 0) {
                    $container.html('<p class="rsa-bot-log-empty">Todas las traducciones EN estan actualizadas.</p>');
                    return;
                }

                var rows = items.map(function (item) {
                    var badge = item.has_elementor
                        ? '<span class="rsa-trans-badge rsa-trans-elementor">Elementor</span>'
                        : '<span class="rsa-trans-badge rsa-trans-classic">Clasico</span>';
                    var days  = item.diff_days > 0 ? item.diff_days + ' dias' : 'Hoy';
                    return '<tr>' +
                        '<td>' + $('<span>').text(item.title).html() + '</td>' +
                        '<td>' + badge + '</td>' +
                        '<td class="rsa-trans-days">' + days + '</td>' +
                        '<td class="rsa-trans-date">' + item.es_modified + '</td>' +
                        '<td>' +
                            '<a href="' + item.url_es + '" target="_blank" class="rsa-trans-link">ES</a> ' +
                            '<a href="' + item.url_en + '" target="_blank" class="rsa-trans-link">EN</a>' +
                        '</td>' +
                        '<td>' +
                            '<button class="button button-small rsa-sync-post-btn" ' +
                                'data-es="' + item.es_id + '" data-en="' + item.en_id + '" ' +
                                'data-title="' + $('<span>').text(item.title).html() + '">' +
                                'Sincronizar con IA' +
                            '</button>' +
                        '</td>' +
                    '</tr>';
                }).join('');

                $container.html(
                    '<table class="widefat rsa-translations-table">' +
                    '<thead><tr>' +
                    '<th>Titulo</th><th>Tipo</th><th>Dias</th><th>ES modificado</th><th>Ver</th><th>Accion</th>' +
                    '</tr></thead><tbody>' + rows + '</tbody></table>'
                );
            },
            error: function () {
                $container.html('<p class="rsa-bot-log-empty">Error de conexion.</p>');
            },
        });
    }

    /* ── Reload translations button ── */
    $('#rsa-bot-reload-translations').on('click', function () {
        loadTranslations();
    });

    /* ── Sync single post ── */
    $(document).on('click', '.rsa-sync-post-btn', function () {
        var $btn   = $(this);
        var esId   = $btn.data('es');
        var enId   = $btn.data('en');
        var title  = $btn.data('title');

        console.log('[RSA Translation] Click sync:', {es: esId, en: enId, title: title});

        if (!confirm('Sincronizar "' + title + '"?\n\nSe copiara la estructura Elementor/HTML desde el espanol y se traducira el contenido al ingles con IA. El proceso puede tardar 10-30 segundos.')) return;

        $btn.prop('disabled', true).text('Sincronizando...');

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action: 'rsa_translation_sync_post',
                _nonce: rsaAjax.nonce,
                es_id: esId,
                en_id: enId,
            },
            timeout: 180000,
            success: function (resp) {
                console.log('[RSA Translation] Sync response:', resp);
                if (resp.success) {
                    $btn.text('Sincronizado').css('color', '#00a32a');
                    botNotice('success', 'Sincronizado "' + title + '": ' + (resp.data.message || ''));
                    // Reload list after 2 seconds
                    setTimeout(loadTranslations, 2000);
                } else {
                    $btn.prop('disabled', false).text('Sincronizar con IA');
                    var errMsg = (typeof resp.data === 'string') ? resp.data : (resp.data && resp.data.message ? resp.data.message : 'Error desconocido');
                    console.error('[RSA Translation] Error:', errMsg);
                    botNotice('error', 'Error al sincronizar "' + title + '": ' + errMsg);
                }
            },
            error: function (xhr, status, err) {
                console.error('[RSA Translation] AJAX error:', status, err, xhr.responseText);
                $btn.prop('disabled', false).text('Sincronizar con IA');
                botNotice('error', 'Error de conexion al sincronizar (' + status + ').');
            },
        });
    });

    /* ── Auto-load translations if bot tab is initially active ── */
    if ($('#rsa-tab-bot').is(':visible')) {
        loadTranslationsOnce();
    }

})(jQuery);

/* ── History Chart ── */
(function () {
    'use strict';
    var canvas = document.getElementById('rsa-history-chart');
    if (!canvas || typeof Chart === 'undefined' || !window.rsaHistory || !rsaHistory.length) return;

    var labels = rsaHistory.map(function (e) {
        return e.timestamp ? e.timestamp.substring(5, 16) : '';
    });

    new Chart(canvas, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                { label: 'Global', data: rsaHistory.map(function (e) { return e.global_score; }),   borderColor: '#2563eb', tension: 0.3, fill: false },
                { label: 'CF',     data: rsaHistory.map(function (e) { return e.cf_score   || 0; }), borderColor: '#f97316', tension: 0.3, fill: false },
                { label: 'SEO',    data: rsaHistory.map(function (e) { return e.seo_score  || 0; }), borderColor: '#16a34a', tension: 0.3, fill: false },
                { label: 'Perf',   data: rsaHistory.map(function (e) { return e.perf_score || 0; }), borderColor: '#9333ea', tension: 0.3, fill: false }
            ]
        },
        options: {
            responsive: true,
            scales: { y: { min: 0, max: 100 } },
            plugins: { legend: { position: 'bottom' } }
        }
    });
})();

/* ══════════════════════════════════════════════════
 *  Agente SEO — JS handlers
 * ══════════════════════════════════════════════════ */
(function ($) {
    'use strict';

    var ANALYSIS_LABELS = {
        quick_wins:   'Oportunidades rápidas (posiciones 8-20)',
        content_plan: 'Plan de contenido y nuevos nichos',
        competitors:  'Análisis de competidores y gaps',
        page_audit:   'Auditoría de páginas con decaimiento',
        meta_titles:  'Mejoras de meta titles y descriptions',
        interlinking: 'Estrategia de enlazado interno',
        image_audit:  'Auditoría de imágenes y alt texts'
    };

    /* ── Guardar credenciales GSC ── */
    $('#rsa-gsc-save-creds').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Guardando…');

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action:             'rsa_seo_save_settings',
                _nonce:             rsaAjax.nonce,
                section:            'gsc',
                gsc_client_id:      $('#gsc_client_id').val(),
                gsc_client_secret:  $('#gsc_client_secret').val()
            },
            success: function (resp) {
                $btn.prop('disabled', false).text('Guardar credenciales');
                if (resp.success) {
                    seoNotice('success', resp.data.message + ' Ahora haz clic en "Conectar con Google".');
                    // Show auth button without full reload
                    setTimeout(function () { window.location.reload(); }, 1500);
                } else {
                    seoNotice('error', resp.data || 'Error al guardar.');
                }
            },
            error: function () {
                $btn.prop('disabled', false).text('Guardar credenciales');
                seoNotice('error', 'Error de conexión.');
            }
        });
    });

    /* ── Desconectar GSC ── */
    $('#rsa-gsc-disconnect').on('click', function () {
        if (!confirm('¿Desconectar Google Search Console? Se eliminarán los tokens de acceso.')) return;

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_seo_disconnect_gsc', _nonce: rsaAjax.nonce },
            success: function (resp) {
                if (resp.success) window.location.reload();
                else seoNotice('error', resp.data || 'Error al desconectar.');
            }
        });
    });

    /* ── Cargar propiedades GSC ── */
    if ($('#rsa-gsc-site-select').length) {
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_seo_list_sites', _nonce: rsaAjax.nonce },
            success: function (resp) {
                if (!resp.success) return;
                var $sel = $('#rsa-gsc-site-select');
                var selectedVal = $sel.data('selected') || $sel.find('option:first').val();
                $sel.empty();
                $.each(resp.data, function (i, site) {
                    var url = site.siteUrl || '';
                    var selected = (url === selectedVal) ? ' selected' : '';
                    $sel.append('<option value="' + url + '"' + selected + '>' + url + '</option>');
                });
            }
        });
    }

    /* ── Guardar propiedad GSC activa ── */
    $('#rsa-gsc-save-site').on('click', function () {
        var $btn = $(this);
        var siteUrl = $('#rsa-gsc-site-select').val();
        if (!siteUrl) return;

        $btn.prop('disabled', true).text('Guardando…');
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_seo_save_settings', _nonce: rsaAjax.nonce, section: 'gsc_site', gsc_site_url: siteUrl },
            success: function (resp) {
                $btn.prop('disabled', false).text('Confirmar');
                if (resp.success) {
                    seoNotice('success', resp.data.message);
                    loadGscData();
                } else {
                    seoNotice('error', resp.data || 'Error.');
                }
            }
        });
    });

    /* ── Guardar DataForSEO ── */
    $('#rsa-dfs-save').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Guardando…');
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action:       'rsa_seo_save_settings',
                _nonce:       rsaAjax.nonce,
                section:      'dataforseo',
                dfs_login:    $('#dfs_login').val(),
                dfs_password: $('#dfs_password').val()
            },
            success: function (resp) {
                $btn.prop('disabled', false).text('Guardar');
                if (resp.success) seoNotice('success', resp.data.message);
                else seoNotice('error', resp.data || 'Error.');
            }
        });
    });

    /* ── Guardar Claude API Key ── */
    $('#rsa-claude-save').on('click', function () {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Guardando…');
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action:         'rsa_seo_save_settings',
                _nonce:         rsaAjax.nonce,
                section:        'claude',
                claude_api_key: $('#claude_api_key').val()
            },
            success: function (resp) {
                $btn.prop('disabled', false).text('Guardar');
                if (resp.success) {
                    seoNotice('success', resp.data.message);
                    setTimeout(function () { window.location.reload(); }, 1500);
                } else {
                    seoNotice('error', resp.data || 'Error.');
                }
            }
        });
    });

    /* ── Guardar PSI API Key ── */
    $('#rsa-psi-save').on('click', function () {
        var $btn = $(this);
        var $msg = $('#rsa-psi-msg');
        var key  = $('#psi_api_key').val().trim();
        $btn.prop('disabled', true).text('Guardando…');
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action:      'rsa_seo_save_settings',
                _nonce:      rsaAjax.nonce,
                section:     'psi',
                psi_api_key: key
            },
            success: function (resp) {
                $btn.prop('disabled', false).text('Guardar');
                if (resp.success) {
                    $msg.text(resp.data.message).css('color', '#059669').show();
                    setTimeout(function () { $msg.fadeOut(); }, 4000);
                } else {
                    $msg.text(resp.data || 'Error.').css('color', '#dc2626').show();
                }
            },
            error: function () {
                $btn.prop('disabled', false).text('Guardar');
                $msg.text('Error de conexión.').css('color', '#dc2626').show();
            }
        });
    });

    /* ── Guardar clave OpenAI ── */
    $('#rsa-openai-save').on('click', function () {
        var $btn = $(this);
        var key  = $('#openai_api_key').val().trim();
        if (!key) {
            seoNotice('error', 'Introduce una API Key de OpenAI antes de guardar.');
            return;
        }
        $btn.prop('disabled', true).text('Guardando…');
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: {
                action:         'rsa_seo_save_settings',
                _nonce:         rsaAjax.nonce,
                section:        'openai',
                openai_api_key: key
            },
            success: function (resp) {
                $btn.prop('disabled', false).text('Guardar');
                if (resp.success) {
                    seoNotice('success', resp.data.message);
                    setTimeout(function () { window.location.reload(); }, 1500);
                } else {
                    seoNotice('error', resp.data || 'Error al guardar.');
                }
            },
            error: function () {
                $btn.prop('disabled', false).text('Guardar');
                seoNotice('error', 'Error de conexión al guardar la clave OpenAI.');
            }
        });
    });

    /* ── Actualizar métricas GSC ── */
    $('#rsa-refresh-gsc').on('click', function () {
        loadGscData();
    });

    /* Auto-cargar datos GSC al entrar en la pestaña ── */
    if ($('#rsa-gsc-dashboard').length) {
        loadGscData();
    }

    function loadGscData() {
        $('#rsa-gsc-metrics').addClass('rsa-gsc-loading');
        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_seo_fetch_gsc_data', _nonce: rsaAjax.nonce },
            timeout: 60000,
            success: function (resp) {
                $('#rsa-gsc-metrics').removeClass('rsa-gsc-loading');
                if (!resp.success) { seoNotice('error', resp.data || 'Error GSC.'); return; }

                var d = resp.data;
                var perf = d.performance || {};
                var r = perf.recent || {};
                var delta = perf.delta || {};

                setText('#gsc-clicks',       r.clicks      !== undefined ? r.clicks.toLocaleString()      : '—');
                setText('#gsc-impressions',  r.impressions !== undefined ? r.impressions.toLocaleString() : '—');
                setText('#gsc-ctr',          r.ctr         !== undefined ? r.ctr + '%'                    : '—');
                setText('#gsc-position',     r.position    !== undefined ? r.position                     : '—');
                setText('#gsc-quick-count',  d.quick_count   !== undefined ? d.quick_count   : '—');
                setText('#gsc-decaying-count', d.decaying_count !== undefined ? d.decaying_count : '—');

                setDelta('#gsc-clicks-delta',      delta.clicks);
                setDelta('#gsc-impressions-delta', delta.impressions);
                setDelta('#gsc-position-delta',    delta.position, true);  // invertido: bajar posición = bueno
            },
            error: function () {
                $('#rsa-gsc-metrics').removeClass('rsa-gsc-loading');
                seoNotice('error', 'Error al cargar datos GSC.');
            }
        });
    }

    function setText(sel, val) {
        $(sel).text(val);
    }

    function setDelta(sel, val, invert) {
        if (val === undefined || val === null) return;
        var good = invert ? val <= 0 : val >= 0;
        var sign = val >= 0 ? '+' : '';
        $(sel).text(sign + val + '%').css('color', good ? '#00a32a' : '#c02b0a');
    }

    /* ── Lanzar análisis de Claude ── */
    $(document).on('click', '.rsa-run-analysis', function () {
        var type    = $(this).data('type');
        var label   = ANALYSIS_LABELS[type] || type;
        var $result = $('#rsa-analysis-result');
        var $loading = $('#rsa-analysis-loading');
        var canPropose = ['quick_wins', 'meta_titles', 'page_audit', 'interlinking', 'content_plan', 'image_audit'].indexOf(type) !== -1;

        $result.hide();
        $loading.fadeIn(200);
        $('html, body').animate({ scrollTop: $loading.offset().top - 80 }, 400);

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_seo_analyze', _nonce: rsaAjax.nonce, analysis_type: type },
            timeout: 180000,
            success: function (resp) {
                $loading.fadeOut(200);
                if (!resp.success) {
                    seoNotice('error', resp.data || 'Error en el análisis.');
                    return;
                }

                var markdown = resp.data.markdown || '';
                $('#rsa-analysis-title').text(label);
                $('#rsa-analysis-content').html(renderMarkdown(markdown));

                // Wire the "Añadir al Autopilot" button to the current analysis type
                var $apBtn = $('#rsa-analysis-to-autopilot');
                $apBtn.data('type', type).attr('data-type', type);
                $apBtn.toggle(canPropose);
                $('#rsa-analysis-to-autopilot-result').hide().text('');

                $result.fadeIn(300);
                $('html, body').animate({ scrollTop: $result.offset().top - 80 }, 400);

                // Actualizar la fecha del análisis en la card y mostrar botón → Autopilot
                $('[data-type="' + type + '"] .rsa-agent-last-run').text('Hace un momento');
                if (canPropose) {
                    var $cardBtns = $('[data-type="' + type + '"] .rsa-agent-card-btns');
                    if (!$cardBtns.find('.rsa-card-to-autopilot').length) {
                        $cardBtns.append(
                            '<button class="button rsa-generate-proposals rsa-card-to-autopilot" data-type="' + type + '" title="Generar propuestas ejecutables">' +
                            '→ Autopilot</button>'
                        );
                    }
                }
            },
            error: function (xhr) {
                $loading.fadeOut(200);
                var msg = 'Error de conexión.';
                try { msg = JSON.parse(xhr.responseText).data || msg; } catch (e) {}
                seoNotice('error', msg);
            }
        });
    });

    /* ── Copiar análisis ── */
    $('#rsa-analysis-copy').on('click', function () {
        var text = $('#rsa-analysis-content').text();
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function () {
                seoNotice('success', 'Análisis copiado al portapapeles.');
            });
        }
    });

    /* ── Cerrar panel de resultado ── */
    $('#rsa-analysis-close').on('click', function () {
        $('#rsa-analysis-result').fadeOut(200);
    });

    /* ── Render análisis guardados (acordeón) ── */
    /* NOTA: el evento 'toggle' de <details> no burbujea, no sirve delegación jQuery */
    document.querySelectorAll('.rsa-analysis-saved-item').forEach(function (el) {
        el.addEventListener('toggle', function () {
            var $content = $(el).find('.rsa-analysis-saved-content');
            if (el.open && $content.html().trim() === '') {
                var md = $content.data('markdown');
                if (md) $content.html(renderMarkdown(md));
            }
        });
    });

    /* ── Markdown renderer básico ── */
    function renderMarkdown(md) {
        if (!md) return '';

        // Escapar HTML
        md = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

        // Bloques de código (antes de procesar inline)
        md = md.replace(/```[\s\S]*?```/g, function (block) {
            var code = block.replace(/^```[^\n]*\n?/, '').replace(/```$/, '');
            return '<pre class="rsa-code-block"><code>' + code + '</code></pre>';
        });

        // Encabezados
        md = md.replace(/^### (.+)$/gm, '<h3>$1</h3>');
        md = md.replace(/^## (.+)$/gm,  '<h2>$1</h2>');
        md = md.replace(/^# (.+)$/gm,   '<h1>$1</h1>');

        // Negrita e itálica
        md = md.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
        md = md.replace(/\*\*(.+?)\*\*/g,      '<strong>$1</strong>');
        md = md.replace(/__(.+?)__/g,           '<strong>$1</strong>');
        md = md.replace(/\*(.+?)\*/g,           '<em>$1</em>');

        // Inline code
        md = md.replace(/`([^`]+)`/g, '<code>$1</code>');

        // Tablas
        md = md.replace(/(\|.+\|\n)(\|[-: |]+\|\n)((\|.+\|\n?)+)/g, function (match, header, sep, body) {
            var headerCells = header.trim().split('|').filter(function (c) { return c.trim(); });
            var headerHtml  = '<thead><tr>' + headerCells.map(function (c) { return '<th>' + c.trim() + '</th>'; }).join('') + '</tr></thead>';
            var bodyRows    = body.trim().split('\n').filter(Boolean).map(function (row) {
                var cells = row.split('|').filter(function (c, i, arr) { return i > 0 && i < arr.length - 1; });
                return '<tr>' + cells.map(function (c) { return '<td>' + c.trim() + '</td>'; }).join('') + '</tr>';
            }).join('');
            return '<table class="rsa-analysis-table"><colgroup></colgroup>' + headerHtml + '<tbody>' + bodyRows + '</tbody></table>';
        });

        // Listas sin ordenar
        md = md.replace(/(^[-*] .+\n?)+/gm, function (block) {
            var items = block.trim().split('\n').map(function (line) {
                return '<li>' + line.replace(/^[-*] /, '') + '</li>';
            }).join('');
            return '<ul>' + items + '</ul>';
        });

        // Listas ordenadas
        md = md.replace(/(^\d+\. .+\n?)+/gm, function (block) {
            var items = block.trim().split('\n').map(function (line) {
                return '<li>' + line.replace(/^\d+\. /, '') + '</li>';
            }).join('');
            return '<ol>' + items + '</ol>';
        });

        // Líneas horizontales
        md = md.replace(/^---+$/gm, '<hr>');

        // Párrafos (líneas que no son ya etiquetas HTML)
        var lines = md.split('\n');
        var output = [];
        lines.forEach(function (line) {
            if (line.trim() === '') {
                output.push('');
            } else if (/^<[h1-6|ul|ol|li|table|pre|hr|thead|tbody|tr]/.test(line.trim())) {
                output.push(line);
            } else {
                output.push('<p>' + line + '</p>');
            }
        });

        return output.join('\n');
    }

    /* ── Generar propuestas ejecutables (análisis guardado, card secundaria, y panel en vivo) ── */
    $(document).on('click', '.rsa-generate-proposals', function () {
        var $btn  = $(this);
        var type  = $btn.data('type');
        // Support: sibling span (saved accordion), panel footer span (live result), or card sibling
        var $res  = $btn.siblings('.rsa-proposals-result').length
            ? $btn.siblings('.rsa-proposals-result')
            : $('#rsa-analysis-to-autopilot-result');

        var origHtml = $btn.html();
        $btn.prop('disabled', true).text('Generando…');
        $res.hide();

        $.ajax({
            url: rsaAjax.url,
            method: 'POST',
            data: { action: 'rsa_seo_generate_proposals', _nonce: rsaAjax.nonce, analysis_type: type },
            timeout: 120000,
            success: function (resp) {
                $btn.prop('disabled', false).html(origHtml);
                if (resp.success) {
                    var autopilotUrl = '?page=replanta-site-audit&rsa_tab=seo#rsa-autopilot';
                    $res.html(resp.data.message + ' <a href="' + autopilotUrl + '">Ver Autopilot →</a>')
                        .css('color', '#059669').show();
                    if (resp.data.count > 0) {
                        setTimeout(function () {
                            window.location.href = autopilotUrl;
                        }, 1800);
                    }
                } else {
                    $res.text(resp.data.message || 'Error desconocido.').css('color', '#dc2626').show();
                }
            },
            error: function () {
                $btn.prop('disabled', false).html(origHtml);
                $res.text('Error de conexión.').css('color', '#dc2626').show();
            }
        });
    });

    /* ── Notificaciones SEO ── */
    function seoNotice(type, msg) {
        var cls     = type === 'success' ? 'notice-success' : type === 'error' ? 'notice-error' : 'notice-info';
        var $notice = $('<div class="notice ' + cls + ' is-dismissible rsa-seo-notice-msg" style="margin:10px 0"><p>' + msg + '</p></div>');
        // Target the currently visible tab so notices appear where the user is looking
        var $target = $('.rsa-tab-content:visible').first();
        if (!$target.length) { $target = $('.rsa-seo-tab'); }
        $target.prepend($notice);
        setTimeout(function () { $notice.fadeOut(400, function () { $(this).remove(); }); }, type === 'error' ? 12000 : 5000);
    }

})(jQuery);

/* ════════════════════════════════════════════════════════════════
 * SEO AUTOPILOT — Proposals UI
 * ════════════════════════════════════════════════════════════════ */
(function ($) {
    'use strict';

    if (!$('#rsa-autopilot').length) return;

    var $section = $('#rsa-autopilot');
    var nonce    = typeof rsaAjax !== 'undefined' ? rsaAjax.nonce : '';
    var ajaxUrl  = typeof rsaAjax !== 'undefined' ? rsaAjax.url : (typeof ajaxurl !== 'undefined' ? ajaxurl : '');

    /* ── Capture-now button ── */
    $section.on('click', '#rsa-autopilot-capture-now', function () {
        var $btn = $(this).prop('disabled', true).text('Programando...');
        $.post(ajaxUrl, { action: 'rsa_autopilot_run_now', _nonce: nonce })
            .done(function (res) {
                if (res.success) {
                    apNotice('success', res.data.message);
                    setTimeout(pollProposals, 90000);
                } else {
                    apNotice('error', res.data || 'Error al programar captura.');
                }
            })
            .fail(function () { apNotice('error', 'Error de conexión.'); })
            .always(function () { $btn.prop('disabled', false).text('Capturar ahora'); });
    });

    /* ── Individual approve / reject ── */
    $section.on('click', '.rsa-ap-approve', function () {
        var id   = parseInt($(this).data('id'), 10);
        var $row = $(this).closest('tr');
        apDecide(id, 'approve', $row);
    });

    $section.on('click', '.rsa-ap-reject', function () {
        var id   = parseInt($(this).data('id'), 10);
        var $row = $(this).closest('tr');
        apDecide(id, 'reject', $row);
    });

    /* ── Checkbox selection ── */
    $section.on('change', '.rsa-ap-check', updateSelection);
    $section.on('change', '#rsa-ap-select-all', function () {
        $section.find('.rsa-ap-check').prop('checked', this.checked);
        updateSelection();
    });

    function updateSelection() {
        var ids = getCheckedIds();
        $('#rsa-ap-approve-selected, #rsa-ap-reject-selected').prop('disabled', ids.length === 0);
        var $cnt = $('#rsa-ap-sel-count');
        if (ids.length) {
            $cnt.text(ids.length + ' seleccionadas').show();
        } else {
            $cnt.text('').hide();
        }
    }

    function getCheckedIds() {
        return $section.find('.rsa-ap-check:checked').map(function () {
            return parseInt($(this).val(), 10);
        }).get();
    }

    /* ── Bulk decide ── */
    $section.on('click', '#rsa-ap-approve-selected', function () {
        var ids = getCheckedIds();
        if (!ids.length) return;
        if (!confirm('¿Aprobar y aplicar ' + ids.length + ' propuesta(s)?')) return;
        apBulkDecide(ids, 'approve');
    });

    $section.on('click', '#rsa-ap-reject-selected', function () {
        var ids = getCheckedIds();
        if (!ids.length) return;
        if (!confirm('¿Rechazar ' + ids.length + ' propuesta(s)?')) return;
        apBulkDecide(ids, 'reject');
    });

    /* ── Decision: single ── */
    function apDecide(id, decision, $row) {
        var $btns = $row.find('button').prop('disabled', true);
        $row.addClass('rsa-ap-row-loading');

        $.post(ajaxUrl, {
            action:      'rsa_autopilot_decide',
            _nonce:      nonce,
            proposal_id: id,
            decision:    decision
        })
        .done(function (res) {
            if (res && res.success) {
                var status = res.data.status;
                var labels = { applied: 'Aplicado', rejected: 'Rechazado', failed: 'Falló' };
                $row.find('.rsa-proposal-actions').html(
                    '<span class="rsa-ap-status-' + status + '">' + (labels[status] || status) + '</span>'
                );
                $row.removeClass('rsa-ap-row-loading').addClass('rsa-ap-row-done');
                updatePendingCount(-1);
                if (status === 'applied' && res.data.message) {
                    apNotice('success', res.data.message);
                }
            } else {
                // If res is a string, PHP output a fatal/notice before JSON — strip tags to show plaintext
                var msg = (res && typeof res === 'object')
                    ? (res.data || 'Error al procesar.')
                    : (typeof res === 'string' ? res.replace(/<[^>]+>/g, '').substring(0, 300) : 'Error al procesar.');
                apNotice('error', msg);
                $row.removeClass('rsa-ap-row-loading');
                $btns.prop('disabled', false);
            }
        })
        .fail(function () {
            apNotice('error', 'Error de conexión.');
            $row.removeClass('rsa-ap-row-loading');
            $btns.prop('disabled', false);
        });
    }

    /* ── Decision: bulk ── */
    function apBulkDecide(ids, decision) {
        $('#rsa-ap-approve-selected, #rsa-ap-reject-selected').prop('disabled', true);

        $.post(ajaxUrl, {
            action:   'rsa_autopilot_bulk_decide',
            _nonce:   nonce,
            ids:      ids,
            decision: decision
        })
        .done(function (res) {
            if (res.success) {
                apNotice('success', res.data.message);
                ids.forEach(function (id) {
                    $section.find('.rsa-proposal-row[data-id="' + id + '"]').fadeOut(300, function () {
                        $(this).remove();
                    });
                    updatePendingCount(-1);
                });
                $('#rsa-ap-select-all').prop('checked', false);
                updateSelection();
            } else {
                apNotice('error', res.data || 'Error en operación masiva.');
                $('#rsa-ap-approve-selected, #rsa-ap-reject-selected').prop('disabled', false);
            }
        })
        .fail(function () {
            apNotice('error', 'Error de conexión.');
            $('#rsa-ap-approve-selected, #rsa-ap-reject-selected').prop('disabled', false);
        });
    }

    /* ── Badge counter ── */
    function updatePendingCount(delta) {
        var $badge = $section.find('.rsa-tab-badge');
        var $stat  = $section.find('.rsa-ap-stat-pending strong');
        var cur    = parseInt($badge.text(), 10) || 0;
        var next   = Math.max(0, cur + delta);
        $badge.text(next);
        $stat.text(next);
        if (next === 0) { $badge.hide(); }
    }

    /* ── Poll after manual capture ── */
    function pollProposals() {
        $.post(ajaxUrl, { action: 'rsa_autopilot_get_proposals', _nonce: nonce })
            .done(function (res) {
                if (res.success && res.data.counts && res.data.counts.pending > 0) {
                    apNotice('info', 'Nuevas propuestas disponibles. Recarga la página para verlas.');
                }
            });
    }

    /* ── Diff inline toggle ── */
    $section.on('click', '.rsa-ap-diff-toggle', function () {
        var id   = $(this).data('id');
        var $row = $('#rsa-diff-' + id);
        var open = $row.is(':visible');
        $row.toggle(!open);
        $(this).html(open ? '<i class="ph ph-eye"></i>' : '<i class="ph ph-x"></i>').attr('title', open ? 'Ver cambio completo' : 'Cerrar');
    });

    /* ── Rollback applied change ── */
    $section.on('click', '.rsa-ap-rollback', function () {
        var id   = $(this).data('id');
        var $btn = $(this);
        var $row = $(this).closest('tr');

        if ( ! confirm('¿Revertir este cambio? Se restaurará el valor anterior en RankMath.') ) {
            return;
        }

        $btn.prop('disabled', true).text('...');

        $.post(ajaxUrl, {
            action:      'rsa_autopilot_rollback',
            _nonce:      nonce,
            proposal_id: id
        })
        .done(function (res) {
            if (res.success) {
                apNotice('success', 'Revertido: ' + res.data.message);
                $btn.replaceWith('<span style="color:#6b7280;font-size:12px">Revertido</span>');
                $row.addClass('rsa-ap-row-done');
            } else {
                apNotice('error', res.data || 'Error al revertir.');
                $btn.prop('disabled', false).html('<i class="ph ph-arrow-counter-clockwise"></i>');
            }
        })
        .fail(function () {
            apNotice('error', 'Error de conexión al revertir.');
            $btn.prop('disabled', false).html('<i class="ph ph-arrow-counter-clockwise"></i>');
        });
    });

    /* ── URL filter ── */
    $section.on('input', '#rsa-ap-url-filter', function () {
        var q = $(this).val().toLowerCase().trim();
        var $rows = $section.find('.rsa-proposal-row');
        var shown = 0;
        $rows.each(function () {
            var url = $(this).find('.rsa-proposal-url').text().toLowerCase();
            var visible = !q || url.indexOf(q) !== -1;
            $(this).toggle(visible);
            if (visible) shown++;
        });
        var $cnt = $('#rsa-ap-filter-count');
        $cnt.text(q ? shown + ' resultado' + (shown === 1 ? '' : 's') : '');
    });

    /* ── Inline notice ── */
    function apNotice(type, msg) {
        var cls = type === 'success' ? 'notice-success' : type === 'error' ? 'notice-error' : 'notice-info';
        var $n  = $('<div class="notice ' + cls + ' is-dismissible" style="margin:8px 0"><p>' + msg + '</p></div>');
        $section.find('.rsa-ap-header').after($n);
        if (type !== 'error') {
            setTimeout(function () { $n.fadeOut(400, function () { $(this).remove(); }); }, 5000);
        }
    }

})(jQuery);

/* ════════════════════════════════════════════════════════════════
 * SERP Sparklines — micro position-history charts in applied table
 * ════════════════════════════════════════════════════════════════ */
(function () {
    'use strict';

    if (typeof Chart === 'undefined') return;

    document.querySelectorAll('canvas.rsa-sparkline').forEach(function (canvas) {
        var raw = canvas.getAttribute('data-history');
        if (!raw) return;

        var data;
        try { data = JSON.parse(raw); } catch (e) { return; }

        var positions = data.positions || [];
        if (!positions.length) return;

        new Chart(canvas, {
            type: 'line',
            data: {
                labels:   data.labels || positions.map(function (_, i) { return i + 1; }),
                datasets: [{
                    data:        positions,
                    borderColor: '#2563eb',
                    borderWidth: 1.5,
                    pointRadius: 0,
                    fill:        false,
                    tension:     0.3,
                }]
            },
            options: {
                responsive: false,
                animation:  false,
                plugins: {
                    legend:  { display: false },
                    tooltip: { enabled: false }
                },
                scales: {
                    x: { display: false },
                    y: {
                        display: false,
                        reverse: true  // lower position number = better = higher on chart
                    }
                }
            }
        });
    });
})();
