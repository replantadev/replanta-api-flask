<?php
/**
 * Plugin Dependencies Manager
 *
 * Documenta y verifica todas las dependencias inter-plugin de Replanta Site Audit.
 * Centraliza la lógica de detección para que no esté dispersa por el código.
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  MAPA DE DEPENDENCIAS INTER-PLUGIN                                      │
 * ├────────────────────────────┬───────────────┬────────────────────────────┤
 * │ Plugin requerido           │ Tipo          │ Qué habilita               │
 * ├────────────────────────────┼───────────────┼────────────────────────────┤
 * │ Dominios Reseller          │ soft (CF)     │ CF Audit, CF Auto-Fix,     │
 * │                            │               │ CF Cache Rules, Hit Ratio  │
 * ├────────────────────────────┼───────────────┼────────────────────────────┤
 * │ Polylang                   │ soft (i18n)   │ Hreflang sitemap check,    │
 * │                            │               │ Translation Sync           │
 * ├────────────────────────────┼───────────────┼────────────────────────────┤
 * │ RankMath SEO               │ soft (SEO)    │ Meta tags, Schema, robots, │
 * │                            │               │ Sitemap XML checks         │
 * ├────────────────────────────┼───────────────┼────────────────────────────┤
 * │ replanta-sitemap-hreflang  │ soft (hreflan)│ Inyección xhtml:link en   │
 * │                            │               │ sitemap, auto-activate fix │
 * ├────────────────────────────┼───────────────┼────────────────────────────┤
 * │ LiteSpeed Cache            │ soft (perf)   │ Object Cache deep check,   │
 * │                            │               │ Critical CSS check         │
 * └────────────────────────────┴───────────────┴────────────────────────────┘
 *
 * Todas las dependencias son SOFT (opcionales): el plugin funciona sin ellas,
 * pero ciertas comprobaciones o auto-fixes quedan deshabilitados.
 * No hay dependencias HARD (el plugin nunca fallará por su ausencia).
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 * @since   2.6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * RSA_Dependencies
 *
 * Comprueba el estado de todas las dependencias opcionales y las expone
 * para el panel de administración y para la lógica interna del plugin.
 */
final class RSA_Dependencies {

    // ── Slugs canónicos de las dependencias ─────────────────────────────────
    const DEP_DOMINIOS_RESELLER      = 'dominios-reseller';
    const DEP_POLYLANG               = 'polylang';
    const DEP_RANK_MATH              = 'seo-by-rank-math';
    const DEP_SITEMAP_HREFLANG       = 'replanta-sitemap-hreflang';
    const DEP_LITESPEED_CACHE        = 'litespeed-cache';

    // ── No se permiten instancias ────────────────────────────────────────────
    private function __construct() {}
    private function __clone() {}

    // ── API pública ──────────────────────────────────────────────────────────

    /**
     * Devuelve el estado completo de todas las dependencias.
     *
     * @return array[]  Array indexado por slug, cada ítem:
     *   - name   (string)   : Nombre legible
     *   - slug   (string)   : Slug del plugin
     *   - type   (string)   : 'soft'|'hard'
     *   - scope  (string)   : Descripción de qué habilita
     *   - active (bool)     : ¿Está activo?
     *   - configured (bool) : ¿Activo Y correctamente configurado?
     *   - note   (string)   : Mensaje de estado corto
     *   - css    (string)   : Clase CSS para el panel (rsa-dep-ok|rsa-dep-warning|rsa-dep-missing)
     */
    public static function get_all(): array {
        return [
            self::DEP_DOMINIOS_RESELLER => self::check_dominios_reseller(),
            self::DEP_POLYLANG          => self::check_polylang(),
            self::DEP_RANK_MATH         => self::check_rank_math(),
            self::DEP_SITEMAP_HREFLANG  => self::check_sitemap_hreflang(),
            self::DEP_LITESPEED_CACHE   => self::check_litespeed_cache(),
        ];
    }

    /**
     * ¿Está activa y configurada una dependencia concreta?
     *
     * @param string $slug  Una de las constantes DEP_*
     */
    public static function is_ready( string $slug ): bool {
        $all = self::get_all();
        return $all[ $slug ]['configured'] ?? false;
    }

    /**
     * Devuelve cuántas dependencias están activas y configuradas.
     */
    public static function ready_count(): int {
        return count( array_filter( self::get_all(), fn( $d ) => $d['configured'] ) );
    }

    /**
     * Renderiza el panel HTML de dependencias (para el tab de Dependencias).
     */
    public static function render_panel(): void {
        $deps = self::get_all();
        ?>
        <div class="rsa-deps-panel">
            <h2 style="margin-top:0">
                <span class="dashicons dashicons-admin-plugins" style="font-size:22px;vertical-align:middle;margin-right:6px;"></span>
                Dependencias inter-plugin
            </h2>
            <p style="color:#666;margin-bottom:20px">
                Replanta Site Audit funciona sin ninguno de estos plugins, pero ciertas 
                comprobaciones y auto-fixes solo están disponibles cuando la dependencia 
                correspondiente está activa y configurada.
            </p>

            <table class="wp-list-table widefat fixed striped rsa-deps-table">
                <thead>
                    <tr>
                        <th style="width:200px">Plugin</th>
                        <th style="width:100px">Estado</th>
                        <th>Qué habilita</th>
                        <th style="width:160px">Nota</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $deps as $dep ) : ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html( $dep['name'] ); ?></strong><br>
                            <small style="color:#888"><?php echo esc_html( $dep['slug'] ); ?></small>
                        </td>
                        <td>
                            <span class="rsa-dep-badge <?php echo esc_attr( $dep['css'] ); ?>">
                                <?php echo $dep['configured'] ? '<i class="ph ph-check-circle"></i> OK' : ( $dep['active'] ? '<i class="ph ph-warning"></i> Config' : '<i class="ph ph-x-circle"></i> Inactivo' ); ?>
                            </span>
                        </td>
                        <td style="font-size:13px;color:#444"><?php echo esc_html( $dep['scope'] ); ?></td>
                        <td style="font-size:12px;color:#666"><?php echo esc_html( $dep['note'] ); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php
            // Aviso especial para Dominios Reseller (más importante)
            $dr = $deps[ self::DEP_DOMINIOS_RESELLER ];
            if ( ! $dr['active'] ) : ?>
                <div class="notice notice-warning inline" style="margin-top:16px">
                    <p>
                        <strong>Cloudflare deshabilitado:</strong>
                        Instala y activa el plugin <em>Dominios Reseller</em> y configura
                        tu token de API de Cloudflare para habilitar la auditoría y auto-fix CF.
                    </p>
                </div>
            <?php elseif ( ! $dr['configured'] ) :
                $dr_settings_url = admin_url( 'admin.php?page=dominios-reseller' );
            ?>
                <div class="notice notice-warning inline" style="margin-top:16px">
                    <p>
                        <strong>Token CF no configurado:</strong>
                        Ve a
                        <a href="<?php echo esc_url( $dr_settings_url ); ?>" target="_blank">
                            Dominios Reseller → pestaña <em>Configuración</em> → sección <em>Cloudflare</em>
                        </a>
                        e introduce tu <strong>API Token</strong> de Cloudflare.
                        El campo se llama <code>cf_api_token</code> y se guarda en
                        <code>dominios_reseller_options[cf_api_token]</code>.
                    </p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    // ── Comprobaciones individuales ──────────────────────────────────────────

    private static function check_dominios_reseller(): array {
        $active     = self::plugin_active( self::DEP_DOMINIOS_RESELLER . '/dominios-reseller.php' )
                      || class_exists( 'Dominios_Reseller_Cloudflare_Service' );
        $configured = RSA_DR_Bridge::is_configured();
        $version    = $configured ? RSA_DR_Bridge::get_status()['plugin_version'] : '';

        return [
            'name'       => 'Dominios Reseller',
            'slug'       => self::DEP_DOMINIOS_RESELLER,
            'type'       => 'soft',
            'scope'      => 'CF Audit, CF Auto-Fix, Cache Rules, Hit Ratio, Zone detection',
            'active'     => $active,
            'configured' => $configured,
            'note'       => $configured
                                ? ( $version ? "v{$version} — token configurado" : 'Token configurado' )
                                : ( $active ? 'Activo, pero falta token CF' : 'Plugin no instalado' ),
            'css'        => $configured ? 'rsa-dep-ok' : ( $active ? 'rsa-dep-warning' : 'rsa-dep-missing' ),
        ];
    }

    private static function check_polylang(): array {
        $active = self::plugin_active( self::DEP_POLYLANG . '/polylang.php' )
                  || function_exists( 'pll_languages_list' )
                  || class_exists( 'Polylang' );

        return [
            'name'       => 'Polylang',
            'slug'       => self::DEP_POLYLANG,
            'type'       => 'soft',
            'scope'      => 'Detección hreflang, Translation Sync, idiomas alternos en sitemap',
            'active'     => $active,
            'configured' => $active,
            'note'       => $active ? 'Activo' : 'Inactivo (i18n deshabilitado)',
            'css'        => $active ? 'rsa-dep-ok' : 'rsa-dep-missing',
        ];
    }

    private static function check_rank_math(): array {
        $active = self::plugin_active( self::DEP_RANK_MATH . '/rank-math.php' )
                  || class_exists( 'RankMath' )
                  || function_exists( 'rank_math' );

        return [
            'name'       => 'RankMath SEO',
            'slug'       => self::DEP_RANK_MATH,
            'type'       => 'soft',
            'scope'      => 'Meta tags, Schema, robots.txt, sitemap XML, comprobaciones SEO avanzadas',
            'active'     => $active,
            'configured' => $active,
            'note'       => $active ? 'Activo' : 'Inactivo (checks SEO limitados)',
            'css'        => $active ? 'rsa-dep-ok' : 'rsa-dep-missing',
        ];
    }

    private static function check_sitemap_hreflang(): array {
        $slug  = self::DEP_SITEMAP_HREFLANG;
        $file  = "{$slug}/{$slug}.php";
        $active = self::plugin_active( $file )
                  || class_exists( 'Replanta_Sitemap_Hreflang' );

        return [
            'name'       => 'Replanta Sitemap Hreflang',
            'slug'       => $slug,
            'type'       => 'soft',
            'scope'      => 'Inyección xhtml:link hreflang en sitemap RankMath, fix auto-activar',
            'active'     => $active,
            'configured' => $active,
            'note'       => $active ? 'Activo' : 'Inactivo (check hreflang deshabilitado)',
            'css'        => $active ? 'rsa-dep-ok' : 'rsa-dep-missing',
        ];
    }

    private static function check_litespeed_cache(): array {
        $active = self::plugin_active( self::DEP_LITESPEED_CACHE . '/litespeed-cache.php' )
                  || class_exists( 'LiteSpeed_Cache' )
                  || class_exists( 'LiteSpeed\\Core' )
                  || defined( 'LSCWP_DIR' );

        return [
            'name'       => 'LiteSpeed Cache',
            'slug'       => self::DEP_LITESPEED_CACHE,
            'type'       => 'soft',
            'scope'      => 'Object Cache profundo, Critical CSS, comprobaciones de rendimiento LSCWP',
            'active'     => $active,
            'configured' => $active,
            'note'       => $active ? 'Activo' : 'Inactivo (checks LSCWP deshabilitados)',
            'css'        => $active ? 'rsa-dep-ok' : 'rsa-dep-missing',
        ];
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Comprueba si un plugin está activo sin necesitar is_plugin_active() (que
     * puede no estar disponible fuera del admin).
     */
    private static function plugin_active( string $plugin_file ): bool {
        if ( function_exists( 'is_plugin_active' ) ) {
            return is_plugin_active( $plugin_file );
        }
        $active_plugins = (array) get_option( 'active_plugins', [] );
        // Comprobación también para multisite
        if ( is_multisite() ) {
            $network_plugins = array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) );
            $active_plugins  = array_merge( $active_plugins, $network_plugins );
        }
        return in_array( $plugin_file, $active_plugins, true );
    }
}
