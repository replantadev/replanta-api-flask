<?php
/**
 * SEO Agent — Orquestador de la pestaña SEO
 *
 * Gestiona la pestaña SEO del panel de Site Audit:
 * - Configuración de integraciones (GSC OAuth2, DataForSEO, Claude)
 * - Dashboard de métricas GSC
 * - Disparadores AJAX para los distintos análisis del agente
 * - Renderizado de resultados
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RSA_SEO_Agent {

	private static ?RSA_SEO_Agent $instance = null;

	public static function get_instance(): RSA_SEO_Agent {
		return self::$instance ??= new self();
	}

	private function __construct() {
		add_action( 'wp_ajax_rsa_seo_save_settings',    [ $this, 'ajax_save_settings' ] );
		add_action( 'wp_ajax_rsa_seo_disconnect_gsc',   [ $this, 'ajax_disconnect_gsc' ] );
		add_action( 'wp_ajax_rsa_seo_fetch_gsc_data',   [ $this, 'ajax_fetch_gsc_data' ] );
		add_action( 'wp_ajax_rsa_seo_analyze',          [ $this, 'ajax_analyze' ] );
		add_action( 'wp_ajax_rsa_seo_list_sites',       [ $this, 'ajax_list_sites' ] );
		add_action( 'wp_ajax_rsa_seo_generate_proposals', [ $this, 'ajax_generate_proposals' ] );
	}

	/* ─────────── AJAX: Guardar configuración ─────────── */

	public function ajax_save_settings(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		$section = sanitize_key( $_POST['section'] ?? '' );

		if ( $section === 'gsc' ) {
			RSA_GSC_Client::get_instance()->save_credentials(
				sanitize_text_field( $_POST['gsc_client_id']     ?? '' ),
				sanitize_text_field( $_POST['gsc_client_secret'] ?? '' )
			);
			wp_send_json_success( [ 'message' => 'Credenciales GSC guardadas.' ] );
		}

		if ( $section === 'gsc_site' ) {
			$site_url = esc_url_raw( sanitize_text_field( $_POST['gsc_site_url'] ?? '' ) );
			update_option( 'rsa_gsc_selected_site', $site_url, false );
			wp_send_json_success( [ 'message' => 'Propiedad GSC guardada.' ] );
		}

		if ( $section === 'dataforseo' ) {
			RSA_DataForSEO_Client::get_instance()->save_credentials(
				sanitize_text_field( $_POST['dfs_login']    ?? '' ),
				sanitize_text_field( $_POST['dfs_password'] ?? '' )
			);
			wp_send_json_success( [ 'message' => 'Credenciales DataForSEO guardadas.' ] );
		}

		if ( $section === 'claude' ) {
			RSA_Claude_SEO_Agent::get_instance()->save_api_key(
				sanitize_text_field( $_POST['claude_api_key'] ?? '' )
			);
			wp_send_json_success( [ 'message' => 'API Key de Claude guardada.' ] );
		}

		if ( $section === 'openai' ) {
			RSA_Claude_SEO_Agent::get_instance()->save_openai_key(
				sanitize_text_field( $_POST['openai_api_key'] ?? '' )
			);
			wp_send_json_success( [ 'message' => 'API Key de OpenAI guardada.' ] );
		}

		if ( $section === 'psi' ) {
			update_option( 'rsa_psi_api_key', sanitize_text_field( $_POST['psi_api_key'] ?? '' ), false );
			wp_send_json_success( [ 'message' => 'API Key de PageSpeed Insights guardada.' ] );
		}

		wp_send_json_error( 'Sección desconocida.' );
	}

	/* ─────────── AJAX: Desconectar GSC ─────────── */

	public function ajax_disconnect_gsc(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		RSA_GSC_Client::get_instance()->disconnect();
		wp_send_json_success( [ 'message' => 'Google Search Console desconectado.' ] );
	}

	/* ─────────── AJAX: Listar sitios GSC ─────────── */

	public function ajax_list_sites(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		$sites = RSA_GSC_Client::get_instance()->list_sites();

		if ( is_wp_error( $sites ) ) {
			wp_send_json_error( $sites->get_error_message() );
		}

		wp_send_json_success( $sites );
	}

	/* ─────────── AJAX: Datos GSC (dashboard) ─────────── */

	public function ajax_fetch_gsc_data(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		$gsc      = RSA_GSC_Client::get_instance();
		$site_url = (string) get_option( 'rsa_gsc_selected_site', '' );

		if ( empty( $site_url ) ) {
			wp_send_json_error( 'No hay propiedad GSC seleccionada.' );
		}

		$perf       = $gsc->get_performance_summary( $site_url );
		$quick_wins = $gsc->get_quick_wins( $site_url );
		$decaying   = $gsc->get_decaying_pages( $site_url );

		if ( is_wp_error( $perf ) ) {
			wp_send_json_error( $perf->get_error_message() );
		}

		wp_send_json_success( [
			'performance'  => is_wp_error( $perf )       ? null  : $perf,
			'quick_wins'   => is_wp_error( $quick_wins ) ? []    : $quick_wins,
			'decaying'     => is_wp_error( $decaying )   ? []    : $decaying,
			'quick_count'  => is_wp_error( $quick_wins ) ? 0     : count( $quick_wins ),
			'decaying_count' => is_wp_error( $decaying ) ? 0     : count( $decaying ),
		] );
	}

	/* ─────────── AJAX: Lanzar análisis Claude ─────────── */

	public function ajax_analyze(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		$type = sanitize_key( $_POST['analysis_type'] ?? '' );
		if ( empty( $type ) ) {
			wp_send_json_error( 'Tipo de análisis no especificado.' );
		}

		$gsc      = RSA_GSC_Client::get_instance();
		$dfs      = RSA_DataForSEO_Client::get_instance();
		$agent    = RSA_Claude_SEO_Agent::get_instance();
		$site_url = (string) get_option( 'rsa_gsc_selected_site', '' );
		$domain   = defined( 'RSA_DOMAIN' ) ? RSA_DOMAIN : parse_url( get_site_url(), PHP_URL_HOST );

		switch ( $type ) {

			case 'quick_wins':
				$wins = $gsc->is_connected() && $site_url ? $gsc->get_quick_wins( $site_url ) : [];
				$perf = $gsc->is_connected() && $site_url ? $gsc->get_performance_summary( $site_url ) : [];

				$result = $agent->analyze_quick_wins(
					is_wp_error( $wins ) ? [] : $wins,
					is_wp_error( $perf ) ? [] : $perf
				);
				break;

			case 'content_plan':
				$kws   = $dfs->is_configured() ? $dfs->keywords_for_site( $domain ) : [];
				$ideas = $dfs->is_configured() ? $dfs->keyword_ideas( [ 'hosting sostenible', 'diseño web sostenible', 'web ecológica' ] ) : [];
				$comps = $dfs->is_configured() ? $dfs->competitors( $domain ) : [];

				$result = $agent->analyze_content_plan(
					is_wp_error( $kws )   ? [] : $kws,
					is_wp_error( $ideas ) ? [] : $ideas,
					is_wp_error( $comps ) ? [] : $comps
				);
				break;

			case 'competitors':
				$comps = $dfs->is_configured() ? $dfs->competitors( $domain ) : [];
				$our   = $dfs->is_configured() ? $dfs->domain_metrics( $domain ) : [];

				// Keyword gap con el primer competidor si hay datos
				$gap = [];
				if ( ! is_wp_error( $comps ) && ! empty( $comps[0]['domain'] ) ) {
					$gap_raw = $dfs->keyword_gap( $domain, $comps[0]['domain'] );
					$gap     = is_wp_error( $gap_raw ) ? [] : $gap_raw;
				}

				$result = $agent->analyze_competitors(
					is_wp_error( $comps ) ? [] : $comps,
					$gap,
					is_wp_error( $our ) ? [] : $our
				);
				break;

			case 'page_audit':
				$decaying = $gsc->is_connected() && $site_url ? $gsc->get_decaying_pages( $site_url ) : [];
				$result   = $agent->analyze_decaying_pages( is_wp_error( $decaying ) ? [] : $decaying );
				break;

			case 'meta_titles':
				$wins  = $gsc->is_connected() && $site_url ? $gsc->get_quick_wins( $site_url ) : [];
				$result = $agent->analyze_meta_titles( is_wp_error( $wins ) ? [] : $wins );
				break;

			case 'interlinking':
				$kws     = $dfs->is_configured() ? $dfs->keywords_for_site( $domain ) : [];
				$decaying = $gsc->is_connected() && $site_url ? $gsc->get_decaying_pages( $site_url ) : [];
				$result   = $agent->analyze_interlinking(
					is_wp_error( $kws )     ? [] : $kws,
					is_wp_error( $decaying ) ? [] : $decaying
				);
				break;

			case 'image_audit':
				$att_ids = get_posts( [
					'post_type'      => 'attachment',
					'post_mime_type' => 'image',
					'post_status'    => 'inherit',
					'posts_per_page' => 200,
					'fields'         => 'ids',
				] );

				$images_data = [];
				foreach ( $att_ids as $att_id ) {
					$alt = (string) get_post_meta( $att_id, '_wp_attachment_image_alt', true );
					if ( strlen( trim( $alt ) ) >= 10 ) {
						continue;
					}
					$att_post = get_post( $att_id );
					$parent   = $att_post ? (int) $att_post->post_parent : 0;
					$images_data[] = [
						'attachment_id' => (int) $att_id,
						'src'           => (string) wp_get_attachment_url( $att_id ),
						'alt'           => $alt,
						'page_url'      => $parent ? (string) get_permalink( $parent ) : '',
						'title'         => get_the_title( $att_id ),
					];
				}

				$result = $agent->analyze_images( $images_data );
				break;

			default:
				wp_send_json_error( "Tipo de análisis desconocido: {$type}" );
				return;
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/* ─────────── Render pestaña SEO ─────────── */

	public function render_tab(): void {
		$gsc   = RSA_GSC_Client::get_instance();
		$agent = RSA_Claude_SEO_Agent::get_instance();

		$gsc_conn    = $gsc->is_connected();
		$claude_conf = $agent->is_configured();
		$openai_conf = $agent->is_openai_configured();
		$any_ai_conf = $claude_conf || $openai_conf;

		$selected_site = (string) get_option( 'rsa_gsc_selected_site', '' );
		$last_analysis = $agent->get_last_analysis();
		?>

		<div class="rsa-seo-tab">

		<?php if ( ! $any_ai_conf ): ?>
			<div class="rsa-seo-notice">
				<strong>Configura Claude AI u OpenAI</strong> para activar el agente SEO. Si configuras ambos, OpenAI actuar&aacute; como fallback autom&aacute;tico.
				</div>
			<?php else: ?>

			<!-- ═══ DASHBOARD GSC ═══ -->
			<?php if ( $gsc_conn && $selected_site ): ?>
			<div class="rsa-seo-section" id="rsa-gsc-dashboard">
				<h2>
					Rendimiento GSC — <?php echo esc_html( $selected_site ); ?>
					<button class="button button-secondary rsa-small-btn" id="rsa-refresh-gsc">Actualizar datos</button>
				</h2>
				<div id="rsa-gsc-metrics" class="rsa-gsc-metrics-grid">
					<div class="rsa-gsc-metric-card" data-metric="clicks">
						<span class="rsa-gsc-metric-value" id="gsc-clicks">—</span>
						<span class="rsa-gsc-metric-label">Clicks (28d)</span>
						<span class="rsa-gsc-metric-delta" id="gsc-clicks-delta"></span>
					</div>
					<div class="rsa-gsc-metric-card" data-metric="impressions">
						<span class="rsa-gsc-metric-value" id="gsc-impressions">—</span>
						<span class="rsa-gsc-metric-label">Impresiones (28d)</span>
						<span class="rsa-gsc-metric-delta" id="gsc-impressions-delta"></span>
					</div>
					<div class="rsa-gsc-metric-card" data-metric="ctr">
						<span class="rsa-gsc-metric-value" id="gsc-ctr">—</span>
						<span class="rsa-gsc-metric-label">CTR medio</span>
					</div>
					<div class="rsa-gsc-metric-card" data-metric="position">
						<span class="rsa-gsc-metric-value" id="gsc-position">—</span>
						<span class="rsa-gsc-metric-label">Posición media</span>
						<span class="rsa-gsc-metric-delta" id="gsc-position-delta"></span>
					</div>
					<div class="rsa-gsc-metric-card rsa-gsc-metric-highlight" data-metric="quick_wins">
						<span class="rsa-gsc-metric-value rsa-metric-orange" id="gsc-quick-count">—</span>
						<span class="rsa-gsc-metric-label">Oportunidades 8-20</span>
					</div>
					<div class="rsa-gsc-metric-card rsa-gsc-metric-highlight" data-metric="decaying">
						<span class="rsa-gsc-metric-value rsa-metric-red" id="gsc-decaying-count">—</span>
						<span class="rsa-gsc-metric-label">Páginas en caída</span>
					</div>
				</div>
			</div>
			<?php endif; ?>

			<!-- ═══ AGENTE SEO ═══ -->
			<div class="rsa-seo-section">
				<h2>Agente SEO — Análisis con Claude</h2>
				<p class="rsa-seo-agent-desc">
					Selecciona un análisis. El agente recopilará datos de GSC y DataForSEO,
					los pasará a Claude y te devolverá un plan de acción concreto.
				</p>

				<div class="rsa-agent-actions-grid">
					<?php foreach ( RSA_Claude_SEO_Agent::ANALYSIS_TYPES as $type => $label ): ?>
					<div class="rsa-agent-action-card" data-type="<?php echo esc_attr( $type ); ?>">
						<div class="rsa-agent-action-info">
							<strong><?php echo esc_html( $label ); ?></strong>
							<?php if ( ! empty( $last_analysis[ $type ]['generated_at'] ) ): ?>
								<span class="rsa-agent-last-run">Último: <?php echo esc_html( $last_analysis[ $type ]['generated_at'] ); ?></span>
							<?php endif; ?>
						</div>
						<div class="rsa-agent-card-btns">
							<button class="button button-primary rsa-run-analysis" data-type="<?php echo esc_attr( $type ); ?>">
								Analizar
							</button>
							<?php if ( ! empty( $last_analysis[ $type ] ) && in_array( $type, [ 'quick_wins', 'meta_titles', 'page_audit', 'interlinking', 'content_plan', 'image_audit' ], true ) ) : ?>
							<button class="button rsa-generate-proposals rsa-card-to-autopilot" data-type="<?php echo esc_attr( $type ); ?>" title="Generar propuestas ejecutables desde el último análisis">
								→ Autopilot
							</button>
							<?php endif; ?>
						</div>
					</div>
					<?php endforeach; ?>
				</div>

				<!-- Área de resultado del análisis -->
				<div id="rsa-analysis-loading" style="display:none;" class="rsa-analysis-loading">
					<div class="rsa-spinner"></div>
					<p>Claude está analizando los datos de replanta.net&hellip; (puede tardar 30-60s)</p>
				</div>

				<div id="rsa-analysis-result" class="rsa-analysis-result" style="display:none;">
					<div class="rsa-analysis-result-header">
						<h3 id="rsa-analysis-title">Resultado</h3>
						<div class="rsa-analysis-result-actions">
							<button class="button button-primary rsa-generate-proposals" id="rsa-analysis-to-autopilot" data-type="">
								<span class="dashicons dashicons-controls-forward" style="vertical-align:middle;margin-top:-2px"></span>
								Añadir al Autopilot
							</button>
							<button class="button" id="rsa-analysis-copy">Copiar</button>
							<button class="button button-link" id="rsa-analysis-close">Cerrar</button>
						</div>
					</div>
					<div id="rsa-analysis-content" class="rsa-analysis-markdown"></div>
					<div style="padding:8px 0 4px">
						<span id="rsa-analysis-to-autopilot-result" class="rsa-proposals-result" style="display:none;font-size:13px;"></span>
					</div>
				</div>

				<!-- Análisis guardados (acordeón) -->
				<?php if ( ! empty( $last_analysis ) ): ?>
				<div class="rsa-saved-analyses">
					<h3>Análisis guardados</h3>
					<?php foreach ( $last_analysis as $type => $data ): ?>
						<?php if ( empty( $data['markdown'] ) ) continue; ?>
						<details class="rsa-analysis-saved-item">
							<summary>
								<strong><?php echo esc_html( RSA_Claude_SEO_Agent::ANALYSIS_TYPES[ $type ] ?? $type ); ?></strong>
								<span class="rsa-analysis-date"><?php echo esc_html( $data['generated_at'] ?? '' ); ?></span>
							</summary>
							<div class="rsa-analysis-markdown rsa-analysis-saved-content"
								data-markdown="<?php echo esc_attr( $data['markdown'] ); ?>">
							</div>
							<?php if ( in_array( $type, [ 'quick_wins', 'meta_titles', 'page_audit', 'interlinking', 'content_plan', 'image_audit' ], true ) ) : ?>
							<div class="rsa-proposals-actions" style="padding:8px 0 4px">
								<button class="button rsa-generate-proposals" data-type="<?php echo esc_attr( $type ); ?>">
									<i class="ph ph-lightning"></i> Generar Propuestas Ejecutables
								</button>
								<span class="rsa-proposals-result" style="display:none;margin-left:8px;font-size:13px;"></span>
							</div>
							<?php endif; ?>
						</details>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>

			</div>

			<?php endif; // claude_conf ?>

		<?php if ( class_exists( 'RSA_SEO_Approval' ) ) : ?>
			<?php RSA_SEO_Approval::get_instance()->render_section(); ?>
		<?php endif; ?>

		</div><!-- .rsa-seo-tab -->
		<?php
	}

	/* ─────────── Render pestaña Configuración ─────────── */

	public function render_config_tab(): void {
		$gsc   = RSA_GSC_Client::get_instance();
		$dfs   = RSA_DataForSEO_Client::get_instance();
		$agent = RSA_Claude_SEO_Agent::get_instance();

		$gsc_creds   = $gsc->get_credentials();
		$gsc_conn    = $gsc->is_connected();
		$dfs_conf    = $dfs->is_configured();
		$claude_conf = $agent->is_configured();
		$openai_conf = $agent->is_openai_configured();
		$psi_conf    = ! empty( get_option( 'rsa_psi_api_key', '' ) );

		$selected_site = (string) get_option( 'rsa_gsc_selected_site', '' );
		$gsc_ok        = ! empty( $_GET['gsc_ok'] );
		?>

		<div class="rsa-config-tab">
			<div class="rsa-seo-integrations">
				<h2>Integraciones</h2>
				<div class="rsa-seo-integrations-grid">

					<!-- GSC -->
					<div class="rsa-integration-card <?php echo $gsc_conn ? 'rsa-int-ok' : ( ! empty( $gsc_creds['client_id'] ) ? 'rsa-int-warn' : 'rsa-int-off' ); ?>">
						<div class="rsa-int-header">
							<i class="ph ph-chart-line rsa-int-icon"></i>
							<strong>Google Search Console</strong>
							<span class="rsa-int-status">
								<?php if ( $gsc_conn ): ?><i class="ph ph-check-circle"></i> Conectado<?php elseif ( ! empty( $gsc_creds['client_id'] ) ): ?><i class="ph ph-warning"></i> Credenciales OK &mdash; sin tokens<?php else: ?><i class="ph ph-x-circle"></i> No configurado<?php endif; ?>
							</span>
						</div>
						<?php if ( $gsc_ok ): ?>
						<div class="rsa-int-success">Google Search Console conectado correctamente.</div>
						<?php endif; ?>

						<?php if ( ! $gsc_conn ): ?>
						<div class="rsa-int-setup">
							<p class="rsa-int-help">
								<a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">Crea credenciales OAuth2</a>
								en Google Cloud Console. Tipo: "Aplicación web". URI de redirección autorizada:<br>
								<code><?php echo esc_html( $gsc->get_redirect_uri() ); ?></code>
							</p>
							<div class="rsa-int-fields">
								<input type="text" id="gsc_client_id" placeholder="Client ID" value="<?php echo esc_attr( $gsc_creds['client_id'] ); ?>" class="regular-text">
								<input type="password" id="gsc_client_secret" placeholder="Client Secret" value="<?php echo esc_attr( $gsc_creds['client_secret'] ); ?>" class="regular-text">
								<button class="button" id="rsa-gsc-save-creds">Guardar credenciales</button>
							</div>
							<?php if ( ! empty( $gsc_creds['client_id'] ) ) : ?>
								<?php $auth_url = $gsc->get_auth_url(); ?>
								<?php if ( $auth_url ) : ?>
								<a href="<?php echo esc_url( $auth_url ); ?>" class="button button-primary rsa-gsc-connect-btn">
									Conectar con Google
								</a>
								<?php endif; ?>
							<?php endif; ?>
						</div>
						<?php else: ?>
						<div class="rsa-int-connected">
							<div class="rsa-gsc-site-selector">
								<label><strong>Propiedad activa:</strong></label>
								<select id="rsa-gsc-site-select" class="regular-text">
									<option value="">— Cargando propiedades... —</option>
									<?php if ( $selected_site ): ?>
										<option value="<?php echo esc_attr( $selected_site ); ?>" selected>
											<?php echo esc_html( $selected_site ); ?>
										</option>
									<?php endif; ?>
								</select>
								<button class="button" id="rsa-gsc-save-site">Confirmar</button>
							</div>
							<button class="button button-link-delete" id="rsa-gsc-disconnect">Desconectar</button>
						</div>
						<?php endif; ?>
					</div>

					<!-- DataForSEO -->
					<div class="rsa-integration-card <?php echo $dfs_conf ? 'rsa-int-ok' : 'rsa-int-off'; ?>">
						<div class="rsa-int-header">
							<i class="ph ph-magnifying-glass rsa-int-icon"></i>
							<strong>DataForSEO</strong>
							<span class="rsa-int-status"><?php echo $dfs_conf ? '<i class="ph ph-check-circle"></i> Configurado' : '<i class="ph ph-x-circle"></i> No configurado'; ?></span>
						</div>
						<div class="rsa-int-setup">
							<?php if ( ! $dfs_conf ): ?>
							<p class="rsa-int-help">Introduce tus credenciales de <a href="https://app.dataforseo.com/register" target="_blank" rel="noopener">DataForSEO</a>.</p>
							<?php endif; ?>
							<div class="rsa-int-fields">
								<input type="text" id="dfs_login" placeholder="Login (email)" class="regular-text"
									value="<?php echo esc_attr( $dfs->get_credentials()['login'] ?? '' ); ?>">
								<input type="password" id="dfs_password" placeholder="Password" class="regular-text">
								<button class="button" id="rsa-dfs-save">Guardar</button>
							</div>
						</div>
					</div>

					<!-- Claude AI -->
					<div class="rsa-integration-card <?php echo $claude_conf ? 'rsa-int-ok' : 'rsa-int-off'; ?>">
						<div class="rsa-int-header">
							<i class="ph ph-robot rsa-int-icon"></i>
							<strong>Claude AI (Anthropic)</strong>
							<span class="rsa-int-status"><?php echo $claude_conf ? '<i class="ph ph-check-circle"></i> Configurado' : '<i class="ph ph-x-circle"></i> No configurado'; ?></span>
						</div>
						<div class="rsa-int-setup">
							<?php if ( ! $claude_conf ): ?>
							<p class="rsa-int-help">API Key de <a href="https://console.anthropic.com/" target="_blank" rel="noopener">Anthropic Console</a>.</p>
							<?php endif; ?>
							<div class="rsa-int-fields">
								<input type="password" id="claude_api_key" placeholder="sk-ant-..." class="regular-text"
									value="<?php echo $claude_conf ? str_repeat( '•', 20 ) : ''; ?>">
								<button class="button" id="rsa-claude-save">Guardar</button>
							</div>
						</div>
					</div>

					<!-- OpenAI (fallback) -->
					<div class="rsa-integration-card <?php echo $openai_conf ? 'rsa-int-ok' : 'rsa-int-off'; ?>">
						<div class="rsa-int-header">
							<i class="ph ph-lightning rsa-int-icon"></i>
							<strong>OpenAI (fallback)</strong>
							<span class="rsa-int-status"><?php echo $openai_conf ? '<i class="ph ph-check-circle"></i> Configurado' : '<i class="ph ph-x-circle"></i> No configurado'; ?></span>
						</div>
						<div class="rsa-int-setup">
							<p class="rsa-int-help">
								Fallback automático cuando Claude no está disponible. Modelo: <strong>gpt-4o</strong>.<br>
								<a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">Obtener clave en OpenAI Platform</a>.
							</p>
							<div class="rsa-int-fields">
								<input type="password" id="openai_api_key" placeholder="sk-..." class="regular-text"
									value="<?php echo $openai_conf ? str_repeat( '•', 20 ) : ''; ?>">
								<button class="button" id="rsa-openai-save">Guardar</button>
								<span id="rsa-openai-msg" style="margin-left:8px;"></span>
							</div>
						</div>
					</div>

					<!-- PageSpeed Insights API -->
					<div class="rsa-integration-card <?php echo $psi_conf ? 'rsa-int-ok' : 'rsa-int-off'; ?>">
						<div class="rsa-int-header">
							<i class="ph ph-gauge rsa-int-icon"></i>
							<strong>PageSpeed Insights API</strong>
							<span class="rsa-int-status"><?php echo $psi_conf ? '<i class="ph ph-check-circle"></i> Configurado' : '<i class="ph ph-x-circle"></i> Cuota pública'; ?></span>
						</div>
						<div class="rsa-int-setup">
							<p class="rsa-int-help">
								API Key de <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">Google Cloud</a> para Core Web Vitals (PSI v5).
								Sin clave se usa la cuota pública compartida (más lenta y limitada).
							</p>
							<div class="rsa-int-fields">
								<input type="password" id="psi_api_key" placeholder="AIza..." class="regular-text"
									value="<?php echo $psi_conf ? str_repeat( '•', 20 ) : ''; ?>">
								<button class="button" id="rsa-psi-save">Guardar</button>
								<span id="rsa-psi-msg" style="margin-left:8px;"></span>
							</div>
						</div>
					</div>

				</div><!-- /.rsa-seo-integrations-grid -->
			</div><!-- /.rsa-seo-integrations -->
		</div><!-- .rsa-config-tab -->
		<?php
	}

	/* ─────────── AJAX: Generar propuestas desde análisis ─────────── */

	public function ajax_generate_proposals(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		// Ensure tables exist — dev environments skip activation hook on file update
		RSA_SEO_Snapshot::create_tables();

		$type     = sanitize_key( $_POST['analysis_type'] ?? '' );
		$analyses = get_option( 'rsa_claude_seo_last_analysis', [] );
		$saved    = is_array( $analyses ) ? ( $analyses[ $type ] ?? null ) : null;

		if ( ! $saved ) {
			wp_send_json_error( [ 'message' => 'No hay análisis guardado para este tipo. Ejecuta primero el análisis.' ] );
			return;
		}

		$agent = RSA_Claude_SEO_Agent::get_instance();
		$items = $agent->extract_proposals( $type, $saved );

		if ( is_wp_error( $items ) ) {
			wp_send_json_error( [ 'message' => $items->get_error_message() ] );
			return;
		}

		$field_map = [
			'meta_title' => 'rank_math_title',
			'meta_desc'  => 'rank_math_description',
			'focus_kw'   => 'rank_math_focus_keyword',
			'h1'         => 'post_title',
			'intro_text' => 'post_content',
			'body_text'  => 'post_content',
			'interlink'  => 'post_content',
			'new_draft'  => 'post_title',
			'alt_text'   => '_wp_attachment_image_alt',
		];

		$count = 0;
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$url    = sanitize_url( $item['url'] ?? '' );
			$type_p = sanitize_key( $item['type'] ?? '' );

			if ( ! $type_p || ! isset( $field_map[ $type_p ] ) ) {
				continue;
			}

			// alt_text proposals use attachment_id as post_id
			if ( $type_p === 'alt_text' ) {
				$post_id = isset( $item['attachment_id'] ) ? (int) $item['attachment_id'] : 0;
				if ( ! $post_id && $url ) {
					$post_id = (int) attachment_url_to_postid( $url );
				}
			} else {
				// Resolve URL to post_id (returns 0 for external URLs or new_draft)
				$post_id = $url ? (int) url_to_postid( $url ) : 0;
			}

			if ( RSA_SEO_Proposal_Engine::has_pending( $type_p, $url ) ) {
				continue;
			}

			// For interlink proposals on Elementor pages, value_before is not useful
			// (post_content is empty). Store a diagnostic hint instead.
			if ( $type_p === 'interlink' && $post_id ) {
				$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );
				$value_before = $el_raw ? '(Elementor page — backup captured at execution time)' : (string) ( get_post_meta( $post_id, 'post_content', true ) ?: '' );
			} elseif ( $type_p === 'h1' && $post_id ) {
				$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );
				if ( $el_raw ) {
					$value_before = '(Elementor H1 — backup captured at execution time)';
				} else {
					$wp_post      = get_post( $post_id );
					$value_before = $wp_post ? (string) $wp_post->post_title : '';
				}
			} elseif ( in_array( $type_p, [ 'intro_text', 'body_text' ], true ) && $post_id ) {
				$el_raw       = (string) get_post_meta( $post_id, '_elementor_data', true );
				$value_before = $el_raw ? '(Elementor — backup captured at execution time)' : '';
			} else {
				$value_before = $post_id ? (string) ( get_post_meta( $post_id, $field_map[ $type_p ], true ) ?: '' ) : '';
			}

			$saved_id = RSA_SEO_Proposal_Engine::save( [
				'type'             => $type_p,
				'post_id'          => $post_id,
				'url'              => $url,
				'field_key'        => $field_map[ $type_p ],
				'lang'             => '',
				'value_before'     => $value_before,
				'value_after'      => (string) ( $item['value_after'] ?? '' ),
				'status'           => 'pending',
				'claude_reasoning' => mb_substr( sanitize_text_field( $item['reasoning'] ?? '' ), 0, 255 ),
				'snapshot_id'      => 0,
				'approval_token'   => wp_generate_password( 32, false ),
				'created_at'       => current_time( 'mysql' ),
			] );
			if ( $saved_id ) {
				$count++;
			}
		}

		wp_send_json_success( [
			'count'   => $count,
			'message' => $count > 0
				? "{$count} propuestas enviadas a SEO Autopilot para aprobación."
				: 'No se generaron propuestas nuevas (puede que ya existan pendientes para estas URLs).',
		] );
	}

	/* ─────────── Helpers ─────────── */
}
