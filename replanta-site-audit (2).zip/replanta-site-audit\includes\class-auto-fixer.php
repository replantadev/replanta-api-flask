<?php
/**
 * Auto-Fixer Engine
 *
 * Corrección automática de problemas detectados por los módulos de auditoría.
 * Cada fix es atómico: modifica un ajuste CF, una opción WP o un archivo.
 * v2.1.0: Añade purga de caché (LiteSpeed + CF) post-fix.
 *
 * @package Replanta_Site_Audit
 * @version 2.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Auto_Fixer {

    private static ?RSA_Auto_Fixer $instance = null;

    /** @var object|null  Dominios_Reseller_Cloudflare_Service instance (via RSA_DR_Bridge) */
    private $cf = null;
    private ?string $zone_id = null;
    
    /** Track if we need to purge caches after fixes */
    private bool $needs_cache_purge = false;

    public static function get_instance(): RSA_Auto_Fixer {
        return self::$instance ??= new self();
    }

    private function __construct() {
        // Acceso al servicio CF siempre a través del bridge — nunca directo.
        $service = RSA_DR_Bridge::get_service();
        if ($service !== null) {
            $this->cf = $service;
            $this->resolve_zone();
        }
    }

    private function resolve_zone(): void {
        if (!$this->cf) return;
        $match = $this->cf->match_domain_to_zone(RSA_DOMAIN);
        if ($match) {
            $this->zone_id = $match['zone_id'];
        } else {
            $zone = $this->cf->get_zone(RSA_DOMAIN);
            if ($zone) {
                $this->zone_id = $zone['zone_id'];
            }
        }
    }

    /* ═══════════════════════════════════════════════════════════
     *  PUBLIC INTERFACE
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Execute a single fix by its ID
     *
     * @param string $fix_id   Identifier matching a fix_* method
     * @param array  $context  Optional data passed to the fixer
     * @return array{success: bool, message: string, cache_purged?: bool}
     */
    public function execute(string $fix_id, array $context = []): array {
        $method = 'fix_' . $fix_id;
        if (!method_exists($this, $method)) {
            return ['success' => false, 'message' => "Fix '{$fix_id}' no implementado."];
        }
        try {
            $result = $this->$method($context);
            
            // Purge ALL caches after successful fix to ensure re-audit sees changes
            if ($result['success']) {
                $purge_result = $this->purge_all_caches();
                $result['cache_purged'] = $purge_result['purged'];
                if (!empty($purge_result['details'])) {
                    $result['message'] .= ' ' . $purge_result['details'];
                }
            }
            
            return $result;
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }

    /**
     * Execute multiple fixes in sequence
     *
     * @return array{total: int, fixed: int, errors: array, results: array}
     */
    public function execute_batch(array $fix_ids): array {
        $results = [];
        $fixed   = 0;
        $errors  = [];

        foreach ($fix_ids as $fid) {
            $r = $this->execute($fid);
            $results[$fid] = $r;
            if ($r['success']) {
                $fixed++;
            } else {
                $errors[$fid] = $r['message'];
            }
        }

        return [
            'total'   => count($fix_ids),
            'fixed'   => $fixed,
            'errors'  => $errors,
            'results' => $results,
        ];
    }

    /**
     * Catalogue of every available fix
     */
    public static function get_catalogue(): array {
        return [
            // ── Cloudflare Settings ──
            'cf_hotlink_off'         => ['label' => 'Desactivar Hotlink Protection', 'group' => 'cloudflare'],
            'cf_always_https'        => ['label' => 'Activar Always HTTPS',          'group' => 'cloudflare'],
            'cf_brotli'              => ['label' => 'Activar Brotli',                'group' => 'cloudflare'],
            'cf_always_online'       => ['label' => 'Activar Always Online',         'group' => 'cloudflare'],
            'cf_early_hints'         => ['label' => 'Activar Early Hints (103)',     'group' => 'cloudflare'],
            'cf_minify_all'          => ['label' => '[DEPRECADO] Minificación CF → usar LiteSpeed Cache', 'group' => 'cloudflare'],
            'cf_dev_mode_off'        => ['label' => 'Desactivar modo desarrollo',    'group' => 'cloudflare'],
            'cf_security_medium'     => ['label' => 'Nivel seguridad → Medium',      'group' => 'cloudflare'],
            'cf_auto_https_rewrites' => ['label' => 'Activar Auto HTTPS Rewrites',   'group' => 'cloudflare'],
            'cf_http3'               => ['label' => 'Activar HTTP/3 (QUIC)',         'group' => 'cloudflare'],
            'cf_rocket_loader_off'   => ['label' => 'Desactivar Rocket Loader',      'group' => 'cloudflare'],
            // ── Cloudflare Firewall ──
            'cf_firewall_bot_exception' => ['label' => 'Añadir excepción bots verificados en firewall', 'group' => 'cloudflare'],
            'cf_whitelist_server'       => ['label' => 'Whitelist IP del servidor en CF', 'group' => 'cloudflare'],
            'cf_unblock_access'         => ['label' => 'Desbloquear acceso (bajar seguridad)', 'group' => 'cloudflare'],
            'cf_security_off'           => ['label' => 'Seguridad CF → Essentially Off', 'group' => 'cloudflare'],
            'cf_disable_firewall_rules' => ['label' => 'Pausar reglas firewall', 'group' => 'cloudflare'],
            // ── Cloudflare Cache ──
            'cf_purge_cache'         => ['label' => 'Purgar caché de Cloudflare',    'group' => 'cloudflare'],
            // ── WordPress ──
            'wp_debug_off'           => ['label' => 'Desactivar WP_DEBUG',           'group' => 'wordpress'],
            'wp_cron_disable'        => ['label' => 'Desactivar WP pseudo-cron',     'group' => 'wordpress'],
            'wp_memory_limit'        => ['label' => 'Aumentar WP_MEMORY_LIMIT',      'group' => 'wordpress'],
            'wp_cron_run_overdue'    => ['label' => 'Ejecutar tareas cron atrasadas','group' => 'wordpress'],
            'heartbeat_optimize'     => ['label' => 'Optimizar Heartbeat API',       'group' => 'wordpress'],
            // ── Database ──
            'db_clean_revisions'     => ['label' => 'Limpiar revisiones antiguas',   'group' => 'database'],
            'db_clean_transients'    => ['label' => 'Limpiar transients expirados',  'group' => 'database'],
            'db_clean_spam'          => ['label' => 'Limpiar spam y papelera',       'group' => 'database'],
            'db_clean_large_transients' => ['label' => 'Limpiar transients grandes', 'group' => 'database'],
            'db_clean_orphaned_meta' => ['label' => 'Limpiar postmeta huérfanos',    'group' => 'database'],
            // ── Server / .htaccess ──
            'security_headers'       => ['label' => 'Añadir security headers (CF)', 'group' => 'server'],
            'htaccess_compression'   => ['label' => 'Activar compresión HTTP',       'group' => 'server'],
            // ── RankMath ──
            'rm_opengraph'           => ['label' => 'Activar Open Graph en RankMath','group' => 'seo'],
            'rm_canonical'           => ['label' => 'Configurar canonical en RankMath','group' => 'seo'],
            // ── Polylang ──
            'pll_hreflang'           => ['label' => 'Activar hreflang en Polylang',  'group' => 'seo'],
            // ── Meta Fill (Bot Healer) ──
            'fill_empty_metas'           => ['label' => 'Rellenar metas vacíos con IA',          'group' => 'seo'],
            // ── Translation Sync ──
            'sync_outdated_translations'  => ['label' => 'Sincronizar traducciones EN con IA',  'group' => 'seo'],
        ];
    }

    /* ═══════════════════════════════════════════════════════════
     *  CACHE PURGE — LiteSpeed + Cloudflare + WordPress
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Purge all caches after a fix is applied.
     * Essential for re-audit to see fresh content.
     *
     * @return array{purged: bool, details: string}
     */
    private function purge_all_caches(): array {
        $purged = [];
        
        // 1. Purge LiteSpeed Cache (if active)
        if (class_exists('LiteSpeed_Cache_API') || defined('LSCWP_V')) {
            do_action('litespeed_purge_all');
            $purged[] = 'LiteSpeed';
        }
        
        // 2. Purge Cloudflare Cache (if available)
        if ($this->zone_id && $this->cf) {
            $result = $this->cf->api_post("/zones/{$this->zone_id}/purge_cache", ['purge_everything' => true]);
            if (!is_wp_error($result) && !empty($result['success'])) {
                $purged[] = 'Cloudflare';
            }
        }
        
        // 3. Clear WordPress audit transient
        delete_transient('rsa_audit_result');
        $purged[] = 'WP Transients';
        
        // 4. Flush rewrite rules (for .htaccess changes)
        flush_rewrite_rules(false);
        
        // 5. Clear object cache if exists
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
            $purged[] = 'Object Cache';
        }
        
        return [
            'purged'  => !empty($purged),
            'details' => !empty($purged) ? '(Caché purgada: ' . implode(', ', $purged) . ')' : '',
        ];
    }

    /**
     * Public fix to purge all caches on demand.
     */
    private function fix_cf_purge_cache(): array {
        $result = $this->purge_all_caches();
        if ($result['purged']) {
            return ['success' => true, 'message' => 'Caché purgada completamente. ' . $result['details']];
        }
        return ['success' => false, 'message' => 'No se pudo purgar ninguna caché.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  CLOUDFLARE — GENERIC SETTING TOGGLE
     * ═══════════════════════════════════════════════════════════ */

    private function cf_setting(string $setting, mixed $value, string $nice_name = ''): array {
        if (!$this->zone_id) {
            return ['success' => false, 'message' => 'No se encontró la zona CF de ' . RSA_DOMAIN . '. Sincroniza zonas en Dominios Reseller.'];
        }
        if (!$this->cf) {
            return ['success' => false, 'message' => 'Plugin Dominios Reseller no activo.'];
        }

        $result = $this->cf->api_patch(
            "/zones/{$this->zone_id}/settings/{$setting}",
            ['value' => $value]
        );

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => ($nice_name ?: $setting) . ': ' . $result->get_error_message()];
        }

        // CF API returns success=true on good patch
        if (isset($result['success']) && $result['success']) {
            // Flush audit cache so the next run mirrors reality
            delete_transient('rsa_audit_result');
            return ['success' => true, 'message' => ($nice_name ?: $setting) . ' actualizado en Cloudflare.'];
        }

        $err = $result['errors'][0]['message'] ?? json_encode($result);
        return ['success' => false, 'message' => ($nice_name ?: $setting) . ' — error: ' . $err];
    }

    /* ─────── Individual CF fixes ─────── */

    private function fix_cf_hotlink_off(): array {
        return $this->cf_setting('hotlink_protection', 'off', 'Hotlink Protection');
    }

    private function fix_cf_always_https(): array {
        return $this->cf_setting('always_use_https', 'on', 'Always Use HTTPS');
    }

    private function fix_cf_brotli(): array {
        return $this->cf_setting('brotli', 'on', 'Brotli Compression');
    }

    private function fix_cf_always_online(): array {
        return $this->cf_setting('always_online', 'on', 'Always Online');
    }

    private function fix_cf_early_hints(): array {
        return $this->cf_setting('early_hints', 'on', 'Early Hints');
    }

    private function fix_cf_minify_all(): array {
        // Cloudflare deprecated Auto Minify (Aug 2024). PATCH is accepted but ignored.
        return ['success' => true, 'message' => 'Auto Minify fue deprecado por Cloudflare (Ago 2024). Usa LiteSpeed Cache o Autoptimize para minificación de CSS/JS/HTML.'];
    }

    private function fix_cf_dev_mode_off(): array {
        return $this->cf_setting('development_mode', 'off', 'Modo Desarrollo');
    }

    private function fix_cf_security_medium(): array {
        return $this->cf_setting('security_level', 'medium', 'Nivel de Seguridad');
    }

    /**
     * Set CF Security Level to essentially_off — allows all traffic
     */
    private function fix_cf_security_off(): array {
        return $this->cf_setting('security_level', 'essentially_off', 'Nivel de Seguridad');
    }

    /**
     * COMPREHENSIVE FIX: Unblock access by:
     * 1. Setting security level to essentially_off
     * 2. Adding server IP to whitelist
     * 3. Pausing active firewall rules
     */
    private function fix_cf_unblock_access(): array {
        if (!$this->zone_id || !$this->cf) {
            return ['success' => false, 'message' => 'No se encontró la zona CF.'];
        }

        $actions = [];
        $errors = [];

        // 1. Set security level to essentially_off
        $sec = $this->cf_setting('security_level', 'essentially_off', 'Seguridad');
        if ($sec['success']) {
            $actions[] = 'Security Level → Essentially Off';
        } else {
            $errors[] = $sec['message'];
        }

        // 2. Try to whitelist server IP
        $ip_result = $this->whitelist_server_ip();
        if ($ip_result['success']) {
            $actions[] = $ip_result['message'];
        }

        // 3. Disable blocking firewall rules
        $fw_result = $this->pause_blocking_rules();
        if ($fw_result['paused'] > 0) {
            $actions[] = "Pausadas {$fw_result['paused']} regla(s) de firewall";
        }

        // 4. Get diagnostic info
        $diagnostic = $this->get_blocking_diagnostic();

        $summary = !empty($actions)
            ? 'Cambios aplicados: ' . implode(', ', $actions) . '.'
            : 'No se pudieron aplicar cambios.';

        if (!empty($errors)) {
            $summary .= ' Errores: ' . implode('; ', $errors);
        }

        if (!empty($diagnostic)) {
            $summary .= "\n\nDIAGNOSTICO: " . $diagnostic;
        }

        $summary .= "\n\nIMPORTANTE: Espera 2-3 minutos para que los cambios propaguen. "
                  . "Si el problema persiste, revisa CF Dashboard → Security → Events.";

        return ['success' => !empty($actions), 'message' => $summary];
    }

    /**
     * Whitelist the server's IP address in Cloudflare
     * Also attempts to add User-Agent exception to geo-blocking rules
     */
    private function fix_cf_whitelist_server(): array {
        if (!$this->zone_id || !$this->cf) {
            return ['success' => false, 'message' => 'No se encontro la zona CF.'];
        }

        $actions = [];
        $manual_steps = [];

        // 1. Whitelist IP in access rules
        $ip_result = $this->whitelist_server_ip();
        if ($ip_result['success']) {
            $actions[] = $ip_result['message'];
        }

        // 2. Try to modify geo-blocking firewall rules to add UA exception
        $ua_result = $this->add_ua_to_firewall_rules();
        if ($ua_result['modified'] > 0) {
            $actions[] = "Anadido User-Agent a {$ua_result['modified']} regla(s)";
        }
        if (!empty($ua_result['manual'])) {
            $manual_steps = $ua_result['manual'];
        }

        // Build response message
        $msg = '';
        if (!empty($actions)) {
            $msg = "Cambios aplicados:\n- " . implode("\n- ", $actions);
        }

        if (!empty($manual_steps)) {
            $msg .= "\n\nACCION MANUAL REQUERIDA:\n";
            $msg .= "No se pudieron modificar algunas reglas automaticamente. ";
            $msg .= "Anade lo siguiente a tus reglas de firewall en CF Dashboard:\n\n";
            foreach ($manual_steps as $step) {
                $msg .= "Regla: \"{$step['name']}\"\n";
                $msg .= "Anadir: or http.user_agent contains \"Replanta-Site-Audit\"\n";
                if (!empty($step['ip'])) {
                    $msg .= "O anadir IP: or ip.src in {" . $step['ip'] . "}\n";
                }
                $msg .= "\n";
            }
        }

        if (empty($actions) && empty($manual_steps)) {
            return ['success' => true, 'message' => 'El servidor no parece estar siendo bloqueado por reglas de firewall.'];
        }

        return [
            'success' => !empty($actions),
            'message' => $msg ?: 'Sin cambios necesarios.'
        ];
    }

    /**
     * Try to add User-Agent exception to geo-blocking firewall rules
     */
    private function add_ua_to_firewall_rules(): array {
        $modified = 0;
        $manual = [];

        // Get server IP for reference
        $server_ip = $this->detect_server_ip();

        // Get all firewall rules
        $rules_resp = $this->cf->api_get("/zones/{$this->zone_id}/firewall/rules", ['per_page' => 100]);
        if (is_wp_error($rules_resp)) {
            return ['modified' => 0, 'manual' => []];
        }

        $rules = $rules_resp['result'] ?? [];
        $ua_audit = 'Replanta-Site-Audit';

        foreach ($rules as $rule) {
            $filter = $rule['filter'] ?? [];
            $expr = $filter['expression'] ?? '';
            $filter_id = $filter['id'] ?? '';
            $action = $rule['action'] ?? '';
            $desc = $rule['description'] ?? 'Sin nombre';

            // Skip if not a blocking geo-rule
            if (!preg_match('/ip\.geoip\.country/i', $expr)) continue;
            if (!in_array($action, ['block', 'challenge', 'js_challenge', 'managed_challenge'])) continue;

            // Skip if already has our UA
            if (preg_match('/Replanta-Site-Audit/i', $expr)) continue;

            // Try to add UA exception to the expression
            // The expression format is usually: (not (...exceptions...) and not ip.src... and not country...)
            // We need to add our UA inside the "not" block of exceptions

            $new_expr = $this->inject_ua_into_expression($expr, $ua_audit);

            if ($new_expr && $new_expr !== $expr && $filter_id) {
                // Try to update the filter
                $update = $this->cf->api_put(
                    "/zones/{$this->zone_id}/filters/{$filter_id}",
                    [
                        'id' => $filter_id,
                        'expression' => $new_expr,
                    ]
                );

                if (!is_wp_error($update) && ($update['success'] ?? false)) {
                    $modified++;
                } else {
                    // API failed, add to manual steps
                    $manual[] = [
                        'name' => $desc,
                        'ip' => $server_ip,
                    ];
                }
            } else {
                // Couldn't parse expression, add to manual steps
                $manual[] = [
                    'name' => $desc,
                    'ip' => $server_ip,
                ];
            }
        }

        return ['modified' => $modified, 'manual' => $manual];
    }

    /**
     * Try to inject UA exception into a firewall expression
     * Returns modified expression or null if cannot parse
     */
    private function inject_ua_into_expression(string $expr, string $ua): ?string {
        // Pattern: find the last "or http.user_agent contains" in the NOT block
        // and add our UA after it

        // Look for pattern like: or http.user_agent contains "SomeThing")
        // and insert before the closing parenthesis of the NOT block

        // Method 1: Find the last UA contains in the expression and add after it
        $pattern = '/(or\s+http\.user_agent\s+contains\s+"[^"]+")(\s*\))/i';
        
        if (preg_match($pattern, $expr)) {
            $new_expr = preg_replace(
                $pattern,
                '$1' . "\n        or http.user_agent contains \"{$ua}\"" . '$2',
                $expr,
                1
            );
            return $new_expr;
        }

        // Method 2: Find "cf.client.bot" and add UA after it
        $pattern2 = '/(or\s+cf\.client\.bot)/i';
        if (preg_match($pattern2, $expr)) {
            $new_expr = preg_replace(
                $pattern2,
                '$1' . "\n        or http.user_agent contains \"{$ua}\"",
                $expr,
                1
            );
            return $new_expr;
        }

        return null;
    }

    private function whitelist_server_ip(): array {
        if (!$this->zone_id || !$this->cf) {
            return ['success' => false, 'message' => 'No se encontró la zona CF.'];
        }

        // Get server IP
        $server_ip = $this->detect_server_ip();
        if (!$server_ip) {
            return ['success' => false, 'message' => 'No se pudo detectar la IP del servidor.'];
        }

        // Check if already whitelisted
        $existing = $this->cf->api_get("/zones/{$this->zone_id}/firewall/access_rules/rules", [
            'configuration.value' => $server_ip,
            'per_page' => 10
        ]);

        if (!is_wp_error($existing)) {
            foreach ($existing['result'] ?? [] as $rule) {
                if ($rule['mode'] === 'whitelist' && 
                    ($rule['configuration']['value'] ?? '') === $server_ip) {
                    return ['success' => true, 'message' => "IP {$server_ip} ya está en whitelist."];
                }
            }
        }

        // Add to whitelist
        $add = $this->cf->api_post("/zones/{$this->zone_id}/firewall/access_rules/rules", [
            'mode' => 'whitelist',
            'configuration' => [
                'target' => 'ip',
                'value' => $server_ip
            ],
            'notes' => 'Replanta Site Audit - Server IP whitelist'
        ]);

        if (is_wp_error($add)) {
            return ['success' => false, 'message' => 'Error al añadir whitelist: ' . $add->get_error_message()];
        }

        return ['success' => true, 'message' => "IP {$server_ip} añadida a whitelist."];
    }

    private function detect_server_ip(): ?string {
        // Try multiple methods to detect server IP
        
        // 1. Check if CF provided the connecting IP
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        }

        // 2. Try to get the server's outbound IP via external service
        $resp = wp_remote_get('https://api.ipify.org?format=json', [
            'timeout' => 5,
            'sslverify' => true
        ]);
        if (!is_wp_error($resp)) {
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($body['ip'])) {
                return $body['ip'];
            }
        }

        // 3. Try cloudflare's trace
        $resp = wp_remote_get('https://www.cloudflare.com/cdn-cgi/trace', [
            'timeout' => 5,
            'sslverify' => true
        ]);
        if (!is_wp_error($resp)) {
            $body = wp_remote_retrieve_body($resp);
            if (preg_match('/ip=([0-9.]+)/', $body, $m)) {
                return $m[1];
            }
        }

        // 4. SERVER_ADDR (less reliable)
        return $_SERVER['SERVER_ADDR'] ?? null;
    }

    /**
     * Pause firewall rules that are blocking/challenging traffic
     */
    private function fix_cf_disable_firewall_rules(): array {
        $result = $this->pause_blocking_rules();
        
        if ($result['paused'] === 0) {
            return ['success' => true, 'message' => 'No se encontraron reglas de firewall activas bloqueando tráfico.'];
        }

        return [
            'success' => true,
            'message' => "Se pausaron {$result['paused']} regla(s) de firewall. " .
                        "Las reglas siguen existiendo pero ya no bloquean. " .
                        "Reactívalas en CF Dashboard → Security → WAF cuando resuelvas el problema."
        ];
    }

    private function pause_blocking_rules(): array {
        if (!$this->zone_id || !$this->cf) {
            return ['paused' => 0, 'errors' => ['No CF zone']];
        }

        $paused = 0;
        $errors = [];

        // Get all firewall rules
        $rules_resp = $this->cf->api_get("/zones/{$this->zone_id}/firewall/rules", ['per_page' => 100]);
        if (is_wp_error($rules_resp)) {
            return ['paused' => 0, 'errors' => [$rules_resp->get_error_message()]];
        }

        $rules = $rules_resp['result'] ?? [];

        foreach ($rules as $rule) {
            $action = $rule['action'] ?? '';
            $paused_status = $rule['paused'] ?? false;

            // Skip if already paused or not a blocking action
            if ($paused_status) continue;
            if (!in_array($action, ['block', 'challenge', 'js_challenge', 'managed_challenge'])) continue;

            // Pause this rule
            $update = $this->cf->api_patch("/zones/{$this->zone_id}/firewall/rules/{$rule['id']}", [
                'paused' => true
            ]);

            if (is_wp_error($update)) {
                $errors[] = "Error pausando regla '{$rule['description']}': " . $update->get_error_message();
            } else {
                $paused++;
            }
        }

        return ['paused' => $paused, 'errors' => $errors];
    }

    private function get_blocking_diagnostic(): string {
        if (!$this->zone_id || !$this->cf) {
            return 'No hay conexión con CF.';
        }

        $info = [];

        // Get current security level
        $settings = $this->cf->api_get("/zones/{$this->zone_id}/settings/security_level");
        if (!is_wp_error($settings)) {
            $level = $settings['result']['value'] ?? 'unknown';
            $info[] = "Security Level: {$level}";
        }

        // Count active firewall rules
        $rules = $this->cf->api_get("/zones/{$this->zone_id}/firewall/rules", ['per_page' => 100]);
        if (!is_wp_error($rules)) {
            $active = 0;
            $blocking = 0;
            foreach ($rules['result'] ?? [] as $r) {
                if (!($r['paused'] ?? false)) {
                    $active++;
                    if (in_array($r['action'] ?? '', ['block', 'challenge', 'js_challenge', 'managed_challenge'])) {
                        $blocking++;
                    }
                }
            }
            $info[] = "Reglas firewall: {$active} activas ({$blocking} bloqueando)";
        }

        // Check rate limits
        $rl = $this->cf->api_get("/zones/{$this->zone_id}/rate_limits", ['per_page' => 50]);
        if (!is_wp_error($rl)) {
            $active_rl = count(array_filter($rl['result'] ?? [], fn($r) => !($r['disabled'] ?? false)));
            if ($active_rl > 0) {
                $info[] = "Rate limits: {$active_rl} activos";
            }
        }

        return implode(' | ', $info);
    }

    private function fix_cf_auto_https_rewrites(): array {
        return $this->cf_setting('automatic_https_rewrites', 'on', 'Auto HTTPS Rewrites');
    }

    private function fix_cf_hsts(): array {
        return $this->cf_setting('security_header', [
            'strict_transport_security' => [
                'enabled'            => true,
                'max_age'            => 31536000,
                'include_subdomains' => true,
                'nosniff'            => true,
            ]
        ], 'HSTS');
    }

    private function fix_cf_tls_12(): array {
        return $this->cf_setting('min_tls_version', '1.2', 'TLS Mínimo');
    }

    private function fix_cf_http3(): array {
        return $this->cf_setting('http3', 'on', 'HTTP/3');
    }

    private function fix_cf_rocket_loader_off(): array {
        return $this->cf_setting('rocket_loader', 'off', 'Rocket Loader');
    }

    /* ═══════════════════════════════════════════════════════════
     *  CLOUDFLARE FIREWALL — ADD BOT EXCEPTION
     * ═══════════════════════════════════════════════════════════ */

    private function fix_cf_firewall_bot_exception(): array {
        if (!$this->zone_id || !$this->cf) {
            return ['success' => false, 'message' => 'No se encontró la zona CF.'];
        }

        // Read current WAF Custom Rules via Rulesets API
        $resp = $this->cf->api_get("/zones/{$this->zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint");
        if (is_wp_error($resp)) {
            return ['success' => false, 'message' => $resp->get_error_message()];
        }

        $ruleset_id = $resp['result']['id'] ?? null;
        $rules = $resp['result']['rules'] ?? [];
        $fixed = 0;
        $errs  = [];

        if (!$ruleset_id) {
            return ['success' => false, 'message' => 'No se encontró el ruleset de WAF Custom Rules.'];
        }

        // Build updated rules array with bot exceptions added
        $updated_rules = [];
        $needs_update = false;

        foreach ($rules as $rule) {
            $expression = $rule['expression'] ?? '';
            $action     = $rule['action'] ?? '';
            $rule_id    = $rule['id'] ?? '';

            // Target: geo-blocking rules WITHOUT bot exception
            $is_geo = preg_match('/ip\.geoip\.country/i', $expression);
            $is_blocking = in_array($action, ['block', 'challenge', 'js_challenge', 'managed_challenge']);
            $has_bot = preg_match('/cf\.bot_management\.verified_bot|cf\.client\.bot/i', $expression);

            if ($is_geo && $is_blocking && !$has_bot) {
                // Wrap the original expression and add bot exception
                $rule['expression'] = '(' . $expression . ') and not cf.bot_management.verified_bot';
                $needs_update = true;
                $fixed++;
            }

            $updated_rules[] = $rule;
        }

        if (!$needs_update) {
            delete_transient('rsa_audit_result');
            return ['success' => true, 'message' => 'Todas las reglas ya tienen excepción para bots verificados.'];
        }

        // Update entire ruleset with modified rules via PUT
        $update = $this->cf->api_put(
            "/zones/{$this->zone_id}/rulesets/{$ruleset_id}",
            [
                'rules' => $updated_rules,
            ]
        );

        delete_transient('rsa_audit_result');

        if (is_wp_error($update)) {
            return ['success' => false, 'message' => 'Error actualizando ruleset: ' . $update->get_error_message()];
        }

        return ['success' => true, 'message' => "Se añadió 'not cf.bot_management.verified_bot' a {$fixed} regla(s). Googlebot y otros crawlers verificados ahora podrán acceder sin challenge."];
    }

    /* ═══════════════════════════════════════════════════════════
     *  HELPERS
     * ═══════════════════════════════════════════════════════════ */

    /**
     * Create a one-time backup of wp-config.php before modifying it.
     * Backup is skipped if it already exists (first write wins).
     */
    private function maybe_backup_config(string $path): void {
        $backup = $path . '.rsa-backup';
        if (!file_exists($backup)) {
            @copy($path, $backup);
        }
    }

    /* ═══════════════════════════════════════════════════════════
     *  WORDPRESS — WP_DEBUG OFF
     * ═══════════════════════════════════════════════════════════ */

    private function fix_wp_debug_off(): array {
        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path)) {
            $config_path = dirname(ABSPATH) . '/wp-config.php';
        }
        if (!file_exists($config_path) || !is_writable($config_path)) {
            return ['success' => false, 'message' => 'wp-config.php no encontrado o no tiene permisos de escritura.'];
        }

        $content  = file_get_contents($config_path);
        $original = $content;

        $content = preg_replace(
            "/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*true\s*\)/i",
            "define('WP_DEBUG', false)",
            $content
        );
        $content = preg_replace(
            "/define\s*\(\s*['\"]WP_DEBUG_LOG['\"]\s*,\s*true\s*\)/i",
            "define('WP_DEBUG_LOG', false)",
            $content
        );
        $content = preg_replace(
            "/define\s*\(\s*['\"]WP_DEBUG_DISPLAY['\"]\s*,\s*true\s*\)/i",
            "define('WP_DEBUG_DISPLAY', false)",
            $content
        );

        if ($content === $original) {
            return ['success' => true, 'message' => 'WP_DEBUG ya estaba desactivado.'];
        }

        $this->maybe_backup_config($config_path);
        file_put_contents($config_path, $content);
        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'WP_DEBUG, WP_DEBUG_LOG y WP_DEBUG_DISPLAY desactivados en wp-config.php.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  WORDPRESS — DISABLE PSEUDO-CRON
     * ═══════════════════════════════════════════════════════════ */

    private function fix_wp_cron_disable(): array {
        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path)) {
            $config_path = dirname(ABSPATH) . '/wp-config.php';
        }
        if (!file_exists($config_path) || !is_writable($config_path)) {
            return ['success' => false, 'message' => 'wp-config.php no encontrado o no tiene permisos de escritura.'];
        }

        $content = file_get_contents($config_path);

        if (strpos($content, 'DISABLE_WP_CRON') !== false) {
            return ['success' => true, 'message' => 'DISABLE_WP_CRON ya está definido.'];
        }

        $markers = [
            "/* That's all",
            "/** That's all",
            "require_once ABSPATH . 'wp-settings.php'",
            "require_once(ABSPATH . 'wp-settings.php')",
        ];

        foreach ($markers as $marker) {
            $pos = strpos($content, $marker);
            if ($pos !== false) {
                $insert = "\n/* Disable WP pseudo-cron — use real system cron instead */\n"
                    . "define('DISABLE_WP_CRON', true);\n\n";
                $content = substr($content, 0, $pos) . $insert . substr($content, $pos);
                $this->maybe_backup_config($config_path);
                file_put_contents($config_path, $content);
                delete_transient('rsa_audit_result');

                $cron_cmd = "*/5 * * * * cd " . rtrim(ABSPATH, '/') . " && php wp-cron.php > /dev/null 2>&1";
                return ['success' => true, 'message' => "DISABLE_WP_CRON añadido. IMPORTANTE: Configura un cron real en tu servidor:\n{$cron_cmd}"];
            }
        }

        return ['success' => false, 'message' => 'No se encontró un punto de inserción seguro en wp-config.php.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  SERVER — SECURITY HEADERS via Cloudflare Transform Rules
     *  
     *  Con LiteSpeed + CF, los headers de .htaccess no llegan al
     *  navegador porque CF los sobrescribe. Usamos CF Transform Rules.
     * ═══════════════════════════════════════════════════════════ */

    private function fix_security_headers(): array {
        // First, try Cloudflare (prefered with LiteSpeed setup)
        if ($this->zone_id && $this->cf) {
            return $this->fix_security_headers_via_cf();
        }
        
        // Fallback to .htaccess
        return $this->fix_security_headers_via_htaccess();
    }
    
    private function fix_security_headers_via_cf(): array {
        // Create Transform Rule via CF Rulesets API to add security headers
        $rule_name = 'Replanta Security Headers';
        
        // First check if rules already exist in the transform phase
        $existing = $this->cf->api_get("/zones/{$this->zone_id}/rulesets/phases/http_response_headers_transform/entrypoint");
        
        if (!is_wp_error($existing) && !empty($existing['result']['rules'])) {
            foreach ($existing['result']['rules'] as $rule) {
                if (stripos($rule['description'] ?? '', 'Security Headers') !== false
                    || stripos($rule['description'] ?? '', 'Replanta') !== false) {
                    return ['success' => true, 'message' => 'Security headers ya configurados en Cloudflare Transform Rules.'];
                }
            }
        }

        // Build the security headers transform rule
        $security_headers = [
            ['operation' => 'set', 'header' => ['name' => 'X-Content-Type-Options', 'value' => 'nosniff']],
            ['operation' => 'set', 'header' => ['name' => 'X-Frame-Options', 'value' => 'SAMEORIGIN']],
            ['operation' => 'set', 'header' => ['name' => 'Referrer-Policy', 'value' => 'strict-origin-when-cross-origin']],
            ['operation' => 'set', 'header' => ['name' => 'Permissions-Policy', 'value' => 'camera=(), microphone=(), geolocation=()']],
            ['operation' => 'set', 'header' => ['name' => 'Strict-Transport-Security', 'value' => 'max-age=31536000; includeSubDomains']],
        ];

        $new_rule = [
            'expression'  => 'true',
            'description' => $rule_name,
            'action'      => 'rewrite',
            'action_parameters' => [
                'headers' => $security_headers,
            ],
            'enabled' => true,
        ];

        // Get existing rules to preserve them
        $current_rules = [];
        if (!is_wp_error($existing) && !empty($existing['result']['rules'])) {
            $current_rules = $existing['result']['rules'];
        }
        $current_rules[] = $new_rule;

        // PUT to the phase entrypoint to set all rules
        $result = $this->cf->api_put(
            "/zones/{$this->zone_id}/rulesets/phases/http_response_headers_transform/entrypoint",
            [
                'rules' => $current_rules,
            ]
        );

        if (is_wp_error($result)) {
            // Fallback: provide manual instructions
            $instructions = "Error al crear Transform Rule: " . $result->get_error_message() . "\n\n"
                . "Configura manualmente en CF Dashboard → Rules → Transform Rules → Modify Response Header:\n"
                . "- X-Content-Type-Options: nosniff\n"
                . "- X-Frame-Options: SAMEORIGIN\n"
                . "- Strict-Transport-Security: max-age=31536000; includeSubDomains\n"
                . "- Referrer-Policy: strict-origin-when-cross-origin\n"
                . "- Permissions-Policy: camera=(), microphone=(), geolocation=()";
            return ['success' => false, 'message' => $instructions];
        }

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'Security headers configurados via CF Transform Rules: X-Content-Type-Options, X-Frame-Options, HSTS, Referrer-Policy, Permissions-Policy.'];
    }
    
    private function fix_security_headers_via_litespeed(): bool {
        // LiteSpeed headers are configured via .htaccess with specific LS directives
        $htaccess = ABSPATH . '.htaccess';
        if (!file_exists($htaccess) || !is_writable($htaccess)) {
            return false;
        }
        
        $content = file_get_contents($htaccess);
        
        if (strpos($content, '# BEGIN Replanta Security Headers') !== false) {
            return true;
        }
        
        // LiteSpeed also respects standard Apache mod_headers
        $block = <<<'HTACCESS'

# BEGIN Replanta Security Headers
# Works with LiteSpeed + Apache (CF may override some)
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"
</IfModule>
# Note: HSTS is better set via Cloudflare SSL/TLS settings
# END Replanta Security Headers

HTACCESS;

        $wp_pos = strpos($content, '# BEGIN WordPress');
        if ($wp_pos !== false) {
            $content = substr($content, 0, $wp_pos) . $block . "\n" . substr($content, $wp_pos);
        } else {
            $content .= $block;
        }
        
        file_put_contents($htaccess, $content);
        return true;
    }

    private function fix_security_headers_via_htaccess(): array {
        $htaccess = ABSPATH . '.htaccess';
        if (!file_exists($htaccess) || !is_writable($htaccess)) {
            return ['success' => false, 'message' => '.htaccess no encontrado o sin permisos de escritura.'];
        }

        $content = file_get_contents($htaccess);

        if (strpos($content, '# BEGIN Replanta Security Headers') !== false) {
            return ['success' => true, 'message' => 'Los security headers ya están en .htaccess.'];
        }

        $block = <<<'HTACCESS'

# BEGIN Replanta Security Headers
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
</IfModule>
# END Replanta Security Headers

HTACCESS;

        $wp_pos = strpos($content, '# BEGIN WordPress');
        if ($wp_pos !== false) {
            $content = substr($content, 0, $wp_pos) . $block . "\n" . substr($content, $wp_pos);
        } else {
            $content .= $block;
        }

        file_put_contents($htaccess, $content);
        return ['success' => true, 'message' => 'Security headers añadidos a .htaccess. Nota: Con Cloudflare, verifica que no los sobrescriba.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  SERVER — HTTP COMPRESSION
     *  
     *  Con LiteSpeed, ya hay compresión. Con CF, también.
     *  Este fix activa Brotli en CF que es superior a gzip.
     * ═══════════════════════════════════════════════════════════ */

    private function fix_htaccess_compression(): array {
        // With LiteSpeed + CF, compression is already handled
        // Best approach: ensure CF Brotli is enabled
        
        $messages = [];
        
        // 1. Enable CF Brotli (best compression)
        if ($this->zone_id && $this->cf) {
            $brotli = $this->cf_setting('brotli', 'on', 'CF Brotli');
            if ($brotli['success']) {
                $messages[] = 'Brotli activado en Cloudflare';
            }
        }
        
        // 2. LiteSpeed has its own compression - just verify it's not disabled
        if (class_exists('LiteSpeed_Cache_API') || defined('LSCWP_V')) {
            $messages[] = 'LiteSpeed Cache maneja compresión automáticamente';
        }
        
        // 3. Fallback: add mod_deflate to .htaccess
        if (empty($messages)) {
            return $this->fix_htaccess_compression_fallback();
        }
        
        return ['success' => true, 'message' => implode('. ', $messages) . '.'];
    }
    
    private function fix_htaccess_compression_fallback(): array {
        $htaccess = ABSPATH . '.htaccess';
        if (!file_exists($htaccess) || !is_writable($htaccess)) {
            return ['success' => false, 'message' => '.htaccess no encontrado o sin permisos.'];
        }

        $content = file_get_contents($htaccess);

        if (strpos($content, '# BEGIN Replanta Compression') !== false) {
            return ['success' => true, 'message' => 'Las reglas de compresión ya están en .htaccess.'];
        }

        $block = <<<'HTACCESS'

# BEGIN Replanta Compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css
    AddOutputFilterByType DEFLATE application/javascript application/json application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml application/rss+xml
    AddOutputFilterByType DEFLATE image/svg+xml font/ttf font/otf
</IfModule>
# END Replanta Compression

HTACCESS;

        $wp_pos = strpos($content, '# BEGIN WordPress');
        if ($wp_pos !== false) {
            $content = substr($content, 0, $wp_pos) . $block . "\n" . substr($content, $wp_pos);
        } else {
            $content .= $block;
        }

        file_put_contents($htaccess, $content);
        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'Reglas de compresión gzip/deflate añadidas a .htaccess.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  RANKMATH — OPEN GRAPH
     * ═══════════════════════════════════════════════════════════ */

    private function fix_rm_opengraph(): array {
        if (!class_exists('RankMath') && !function_exists('rank_math')) {
            return ['success' => false, 'message' => 'RankMath no está activo.'];
        }

        $titles = get_option('rank-math-options-titles', []);
        if (empty($titles)) {
            return ['success' => false, 'message' => 'No se encontraron opciones de RankMath.'];
        }

        $changed = false;

        if (empty($titles['homepage_facebook_title'])) {
            $titles['homepage_facebook_title'] = get_bloginfo('name') . ' — ' . get_bloginfo('description');
            $changed = true;
        }
        if (empty($titles['homepage_facebook_description'])) {
            $titles['homepage_facebook_description'] = get_bloginfo('description');
            $changed = true;
        }
        if (empty($titles['homepage_facebook_image_id'])) {
            $logo_id = get_theme_mod('custom_logo');
            if ($logo_id) {
                $titles['homepage_facebook_image_id'] = $logo_id;
                $titles['homepage_facebook_image']    = wp_get_attachment_url($logo_id);
                $changed = true;
            }
        }

        // Enable OG globally
        $general = get_option('rank-math-options-general', []);
        if (!empty($general)) {
            if (empty($general['opengraph']) || $general['opengraph'] !== 'on') {
                $general['opengraph'] = 'on';
                update_option('rank-math-options-general', $general);
                $changed = true;
            }
        }

        if ($changed) {
            update_option('rank-math-options-titles', $titles);
        }

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'Open Graph activado en RankMath. Se configuraron og:title, og:description' . ($titles['homepage_facebook_image_id'] ?? '' ? ' y og:image (logo del sitio)' : '') . '.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  RANKMATH — CANONICAL
     * ═══════════════════════════════════════════════════════════ */

    private function fix_rm_canonical(): array {
        if (!class_exists('RankMath') && !function_exists('rank_math')) {
            return ['success' => false, 'message' => 'RankMath no está activo.'];
        }

        $front_id = get_option('page_on_front');
        if (!$front_id) {
            return ['success' => false, 'message' => 'No hay página de inicio configurada (Settings → Reading).'];
        }

        // Ensure canonical URL is set for the front page
        $current = get_post_meta($front_id, 'rank_math_canonical_url', true);
        if (empty($current)) {
            update_post_meta($front_id, 'rank_math_canonical_url', home_url('/'));
        }

        // Also verify RankMath isn't disabling canonical globally
        $general = get_option('rank-math-options-general', []);
        // RankMath generates canonical by default; just log it

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'Canonical URL configurada para la portada: ' . home_url('/') . '. RankMath ahora generará <link rel="canonical"> automáticamente.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  SITEMAP — REGENERAR
     * ═══════════════════════════════════════════════════════════ */

    private function fix_sitemap_regenerate(): array {
        $regenerated = [];

        // RankMath: fire invalidation hooks
        if (class_exists('RankMath') || function_exists('rank_math')) {
            // Invalidate RankMath sitemap transients
            do_action('rank_math/sitemap/invalidate', 'all');
            delete_transient('rank_math_sitemap_cache');

            // Clear RankMath sitemap specific options/transients
            global $wpdb;
            $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rank_math_sitemap%'");
            $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_rank_math_sitemap%'");

            $regenerated[] = 'RankMath sitemap regenerado';
        }

        // WP core sitemap: clear any cached output
        delete_transient('wp_sitemap');

        // LiteSpeed cache: purge sitemap URLs
        if (class_exists('LiteSpeed_Cache_API')) {
            LiteSpeed_Cache_API::purge('sitemap');
            $regenerated[] = 'LiteSpeed sitemap purgeado';
        } elseif (function_exists('litespeed_purge_url')) {
            litespeed_purge_url(home_url('/sitemap_index.xml'));
            litespeed_purge_url(home_url('/sitemap.xml'));
            $regenerated[] = 'LiteSpeed sitemap purgeado';
        }

        // Cloudflare: purge sitemap URLs (via Dominios Reseller)
        if ($this->cf && $this->zone_id) {
            $this->cf->api_post("zones/{$this->zone_id}/purge_cache", [
                'files' => [
                    home_url('/sitemap_index.xml'),
                    home_url('/sitemap.xml'),
                    home_url('/wp-sitemap.xml'),
                ],
            ]);
            $regenerated[] = 'CF caché sitemap purgada';
        }

        delete_transient('rsa_audit_result');

        return [
            'success' => true,
            'message' => 'Sitemap regenerado: ' . implode(', ', $regenerated ?: ['transients eliminados']) . '. Espera ~60 segundos y vuelve a ejecutar la auditoría para ver el resultado.',
        ];
    }

    /* ═══════════════════════════════════════════════════════════
     *  RANKMATH — SCHEMA
     * ═══════════════════════════════════════════════════════════ */

    private function fix_rm_schema_enable(): array {
        if (!class_exists('RankMath') && !function_exists('rank_math')) {
            return ['success' => false, 'message' => 'RankMath no está activo.'];
        }

        $titles  = get_option('rank-math-options-titles', []);
        $general = get_option('rank-math-options-general', []);
        $changed = false;

        // Enable schema on homepage
        if (isset($titles['homepage_schema_type']) && $titles['homepage_schema_type'] === 'off') {
            $titles['homepage_schema_type'] = 'WebPage';
            $changed = true;
        }

        // Ensure local SEO schema (Organization/PersonSchema) is set
        if (empty($titles['knowledgegraph_type'])) {
            $titles['knowledgegraph_type'] = 'organization';
            $changed = true;
        }
        if (empty($titles['knowledgegraph_name'])) {
            $titles['knowledgegraph_name'] = get_bloginfo('name');
            $changed = true;
        }
        if (empty($titles['url'])) {
            $titles['url'] = home_url('/');
            $changed = true;
        }

        // Ensure JSON-LD output is enabled (not disabled)
        if (isset($general['schema_markup']) && $general['schema_markup'] !== 'on') {
            $general['schema_markup'] = 'on';
            update_option('rank-math-options-general', $general);
            $changed = true;
        }

        if ($changed) {
            update_option('rank-math-options-titles', $titles);
        }

        delete_transient('rsa_audit_result');
        return [
            'success' => true,
            'message' => $changed
                ? 'Schema de RankMath configurado: Organization schema con nombre y URL del sitio. Vuelve a ejecutar la auditoría para verificar.'
                : 'El schema de RankMath ya estaba configurado. Revisa manualmente los bloques JSON-LD en RankMath → Titles & Meta → Global Meta → Schema.',
        ];
    }

    /* ═══════════════════════════════════════════════════════════
     *  WORDPRESS — THEME TITLE-TAG SUPPORT
     * ═══════════════════════════════════════════════════════════ */

    private function fix_theme_title_tag(): array {
        // Check if the theme already declares title-tag support
        $current_theme_support = current_theme_supports('title-tag');
        if ($current_theme_support) {
            // Title-tag is supported but still showing duplicates — RankMath/Yoast conflict
            // Try updating RankMath to not output a separate <title>
            if (class_exists('RankMath') || function_exists('rank_math')) {
                $general = get_option('rank-math-options-general', []);
                if (!isset($general['headless_mode'])) {
                    // RankMath typically defers to wp_title/wp_head when title-tag is supported.
                    // Force update: ensure rank_math is not adding extra title output hooks
                    update_option('rank-math-options-general', $general);
                }
                delete_transient('rsa_audit_result');
                return [
                    'success' => true,
                    'message' => 'Tu tema ya tiene add_theme_support("title-tag"). El título duplicado viene de RankMath o Yoast y el tema. Comprueba que tu tema NO llame wp_title() ni imprima <title> directamente en header.php. Solución definitiva: edita header.php y elimina el <title> manual del tema.',
                ];
            }
        }

        // Try to add title-tag support via functions.php of the child theme
        $child_theme_dir = get_stylesheet_directory();
        $functions_php   = $child_theme_dir . '/functions.php';

        $snippet = "\n\n/* RSA Fix: ensure WordPress manages <title> tag */\nadd_action('after_setup_theme', function() {\n    add_theme_support('title-tag');\n});\n";

        if (!file_exists($functions_php)) {
            return [
                'success' => false,
                'message' => 'No se encontró functions.php del tema hijo. Añade manualmente: add_theme_support(\'title-tag\') en el functions.php de tu tema hijo.',
            ];
        }

        if (!is_writable($functions_php)) {
            return [
                'success' => false,
                'message' => "functions.php no tiene permisos de escritura. Añade manualmente en {$functions_php}: add_theme_support('title-tag');",
            ];
        }

        $content = file_get_contents($functions_php);
        if (strpos($content, "add_theme_support('title-tag')") !== false ||
            strpos($content, 'add_theme_support("title-tag")') !== false) {
            delete_transient('rsa_audit_result');
            return [
                'success' => true,
                'message' => 'add_theme_support("title-tag") ya existe en functions.php. El conflicto está en que el tema padre también imprime un <title> manual. Edita header.php del tema padre y elimina la etiqueta <title> o usa un tema hijo que la sobrescriba.',
            ];
        }

        file_put_contents($functions_php, $content . $snippet);
        delete_transient('rsa_audit_result');

        return [
            'success' => true,
            'message' => "Añadido add_theme_support('title-tag') al functions.php del tema hijo ({$child_theme_dir}). WordPress ahora gestionará el <title> de forma estándar. Vuelve a ejecutar la auditoría para confirmar.",
        ];
    }

    /* ═══════════════════════════════════════════════════════════
     *  POLYLANG — HREFLANG
     * ═══════════════════════════════════════════════════════════ */

    private function fix_pll_hreflang(): array {
        if (!function_exists('pll_languages_list')) {
            return ['success' => false, 'message' => 'Polylang no está activo.'];
        }

        $options = get_option('polylang', []);
        if (empty($options)) {
            return ['success' => false, 'message' => 'No se encontraron opciones de Polylang.'];
        }

        $changed   = false;
        $messages  = [];

        // 1. Ensure URL modification is enabled (subdirectory)
        if (($options['force_lang'] ?? 0) == 0) {
            $options['force_lang'] = 1;
            $changed = true;
            $messages[] = 'URLs de idioma configuradas como subdirectorio (/en/)';
        }

        // 2. Ensure hreflang is not explicitly disabled
        if (isset($options['hreflang']) && !$options['hreflang']) {
            $options['hreflang'] = 1;
            $changed = true;
            $messages[] = 'hreflang reactivado';
        }

        if ($changed) {
            update_option('polylang', $options);
        }

        // 3. Verify front page has translations
        $front_id  = get_option('page_on_front');
        $languages = pll_languages_list(['fields' => 'slug']);
        if ($front_id) {
            $translations = pll_get_post_translations($front_id);
            $missing = array_diff($languages, array_keys($translations));
            if (!empty($missing)) {
                $messages[] = 'AVISO: La portada no tiene traducción para: ' . implode(', ', $missing) . '. Crea las traducciones en Pages para que hreflang funcione';
            }
        }

        // flush rewrite rules
        flush_rewrite_rules();
        delete_transient('rsa_audit_result');

        if (empty($messages)) {
            return ['success' => true, 'message' => 'Polylang ya tenía hreflang configurado correctamente.'];
        }
        return ['success' => true, 'message' => implode('. ', $messages) . '.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  DATABASE — CLEAN REVISIONS
     * ═══════════════════════════════════════════════════════════ */

    private function fix_db_clean_revisions(): array {
        global $wpdb;

        // Keep last 3 revisions per post, delete older ones
        $deleted = $wpdb->query(
            "DELETE r FROM {$wpdb->posts} r
             WHERE r.post_type = 'revision'
             AND r.ID NOT IN (
                 SELECT ID FROM (
                     SELECT ID FROM {$wpdb->posts}
                     WHERE post_type = 'revision'
                     ORDER BY post_date DESC
                     LIMIT 1000000
                 ) AS keep_recent
             )"
        );

        // Simpler approach: delete all revisions older than 30 days
        $deleted = $wpdb->query(
            "DELETE FROM {$wpdb->posts} 
             WHERE post_type = 'revision' 
             AND post_date < DATE_SUB(NOW(), INTERVAL 30 DAY)"
        );

        if ($deleted === false) {
            return ['success' => false, 'message' => 'Error al eliminar revisiones: ' . $wpdb->last_error];
        }

        // Clean orphaned postmeta
        $wpdb->query(
            "DELETE pm FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE p.ID IS NULL"
        );

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => "Eliminadas {$deleted} revisiones antiguas (>30 días). Añade 'define(\"WP_POST_REVISIONS\", 3);' a wp-config.php para limitar futuras revisiones."];
    }

    /* ═══════════════════════════════════════════════════════════
     *  DATABASE — CLEAN EXPIRED TRANSIENTS
     * ═══════════════════════════════════════════════════════════ */

    private function fix_db_clean_transients(): array {
        global $wpdb;

        // Delete expired transients
        $time = time();
        $expired = $wpdb->query(
            "DELETE a, b FROM {$wpdb->options} a
             INNER JOIN {$wpdb->options} b ON b.option_name = CONCAT('_transient_timeout_', SUBSTRING(a.option_name, 12))
             WHERE a.option_name LIKE '_transient_%'
             AND a.option_name NOT LIKE '_transient_timeout_%'
             AND b.option_value < {$time}"
        );

        // Also delete orphaned transient timeouts
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_timeout_%'
             AND option_value < {$time}"
        );

        // Optimize options table
        $wpdb->query("OPTIMIZE TABLE {$wpdb->options}");

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => "Limpiados transients expirados. Tabla wp_options optimizada."];
    }

    /* ═══════════════════════════════════════════════════════════
     *  DATABASE — CLEAN SPAM AND TRASH COMMENTS
     * ═══════════════════════════════════════════════════════════ */

    private function fix_db_clean_spam(): array {
        global $wpdb;

        $spam = $wpdb->query("DELETE FROM {$wpdb->comments} WHERE comment_approved = 'spam'");
        $trash = $wpdb->query("DELETE FROM {$wpdb->comments} WHERE comment_approved = 'trash'");

        // Clean orphaned comment meta
        $wpdb->query(
            "DELETE FROM {$wpdb->commentmeta}
             WHERE comment_id NOT IN (SELECT comment_ID FROM {$wpdb->comments})"
        );

        delete_transient('rsa_audit_result');
        $total = ($spam ?: 0) + ($trash ?: 0);
        return ['success' => true, 'message' => "Eliminados {$total} comentarios (spam: {$spam}, papelera: {$trash})."];
    }

    /* ═══════════════════════════════════════════════════════════
     *  DATABASE — CLEAN LARGE TRANSIENTS
     * ═══════════════════════════════════════════════════════════ */

    private function fix_db_clean_large_transients(): array {
        global $wpdb;

        // Delete transients larger than 100KB
        $deleted = $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_%'
             AND option_name NOT LIKE '_transient_timeout_%'
             AND LENGTH(option_value) > 102400"
        );

        // Also clean their timeouts
        $wpdb->query(
            "DELETE a FROM {$wpdb->options} a
             WHERE a.option_name LIKE '_transient_timeout_%'
             AND NOT EXISTS (
                 SELECT 1 FROM (SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '_transient_%' AND option_name NOT LIKE '_transient_timeout_%') b
                 WHERE b.option_name = CONCAT('_transient_', SUBSTRING(a.option_name, 20))
             )"
        );

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => "Eliminados {$deleted} transients grandes (>100KB). Plugins que generan transients grandes deberían usar object cache."];
    }

    /* ═══════════════════════════════════════════════════════════
     *  DATABASE — CLEAN ORPHANED POSTMETA
     * ═══════════════════════════════════════════════════════════ */

    private function fix_db_clean_orphaned_meta(): array {
        global $wpdb;

        $deleted = $wpdb->query(
            "DELETE pm FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE p.ID IS NULL"
        );

        if ($deleted === false) {
            return ['success' => false, 'message' => 'Error: ' . $wpdb->last_error];
        }

        // Also clean orphaned termmeta
        $term_deleted = $wpdb->query(
            "DELETE tm FROM {$wpdb->termmeta} tm
             LEFT JOIN {$wpdb->terms} t ON tm.term_id = t.term_id
             WHERE t.term_id IS NULL"
        );

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => "Eliminados {$deleted} registros postmeta huérfanos" . ($term_deleted ? " y {$term_deleted} termmeta huérfanos" : '') . ". BD más ligera."];
    }

    /* ═══════════════════════════════════════════════════════════
     *  WORDPRESS — INCREASE MEMORY LIMIT
     * ═══════════════════════════════════════════════════════════ */

    private function fix_wp_memory_limit(): array {
        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path)) {
            $config_path = dirname(ABSPATH) . '/wp-config.php';
        }
        if (!file_exists($config_path) || !is_writable($config_path)) {
            return ['success' => false, 'message' => 'wp-config.php no encontrado o sin permisos de escritura.'];
        }

        $content = file_get_contents($config_path);

        // Check if already defined
        if (preg_match("/define\s*\(\s*['\"]WP_MEMORY_LIMIT['\"]\s*,\s*['\"](\d+)M['\"]\s*\)/i", $content, $m)) {
            $current = (int)$m[1];
            if ($current >= 256) {
                return ['success' => true, 'message' => "WP_MEMORY_LIMIT ya está en {$current}M."];
            }
            // Update existing
            $content = preg_replace(
                "/define\s*\(\s*['\"]WP_MEMORY_LIMIT['\"]\s*,\s*['\"][^'\"]+['\"]\s*\)/i",
                "define('WP_MEMORY_LIMIT', '256M')",
                $content
            );
        } else {
            // Add new
            $markers = [
                "/* That's all",
                "/** That's all",
                "require_once ABSPATH . 'wp-settings.php'",
            ];
            $inserted = false;
            foreach ($markers as $marker) {
                $pos = strpos($content, $marker);
                if ($pos !== false) {
                    $insert = "\n/* Memory limits */\ndefine('WP_MEMORY_LIMIT', '256M');\ndefine('WP_MAX_MEMORY_LIMIT', '512M');\n\n";
                    $content = substr($content, 0, $pos) . $insert . substr($content, $pos);
                    $inserted = true;
                    break;
                }
            }
            if (!$inserted) {
                return ['success' => false, 'message' => 'No se encontró un punto de inserción en wp-config.php.'];
            }
        }

        $this->maybe_backup_config($config_path);
        file_put_contents($config_path, $content);
        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'WP_MEMORY_LIMIT aumentado a 256M. Si el servidor lo permite, PHP usará más memoria.'];
    }

    /* ═══════════════════════════════════════════════════════════
     *  WORDPRESS — RUN OVERDUE CRON JOBS
     * ═══════════════════════════════════════════════════════════ */

    private function fix_wp_cron_run_overdue(): array {
        $crons = _get_cron_array();
        if (!is_array($crons)) {
            return ['success' => true, 'message' => 'No hay tareas cron.'];
        }

        $executed = 0;
        $now = time();

        foreach ($crons as $timestamp => $hooks) {
            if ($timestamp > $now) continue; // Not overdue
            if (!is_array($hooks)) continue;

            foreach ($hooks as $hook => $events) {
                foreach ($events as $key => $event) {
                    // Execute the cron event — wrap in try/catch so a broken hook
                    // (e.g. a third-party plugin calling a missing method) doesn't
                    // abort the rest of the queue.
                    try {
                        do_action_ref_array($hook, $event['args'] ?? []);
                        $executed++;
                    } catch (\Throwable $e) {
                        error_log('[RSA cron fix] Hook "' . $hook . '" falló: ' . $e->getMessage());
                        // Count as attempted but skip rescheduling for broken hooks
                        continue;
                    }

                    // Handle scheduling
                    if (!empty($event['schedule'])) {
                        $schedules = wp_get_schedules();
                        $interval  = $schedules[$event['schedule']]['interval'] ?? 0;
                        if ($interval) {
                            wp_schedule_event($now + $interval, $event['schedule'], $hook, $event['args'] ?? []);
                        }
                    }
                }
            }

            // Remove the old timestamp
            unset($crons[$timestamp]);
        }

        _set_cron_array($crons);

        // IMPORTANT: Also suggest/attempt to set up real cron
        $cron_url = site_url('wp-cron.php');
        $cron_suggestion = "\n\nIMPORTANTE: Para evitar que las tareas se vuelvan a acumular, configura un cron real:\n"
            . "1. En tu hosting: Cron Jobs cada 5 min: wget -q -O - {$cron_url} > /dev/null 2>&1\n"
            . "2. O añade 'define(\"DISABLE_WP_CRON\", true);' en wp-config.php y usa el cron del servidor.";

        return ['success' => true, 'message' => "Ejecutadas {$executed} tareas cron atrasadas. Cola limpiada." . $cron_suggestion];
    }

    /* ═══════════════════════════════════════════════════════════
     *  WORDPRESS — OPTIMIZE HEARTBEAT
     * ═══════════════════════════════════════════════════════════ */

    private function fix_heartbeat_optimize(): array {
        // Add a mu-plugin to control Heartbeat
        $mu_dir = WPMU_PLUGIN_DIR;
        if (!is_dir($mu_dir)) {
            if (!wp_mkdir_p($mu_dir)) {
                return ['success' => false, 'message' => 'No se pudo crear el directorio mu-plugins.'];
            }
        }

        $mu_file = $mu_dir . '/replanta-heartbeat-control.php';
        $code = <<<'PHP'
<?php
/**
 * Replanta Heartbeat Control
 * Optimizes WordPress Heartbeat API to reduce server load.
 * Generated by Replanta Site Audit.
 */

// Disable Heartbeat on dashboard and most pages
add_action('init', function() {
    // Allow on post edit screens for autosave
    global $pagenow;
    if (!in_array($pagenow, ['post.php', 'post-new.php'])) {
        wp_deregister_script('heartbeat');
    }
}, 1);

// Slow down Heartbeat where it's needed (post edit)
add_filter('heartbeat_settings', function($settings) {
    $settings['interval'] = 120; // 120 seconds instead of default 15-60
    return $settings;
});
PHP;

        if (file_put_contents($mu_file, $code) === false) {
            return ['success' => false, 'message' => 'No se pudo escribir el archivo mu-plugin.'];
        }

        delete_transient('rsa_audit_result');
        return ['success' => true, 'message' => 'Heartbeat optimizado: desactivado en dashboard, intervalo 120s en editor. Archivo: ' . basename($mu_file)];
    }

    /* ────────────────────────────────────────
     *  META FILL (integra con replanta-meta-fill)
     * ════════════════════════════════════════ */

    /**
     * Rellena hasta 5 metas vacíos usando replanta-meta-fill.
     * El Bot de Salud hace el grueso (máx configurado); este fix
     * se dispara desde el botón manual en la sección de issues.
     */
    private function fix_fill_empty_metas(array $context = []): array {
        if (!class_exists('Replanta_Meta_Fill_OpenAI_Handler')) {
            return ['success' => false, 'message' => 'replanta-meta-fill no está instalado o activo.'];
        }

        if (!class_exists('RSA_Bot_Healer')) {
            return ['success' => false, 'message' => 'RSA_Bot_Healer no disponible.'];
        }

        $limit  = (int)($context['limit'] ?? 5);
        $posts  = RSA_Bot_Healer::get_instance()->get_posts_without_meta(['post', 'page'], $limit);

        if (empty($posts)) {
            return ['success' => true, 'message' => 'Todos los posts ya tienen meta descripción.'];
        }

        $openai = Replanta_Meta_Fill_OpenAI_Handler::instance();
        $filled = 0;
        $errors = 0;

        foreach ($posts as $i => $post) {
            if ($i > 0) sleep(1); // Rate-limit OpenAI
            $result = $openai->generate_meta_description($post->ID);
            $result['success'] ? $filled++ : $errors++;
        }

        if ($filled === 0) {
            return ['success' => false, 'message' => "No se pudieron generar metas ($errors errores)."];
        }

        return [
            'success' => true,
            'message' => "Rellenadas $filled meta descripciones" . ($errors ? " ($errors errores)" : '') . '. El bot puede rellenar el resto automáticamente.',
        ];
    }

    private function fix_sync_outdated_translations(array $context = []): array {
        if ( ! class_exists( 'RSA_Translation_Sync' ) || ! RSA_Translation_Sync::is_available() ) {
            return [ 'success' => false, 'message' => 'Polylang no disponible o RSA_Translation_Sync no cargado.' ];
        }

        $sync  = RSA_Translation_Sync::get_instance();
        $limit = (int) ( $context['limit'] ?? 3 );
        $items = $sync->get_outdated_translations( [ 'page', 'post' ], $limit );

        if ( empty( $items ) ) {
            return [ 'success' => true, 'message' => 'Todas las traducciones EN ya están actualizadas.' ];
        }

        $synced = 0;
        $errors = 0;
        $msgs   = [];

        foreach ( $items as $i => $item ) {
            if ( $i > 0 ) sleep( 2 ); // Rate-limit between OpenAI batch calls
            $result = $sync->sync_post( $item['es_id'], $item['en_id'] );
            if ( $result['success'] ) {
                $synced++;
                $msgs[] = '"' . $item['title'] . '" (' . $result['translated'] . ' cadenas)';
            } else {
                $errors++;
            }
        }

        if ( $synced === 0 ) {
            return [ 'success' => false, 'message' => "No se pudo sincronizar ninguna traducción ($errors errores)." ];
        }

        return [
            'success' => true,
            'message' => "Sincronizadas $synced páginas: " . implode( ', ', $msgs ) . ( $errors ? " ($errors errores)" : '' ),
        ];
    }

    /* ══════════════════════════ v2.6: NEW FIXES ══════════════════════════ */

    /**
     * Habilita LiteSpeed Object Cache (requiere Redis/Memcached en servidor).
     */
    private function fix_ls_enable_object_cache(): array {
        if (!class_exists('LiteSpeed_Cache') && !defined('LSCWP_V')) {
            return ['success' => false, 'message' => 'LiteSpeed Cache plugin no instalado.'];
        }
        // LSCWP stores settings as individual options prefixed litespeed.conf.*
        update_option('litespeed.conf.object-cache', 1);
        // Reload LSCWP config if the action exists
        do_action('litespeed_update_conf', 'object-cache', 1);
        do_action('litespeed_update_conf_option', 'object-cache', 1);
        return [
            'success' => true,
            'message' => 'LiteSpeed Object Cache habilitado en la configuración. '
                . 'Próximo paso: ve a LSCWP → Caché → Object Cache y selecciona Redis o Memcached '
                . '(debe estar disponible en el servidor — consulta con tu hosting).',
        ];
    }

    /**
     * Activa Critical CSS (generación + async loading) en LiteSpeed Cache.
     * Mejora LCP/CLS con temas como Astra eliminando render-blocking CSS.
     */
    private function fix_ls_enable_ccss(): array {
        if (!class_exists('LiteSpeed_Cache') && !defined('LSCWP_V')) {
            return ['success' => false, 'message' => 'LiteSpeed Cache plugin no instalado.'];
        }
        update_option('litespeed.conf.optm-ccss_gen', 1);
        update_option('litespeed.conf.optm-ccss_async', 1);
        do_action('litespeed_update_conf', 'optm-ccss_gen', 1);
        do_action('litespeed_update_conf', 'optm-ccss_async', 1);
        return [
            'success' => true,
            'message' => 'Critical CSS habilitado (generación + async loading). '
                . 'La primera visita a cada página generará su CSS crítico. '
                . 'Visita las páginas principales para precalentar el CCSS.',
        ];
    }

    /**
     * Crea Cache Rules básicas en Cloudflare via Rulesets API.
     * Regla 1: bypass wp-admin / POST requests.
     * Regla 2: cachear HTML GET para visitantes no logueados.
     */
    private function fix_cf_create_cache_rules(): array {
        if (!$this->zone_id || !$this->cf) {
            return ['success' => false, 'message' => 'Cloudflare no configurado o sin zona encontrada.'];
        }

        // CF Rulesets API — phase: http_request_cache_settings
        // Only valid action is "set_cache_settings".
        // To bypass: set_cache_settings with action_parameters.cache = false
        //
        // IMPORTANT — "last matching rule wins" in CF Rulesets.
        // Rule 2 must explicitly exclude all paths Rule 1 bypasses, otherwise
        // a visitor GET to /wp-cron.php or /wp-json/ matches both rules and
        // Rule 2 (cache: true) would silently override Rule 1 (cache: false).

        $bypass_paths = '(http.request.uri.path contains "/wp-admin") '
                      . 'or (http.request.uri.path contains "/wp-login.php") '
                      . 'or (http.request.uri.path contains "/wp-cron.php") '
                      . 'or (http.request.uri.path contains "/wp-json/")';

        $rules = [
            [
                'action'            => 'set_cache_settings',
                'expression'        => "({$bypass_paths})"
                                     . ' or (http.request.method ne "GET")'
                                     . ' or (http.cookie contains "wordpress_logged_in")',
                'description'       => 'RSA: Bypass — wp-admin, login, cron, REST API, no-GET, usuarios logueados',
                'enabled'           => true,
                'action_parameters' => ['cache' => false],
            ],
            [
                'action'            => 'set_cache_settings',
                // Inverse of rule 1: only fires when NONE of the bypass conditions apply
                'expression'        => '(http.request.method eq "GET") '
                                     . 'and (not http.cookie contains "wordpress_logged_in") '
                                     . 'and (not http.request.uri.path contains "/wp-admin") '
                                     . 'and (not http.request.uri.path contains "/wp-login.php") '
                                     . 'and (not http.request.uri.path contains "/wp-cron.php") '
                                     . 'and (not http.request.uri.path contains "/wp-json/")',
                'description'       => 'RSA: Cachear GET visitantes — 1h edge TTL, browser sigue origin',
                'enabled'           => true,
                'action_parameters' => [
                    'cache'       => true,
                    'edge_ttl'    => ['mode' => 'override_origin', 'default' => 3600],
                    'browser_ttl' => ['mode' => 'respect_origin'],
                    'cache_key'   => ['ignore_query_strings_order' => true],
                ],
            ],
        ];

        $endpoint = "/zones/{$this->zone_id}/rulesets/phases/http_request_cache_settings/entrypoint";
        $result   = $this->cf->api_put($endpoint, ['rules' => $rules]);

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => 'Error CF API: ' . $result->get_error_message()];
        }
        if (!empty($result['success'])) {
            return [
                'success' => true,
                'message' => 'Cache Rules creadas en Cloudflare: '
                    . '(1) Bypass wp-admin/POST/usuarios logueados, '
                    . '(2) Caché HTML 1h para visitantes GET. '
                    . 'El hit ratio mejorará en las próximas horas.',
            ];
        }

        // Si ya existe el ruleset, intentar con PATCH
        $err = $result['errors'][0]['message'] ?? json_encode($result);
        if (strpos($err, 'already exists') !== false || strpos($err ?? '', '10016') !== false) {
            $existing = $this->cf->api_get($endpoint);
            $rid = $existing['result']['id'] ?? null;
            if ($rid) {
                $upd = $this->cf->api_put("/zones/{$this->zone_id}/rulesets/{$rid}", ['rules' => $rules]);
                if (!is_wp_error($upd) && !empty($upd['success'])) {
                    return ['success' => true, 'message' => 'Cache Rules actualizadas con configuración básica.'];
                }
            }
        }

        return ['success' => false, 'message' => 'No se pudieron crear Cache Rules: ' . $err
            . '. Puede requerir CF plan Pro o permisos Zone.Cache Rules en el token API.'];
    }

    /**
     * Activa el plugin replanta-sitemap-hreflang para inyectar <xhtml:link> en el sitemap XML.
     */
    private function fix_activate_hreflang_plugin(): array {
        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugin_file = 'replanta-sitemap-hreflang/replanta-sitemap-hreflang.php';

        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        if (is_plugin_active($plugin_file)) {
            return ['success' => true, 'message' => 'replanta-sitemap-hreflang ya estaba activo.'];
        }

        if (!file_exists(WP_PLUGIN_DIR . '/' . $plugin_file)) {
            return ['success' => false, 'message' => 'Plugin replanta-sitemap-hreflang no encontrado en ' . WP_PLUGIN_DIR . '. Sube el plugin primero.'];
        }

        $result = activate_plugin($plugin_file);
        if (is_wp_error($result)) {
            return ['success' => false, 'message' => 'Error activando plugin: ' . $result->get_error_message()];
        }
        return [
            'success' => true,
            'message' => 'Plugin replanta-sitemap-hreflang activado. '
                . 'El sitemap XML incluirá <xhtml:link hreflang> en la próxima regeneración. '
                . 'Limpia la caché del sitemap desde RankMath → Ajustes → Sitemap.',
        ];
    }
}
