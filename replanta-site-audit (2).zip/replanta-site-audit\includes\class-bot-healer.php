<?php
/**
 * Bot de Salud — Auto-Healer v1.0
 *
 * Ejecuta la auditoría periódicamente via WP-Cron, aplica todos
 * los fixes automáticos disponibles y rellena metas vacíos usando
 * replanta-meta-fill. Guarda log completo de cada acción.
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Bot_Healer {

    const LOG_OPTION      = 'rsa_bot_log';
    const SETTINGS_OPTION = 'rsa_bot_settings';
    const MAX_LOG_ENTRIES = 200;
    const CRON_HOOK       = 'rsa_bot_healer_run';

    private static ?RSA_Bot_Healer $instance = null;

    public static function get_instance(): RSA_Bot_Healer {
        return self::$instance ??= new self();
    }

    private function __construct() {
        add_action(self::CRON_HOOK, [$this, 'run']);
        add_action('init', [$this, 'maybe_schedule']);
        add_action('rsa_weekly_digest', [$this, 'send_weekly_digest']);

        // AJAX handlers
        add_action('wp_ajax_rsa_bot_run_now',        [$this, 'ajax_run_now']);
        add_action('wp_ajax_rsa_bot_toggle',         [$this, 'ajax_toggle']);
        add_action('wp_ajax_rsa_bot_clear_log',      [$this, 'ajax_clear_log']);
        add_action('wp_ajax_rsa_bot_save_settings',  [$this, 'ajax_save_settings']);
        add_action('wp_ajax_rsa_bot_get_log',        [$this, 'ajax_get_log']);
        add_action('wp_ajax_rsa_bot_scan_only',      [$this, 'ajax_scan_only']);
    }

    /* ═══════════════════════════════════════════════════════════
     *  CRON MANAGEMENT
     * ═══════════════════════════════════════════════════════════ */

    public function maybe_schedule(): void {
        $settings  = $this->get_settings();
        $scheduled = wp_next_scheduled(self::CRON_HOOK);

        if (!$settings['enabled']) {
            if ($scheduled) {
                wp_clear_scheduled_hook(self::CRON_HOOK);
            }
            return;
        }

        if (!$scheduled) {
            wp_schedule_event(time(), $settings['schedule'], self::CRON_HOOK);
            return;
        }

        // Detect if the schedule interval has changed and reschedule if so
        $crons = _get_cron_array();
        foreach ($crons as $hooks) {
            if (!isset($hooks[self::CRON_HOOK])) {
                continue;
            }
            foreach ($hooks[self::CRON_HOOK] as $event) {
                $current_interval = $event['schedule'] ?? '';
                if ($current_interval && $current_interval !== $settings['schedule']) {
                    wp_clear_scheduled_hook(self::CRON_HOOK);
                    wp_schedule_event(time() + 60, $settings['schedule'], self::CRON_HOOK);
                }
                return;
            }
        }
    }

    public static function on_activate(): void {
        $settings = self::get_instance()->get_settings();
        if ($settings['enabled'] && !wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), $settings['schedule'], self::CRON_HOOK);
        }
        if (!wp_next_scheduled('rsa_weekly_digest')) {
            wp_schedule_event(strtotime('next monday 08:00:00'), 'weekly', 'rsa_weekly_digest');
        }
    }

    public static function on_deactivate(): void {
        wp_clear_scheduled_hook(self::CRON_HOOK);
        wp_clear_scheduled_hook('rsa_weekly_digest');
    }

    /* ═══════════════════════════════════════════════════════════
     *  MAIN RUNNER
     * ═══════════════════════════════════════════════════════════ */

    public function run(): void {
        $this->log('info', 'bot_run', 'Bot de Salud iniciado');
        $settings = $this->get_settings();

        // Step 1: Audit + auto-fix
        $this->run_audit_and_fix();

        // Step 2: Core Web Vitals — refresh diario via PageSpeed Insights
        $this->refresh_core_web_vitals();

        // Step 3: Fill empty metas
        if ($settings['fill_metas']) {
            $this->fill_empty_metas();
        }

        // Step 4: Sync outdated translations (ES → EN)
        if (!empty($settings['sync_translations'])) {
            $this->sync_translations();
        }

        $this->log('success', 'bot_run', 'Bot de Salud completado — ' . current_time('d/m/Y H:i'));
    }

    /* ─────────── Step 1b: Core Web Vitals refresh ─────────── */

    private function refresh_core_web_vitals(): void {
        if (!class_exists('RSA_Core_Web_Vitals')) {
            return;
        }
        $this->log('info', 'cwv', 'Actualizando Core Web Vitals via PageSpeed Insights...');
        try {
            (new RSA_Core_Web_Vitals())->refresh();
            $this->log('success', 'cwv', 'Core Web Vitals actualizados (caché 24h)');
        } catch (\Throwable $e) {
            $this->log('error', 'cwv', 'Error CWV: ' . $e->getMessage());
        }
    }

    /* ─────────── Step 1: Audit + Fix ─────────── */

    private function run_audit_and_fix(): void {
        $this->log('info', 'audit', 'Ejecutando auditoría completa...');

        try {
            // Force fresh (bypass transient)
            $result = RSA_Audit_Engine::run(false);

            $this->log('info', 'audit', sprintf(
                'Auditoría completada: Score %d%% · %d críticos · %d avisos · %d corregibles',
                $result['global_score'],
                $result['summary']['critical'],
                $result['summary']['warnings'],
                $result['summary']['fixable'] ?? 0
            ));

            // Collect fixable issues
            $issues  = RSA_Audit_Engine::get_issues($result['checks']);
            $fixable = array_filter($issues, fn($c) => !empty($c['fixable']));

            if (empty($fixable)) {
                $this->log('success', 'audit_fix', 'No hay issues corregibles pendientes');
                return;
            }

            $fixer = RSA_Auto_Fixer::get_instance();

            foreach ($fixable as $check) {
                // Skip meta_fill here — handled by Step 2 with rate limiting
                if (($check['fix_id'] ?? '') === 'fill_empty_metas') {
                    continue;
                }

                $fix_result = $fixer->execute($check['fix_id']);

                if ($fix_result['success']) {
                    $this->log('success', 'audit_fix', sprintf(
                        'Fix aplicado [%s]: %s — %s',
                        $check['fix_id'],
                        $check['label'],
                        $fix_result['message']
                    ));
                } else {
                    $this->log('error', 'audit_fix', sprintf(
                        'Fix fallido [%s]: %s',
                        $check['fix_id'],
                        $fix_result['message']
                    ));
                }
            }

        } catch (\Throwable $e) {
            $this->log('error', 'audit', 'Error en auditoría: ' . $e->getMessage());
            return;
        }

        // Email alert on critical drop
        $settings = $this->get_settings();
        if (!empty($settings['notify_on_critical']) && !empty($settings['notify_email'])) {
            $history    = RSA_Audit_Engine::get_history();
            $prev_score = count($history) >= 2 ? (int)($history[count($history) - 2]['global_score'] ?? 100) : 100;
            if (($result['summary']['critical'] ?? 0) > 0 || $result['global_score'] < $prev_score - 10) {
                $this->send_critical_alert($result, $prev_score, $settings['notify_email']);
            }
        }
    }

    /* ─────────── Step 2: Fill Empty Metas ─────────── */

    private function fill_empty_metas(): void {
        if (!class_exists('Replanta_Meta_Fill_OpenAI_Handler')) {
            $this->log('error', 'meta_fill', 'Plugin replanta-meta-fill no disponible o no activo');
            return;
        }

        $settings   = $this->get_settings();
        $post_types = $settings['meta_post_types'] ?? ['post', 'page'];
        $max_posts  = $settings['meta_max_per_run'] ?? 10;

        $posts_needing = $this->get_posts_without_meta($post_types, $max_posts);

        if (empty($posts_needing)) {
            $this->log('success', 'meta_fill', 'Todos los posts tienen meta descripción');
            return;
        }

        $this->log('info', 'meta_fill', sprintf(
            'Encontrados %d posts sin meta descripción (rellenando hasta %d)...',
            count($posts_needing),
            $max_posts
        ));

        $openai = Replanta_Meta_Fill_OpenAI_Handler::instance();
        $filled = 0;
        $errors = 0;

        foreach ($posts_needing as $post) {
            // Rate-limit: pause between OpenAI calls
            if ($filled > 0) {
                sleep(1);
            }

            $result = $openai->generate_meta_description($post->ID);

            if (!empty($result['success'])) {
                $filled++;
                $this->log(
                    'success',
                    'meta_fill',
                    sprintf(
                        '[%d] %s — "%s..."',
                        $post->ID,
                        $post->post_title,
                        substr($result['meta_description'] ?? '', 0, 80)
                    ),
                    $post->ID
                );
            } else {
                $errors++;
                $this->log(
                    'error',
                    'meta_fill',
                    sprintf(
                        '[%d] %s — %s',
                        $post->ID,
                        $post->post_title,
                        $result['error'] ?? 'Error desconocido'
                    ),
                    $post->ID
                );
            }
        }

        $this->log('info', 'meta_fill', sprintf(
            'Meta fill completado: %d rellenadas · %d errores',
            $filled,
            $errors
        ));
    }

    /* ─────────── Step 3: Sync Translations ─────────── */

    private function sync_translations(): void {
        if ( ! class_exists( 'RSA_Translation_Sync' ) || ! RSA_Translation_Sync::is_available() ) {
            $this->log( 'error', 'translation_sync', 'Polylang no disponible — sincronización de traducciones omitida' );
            return;
        }

        $settings  = $this->get_settings();
        $max_items = (int) ( $settings['translations_max_per_run'] ?? 2 );
        $sync      = RSA_Translation_Sync::get_instance();
        $outdated  = $sync->get_outdated_translations( [ 'page', 'post' ], $max_items );

        if ( empty( $outdated ) ) {
            $this->log( 'success', 'translation_sync', 'Todas las traducciones EN están actualizadas' );
            return;
        }

        $this->log( 'info', 'translation_sync', sprintf(
            'Encontradas %d páginas EN desactualizadas (sincronizando hasta %d)...',
            count( $outdated ), $max_items
        ) );

        foreach ( $outdated as $i => $item ) {
            if ( $i > 0 ) sleep( 2 );

            $result = $sync->sync_post( $item['es_id'], $item['en_id'] );

            if ( $result['success'] ) {
                $this->log( 'success', 'translation_sync', sprintf(
                    'Sincronizado [ES:%d → EN:%d] "%s" — %s',
                    $item['es_id'], $item['en_id'],
                    $item['title'],
                    $result['message']
                ), $item['en_id'] );
            } else {
                $this->log( 'error', 'translation_sync', sprintf(
                    'Error [ES:%d → EN:%d] "%s" — %s',
                    $item['es_id'], $item['en_id'],
                    $item['title'],
                    $result['message']
                ), $item['en_id'] );
            }
        }
    }

    /* ─────────── Helpers ─────────── */

    /**
     * Get published posts of given types that have no meta description (any SEO plugin).
     */
    public function get_posts_without_meta(array $post_types, int $limit = 10): array {
        // Overfetch to account for posts that already have meta
        $posts = get_posts([
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => min($limit * 4, 200),
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ]);

        $without = [];

        foreach ($posts as $post) {
            if (count($without) >= $limit) break;
            if (empty(trim($this->get_post_meta_desc($post->ID)))) {
                $without[] = $post;
            }
        }

        return $without;
    }

    /**
     * Returns existing meta description from any installed SEO plugin.
     */
    public static function get_post_meta_desc(int $post_id): string {
        // RankMath
        $rm = get_post_meta($post_id, 'rank_math_description', true);
        if (!empty($rm)) return (string)$rm;

        // Yoast
        $yoast = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
        if (!empty($yoast)) return (string)$yoast;

        // SEOPress
        $seop = get_post_meta($post_id, '_seopress_titles_desc', true);
        if (!empty($seop)) return (string)$seop;

        // Generic fallback
        $gen = get_post_meta($post_id, '_meta_description', true);
        if (!empty($gen)) return (string)$gen;

        return '';
    }

    /* ═══════════════════════════════════════════════════════════
     *  AJAX HANDLERS
     * ═══════════════════════════════════════════════════════════ */

    public function ajax_scan_only(): void {
        check_ajax_referer( 'rsa_audit', '_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Sin permisos.' );

        try {
            // Run fresh audit (bypass cache)
            $result = RSA_Audit_Engine::run( false );

            // Count outdated translations if available
            $outdated_count = 0;
            if ( class_exists( 'RSA_Translation_Sync' ) && RSA_Translation_Sync::is_available() ) {
                $outdated = RSA_Translation_Sync::get_instance()->get_outdated_translations( [ 'page', 'post' ], 50 );
                $outdated_count = count( $outdated );
            }

            wp_send_json_success( [
                'score'              => $result['global_score']      ?? 0,
                'critical'           => $result['summary']['critical'] ?? 0,
                'warnings'           => $result['summary']['warnings'] ?? 0,
                'fixable'            => $result['summary']['fixable']  ?? 0,
                'outdated_translations' => $outdated_count,
                'checks'             => $result['checks']             ?? [],
            ] );
        } catch ( \Throwable $e ) {
            wp_send_json_error( 'Error al ejecutar scan: ' . $e->getMessage() );
        }
    }

    public function ajax_run_now(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos.');

        // Rate limit: 1 ejecución manual cada 5 minutos por usuario
        $rate_key = 'rsa_bot_run_rate_' . get_current_user_id();
        if (get_transient($rate_key)) {
            wp_send_json_error('Espera 5 minutos entre ejecuciones manuales del bot.');
        }
        set_transient($rate_key, 1, 300);

        $this->run();

        wp_send_json_success([
            'message'   => 'Bot ejecutado correctamente',
            'next_run'  => $this->get_next_run(),
            'last_run'  => $this->get_last_run(),
            'log_count' => count($this->get_log()),
        ]);
    }

    public function ajax_toggle(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos.');

        $settings            = $this->get_settings();
        $settings['enabled'] = !$settings['enabled'];
        $this->save_settings($settings);

        // Update cron accordingly
        wp_clear_scheduled_hook(self::CRON_HOOK);
        if ($settings['enabled']) {
            wp_schedule_event(time(), $settings['schedule'], self::CRON_HOOK);
            $this->log('info', 'config', 'Bot activado (cron ' . $settings['schedule'] . ')');
        } else {
            $this->log('info', 'config', 'Bot desactivado');
        }

        wp_send_json_success([
            'enabled'  => $settings['enabled'],
            'next_run' => $this->get_next_run(),
        ]);
    }

    public function ajax_clear_log(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos.');

        delete_option(self::LOG_OPTION);
        wp_send_json_success(['message' => 'Log borrado']);
    }

    public function ajax_save_settings(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos.');

        $schedule    = sanitize_text_field($_POST['schedule'] ?? 'daily');
        $fill_metas  = filter_var($_POST['fill_metas'] ?? true, FILTER_VALIDATE_BOOLEAN);
        $max_per_run = (int)($_POST['max_per_run'] ?? 10);
        $post_types  = array_map('sanitize_text_field', (array)($_POST['post_types'] ?? ['post', 'page']));

        $valid_schedules = ['hourly', 'twicedaily', 'daily', 'weekly'];
        if (!in_array($schedule, $valid_schedules, true)) $schedule = 'daily';
        $max_per_run = max(1, min(50, $max_per_run));

        $settings                      = $this->get_settings();
        $settings['schedule']          = $schedule;
        $settings['fill_metas']        = $fill_metas;
        $settings['meta_max_per_run']  = $max_per_run;
        $settings['meta_post_types']   = $post_types;
        $settings['sync_translations'] = filter_var(
            $_POST['sync_translations'] ?? false, FILTER_VALIDATE_BOOLEAN
        );
        $settings['translations_max_per_run'] = max( 1, min( 10, (int) ( $_POST['translations_max_per_run'] ?? 2 ) ) );
        $settings['notify_email']         = sanitize_email($_POST['notify_email'] ?? get_option('admin_email', ''));
        $settings['notify_on_critical']   = filter_var($_POST['notify_on_critical']   ?? false, FILTER_VALIDATE_BOOLEAN);
        $settings['notify_weekly_digest'] = filter_var($_POST['notify_weekly_digest'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $this->save_settings($settings);

        // Reschedule if enabled
        if ($settings['enabled']) {
            wp_clear_scheduled_hook(self::CRON_HOOK);
            wp_schedule_event(time() + 60, $schedule, self::CRON_HOOK);
        }

        $this->log('info', 'config', sprintf(
            'Configuración guardada: %s, meta-fill %s, máx %d posts',
            $schedule,
            $fill_metas ? 'activado' : 'desactivado',
            $max_per_run
        ));

        wp_send_json_success([
            'message'  => 'Configuración guardada',
            'next_run' => $this->get_next_run(),
        ]);
    }

    public function ajax_get_log(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos.');

        $filter = sanitize_text_field($_POST['filter'] ?? 'all');
        $log    = $this->get_log();

        if ($filter !== 'all') {
            $log = array_values(array_filter($log, fn($e) => $e['type'] === $filter || $e['status'] === $filter));
        }

        wp_send_json_success(['log' => array_slice($log, 0, 200)]);
    }

    /* ═══════════════════════════════════════════════════════════
     *  LOG
     * ═══════════════════════════════════════════════════════════ */

    public function log(string $status, string $type, string $message, int $post_id = 0): void {
        $log = get_option(self::LOG_OPTION, []);

        array_unshift($log, [
            'time'    => current_time('Y-m-d H:i:s'),
            'status'  => $status,   // success | error | info
            'type'    => $type,     // bot_run | audit | audit_fix | meta_fill | config
            'message' => $message,
            'post_id' => $post_id,
        ]);

        if (count($log) > self::MAX_LOG_ENTRIES) {
            $log = array_slice($log, 0, self::MAX_LOG_ENTRIES);
        }

        update_option(self::LOG_OPTION, $log, false);
    }

    public function get_log(): array {
        return get_option(self::LOG_OPTION, []);
    }

    /* ═══════════════════════════════════════════════════════════
     *  SETTINGS
     * ═══════════════════════════════════════════════════════════ */

    public function get_settings(): array {
        $defaults = [
            'enabled'                    => false,
            'schedule'                   => 'daily',
            'fill_metas'                 => true,
            'meta_max_per_run'           => 10,
            'meta_post_types'            => ['post', 'page'],
            'sync_translations'          => false,
            'translations_max_per_run'   => 2,
            'notify_email'               => get_option('admin_email', ''),
            'notify_on_critical'         => false,
            'notify_weekly_digest'       => false,
        ];
        return wp_parse_args(get_option(self::SETTINGS_OPTION, []), $defaults);
    }

    private function save_settings(array $settings): void {
        update_option(self::SETTINGS_OPTION, $settings, false);
    }

    /* ═══════════════════════════════════════════════════════════
     *  STATS HELPERS (for admin UI)
     * ═══════════════════════════════════════════════════════════ */

    public function get_next_run(): string {
        $next = wp_next_scheduled(self::CRON_HOOK);
        if (!$next) {
            return 'No programado';
        }
        if ($next < time()) {
            // Overdue — will fire on next frontend request (wp_spawn_cron handles it)
            return 'Pendiente (se ejecuta en la proxima peticion)';
        }
        return wp_date('d/m/Y H:i:s', $next);
    }

    public function get_last_run(): string {
        $log = $this->get_log();
        foreach ($log as $entry) {
            if ($entry['type'] === 'bot_run' && $entry['status'] === 'success') {
                return $entry['time'];
            }
        }
        return 'Nunca';
    }

    public function get_log_stats(): array {
        $log = $this->get_log();
        return [
            'total'               => count($log),
            'success'             => count(array_filter($log, fn($e) => $e['status'] === 'success')),
            'error'               => count(array_filter($log, fn($e) => $e['status'] === 'error')),
            'meta_fills'          => count(array_filter($log, fn($e) => $e['type'] === 'meta_fill' && $e['status'] === 'success')),
            'fixes'               => count(array_filter($log, fn($e) => $e['type'] === 'audit_fix' && $e['status'] === 'success')),
            'translations_synced' => count(array_filter($log, fn($e) => $e['type'] === 'translation_sync' && $e['status'] === 'success')),
        ];
    }

    public function count_posts_without_meta(): int {
        $settings = $this->get_settings();
        return count($this->get_posts_without_meta(
            $settings['meta_post_types'] ?? ['post', 'page'],
            100
        ));
    }

    /* ═══════════════════════════════════════════════════════════
     *  NOTIFICATIONS
     * ═══════════════════════════════════════════════════════════ */

    public function send_critical_alert(array $result, int $prev_score, string $email): void {
        $last_sent = (int) get_option('rsa_last_alert_sent', 0);
        if (time() - $last_sent < 86400) return; // max 1 alert per day
        update_option('rsa_last_alert_sent', time(), false);

        $site  = get_bloginfo('name');
        $url   = admin_url('admin.php?page=replanta-site-audit');
        $score = $result['global_score'];
        $crit  = $result['summary']['critical'] ?? 0;
        $drop  = $prev_score - $score;

        $subject = "[{$site}] ⚠️ Site Audit: score {$score}%" . ($drop > 0 ? " (bajó {$drop} pts)" : '');
        $body    = "Hola,\n\nEl Site Audit de {$site} ha detectado problemas:\n\n"
            . "Score actual: {$score}%\n"
            . ($drop > 0 ? "Caída: -{$drop} pts respecto a la auditoría anterior\n" : '')
            . "Issues críticos: {$crit}\n\n"
            . "Ver informe completo: {$url}\n\n"
            . "— Bot de Salud de Replanta";

        wp_mail($email, $subject, $body);
        $this->log('info', 'notification', "Alerta crítica enviada a {$email}");
    }

    public function send_weekly_digest(): void {
        $settings = $this->get_settings();
        if (empty($settings['notify_weekly_digest']) || empty($settings['notify_email'])) return;

        $email   = $settings['notify_email'];
        $site    = get_bloginfo('name');
        $url     = admin_url('admin.php?page=replanta-site-audit');
        $stats   = $this->get_log_stats();
        $history = RSA_Audit_Engine::get_history();
        $last    = !empty($history) ? end($history) : [];
        $current_score  = $last['global_score'] ?? '?';
        $week_ago_score = count($history) > 1 ? $history[max(0, count($history) - 8)]['global_score'] : $current_score;

        $subject = "[{$site}] 📊 Resumen semanal Site Audit — score {$current_score}%";
        $body    = "Resumen semanal de {$site}:\n\n"
            . "Score actual: {$current_score}%\n"
            . "Score hace 7 días: {$week_ago_score}%\n\n"
            . "Actividad del bot:\n"
            . "  Fixes aplicados:            {$stats['fixes']}\n"
            . "  Metas rellenadas:           {$stats['meta_fills']}\n"
            . "  Traducciones sincronizadas: {$stats['translations_synced']}\n"
            . "  Errores:                    {$stats['error']}\n\n"
            . "Ver informe: {$url}\n\n"
            . "— Bot de Salud de Replanta";

        wp_mail($email, $subject, $body);
        $this->log('info', 'notification', "Digest semanal enviado a {$email}");
    }
}
