<?php
/**
 * Translation Sync — Detects and updates outdated EN translations
 *
 * Requires Polylang. Compares ES (default) post modification dates
 * against their EN translation last-modified date. When the ES page
 * is newer, copies the Elementor/HTML structure and translates all
 * text content via OpenAI in a single batched request.
 *
 * Supported Elementor widgets: heading, text-editor, html, button,
 * image-box, icon-box, alert, testimonial, accordion, toggle, tabs,
 * icon-list, blockquote.
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RSA_Translation_Sync {

    /* Post-meta key used to mark the last time WE synced the EN post */
    const SYNCED_META = '_rsa_translation_synced';

    private static ?RSA_Translation_Sync $instance = null;

    /** Options from replanta-meta-fill (shares OpenAI key + model) */
    private array $openai_options = [];

    public static function get_instance(): RSA_Translation_Sync {
        return self::$instance ??= new self();
    }

    private function __construct() {
        $this->openai_options = get_option( 'replanta_meta_fill_options', [] );

        // If the meta-fill plugin has no key configured, fall back to the
        // key stored by this plugin (rsa_seo_save_settings → rsa_openai_api_key).
        if ( empty( $this->openai_options['openai_api_key'] ) ) {
            $rsa_key = get_option( 'rsa_openai_api_key', '' );
            if ( ! empty( $rsa_key ) ) {
                $this->openai_options['openai_api_key'] = $rsa_key;
            }
        }

        add_action( 'wp_ajax_rsa_translation_get_outdated',  [ $this, 'ajax_get_outdated' ] );
        add_action( 'wp_ajax_rsa_translation_sync_post',     [ $this, 'ajax_sync_post' ] );
        add_action( 'wp_ajax_rsa_translation_sync_status',   [ $this, 'ajax_sync_status' ] );
        add_action( 'rsa_translation_do_sync',               [ $this, 'cron_do_sync' ], 10, 3 );
    }

    /* ══════════════════════════════════════════════════════════
     *  AVAILABILITY
     * ══════════════════════════════════════════════════════════ */

    public static function is_available(): bool {
        return function_exists( 'pll_get_post_translations' )
            && function_exists( 'pll_get_post_language' );
    }

    /* ══════════════════════════════════════════════════════════
     *  DETECTION: which EN pages are outdated?
     * ══════════════════════════════════════════════════════════ */

    /**
     * Return list of ES posts whose EN translation is outdated
     * (i.e. ES was modified more recently than EN was last synced).
     *
     * @param  array $post_types  Post types to scan.
     * @param  int   $limit       Max items to return.
     * @return array[]            Each item: es_id, en_id, title, es_modified, en_modified, diff_days, has_elementor.
     */
    public function get_outdated_translations( array $post_types = [ 'page', 'post' ], int $limit = 30 ): array {

        if ( ! self::is_available() ) {
            return [];
        }

        // Fetch published Spanish posts
        $all_ids = get_posts( [
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => min( $limit * 6, 300 ),
            'fields'         => 'ids',
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => true,
            'lang'           => 'es',
        ] );

        $outdated = [];

        foreach ( $all_ids as $es_id ) {
            if ( count( $outdated ) >= $limit ) break;

            $lang = pll_get_post_language( $es_id, 'slug' );
            if ( $lang !== 'es' ) continue;

            $translations = pll_get_post_translations( $es_id );
            if ( empty( $translations['en'] ) ) continue;

            $en_id = (int) $translations['en'];
            if ( $en_id === $es_id ) continue;

            $es_post = get_post( $es_id );
            $en_post = get_post( $en_id );
            if ( ! $es_post || ! $en_post ) continue;
            if ( $en_post->post_status !== 'publish' ) continue;

            $es_ts = strtotime( $es_post->post_modified );
            $en_ts = strtotime( $en_post->post_modified );

            // The last time we (RSA) updated this EN post via sync
            $last_sync = (int) get_post_meta( $en_id, self::SYNCED_META, true );

            // Consider up-to-date if ES was modified before EN was last touched (by anyone or by us)
            if ( $es_ts <= max( $en_ts, $last_sync ) ) continue;

            $reference_ts = max( $en_ts, $last_sync );
            $diff_days    = ceil( ( $es_ts - $reference_ts ) / DAY_IN_SECONDS );

            $outdated[] = [
                'es_id'         => $es_id,
                'en_id'         => $en_id,
                'title'         => $es_post->post_title,
                'url_es'        => get_permalink( $es_id ),
                'url_en'        => get_permalink( $en_id ),
                'es_modified'   => $es_post->post_modified,
                'en_modified'   => $en_post->post_modified,
                'last_sync'     => $last_sync ? wp_date( 'Y-m-d H:i:s', $last_sync ) : null,
                'diff_days'     => (int) $diff_days,
                'has_elementor' => ! empty( get_post_meta( $es_id, '_elementor_data', true ) ),
            ];
        }

        // Most outdated first
        usort( $outdated, fn( $a, $b ) => $b['diff_days'] - $a['diff_days'] );

        return $outdated;
    }

    /* ══════════════════════════════════════════════════════════
     *  SYNC: copy structure + translate content
     * ══════════════════════════════════════════════════════════ */

    /**
     * Main entry point. Syncs a single ES → EN pair.
     *
     * @param  int $es_id  Spanish post ID.
     * @param  int $en_id  English post ID.
     * @return array       [ 'success' => bool, 'message' => string, 'translated' => int ]
     */
    public function sync_post( int $es_id, int $en_id ): array {

        $es_post = get_post( $es_id );
        $en_post = get_post( $en_id );

        if ( ! $es_post || ! $en_post ) {
            return [ 'success' => false, 'message' => "Posts no encontrados: ES $es_id / EN $en_id", 'translated' => 0 ];
        }

        try {
            $has_elementor = ! empty( get_post_meta( $es_id, '_elementor_data', true ) );
            $result        = $has_elementor
                ? $this->sync_elementor_post( $es_id, $en_id )
                : $this->sync_classic_post( $es_id, $en_id, $es_post );

            if ( $result['success'] ) {
                update_post_meta( $en_id, self::SYNCED_META, time() );
                $this->sync_post_title( $es_id, $en_id );
                $this->sync_post_excerpt( $es_id, $en_id );
            }

            return $result;

        } catch ( \Throwable $e ) {
            return [ 'success' => false, 'message' => 'Excepcion: ' . $e->getMessage(), 'translated' => 0 ];
        }
    }

    /* ──── Elementor sync ──── */

    private function sync_elementor_post( int $es_id, int $en_id ): array {

        $raw_json = get_post_meta( $es_id, '_elementor_data', true );
        if ( empty( $raw_json ) ) {
            return [ 'success' => false, 'message' => 'Sin datos Elementor en el post ES', 'translated' => 0 ];
        }

        $data = json_decode( $raw_json, true );
        if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
            return [ 'success' => false, 'message' => 'JSON Elementor invalido', 'translated' => 0 ];
        }

        // --- Collect all translatable strings ---
        $string_items = [];
        $this->extract_elementor_strings( $data, $string_items );

        if ( empty( $string_items ) ) {
            // Just copy structure, nothing to translate
            update_post_meta( $en_id, '_elementor_data', $raw_json );
            update_post_meta( $en_id, '_elementor_edit_mode', 'builder' );
            $this->flush_elementor_cache( $en_id );
            return [ 'success' => true, 'message' => 'Estructura Elementor copiada (sin texto traducible)', 'translated' => 0 ];
        }

        // --- Batch translate ---
        $texts        = array_column( $string_items, 'text' );
        $translations = $this->batch_translate( $texts, 'es', 'en' );

        if ( $translations === null ) {
            return [ 'success' => false, 'message' => 'Error al llamar a OpenAI para traduccion en batch', 'translated' => 0 ];
        }

        // Build original-text → translated-text map
        $map = [];
        foreach ( $string_items as $i => $item ) {
            if ( isset( $translations[ $i ] ) && $translations[ $i ] !== $item['text'] ) {
                $map[ $item['text'] ] = $translations[ $i ];
            }
        }

        // --- Apply translations in-place ---
        $translated_data = $data;
        $this->apply_elementor_translations( $translated_data, $map );

        // --- Persist ---
        $new_json = wp_json_encode( $translated_data, JSON_UNESCAPED_UNICODE );
        update_post_meta( $en_id, '_elementor_data', $new_json );
        update_post_meta( $en_id, '_elementor_edit_mode', 'builder' );
        $this->flush_elementor_cache( $en_id );

        return [
            'success'    => true,
            'message'    => sprintf( 'Elementor sincronizado: %d cadenas traducidas', count( $string_items ) ),
            'translated' => count( $string_items ),
        ];
    }

    private function sync_classic_post( int $es_id, int $en_id, \WP_Post $es_post ): array {

        if ( empty( trim( strip_tags( $es_post->post_content ) ) ) ) {
            return [ 'success' => true, 'message' => 'Contenido clasico vacio, nada que sincronizar', 'translated' => 0 ];
        }

        $translated = $this->translate_single_string( $es_post->post_content );
        if ( $translated === null ) {
            return [ 'success' => false, 'message' => 'Error al traducir contenido clasico', 'translated' => 0 ];
        }

        wp_update_post( [ 'ID' => $en_id, 'post_content' => $translated ], false, false );

        return [ 'success' => true, 'message' => 'Contenido clasico traducido', 'translated' => 1 ];
    }

    private function sync_post_title( int $es_id, int $en_id ): void {
        $es_title = get_post_field( 'post_title', $es_id );
        if ( empty( $es_title ) ) return;
        $en_title = $this->translate_single_string( $es_title );
        if ( $en_title ) {
            wp_update_post( [ 'ID' => $en_id, 'post_title' => $en_title ], false, false );
        }
    }

    private function sync_post_excerpt( int $es_id, int $en_id ): void {
        $es_excerpt = get_post_field( 'post_excerpt', $es_id );
        if ( empty( trim( $es_excerpt ) ) ) return;
        $en_excerpt = $this->translate_single_string( $es_excerpt );
        if ( $en_excerpt ) {
            wp_update_post( [ 'ID' => $en_id, 'post_excerpt' => $en_excerpt ], false, false );
        }
    }

    /* ══════════════════════════════════════════════════════════
     *  ELEMENTOR PARSER: extract strings
     * ══════════════════════════════════════════════════════════ */

    /**
     * Walk Elementor node tree and collect all translatable text fields.
     * Each item: [ 'text' => string, 'node_id' => string, 'widget' => string, 'field' => string ]
     */
    private function extract_elementor_strings( array $nodes, array &$items ): void {
        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) continue;

            if ( ! empty( $node['elements'] ) ) {
                $this->extract_elementor_strings( $node['elements'], $items );
            }

            $type   = $node['elType']     ?? '';
            $widget = $node['widgetType'] ?? '';

            if ( $type !== 'widget' && empty( $widget ) ) continue;

            $this->extract_widget_strings( $node, $items );
        }
    }

    private function extract_widget_strings( array $node, array &$items ): void {
        $widget   = $node['widgetType'] ?? '';
        $settings = $node['settings']   ?? [];
        $nid      = $node['id']         ?? uniqid( 'n' );

        // Widgets with simple string fields
        $simple = [
            'heading'      => [ 'title' ],
            'text-editor'  => [ 'editor' ],
            'text'         => [ 'editor' ],
            'html'         => [ 'html' ],
            'button'       => [ 'text' ],
            'image-box'    => [ 'title_text', 'description_text' ],
            'icon-box'     => [ 'title_text', 'description_text' ],
            'alert'        => [ 'alert_title', 'alert_description' ],
            'testimonial'  => [ 'testimonial_content', 'testimonial_name', 'testimonial_job' ],
            'blockquote'   => [ 'blockquote_content', 'tweet_button_label' ],
        ];

        if ( isset( $simple[ $widget ] ) ) {
            foreach ( $simple[ $widget ] as $field ) {
                if ( ! empty( $settings[ $field ] ) && is_string( $settings[ $field ] ) ) {
                    $items[] = [ 'text' => $settings[ $field ], 'node_id' => $nid, 'widget' => $widget, 'field' => $field ];
                }
            }
        }

        // Repeater widgets: accordion, tabs, toggle
        $tab_widgets = [ 'accordion', 'toggle', 'tabs' ];
        if ( in_array( $widget, $tab_widgets, true ) && ! empty( $settings['tabs'] ) && is_array( $settings['tabs'] ) ) {
            foreach ( $settings['tabs'] as $tk => $tab ) {
                foreach ( [ 'tab_title', 'tab_content' ] as $f ) {
                    if ( ! empty( $tab[ $f ] ) && is_string( $tab[ $f ] ) ) {
                        $items[] = [ 'text' => $tab[ $f ], 'node_id' => $nid, 'widget' => $widget, 'field' => "tabs.{$tk}.{$f}" ];
                    }
                }
            }
        }

        // Icon list
        if ( $widget === 'icon-list' && ! empty( $settings['icon_list'] ) && is_array( $settings['icon_list'] ) ) {
            foreach ( $settings['icon_list'] as $ik => $item ) {
                if ( ! empty( $item['text'] ) && is_string( $item['text'] ) ) {
                    $items[] = [ 'text' => $item['text'], 'node_id' => $nid, 'widget' => 'icon-list', 'field' => "icon_list.{$ik}.text" ];
                }
            }
        }
    }

    /* ══════════════════════════════════════════════════════════
     *  ELEMENTOR PARSER: apply translations
     * ══════════════════════════════════════════════════════════ */

    private function apply_elementor_translations( array &$nodes, array $map ): void {
        foreach ( $nodes as &$node ) {
            if ( ! is_array( $node ) ) continue;

            if ( ! empty( $node['elements'] ) ) {
                $this->apply_elementor_translations( $node['elements'], $map );
            }

            $type   = $node['elType']     ?? '';
            $widget = $node['widgetType'] ?? '';
            if ( $type !== 'widget' && empty( $widget ) ) continue;

            $s = &$node['settings'];

            // Simple fields
            $simple = [
                'heading'     => [ 'title' ],
                'text-editor' => [ 'editor' ],
                'text'        => [ 'editor' ],
                'html'        => [ 'html' ],
                'button'      => [ 'text' ],
                'image-box'   => [ 'title_text', 'description_text' ],
                'icon-box'    => [ 'title_text', 'description_text' ],
                'alert'       => [ 'alert_title', 'alert_description' ],
                'testimonial' => [ 'testimonial_content', 'testimonial_name', 'testimonial_job' ],
                'blockquote'  => [ 'blockquote_content', 'tweet_button_label' ],
            ];

            if ( isset( $simple[ $widget ] ) ) {
                foreach ( $simple[ $widget ] as $f ) {
                    if ( isset( $s[ $f ], $map[ $s[ $f ] ] ) ) {
                        $s[ $f ] = $map[ $s[ $f ] ];
                    }
                }
            }

            // Repeater (accordion/tabs/toggle)
            if ( in_array( $widget, [ 'accordion', 'toggle', 'tabs' ], true ) && ! empty( $s['tabs'] ) ) {
                foreach ( $s['tabs'] as &$tab ) {
                    foreach ( [ 'tab_title', 'tab_content' ] as $f ) {
                        if ( isset( $tab[ $f ], $map[ $tab[ $f ] ] ) ) {
                            $tab[ $f ] = $map[ $tab[ $f ] ];
                        }
                    }
                }
                unset( $tab );
            }

            // Icon list
            if ( $widget === 'icon-list' && ! empty( $s['icon_list'] ) ) {
                foreach ( $s['icon_list'] as &$item ) {
                    if ( isset( $item['text'], $map[ $item['text'] ] ) ) {
                        $item['text'] = $map[ $item['text'] ];
                    }
                }
                unset( $item );
            }
        }
        unset( $node );
    }

    private function flush_elementor_cache( int $post_id ): void {
        delete_post_meta( $post_id, '_elementor_css' );
        if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
    }

    /* ══════════════════════════════════════════════════════════
     *  OPENAI TRANSLATION
     * ══════════════════════════════════════════════════════════ */

    /**
     * Translate an array of strings (ES → EN) via OpenAI in a single request.
     * Returns translated array in same order, or null on error.
     *
     * @param  string[] $texts
     * @return string[]|null
     */
    public function batch_translate( array $texts, string $from = 'es', string $to = 'en' ): ?array {

        if ( empty( $texts ) ) return [];

        // Chunk large arrays to keep individual OpenAI requests fast and within token limits.
        // 20 strings per chunk — keeps both input and output well under gpt-4o-mini context limits.
        $chunk_size = 20;
        if ( count( $texts ) > $chunk_size ) {
            $chunks = array_chunk( $texts, $chunk_size );
            $merged = [];
            foreach ( $chunks as $chunk ) {
                $result = $this->batch_translate( $chunk, $from, $to );
                if ( $result === null ) {
                    return null;
                }
                $merged = array_merge( $merged, $result );
            }
            return $merged;
        }

        $api_key = $this->openai_options['openai_api_key'] ?? '';
        if ( empty( $api_key ) ) {
            error_log( '[RSA Translation] batch_translate: API key vacía — no se puede traducir' );
            return null;
        }

        $model = $this->openai_options['openai_model'] ?? 'gpt-4o-mini';

        $lang_names = [
            'es' => 'Spanish', 'en' => 'English', 'fr' => 'French',
            'de' => 'German',  'it' => 'Italian', 'pt' => 'Portuguese',
            'ca' => 'Catalan',
        ];
        $from_name = $lang_names[ $from ] ?? $from;
        $to_name   = $lang_names[ $to ]   ?? $to;

        $input_json = json_encode( array_values( $texts ), JSON_UNESCAPED_UNICODE );

        $prompt = implode( "\n\n", [
            "Translate the following JSON array of strings from {$from_name} to {$to_name}.",
            "Rules:",
            "- Preserve all HTML tags exactly (do not modify tag names, attributes or structure)",
            "- Keep URLs, emails, phone numbers unchanged",
            "- Preserve whitespace and line break structure",
            "- Return ONLY a valid JSON array with exactly the same number of elements as input",
            "- Do not include any explanation outside the JSON array",
            "",
            "Input:",
            $input_json,
        ] );

        $http = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'timeout' => 55,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'       => $model,
                'temperature' => 0.2,
                'max_tokens'  => 4096,
                'messages'    => [
                    [ 'role' => 'system', 'content' => 'You are a professional translator. Translate content while preserving all HTML structure and tags.' ],
                    [ 'role' => 'user', 'content' => $prompt ],
                ],
            ] ),
        ] );

        if ( is_wp_error( $http ) ) {
            error_log( '[RSA Translation] wp_remote_post error: ' . $http->get_error_message() );
            return null;
        }

        $http_code = (int) wp_remote_retrieve_response_code( $http );
        $raw_body  = wp_remote_retrieve_body( $http );
        $body      = json_decode( $raw_body, true );

        if ( $http_code !== 200 ) {
            $err = $body['error']['message'] ?? $raw_body;
            error_log( "[RSA Translation] OpenAI HTTP {$http_code}: " . mb_substr( $err, 0, 300 ) );
            return null;
        }

        $content = trim( $body['choices'][0]['message']['content'] ?? '' );

        // Strip markdown fences if present
        $content = preg_replace( '/^```(?:json)?\s*/m', '', $content );
        $content = preg_replace( '/\s*```$/m', '', $content );
        $content = trim( $content );

        $result = json_decode( $content, true );

        // Fallback: try to extract first JSON array from response (greedy, no /U)
        if ( ! is_array( $result ) || count( $result ) !== count( $texts ) ) {
            if ( preg_match( '/\[[\s\S]+\]/', $content, $m ) ) {
                $result = json_decode( $m[0], true );
            }
        }

        if ( ! is_array( $result ) || count( $result ) !== count( $texts ) ) {
            error_log( '[RSA Translation] JSON parse failed or count mismatch. Expected: ' . count( $texts ) . ', got: ' . ( is_array( $result ) ? count( $result ) : 'null' ) . '. Content preview: ' . mb_substr( $content, 0, 300 ) );
            return null;
        }

        return array_values( $result );
    }

    public function translate_single_string( string $text, string $from = 'es', string $to = 'en' ): ?string {
        $r = $this->batch_translate( [ $text ], $from, $to );
        return is_array( $r ) ? ( $r[0] ?? null ) : null;
    }

    /* ══════════════════════════════════════════════════════════
     *  AJAX HANDLERS
     * ══════════════════════════════════════════════════════════ */

    public function ajax_get_outdated(): void {
        check_ajax_referer( 'rsa_audit', '_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

        $post_types = array_map( 'sanitize_text_field', (array) ( $_POST['post_types'] ?? [ 'page', 'post' ] ) );
        $limit      = min( (int) ( $_POST['limit'] ?? 30 ), 100 );
        $outdated   = $this->get_outdated_translations( $post_types, $limit );

        wp_send_json_success( [ 'outdated' => $outdated, 'count' => count( $outdated ) ] );
    }

    public function ajax_sync_post(): void {
        check_ajax_referer( 'rsa_audit', '_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

        $es_id = (int) ( $_POST['es_id'] ?? 0 );
        $en_id = (int) ( $_POST['en_id'] ?? 0 );

        if ( ! $es_id || ! $en_id ) {
            wp_send_json_error( 'es_id y en_id son requeridos.' );
            return;
        }

        // Pre-check: OpenAI API key
        $api_key = $this->openai_options['openai_api_key'] ?? '';
        if ( empty( $api_key ) ) {
            error_log( '[RSA Translation] Error: No hay API key de OpenAI configurada (rsa_openai_api_key ni replanta_meta_fill_options)' );
            wp_send_json_error( 'No hay API key de OpenAI configurada. Ve a Replanta Site Audit → SEO → Integraciones y guarda tu clave OpenAI.' );
            return;
        }

        // Queue the job — avoids PHP execution timeout on large Elementor pages.
        $job_id = wp_generate_password( 20, false );
        set_transient( "rsa_tl_job_{$job_id}", [ 'status' => 'pending', 'es_id' => $es_id, 'en_id' => $en_id ], 600 );

        wp_schedule_single_event( time() - 1, 'rsa_translation_do_sync', [ $job_id, $es_id, $en_id ] );

        // Kick the cron runner in the background so the event runs immediately
        // without waiting for the next visitor request.
        wp_remote_post(
            add_query_arg( 'doing_wp_cron', sprintf( '%.22F', microtime( true ) ), site_url( '/' ) ),
            [ 'blocking' => false, 'sslverify' => false, 'timeout' => 0.01 ]
        );

        error_log( "[RSA Translation] Job {$job_id} queued for ES={$es_id} EN={$en_id}" );

        wp_send_json_success( [ 'status' => 'queued', 'job_id' => $job_id ] );
    }

    public function ajax_sync_status(): void {
        check_ajax_referer( 'rsa_audit', '_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

        $job_id = sanitize_text_field( $_POST['job_id'] ?? '' );
        if ( empty( $job_id ) ) {
            wp_send_json_error( 'job_id requerido.' );
            return;
        }

        $job = get_transient( "rsa_tl_job_{$job_id}" );
        if ( $job === false ) {
            wp_send_json_error( 'Job no encontrado o expirado.' );
            return;
        }

        wp_send_json_success( $job );
    }

    /**
     * WP-Cron worker. Runs the actual sync in the background.
     */
    public function cron_do_sync( string $job_id, int $es_id, int $en_id ): void {
        @set_time_limit( 300 );
        @ini_set( 'memory_limit', '512M' );

        error_log( "[RSA Translation] cron_do_sync start: job={$job_id} ES={$es_id} EN={$en_id}" );

        set_transient( "rsa_tl_job_{$job_id}", [ 'status' => 'running', 'es_id' => $es_id, 'en_id' => $en_id ], 600 );

        $result = $this->sync_post( $es_id, $en_id );

        error_log( "[RSA Translation] cron_do_sync done: job={$job_id} result=" . wp_json_encode( $result ) );

        set_transient(
            "rsa_tl_job_{$job_id}",
            [ 'status' => 'done', 'result' => $result, 'es_id' => $es_id, 'en_id' => $en_id ],
            600
        );
    }
}
