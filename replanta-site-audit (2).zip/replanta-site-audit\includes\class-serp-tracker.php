<?php
/**
 * RSA_SERP_Tracker
 *
 * Computes position and clicks deltas for applied proposals by comparing
 * rsa_seo_snapshots captured before and after the change was applied.
 *
 * Used by RSA_SEO_Approval::render_section() to show the impact table,
 * and by the weekly digest to flag regressions.
 *
 * @package Replanta_Site_Audit
 * @since   3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class RSA_SERP_Tracker {

	const MIN_DAYS_AFTER = 7;   // minimum days to wait for SERP data to stabilise

	/* ─────────────────────────────────────────
	 * Delta for a single applied proposal
	 * ───────────────────────────────────────── */

	/**
	 * Compares the snapshot recorded immediately before the proposal was applied
	 * with the first snapshot taken at least MIN_DAYS_AFTER days afterwards.
	 *
	 * Returns an array with:
	 *   position_delta float|null  — negative = improved (moved up in ranking)
	 *   clicks_delta   int|null    — positive = more clicks
	 *
	 * @param  array $proposal  Row from rsa_seo_proposals (must have applied_at + url)
	 * @return array{position_delta: float|null, clicks_delta: int|null}
	 */
	public static function get_proposal_impact( array $proposal ): array {
		$null = [ 'position_delta' => null, 'clicks_delta' => null ];

		if ( empty( $proposal['applied_at'] ) || empty( $proposal['url'] ) ) {
			return $null;
		}

		global $wpdb;
		$table   = $wpdb->prefix . RSA_SEO_Snapshot::TABLE_SNAPS;
		$url     = $proposal['url'];
		$applied = $proposal['applied_at'];

		// Snapshot just before the change
		$before = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT position, clicks FROM `{$table}`
				 WHERE url = %s AND captured_at < %s
				 ORDER BY captured_at DESC LIMIT 1",
				$url,
				$applied
			),
			ARRAY_A
		);

		// First snapshot at least MIN_DAYS_AFTER days after
		$after = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT position, clicks FROM `{$table}`
				 WHERE url = %s
				   AND captured_at >= DATE_ADD( %s, INTERVAL %d DAY )
				 ORDER BY captured_at ASC LIMIT 1",
				$url,
				$applied,
				self::MIN_DAYS_AFTER
			),
			ARRAY_A
		);

		if ( ! $before || ! $after ) {
			return $null;
		}

		return [
			'position_delta' => ( $after['position'] !== null && $before['position'] !== null )
				? round( (float) $after['position'] - (float) $before['position'], 1 )
				: null,
			'clicks_delta'   => ( $after['clicks'] !== null && $before['clicks'] !== null )
				? (int) $after['clicks'] - (int) $before['clicks']
				: null,
		];
	}

	/* ─────────────────────────────────────────
	 * Regression detection (for digest alert)
	 * ───────────────────────────────────────── */

	/**
	 * Returns applied proposals where position degraded by ≥5 positions.
	 * Used by the weekly digest to include a "⚠️ Regresiones detectadas" block.
	 */
	public static function get_regressions(): array {
		$applied     = RSA_SEO_Proposal_Engine::get_all( 'applied', 200 );
		$regressions = [];

		foreach ( $applied as $p ) {
			$impact = self::get_proposal_impact( $p );
			// position_delta > 0 = position number increased = ranking got worse
			if ( $impact['position_delta'] !== null && $impact['position_delta'] >= 5 ) {
				$regressions[] = array_merge( $p, $impact );
			}
		}

		return $regressions;
	}

	/* ─────────────────────────────────────────
	 * Sparkline data for JS charts
	 * ───────────────────────────────────────── */

	/**
	 * Returns position / clicks history for a URL formatted for Chart.js.
	 *
	 * @param  string $url
	 * @param  int    $limit  Number of data points (oldest to newest)
	 * @return array{labels: string[], positions: float[], clicks: int[]}
	 */
	public static function get_sparkline_data( string $url, int $limit = 8 ): array {
		$history = RSA_SEO_Snapshot::get_history( $url, $limit );

		// get_history() returns newest-first; reverse for chronological chart
		$history = array_reverse( $history );

		$labels    = [];
		$positions = [];
		$clicks    = [];

		foreach ( $history as $row ) {
			$labels[]    = date_i18n( 'd/m', strtotime( $row['captured_at'] ) );
			$positions[] = $row['position'] !== null ? (float) $row['position'] : null;
			$clicks[]    = $row['clicks']   !== null ? (int)   $row['clicks']   : null;
		}

		return compact( 'labels', 'positions', 'clicks' );
	}
}
