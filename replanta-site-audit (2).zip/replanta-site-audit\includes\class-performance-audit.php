<?php
/**
 * Performance Audit Module — v2.1
 *
 * Comprueba headers HTTP, compresión, TTFB, cache, LiteSpeed,
 * seguridad del servidor, base de datos, memoria y estado de plugins.
 * Incluye checks profundos de rendimiento WP: queries, memoria, cron, transients.
 *
 * @package Replanta_Site_Audit
 * @version 2.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Performance_Audit {

    private string $site_url;

    public function __construct() {
        $this->site_url = home_url();
    }

    public function run(): array {
        $checks = array_merge(
            $this->check_http_headers(),
            $this->check_litespeed(),
            $this->check_ttfb(),
            $this->check_gzip_brotli(),
            $this->check_wp_cron(),
            $this->check_php_version(),
            $this->check_wp_debug(),
            $this->check_object_cache(),
            $this->check_plugins_count(),
            $this->check_autoloaded_options(),
            // ── v2.0 ──
            $this->check_database_maintenance(),
            $this->check_ssl_certificate(),
            $this->check_page_size(),
            $this->check_plugin_updates(),
            $this->check_image_optimization(),
            // ── NEW v2.1 — Deep Performance ──
            $this->check_memory_usage(),
            $this->check_memory_limit(),
            $this->check_database_size(),
            $this->check_cron_queue(),
            $this->check_large_transients(),
            $this->check_heartbeat(),
            $this->check_external_requests(),
            $this->check_query_performance(),
        );

        $total  = count($checks);
        $passed = count(array_filter($checks, fn($c) => $c['status'] === 'pass'));

        return [
            'score'   => $total > 0 ? round(($passed / $total) * 100) : 0,
            'summary' => ['total' => $total, 'passed' => $passed],
            'checks'  => $checks,
        ];
    }

    /* ─────────────────────── helpers ─────────────────────── */

    private function make_check(
        string  $id,
        string  $label,
        string  $status,
        string  $value,
        string  $detail,
        ?string $fix_id    = null,
        ?string $fix_label = null
    ): array {
        $c = [
            'id' => $id, 'label' => $label, 'status' => $status,
            'value' => $value, 'detail' => $detail, 'category' => 'performance',
        ];
        if ($fix_id && in_array($status, ['warning', 'critical', 'info'], true)) {
            $c['fixable']   = true;
            $c['fix_id']    = $fix_id;
            $c['fix_label'] = $fix_label ?? 'Corregir';
        }
        return $c;
    }

    /* ═══════════════════════ CHECKS ═══════════════════════ */

    private function check_http_headers(): array {
        $checks = [];
        $response = wp_remote_get($this->site_url, [
            'timeout' => 10, 'sslverify' => false,
            'user-agent' => 'Replanta-Site-Audit/2.0 (WordPress)',
        ]);

        if (is_wp_error($response))
            return [$this->make_check('http_headers', 'HTTP Headers', 'warning', 'Error', 'No se pudo conectar: ' . $response->get_error_message())];

        $headers = wp_remote_retrieve_headers($response);
        $code    = wp_remote_retrieve_response_code($response);

        if ($code === 200) {
            $checks[] = $this->make_check('http_status', 'HTTP Status', 'pass', (string)$code, 'Portada responde 200 OK.');
        } elseif (in_array($code, [403, 503], true)) {
            $cf_ray = $headers['cf-ray'] ?? null;
            if ($cf_ray) {
                // CF challenge — test with Googlebot UA
                $bot_r = wp_remote_get($this->site_url, [
                    'timeout' => 10, 'sslverify' => false,
                    'user-agent' => 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
                ]);
                $bot_code = is_wp_error($bot_r) ? 'error' : wp_remote_retrieve_response_code($bot_r);

                $checks[] = ($bot_code === 200)
                    ? $this->make_check('http_status', 'HTTP Status (CF)', 'info', '403 → OK',
                        'CF managed_challenge bloquea UA genérico pero Googlebot pasa (200). Normal si hay excepción para bots verificados.')
                    : $this->make_check('http_status', 'HTTP Status (CF)', 'critical', (string)$code,
                        'CF bloquea con ' . $code . ' y Googlebot también falla (' . $bot_code . '). CRÍTICO: crawlers no pueden acceder.',
                        'cf_firewall_bot_exception', 'Añadir excepción bots');
            } else {
                $checks[] = $this->make_check('http_status', 'HTTP Status', 'warning', (string)$code,
                    'Portada responde ' . $code . '. Sin cf-ray. Revisa .htaccess o servidor.');
            }

            // Internal fallback for remaining header checks
            $internal = wp_remote_get('http://127.0.0.1/', [
                'timeout' => 10, 'sslverify' => false,
                'headers' => ['Host' => wp_parse_url($this->site_url, PHP_URL_HOST) ?: RSA_DOMAIN],
            ]);
            if (!is_wp_error($internal)) {
                $int_code = wp_remote_retrieve_response_code($internal);
                $checks[] = $this->make_check('http_status_internal', 'HTTP Status (Interno)',
                    $int_code === 200 ? 'pass' : 'warning', (string)$int_code,
                    'Acceso directo (sin CF): ' . $int_code . '.');
                if ($int_code === 200) $headers = wp_remote_retrieve_headers($internal);
            }
        } else {
            $checks[] = $this->make_check('http_status', 'HTTP Status', 'warning', (string)$code,
                'Portada responde ' . $code . '.');
        }

        // Security headers
        $sec = [
            'x-content-type-options'    => 'Nosniff',
            'x-frame-options'           => 'Clickjacking',
            'strict-transport-security' => 'HSTS',
            'content-security-policy'   => 'CSP',
            'permissions-policy'        => 'Permissions',
        ];
        $present = []; $missing = [];
        foreach ($sec as $h => $name) { ($headers[$h] ?? null) ? $present[] = $name : $missing[] = $name; }

        $checks[] = count($present) >= 3
            ? $this->make_check('security_headers', 'Security Headers', 'pass', count($present) . '/5',
                'Presentes: ' . implode(', ', $present))
            : $this->make_check('security_headers', 'Security Headers', 'warning', count($present) . '/5',
                'Faltan: ' . implode(', ', $missing) . '. Mejoran seguridad del sitio.',
                'security_headers', 'Añadir headers');

        // HSTS specific
        $hsts = $headers['strict-transport-security'] ?? null;
        if ($hsts && preg_match('/max-age=(\d+)/', $hsts, $m) && (int)$m[1] >= 31536000)
            $checks[] = $this->make_check('hsts', 'HSTS', 'pass', 'max-age≥1año', 'HSTS adecuado.');

        // Cache headers
        $cf_cache = $headers['cf-cache-status'] ?? null;
        if ($cf_cache)
            $checks[] = $this->make_check('cf_cache', 'CF-Cache-Status', 'info', $cf_cache,
                'Cache CF: ' . $cf_cache . '. "HIT"=cache, "DYNAMIC"=no cache (normal para HTML).');

        $ls_cache = $headers['x-litespeed-cache'] ?? $headers['x-lsadc-cache'] ?? null;
        if ($ls_cache)
            $checks[] = $this->make_check('ls_cache_header', 'LiteSpeed Cache Header', 'pass', $ls_cache,
                'Página servida desde cache LiteSpeed.');

        return $checks;
    }

    private function check_litespeed(): array {
        $checks = [];
        if (!defined('LSCWP_V') && !class_exists('LiteSpeed_Cache'))
            return [$this->make_check('litespeed', 'LiteSpeed Cache', 'warning', 'No detectado',
                'LiteSpeed Cache plugin no activo. Instala y configúralo si el servidor es LiteSpeed.')];

        $version = defined('LSCWP_V') ? LSCWP_V : 'Unknown';
        $checks[] = $this->make_check('litespeed', 'LiteSpeed Cache', 'pass', 'v' . $version, 'LiteSpeed Cache v' . $version);

        $checks[] = get_option('litespeed.conf.cache')
            ? $this->make_check('ls_cache_on', 'LS Cache Enabled', 'pass', 'Sí', 'Cache activado.')
            : $this->make_check('ls_cache_on', 'LS Cache Enabled', 'warning', 'No', 'Cache de LiteSpeed NO activado.');

        $optm = [];
        if (get_option('litespeed.conf.optm-css_min'))  $optm[] = 'CSS Min';
        if (get_option('litespeed.conf.optm-js_min'))   $optm[] = 'JS Min';
        if (get_option('litespeed.conf.optm-css_comb')) $optm[] = 'CSS Comb';
        if (get_option('litespeed.conf.optm-js_comb'))  $optm[] = 'JS Comb';

        $checks[] = !empty($optm)
            ? $this->make_check('ls_optm', 'LS Optimización', 'pass', implode(', ', $optm), 'Optimizaciones activas.')
            : $this->make_check('ls_optm', 'LS Optimización', 'info', 'Ninguna', 'Sin minificación CSS/JS en LiteSpeed.');

        if (get_option('litespeed.conf.media-lazy'))
            $checks[] = $this->make_check('ls_lazy', 'Lazy Load Imágenes', 'pass', 'Activado', 'Lazy loading activo.');

        // ── Critical CSS (v2.6) ──
        $ccss_gen   = (bool) get_option('litespeed.conf.optm-ccss_gen', 0);
        $ccss_async = (bool) get_option('litespeed.conf.optm-ccss_async', 0);
        if ($ccss_gen && $ccss_async) {
            $checks[] = $this->make_check('ls_ccss', 'Critical CSS', 'pass', 'Activado',
                'Critical CSS generación + async loading activos. Elimina render-blocking CSS y mejora LCP/CLS con Astra.');
        } else {
            $what = !$ccss_gen ? 'generación' : 'async loading';
            $checks[] = $this->make_check('ls_ccss', 'Critical CSS', 'warning', 'Desactivado',
                "Critical CSS ({$what}) no activo. Con el tema Astra esto puede estar bloqueando el render y penalizando LCP/CLS.",
                'ls_enable_ccss', 'Activar Critical CSS');
        }

        return $checks;
    }

    private function check_ttfb(): array {
        $host  = wp_parse_url($this->site_url, PHP_URL_HOST) ?: RSA_DOMAIN;
        $start = microtime(true);
        $resp  = wp_remote_get('http://127.0.0.1/', [
            'timeout' => 15, 'sslverify' => false,
            'headers' => ['Host' => $host],
        ]);
        if (is_wp_error($resp)) {
            $start = microtime(true);
            $resp  = wp_remote_get($this->site_url, ['timeout' => 15, 'sslverify' => false]);
        }
        $ms = round((microtime(true) - $start) * 1000);

        if (is_wp_error($resp))
            return [$this->make_check('ttfb', 'TTFB (interno)', 'warning', 'Error', 'No se pudo medir.')];
        if ($ms < 500)
            return [$this->make_check('ttfb', 'TTFB (interno)', 'pass', $ms . 'ms', 'Excelente (< 500ms).')];
        if ($ms < 1500)
            return [$this->make_check('ttfb', 'TTFB (interno)', 'info', $ms . 'ms', 'Aceptable. Google recomienda < 800ms.')];
        return [$this->make_check('ttfb', 'TTFB (interno)', 'warning', $ms . 'ms', 'Lento (> 1.5s). Revisar LiteSpeed Cache.')];
    }

    private function check_gzip_brotli(): array {
        $host = wp_parse_url($this->site_url, PHP_URL_HOST) ?: RSA_DOMAIN;
        $resp = wp_remote_get($this->site_url, [
            'timeout' => 10, 'sslverify' => false,
            'headers' => ['Accept-Encoding' => 'gzip, br'],
        ]);
        if (is_wp_error($resp) || in_array(wp_remote_retrieve_response_code($resp), [403, 503], true)) {
            $resp = wp_remote_get('http://127.0.0.1/', [
                'timeout' => 10, 'sslverify' => false,
                'headers' => ['Accept-Encoding' => 'gzip, br', 'Host' => $host],
            ]);
        }
        if (is_wp_error($resp)) return [];

        $enc = wp_remote_retrieve_header($resp, 'content-encoding');
        if (stripos($enc, 'br') !== false)
            return [$this->make_check('compression', 'Compresión HTTP', 'pass', 'Brotli', 'Mejor compresión posible.')];
        if (stripos($enc, 'gzip') !== false)
            return [$this->make_check('compression', 'Compresión HTTP', 'pass', 'Gzip', 'OK, pero Brotli ofrece ~20% más.')];

        // With LiteSpeed + CF, compression should already be active
        // This warning may be false positive due to internal WP HTTP client
        return [$this->make_check('compression', 'Compresión HTTP', 'info', 'No detectada',
            'Compresión no detectada en test interno. LiteSpeed + CF comprimen por defecto. Verificar en herramientas externas (GTmetrix).')];
    }

    private function check_wp_cron(): array {
        if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON)
            return [$this->make_check('wp_cron', 'WP-Cron', 'pass', 'Desactivado', 'Usa cron real del sistema.')];
        return [$this->make_check('wp_cron', 'WP-Cron', 'info', 'Pseudo-cron',
            'WP-Cron se ejecuta en cada request. Mejor: cron del sistema.', 'wp_cron_disable', 'Configurar cron real')];
    }

    private function check_php_version(): array {
        $v = phpversion();
        $f = (float)$v;
        if ($f >= 8.2) return [$this->make_check('php_version', 'Versión PHP', 'pass', $v, 'Excelente.')];
        if ($f >= 8.0) return [$this->make_check('php_version', 'Versión PHP', 'info', $v, 'Actualizar a 8.2+ para mejor rendimiento.')];
        return [$this->make_check('php_version', 'Versión PHP', 'warning', $v, 'PHP antiguo. 8.2+ mejora rendimiento ~30%.')];
    }

    private function check_wp_debug(): array {
        if (defined('WP_DEBUG') && WP_DEBUG)
            return [$this->make_check('wp_debug', 'WP_DEBUG', 'warning', 'Activado',
                'WP_DEBUG en producción expone info y ralentiza.', 'wp_debug_off', 'Desactivar WP_DEBUG')];
        return [$this->make_check('wp_debug', 'WP_DEBUG', 'pass', 'Desactivado', 'Correcto.')];
    }

    private function check_object_cache(): array {
        // 1. PHP-level persistent cache drop-in
        if (wp_using_ext_object_cache()) {
            // Detect which backend
            global $wp_object_cache;
            $backend = '';
            if (extension_loaded('redis') || class_exists('Redis')) $backend = 'Redis';
            elseif (extension_loaded('memcached') || extension_loaded('memcache')) $backend = 'Memcached';
            else $backend = 'Persistente';
            return [$this->make_check('object_cache', 'Object Cache', 'pass', $backend, $backend . ' activo como object cache persistente.')];
        }

        // 2. LSCWP has its own object cache setting (may not create drop-in)
        if ((class_exists('LiteSpeed_Cache') || defined('LSCWP_V'))) {
            $ls_oc = get_option('litespeed.conf.object-cache', 0)
                  || get_option('litespeed-object-cache', 0);
            if ($ls_oc) {
                return [$this->make_check('object_cache', 'Object Cache', 'pass', 'LSCWP Object Cache',
                    'LiteSpeed Object Cache habilitado. Asegúrate de tener Redis/Memcached activo en el servidor.')];
            }
            // LSCWP present but object cache off
            return [$this->make_check('object_cache', 'Object Cache', 'warning', 'Desactivado',
                'LiteSpeed Cache instalado pero Object Cache no activo. '
                . 'Con Polylang + WooCommerce esto genera queries DB en cada request. '
                . 'Actívalo en LSCWP → Caché → Object Cache (requiere Redis/Memcached en servidor).',
                'ls_enable_object_cache', 'Activar LS Object Cache')];
        }

        // 3. Generic WP without persistent cache
        return [$this->make_check('object_cache', 'Object Cache', 'warning', 'Solo en memoria',
            'Sin object cache persistente (Redis/Memcached). Polylang + múltiples CPTs generan queries DB en cada request. '
            . 'Instala Redis y el plugin LiteSpeed o WP Redis.',
            'ls_enable_object_cache', 'Configurar Object Cache')];
    }

    private function check_plugins_count(): array {
        $count = count(get_option('active_plugins', []));
        return ($count > 30)
            ? [$this->make_check('plugins_count', 'Plugins Activos', 'warning', (string)$count,
                $count . ' plugins. Número alto afecta rendimiento.')]
            : [$this->make_check('plugins_count', 'Plugins Activos', 'pass', (string)$count, $count . ' plugins. Razonable.')];
    }

    private function check_autoloaded_options(): array {
        global $wpdb;
        $size = $wpdb->get_var("SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload = 'yes'");
        $mb = round($size / 1024 / 1024, 2);
        if ($mb > 2) return [$this->make_check('autoload', 'Autoloaded Options', 'warning', $mb . ' MB',
            'Autoloaded options: ' . $mb . ' MB. >1 MB ralentiza. Limpiar opciones obsoletas.')];
        if ($mb > 1) return [$this->make_check('autoload', 'Autoloaded Options', 'info', $mb . ' MB', $mb . ' MB. Aceptable, monitorizar.')];
        return [$this->make_check('autoload', 'Autoloaded Options', 'pass', $mb . ' MB', 'Correcto.')];
    }

    /* ═══════════════════ NEW CHECKS v2.0 ═══════════════════ */

    private function check_database_maintenance(): array {
        global $wpdb;
        $checks = [];

        // Post revisions
        $revisions = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'");
        $checks[] = ($revisions > 500)
            ? $this->make_check('db_revisions', 'Revisiones de Posts', 'warning', number_format($revisions),
                $revisions . ' revisiones. Ocupan espacio y ralentizan consultas. Limitar con WP_POST_REVISIONS.',
                'db_clean_revisions', 'Limpiar revisiones')
            : $this->make_check('db_revisions', 'Revisiones de Posts', 'pass', number_format($revisions), 'Cantidad aceptable.');

        // Expired transients
        $expired = (int)$wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < " . time()
        );
        $checks[] = ($expired > 100)
            ? $this->make_check('db_transients', 'Transients Expirados', 'info', number_format($expired),
                $expired . ' transients expirados. Limpiar para reducir tamaño de options.',
                'db_clean_transients', 'Limpiar transients')
            : $this->make_check('db_transients', 'Transients Expirados', 'pass', number_format($expired), 'OK.');

        // Spam/trash comments
        $spam = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved IN ('spam', 'trash')");
        if ($spam > 100)
            $checks[] = $this->make_check('db_spam', 'Spam/Papelera Comentarios', 'info', number_format($spam),
                $spam . ' comentarios spam/papelera. Limpiar para optimizar DB.',
                'db_clean_spam', 'Limpiar spam');

        return $checks;
    }

    private function check_ssl_certificate(): array {
        $host = wp_parse_url($this->site_url, PHP_URL_HOST) ?: RSA_DOMAIN;

        $ctx = stream_context_create([
            'ssl' => ['capture_peer_cert' => true, 'verify_peer' => false, 'verify_peer_name' => false],
        ]);

        $socket = @stream_socket_client("ssl://{$host}:443", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $ctx);
        if (!$socket)
            return [$this->make_check('ssl_cert', 'Certificado SSL', 'warning', 'Error', 'No se pudo conectar para verificar SSL.')];

        $params = stream_context_get_params($socket);
        fclose($socket);

        $cert = $params['options']['ssl']['peer_certificate'] ?? null;
        if (!$cert)
            return [$this->make_check('ssl_cert', 'Certificado SSL', 'warning', 'No obtenido', 'No se pudo leer el certificado.')];

        $info = openssl_x509_parse($cert);
        $valid_to = $info['validTo_time_t'] ?? 0;
        $days_left = max(0, (int)round(($valid_to - time()) / 86400));

        if ($days_left < 7)
            return [$this->make_check('ssl_cert', 'Certificado SSL', 'critical', $days_left . ' días',
                'Certificado SSL expira en ' . $days_left . ' días. RENOVAR URGENTE.')];
        if ($days_left < 30)
            return [$this->make_check('ssl_cert', 'Certificado SSL', 'warning', $days_left . ' días',
                'Expira pronto. Verificar auto-renovación.')];

        $issuer = $info['issuer']['O'] ?? $info['issuer']['CN'] ?? 'Desconocido';
        return [$this->make_check('ssl_cert', 'Certificado SSL', 'pass', $days_left . ' días',
            'Válido ' . $days_left . ' días más. Emisor: ' . $issuer)];
    }

    private function check_page_size(): array {
        $host = wp_parse_url($this->site_url, PHP_URL_HOST) ?: RSA_DOMAIN;
        $resp = wp_remote_get('http://127.0.0.1/', [
            'timeout' => 15, 'sslverify' => false,
            'headers' => ['Host' => $host],
        ]);
        if (is_wp_error($resp)) {
            $resp = wp_remote_get($this->site_url, ['timeout' => 15, 'sslverify' => false]);
        }
        if (is_wp_error($resp)) return [];

        $body = wp_remote_retrieve_body($resp);
        $kb = round(strlen($body) / 1024, 1);

        if ($kb > 500)
            return [$this->make_check('page_size', 'Tamaño HTML Portada', 'warning', $kb . ' KB',
                'HTML de portada: ' . $kb . ' KB. >500 KB es excesivo. Revisar contenido inline.')];
        if ($kb > 200)
            return [$this->make_check('page_size', 'Tamaño HTML Portada', 'info', $kb . ' KB',
                'HTML: ' . $kb . ' KB. Aceptable, pero optimizable.')];
        return [$this->make_check('page_size', 'Tamaño HTML Portada', 'pass', $kb . ' KB', 'Tamaño de HTML correcto.')];
    }

    private function check_plugin_updates(): array {
        // Force update check if stale
        $update_plugins = get_site_transient('update_plugins');
        if (!$update_plugins) {
            wp_update_plugins();
            $update_plugins = get_site_transient('update_plugins');
        }
        if (!$update_plugins || !isset($update_plugins->response)) return [];

        $count = count($update_plugins->response);
        if ($count === 0)
            return [$this->make_check('plugin_updates', 'Plugins Desactualizados', 'pass', '0', 'Todo actualizado.')];

        $names = [];
        foreach (array_slice($update_plugins->response, 0, 5) as $file => $info) {
            $slug = $info->slug ?? basename(dirname($file));
            $names[] = $slug . ' → ' . ($info->new_version ?? '?');
        }

        $status = $count > 5 ? 'warning' : 'info';
        return [$this->make_check('plugin_updates', 'Plugins Desactualizados', $status, (string)$count,
            $count . ' plugin(s) con actualización: ' . implode(', ', $names) . ($count > 5 ? '...' : ''))];
    }

    private function check_image_optimization(): array {
        $checks = [];

        // ── WebP ──
        $webp_active = defined('LSCWP_V') && (bool) get_option('litespeed.conf.img_optm-webp_replace');

        if ($webp_active) {
            $checks[] = $this->make_check('webp', 'WebP Images', 'pass', 'Activo', 'LiteSpeed WebP replacement activo.');
        } else {
            $upload_dir = wp_upload_dir();
            $base       = $upload_dir['basedir'] ?? '';
            $has_webp   = false;
            if ($base && is_dir($base)) {
                $month_dir = $base . '/' . date('Y');
                if (is_dir($month_dir)) {
                    foreach (array_slice(array_reverse((array) @scandir($month_dir)), 0, 3) as $m) {
                        if ($m === '.' || $m === '..') {
                            continue;
                        }
                        if (!empty(@glob($month_dir . '/' . $m . '/*.webp'))) {
                            $has_webp = true;
                            break;
                        }
                    }
                }
            }
            $checks[] = $has_webp
                ? $this->make_check('webp', 'WebP Images', 'pass', 'Detectadas', 'Imágenes WebP encontradas en media.')
                : $this->make_check('webp', 'WebP Images', 'info', 'No detectado',
                    'Sin WebP activo. Ahorra ~30% de tamaño. Actívalo en LiteSpeed → Image Optimization → WebP Replacement.');
        }

        // ── Alt text + Lazy loading (análisis de la portada) ──
        $checks = array_merge($checks, $this->check_image_attributes());

        return $checks;
    }

    /**
     * Verifica atributos alt y loading="lazy" en las imágenes de la portada.
     */
    private function check_image_attributes(): array {
        $response = wp_remote_get($this->site_url, [
            'timeout'    => 10,
            'sslverify'  => false,
            'user-agent' => 'Replanta-Site-Audit/2.0 (WordPress)',
            'headers'    => ['Accept-Encoding' => ''],
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return [];
        }

        $html = wp_remote_retrieve_body($response);

        // Extraer todas las etiquetas <img>
        preg_match_all('/<img(?:\s[^>]*)?\/?>/is', $html, $raw);
        $imgs  = $raw[0] ?? [];
        $total = count($imgs);

        if ($total === 0) {
            return [$this->make_check('img_total', 'Imágenes en portada', 'info', '0', 'Sin imágenes detectadas en la portada.')];
        }

        $no_alt  = 0;
        $no_lazy = 0;

        foreach ($imgs as $i => $img) {
            // alt ausente del todo (alt="" es válido para imágenes decorativas)
            if (!preg_match('/\balt\s*=/i', $img)) {
                $no_alt++;
            }
            // Las primeras 3 imágenes probablemente son above-the-fold (LCP candidate) — no penalizar
            if ($i >= 3 && !preg_match('/\bloading\s*=\s*["\']lazy["\']/i', $img)) {
                $no_lazy++;
            }
        }

        $checks = [];

        // Alt text
        if ($no_alt === 0) {
            $checks[] = $this->make_check('img_alt', 'Alt en imágenes', 'pass',
                "{$total}/{$total} OK",
                "Todas las {$total} imágenes de portada tienen atributo alt. Correcto para SEO e indexación en Google Images.");
        } else {
            $checks[] = $this->make_check('img_alt', 'Alt en imágenes', 'warning',
                "{$no_alt}/{$total} sin alt",
                "{$no_alt} de {$total} imágenes no tienen atributo alt. "
                . 'El alt es clave para SEO (Google Images, búsqueda por imagen) y accesibilidad (WCAG 2.1 AA). '
                . 'Añade alt descriptivo en Medios → Editar imagen → Texto alternativo.');
        }

        // Lazy loading (solo si hay candidatas, es decir imágenes más allá de la 3ª)
        $candidates = max(0, $total - 3);
        if ($candidates > 0) {
            if ($no_lazy === 0) {
                $checks[] = $this->make_check('img_lazy', 'Lazy loading imágenes', 'pass',
                    "{$candidates}/{$candidates} OK",
                    'Todas las imágenes candidatas tienen loading="lazy". Correcto para LCP y tiempo de carga.');
            } else {
                $checks[] = $this->make_check('img_lazy', 'Lazy loading imágenes', 'info',
                    "{$no_lazy}/{$candidates} sin lazy",
                    "{$no_lazy} imágenes podrían tener loading=\"lazy\" para mejorar el tiempo de carga inicial. "
                    . 'LiteSpeed Cache puede añadirlo automáticamente (Optimización → Imágenes → Lazy Load).',
                    'ls_enable_lazy', 'Activar lazy load en LiteSpeed');
            }
        }

        return $checks;
    }

    /* ═══════════════════ NEW CHECKS v2.1 — DEEP PERFORMANCE ═══════════════════ */

    /**
     * Check current PHP memory usage
     */
    private function check_memory_usage(): array {
        $current = memory_get_usage(true);
        $peak = memory_get_peak_usage(true);
        $current_mb = round($current / 1024 / 1024, 1);
        $peak_mb = round($peak / 1024 / 1024, 1);

        if ($peak_mb > 128) {
            return [$this->make_check('memory_usage', 'Uso de Memoria PHP', 'warning', $peak_mb . ' MB peak',
                "Actual: {$current_mb} MB, Pico: {$peak_mb} MB. Alto consumo de memoria. Revisar plugins pesados.")];
        }
        if ($peak_mb > 64) {
            return [$this->make_check('memory_usage', 'Uso de Memoria PHP', 'info', $peak_mb . ' MB peak',
                "Actual: {$current_mb} MB, Pico: {$peak_mb} MB. Consumo moderado.")];
        }
        return [$this->make_check('memory_usage', 'Uso de Memoria PHP', 'pass', $peak_mb . ' MB peak',
            "Actual: {$current_mb} MB, Pico: {$peak_mb} MB. Correcto.")];
    }

    /**
     * Check WP_MEMORY_LIMIT setting
     */
    private function check_memory_limit(): array {
        $limit = WP_MEMORY_LIMIT;
        $limit_bytes = wp_convert_hr_to_bytes($limit);
        $limit_mb = round($limit_bytes / 1024 / 1024);

        $max_limit = defined('WP_MAX_MEMORY_LIMIT') ? WP_MAX_MEMORY_LIMIT : '256M';
        $max_bytes = wp_convert_hr_to_bytes($max_limit);
        $max_mb = round($max_bytes / 1024 / 1024);

        if ($limit_mb < 128) {
            return [$this->make_check('memory_limit', 'WP_MEMORY_LIMIT', 'warning', $limit,
                "Límite bajo ({$limit}). Recomendado: 256M mínimo. Admin: {$max_limit}.",
                'wp_memory_limit', 'Aumentar a 256M')];
        }
        if ($limit_mb < 256) {
            return [$this->make_check('memory_limit', 'WP_MEMORY_LIMIT', 'info', $limit,
                "Aceptable ({$limit}). Admin: {$max_limit}. 256M es mejor para sitios grandes.")];
        }
        return [$this->make_check('memory_limit', 'WP_MEMORY_LIMIT', 'pass', $limit,
            "Correcto ({$limit}). Admin: {$max_limit}.")];
    }

    /**
     * Check total database size
     */
    private function check_database_size(): array {
        global $wpdb;
        $db_name = DB_NAME;

        $size = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = %s",
            $db_name
        ));

        if ($size === null) {
            return [$this->make_check('db_size', 'Tamaño Base de Datos', 'info', 'N/A', 'No se pudo obtener el tamaño.')];
        }

        $mb = round($size / 1024 / 1024, 1);
        $gb = round($mb / 1024, 2);

        if ($mb > 1024) {
            return [$this->make_check('db_size', 'Tamaño Base de Datos', 'warning', $gb . ' GB',
                "DB muy grande ({$gb} GB). Considerar limpiar revisiones, transients, logs.")];
        }
        if ($mb > 500) {
            return [$this->make_check('db_size', 'Tamaño Base de Datos', 'info', $mb . ' MB',
                "DB de tamaño considerable ({$mb} MB). Monitorizar crecimiento.")];
        }
        return [$this->make_check('db_size', 'Tamaño Base de Datos', 'pass', $mb . ' MB', 'Tamaño correcto.')];
    }

    /**
     * Check WP-Cron queue for stuck/overdue jobs
     */
    private function check_cron_queue(): array {
        $crons = _get_cron_array();
        if (!is_array($crons)) {
            return [$this->make_check('cron_queue', 'Cola WP-Cron', 'info', 'Vacía', 'Sin tareas programadas.')];
        }

        $total_jobs = 0;
        $overdue = 0;
        $now = time();

        foreach ($crons as $timestamp => $hooks) {
            if (!is_array($hooks)) continue;
            foreach ($hooks as $hook => $events) {
                $total_jobs += count($events);
                if ($timestamp < $now - 3600) { // More than 1 hour overdue
                    $overdue += count($events);
                }
            }
        }

        if ($overdue > 10) {
            return [$this->make_check('cron_queue', 'Cola WP-Cron', 'warning', $overdue . ' atrasadas',
                "{$total_jobs} tareas totales, {$overdue} atrasadas >1h. WP-Cron puede estar bloqueado. Verificar acceso a wp-cron.php.",
                'wp_cron_run_overdue', 'Ejecutar tareas atrasadas')];
        }
        if ($overdue > 0) {
            return [$this->make_check('cron_queue', 'Cola WP-Cron', 'info', $overdue . ' atrasadas',
                "{$total_jobs} tareas totales, {$overdue} ligeramente atrasadas.")];
        }
        return [$this->make_check('cron_queue', 'Cola WP-Cron', 'pass', $total_jobs . ' tareas',
            "Cola cron saludable con {$total_jobs} tareas programadas.")];
    }

    /**
     * Check for unusually large transients
     */
    private function check_large_transients(): array {
        global $wpdb;

        // Find transients larger than 100KB
        $large = $wpdb->get_results(
            "SELECT option_name, LENGTH(option_value) as size 
             FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_%' 
             AND option_name NOT LIKE '_transient_timeout_%'
             AND LENGTH(option_value) > 102400
             ORDER BY size DESC
             LIMIT 5"
        );

        if (empty($large)) {
            return [$this->make_check('large_transients', 'Transients Grandes', 'pass', 'Ninguno',
                'No hay transients mayores a 100KB.')];
        }

        $details = [];
        $total_kb = 0;
        foreach ($large as $t) {
            $name = str_replace('_transient_', '', $t->option_name);
            $kb = round($t->size / 1024, 1);
            $total_kb += $kb;
            $details[] = substr($name, 0, 30) . ": {$kb}KB";
        }

        return [$this->make_check('large_transients', 'Transients Grandes', 'warning', count($large) . ' encontrados',
            "Total: " . round($total_kb, 0) . "KB en transients grandes. " . implode(', ', $details),
            'db_clean_large_transients', 'Limpiar transients grandes')];
    }

    /**
     * Check Heartbeat API configuration
     */
    private function check_heartbeat(): array {
        // Check if Heartbeat is disabled
        if (defined('DISABLE_HEARTBEAT') && DISABLE_HEARTBEAT) {
            return [$this->make_check('heartbeat', 'Heartbeat API', 'pass', 'Desactivado',
                'Heartbeat desactivado globalmente. Mejor para rendimiento.')];
        }

        // Check if it's slowed down by a plugin
        $interval = apply_filters('heartbeat_settings', ['interval' => 60]);
        $int_val = $interval['interval'] ?? 60;

        if ($int_val >= 120) {
            return [$this->make_check('heartbeat', 'Heartbeat API', 'pass', $int_val . 's',
                "Intervalo optimizado: {$int_val}s. Bajo impacto en servidor.")];
        }
        if ($int_val >= 60) {
            return [$this->make_check('heartbeat', 'Heartbeat API', 'info', $int_val . 's',
                "Intervalo: {$int_val}s. Aceptable. Puede aumentarse a 120s para reducir requests.",
                'heartbeat_optimize', 'Optimizar a 120s')];
        }

        return [$this->make_check('heartbeat', 'Heartbeat API', 'warning', $int_val . 's',
            "Intervalo bajo: {$int_val}s. Genera muchos requests AJAX. Aumentar mínimo a 60s.",
            'heartbeat_optimize', 'Optimizar intervalo')];
    }

    /**
     * Check for problematic external HTTP requests on page load
     */
    private function check_external_requests(): array {
        // This check requires SAVEQUERIES or similar — just check common issues
        $checks = [];

        // Check if external crons are being used (admin-ajax spam)
        $cron_url = site_url('wp-cron.php');
        $external_crons = get_option('rsa_external_cron_count', 0);

        // Check for known problematic update checks
        $update_check_issues = [];

        // Google Fonts loaded from external
        $theme = wp_get_theme();
        $theme_file = $theme->get_stylesheet_directory() . '/style.css';
        if (file_exists($theme_file)) {
            $style = file_get_contents($theme_file);
            if (preg_match('/fonts\.googleapis\.com/', $style)) {
                $update_check_issues[] = 'Google Fonts externo en theme';
            }
        }

        if (empty($update_check_issues)) {
            return [$this->make_check('external_requests', 'Requests Externos', 'pass', 'OK',
                'No se detectaron problemas conocidos de requests externos.')];
        }

        return [$this->make_check('external_requests', 'Requests Externos', 'info', 
            count($update_check_issues) . ' detectados',
            'Posibles requests externos: ' . implode(', ', $update_check_issues) . '. Considerar self-hosting.')];
    }

    /**
     * Check query performance indicators
     */
    private function check_query_performance(): array {
        global $wpdb;
        $checks = [];

        // Check for missing indexes on large tables
        $posts_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts}");
        $postmeta_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta}");

        if ($postmeta_count > 100000) {
            // Check for common slow query patterns
            $orphaned_meta = (int)$wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} pm 
                 LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID 
                 WHERE p.ID IS NULL"
            );

            if ($orphaned_meta > 1000) {
                $checks[] = $this->make_check('orphaned_meta', 'Postmeta Huérfanos', 'warning', 
                    number_format($orphaned_meta),
                    "{$orphaned_meta} registros postmeta sin post asociado. Ralentizan queries.",
                    'db_clean_orphaned_meta', 'Limpiar postmeta huérfanos');
            }
        }

        // Check options table for non-autoload bloat
        $total_options = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->options}");
        if ($total_options > 5000) {
            $checks[] = $this->make_check('options_count', 'Filas en Options', 'info', 
                number_format($total_options),
                "{$total_options} filas en wp_options. Número alto puede indicar plugins que no limpian.");
        }

        if (empty($checks)) {
            $checks[] = $this->make_check('query_health', 'Salud de Queries', 'pass', 'OK',
                "Posts: {$posts_count}, Postmeta: {$postmeta_count}. Sin problemas detectados.");
        }

        return $checks;
    }
}
