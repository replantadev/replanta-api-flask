<?php
/**
 * Dominios Reseller Bridge
 *
 * Punto único de acceso al servicio de Cloudflare de Dominios Reseller.
 * Replanta Site Audit no gestiona ni almacena tokens de Cloudflare propios,
 * todos los accesos a la API de CF se realizan a través de este puente.
 *
 * DEPENDENCIA INTER-PLUGIN:
 *   - Plugin requerido (soft): Dominios Reseller (slug: dominios-reseller)
 *   - Clase expuesta: Dominios_Reseller_Cloudflare_Service (singleton)
 *   - Opción WP donde se guarda el token: dominios_reseller_options['cf_api_token']
 *   - Cargado por DR en: includes/class-cloudflare-service.php (al nivel raíz, no en plugins_loaded)
 *
 * Por qué es una dependencia soft (opcional):
 *   - Sin DR los módulos SEO y Rendimiento siguen funcionando.
 *   - Solo los módulos Cloudflare Audit y Auto-Fixer CF quedan deshabilitados.
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 * @since   2.6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * RSA_DR_Bridge
 *
 * Proporciona acceso estático centralizado al servicio CF de Dominios Reseller.
 * Ningún otro archivo de Site Audit debe hacer class_exists('Dominios_Reseller_Cloudflare_Service')
 * directamente — todo debe pasar por esta clase.
 */
final class RSA_DR_Bridge {

    /**
     * Cache interna del singleton del servicio CF de DR.
     * @var Dominios_Reseller_Cloudflare_Service|null
     */
    private static ?object $service = null;

    /**
     * Flag para evitar llamadas repetidas a class_exists.
     * @var bool|null  null = no comprobado aún
     */
    private static ?bool $available = null;

    // ── No se permiten instancias ────────────────────────────────────────────

    private function __construct() {}
    private function __clone() {}

    // ── API pública ──────────────────────────────────────────────────────────

    /**
     * ¿Está disponible la clase Dominios_Reseller_Cloudflare_Service?
     *
     * Devuelve true sólo si el plugin Dominios Reseller está activo y
     * su clase CF ha sido cargada. No comprueba si hay token configurado.
     */
    public static function is_available(): bool {
        if ( self::$available === null ) {
            self::$available = class_exists( 'Dominios_Reseller_Cloudflare_Service' );
        }
        return self::$available;
    }

    /**
     * ¿Está disponible Y configurado con un token de API?
     *
     * Devuelve true sólo si la clase existe y contiene un token no vacío.
     * Es la comprobación relevante antes de hacer llamadas reales a CF.
     */
    public static function is_configured(): bool {
        if ( ! self::is_available() ) {
            return false;
        }
        return self::get_token() !== '';
    }

    /**
     * Devuelve el singleton de Dominios_Reseller_Cloudflare_Service, o null.
     *
     * @return Dominios_Reseller_Cloudflare_Service|null
     */
    public static function get_service(): ?object {
        if ( ! self::is_available() ) {
            return null;
        }
        if ( self::$service === null ) {
            self::$service = Dominios_Reseller_Cloudflare_Service::get_instance();
        }
        return self::$service;
    }

    /**
     * Devuelve el token de API de Cloudflare configurado en Dominios Reseller.
     *
     * Esta función es la ÚNICA fuente del token CF en todo el plugin Site Audit.
     * No hay tokens duplicados ni almacenados localmente.
     *
     * @return string  Token CF, o cadena vacía si no está configurado.
     */
    public static function get_token(): string {
        $service = self::get_service();
        if ( $service === null ) {
            return '';
        }
        return $service->get_token();
    }

    /**
     * Información de estado para el panel de administración y diagnóstico.
     *
     * @return array{
     *   available: bool,
     *   configured: bool,
     *   token_masked: string,
     *   plugin_version: string,
     *   label: string,
     *   status_class: string
     * }
     */
    public static function get_status(): array {
        $available  = self::is_available();
        $configured = $available && self::is_configured();

        $token_masked = '';
        $plugin_version = '';

        if ( $configured ) {
            $token = self::get_token();
            // Mostrar solo los últimos 6 caracteres del token, enmascarar el resto
            $token_masked = str_repeat( '*', max( 0, strlen( $token ) - 6 ) ) . substr( $token, -6 );
        }

        if ( $available ) {
            // Intentar leer la versión del plugin activo
            $plugin_file = WP_PLUGIN_DIR . '/dominios-reseller/dominios-reseller.php';
            if ( file_exists( $plugin_file ) ) {
                $plugin_data    = get_file_data( $plugin_file, [ 'Version' => 'Version' ] );
                $plugin_version = $plugin_data['Version'] ?? '';
            }
            if ( empty( $plugin_version ) && defined( 'DOMINIOS_RESELLER_VERSION' ) ) {
                $plugin_version = DOMINIOS_RESELLER_VERSION;
            }
        }

        if ( ! $available ) {
            $label        = 'No instalado';
            $status_class = 'rsa-dep-missing';
        } elseif ( ! $configured ) {
            $label        = 'Instalado — sin token CF';
            $status_class = 'rsa-dep-warning';
        } else {
            $label        = 'Activo y configurado';
            $status_class = 'rsa-dep-ok';
        }

        return [
            'available'      => $available,
            'configured'     => $configured,
            'token_masked'   => $token_masked,
            'plugin_version' => $plugin_version,
            'label'          => $label,
            'status_class'   => $status_class,
        ];
    }

    /**
     * Restablece las caches internas (útil en tests).
     */
    public static function reset(): void {
        self::$service   = null;
        self::$available = null;
    }
}
