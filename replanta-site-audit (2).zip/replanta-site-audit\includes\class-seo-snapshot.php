<?php
/**
 * RSA_SEO_Snapshot
 *
 * Manages weekly SERP + meta snapshots for the SEO Autopilot.
 * Captures top-50 URLs from GSC with their current RankMath metas and schema state,
 * then triggers proposal generation.
 *
 * @package Replanta_Site_Audit
 * @since   3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class RSA_SEO_Snapshot {

	/* ─── Constants ─── */
	const CRON_CAPTURE  = 'rsa_seo_snapshot_capture';
	const TABLE_SNAPS   = 'rsa_seo_snapshots';
	const TABLE_PROPS   = 'rsa_seo_proposals';
	const TABLE_EXLOG   = 'rsa_seo_execution_log';
	const TOP_URLS      = 50;
	const DB_VERSION    = '3.1';
	const OPTION_DB_VER = 'rsa_autopilot_db_ver';

	/* ─── Singleton ─── */
	private static ?self $instance = null;

	public static function get_instance(): self {
		return self::$instance ??= new self();
	}

	private function __construct() {
		add_action( self::CRON_CAPTURE, [ $this, 'capture_and_propose' ] );
		add_action( 'init',             [ $this, 'maybe_schedule' ] );
	}

	/* ─────────────────────────────────────────
	 * Scheduling
	 * ───────────────────────────────────────── */

	public function maybe_schedule(): void {
		self::maybe_migrate();
		if ( ! wp_next_scheduled( self::CRON_CAPTURE ) ) {
			wp_schedule_event( strtotime( 'next sunday 03:00:00' ), 'weekly', self::CRON_CAPTURE );
		}
	}

	public static function on_activate(): void {
		self::create_tables();
		self::maybe_migrate(); // adds columns to pre-existing tables
		if ( ! wp_next_scheduled( self::CRON_CAPTURE ) ) {
			wp_schedule_event( strtotime( 'next sunday 03:00:00' ), 'weekly', self::CRON_CAPTURE );
		}
		// Daily safety-net executor cron
		if ( ! wp_next_scheduled( 'rsa_seo_execute_approved' ) ) {
			wp_schedule_event( time(), 'daily', 'rsa_seo_execute_approved' );
		}
	}

	public static function on_deactivate(): void {
		wp_clear_scheduled_hook( self::CRON_CAPTURE );
		wp_clear_scheduled_hook( 'rsa_seo_execute_approved' );
	}

	/* ─────────────────────────────────────────
	 * DB migration (forward-compatible column adds)
	 * ───────────────────────────────────────── */

	/**
	 * Adds v3.x columns to existing tables without dropping data.
	 * Bails immediately if already at DB_VERSION — runs on every init but is O(1) in the normal case.
	 */
	public static function maybe_migrate(): void {
		if ( get_option( self::OPTION_DB_VER ) === self::DB_VERSION ) {
			return;
		}

		global $wpdb;
		$snaps = $wpdb->prefix . self::TABLE_SNAPS;
		$props = $wpdb->prefix . self::TABLE_PROPS;

		// ── rsa_seo_snapshots ────────────────────────────────────────────
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$snap_cols = $wpdb->get_col( "DESCRIBE `{$snaps}`", 0 );
		if ( ! empty( $snap_cols ) ) {
			if ( ! in_array( 'lang',       $snap_cols, true ) ) $wpdb->query( "ALTER TABLE `{$snaps}` ADD COLUMN lang       VARCHAR(10)      DEFAULT NULL" );
			if ( ! in_array( 'post_type',  $snap_cols, true ) ) $wpdb->query( "ALTER TABLE `{$snaps}` ADD COLUMN post_type  VARCHAR(100)     DEFAULT NULL" );
			if ( ! in_array( 'dfs_volume', $snap_cols, true ) ) $wpdb->query( "ALTER TABLE `{$snaps}` ADD COLUMN dfs_volume INT              DEFAULT NULL" );
			if ( ! in_array( 'dfs_kd',     $snap_cols, true ) ) $wpdb->query( "ALTER TABLE `{$snaps}` ADD COLUMN dfs_kd     TINYINT UNSIGNED DEFAULT NULL" );
			$has_idx = $wpdb->get_var( "SHOW INDEX FROM `{$snaps}` WHERE Key_name = 'idx_lang'" );
			if ( ! $has_idx ) $wpdb->query( "ALTER TABLE `{$snaps}` ADD INDEX idx_lang (lang)" );
		}

		// ── rsa_seo_proposals ────────────────────────────────────────────
		$prop_cols = $wpdb->get_col( "DESCRIBE `{$props}`", 0 );
		if ( ! empty( $prop_cols ) ) {
			if ( ! in_array( 'lang',             $prop_cols, true ) ) $wpdb->query( "ALTER TABLE `{$props}` ADD COLUMN lang             VARCHAR(10) DEFAULT NULL" );
			if ( ! in_array( 'propagated_langs', $prop_cols, true ) ) $wpdb->query( "ALTER TABLE `{$props}` ADD COLUMN propagated_langs TEXT        DEFAULT NULL" );
		}
		// phpcs:enable

		update_option( self::OPTION_DB_VER, self::DB_VERSION );
	}

	/* ─────────────────────────────────────────
	 * Table creation (all 3 autopilot tables)
	 * ───────────────────────────────────────── */

	public static function create_tables(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$snaps   = $wpdb->prefix . self::TABLE_SNAPS;
		$props   = $wpdb->prefix . self::TABLE_PROPS;
		$exlog   = $wpdb->prefix . self::TABLE_EXLOG;

		dbDelta( "CREATE TABLE IF NOT EXISTS {$snaps} (
			id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id           BIGINT UNSIGNED NOT NULL DEFAULT 0,
			url               VARCHAR(500)    NOT NULL DEFAULT '',
			keyword           VARCHAR(255)    NOT NULL DEFAULT '',
			lang              VARCHAR(10)              DEFAULT NULL,
			post_type         VARCHAR(100)             DEFAULT NULL,
			dfs_volume        INT                      DEFAULT NULL,
			dfs_kd            TINYINT UNSIGNED         DEFAULT NULL,
			position          FLOAT                    DEFAULT NULL,
			clicks            INT                      DEFAULT NULL,
			impressions       INT                      DEFAULT NULL,
			ctr               FLOAT                    DEFAULT NULL,
			rank_math_title   TEXT                     DEFAULT NULL,
			rank_math_desc    TEXT                     DEFAULT NULL,
			rank_math_focus_kw VARCHAR(255)            DEFAULT NULL,
			schema_types      TEXT                     DEFAULT NULL,
			schema_issues     TEXT                     DEFAULT NULL,
			captured_at       DATETIME         NOT NULL,
			PRIMARY KEY  (id),
			INDEX idx_url        (url(191)),
			INDEX idx_post_id    (post_id),
			INDEX idx_lang       (lang),
			INDEX idx_captured_at (captured_at)
		) {$charset};" );

		dbDelta( "CREATE TABLE IF NOT EXISTS {$props} (
			id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			type             VARCHAR(50)     NOT NULL,
			post_id          BIGINT UNSIGNED NOT NULL DEFAULT 0,
			url              VARCHAR(500)    NOT NULL DEFAULT '',
			field_key        VARCHAR(100)    NOT NULL DEFAULT '',
			lang             VARCHAR(10)              DEFAULT NULL,
			value_before     LONGTEXT                 DEFAULT NULL,
			value_after      LONGTEXT        NOT NULL DEFAULT '',
			status           ENUM('pending','approved','rejected','applied','failed') NOT NULL DEFAULT 'pending',
			claude_reasoning TEXT                     DEFAULT NULL,
			propagated_langs TEXT                     DEFAULT NULL,
			snapshot_id      BIGINT UNSIGNED          DEFAULT NULL,
			approval_token   VARCHAR(64)              DEFAULT NULL,
			created_at       DATETIME        NOT NULL,
			decided_at       DATETIME                 DEFAULT NULL,
			applied_at       DATETIME                 DEFAULT NULL,
			PRIMARY KEY  (id),
			INDEX idx_status  (status),
			INDEX idx_type    (type),
			INDEX idx_post_id (post_id),
			INDEX idx_token   (approval_token)
		) {$charset};" );

		dbDelta( "CREATE TABLE IF NOT EXISTS {$exlog} (
			id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			proposal_id  BIGINT UNSIGNED NOT NULL,
			action       VARCHAR(100)    NOT NULL,
			backup_data  LONGTEXT                 DEFAULT NULL,
			result       LONGTEXT                 DEFAULT NULL,
			executed_at  DATETIME        NOT NULL,
			PRIMARY KEY  (id),
			INDEX idx_proposal_id (proposal_id)
		) {$charset};" );
	}

	/* ─────────────────────────────────────────
	 * Main cron job
	 * ───────────────────────────────────────── */

	/**
	 * Capture a weekly snapshot of top-50 URLs and trigger proposal generation.
	 *
	 * Data sources (priority order):
	 *  1. RankMath Analytics DB  — local, zero API cost, granular daily data.
	 *  2. Google Search Console API — fallback when RM table is absent or empty.
	 *
	 * Enrichments applied per URL:
	 *  - BetterDocs CPT fallback for url_to_postid resolution.
	 *  - Polylang language tag (pll_get_post_language).
	 *  - DataForSEO keyword volume + competition (best-effort, cached 7 days).
	 *
	 * Runs inside WP-Cron: slow I/O is acceptable.
	 */
	public function capture_and_propose(): void {
		// ── 1. Traffic data: RankMath Analytics DB → GSC API fallback ─────────
		$raw_rows = $this->get_rankmath_analytics_data();

		if ( empty( $raw_rows ) ) {
			$gsc = RSA_GSC_Client::get_instance();
			if ( ! $gsc->is_connected() ) {
				return;
			}

			$site_url = (string) get_option( 'rsa_gsc_selected_site', '' );
			if ( ! $site_url ) {
				return;
			}

			$api_rows = $gsc->search_analytics(
				$site_url,
				date( 'Y-m-d', strtotime( '-28 days' ) ),
				date( 'Y-m-d' ),
				[ 'page', 'query' ],
				200
			);

			if ( is_wp_error( $api_rows ) || empty( $api_rows ) ) {
				return;
			}

			foreach ( $api_rows as $r ) {
				$raw_rows[] = [
					'url'         => $r['keys'][0] ?? '',
					'keyword'     => $r['keys'][1] ?? '',
					'clicks'      => (int)   $r['clicks'],
					'impressions' => (int)   $r['impressions'],
					'ctr'         => round( (float) $r['ctr'] * 100, 2 ),
					'position'    => round( (float) $r['position'], 1 ),
				];
			}
		}

		// ── 2. Aggregate: top keyword per URL, limit to TOP_URLS by clicks ─────
		$urls_map = [];
		foreach ( $raw_rows as $row ) {
			$url = $row['url'] ?? '';
			if ( ! $url ) {
				continue;
			}
			if ( ! isset( $urls_map[ $url ] ) || $row['clicks'] > $urls_map[ $url ]['clicks'] ) {
				$urls_map[ $url ] = $row;
			}
		}
		uasort( $urls_map, fn( $a, $b ) => $b['clicks'] <=> $a['clicks'] );
		$urls_map = array_slice( $urls_map, 0, self::TOP_URLS, true );

		if ( empty( $urls_map ) ) {
			return;
		}

		// ── 3. DataForSEO enrichment: volume + difficulty per URL (best-effort) ─
		$dfs_map = $this->enrich_with_dataforseo();

		// ── 4. Resolve per-URL: post_id, metas, schema, lang, post_type ────────
		global $wpdb;
		$now      = current_time( 'mysql' );
		$snap_ids = [];
		$resolved = []; // url → compact array for reuse in batch_input

		foreach ( $urls_map as $url => $entry ) {
			// 4a. Resolve post_id — with BetterDocs CPT fallback
			$post_id = url_to_postid( $url );

			if ( ! $post_id ) {
				$slug = basename( untrailingslashit( $url ) );
				if ( $slug ) {
					$bdq     = new WP_Query( [
						'post_type'      => 'betterdocs_doc',
						'name'           => $slug,
						'posts_per_page' => 1,
						'no_found_rows'  => true,
					] );
					$post_id = ! empty( $bdq->posts ) ? (int) $bdq->posts[0]->ID : 0;
					wp_reset_postdata();
				}
			}

			// 4b. Post metadata + Polylang language
			$rm_title  = '';
			$rm_desc   = '';
			$rm_kw     = '';
			$s_types   = '';
			$s_issues  = '';
			$lang      = '';
			$post_type = '';

			if ( $post_id ) {
				$rm_title  = (string) get_post_meta( $post_id, 'rank_math_title',         true );
				$rm_desc   = (string) get_post_meta( $post_id, 'rank_math_description',   true );
				$rm_kw     = (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true );
				$post_type = (string) ( get_post_type( $post_id ) ?: '' );

				$schema  = RSA_Schema_Audit::get_instance()->analyze_post( $post_id );
				$s_types = implode( ', ', $schema['types'] ?? [] );
				$issues  = $schema['issues'] ?? [];
				if ( ! empty( $issues ) ) {
					$s_issues = wp_json_encode( array_slice( array_column( $issues, 'message' ), 0, 5 ) );
				}

				if ( function_exists( 'pll_get_post_language' ) ) {
					$lang = (string) ( pll_get_post_language( $post_id ) ?: '' );
				}
			}

			// 4b-bis. Post content excerpt for interlink anchor resolution
			// For Elementor pages, post_content is empty — extract text from widget tree instead.
			$post_excerpt = '';
			if ( $post_id ) {
				$post_obj = get_post( $post_id );
				if ( $post_obj ) {
					$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );
					if ( $el_raw ) {
						$post_excerpt = mb_substr( self::extract_elementor_text( $el_raw ), 0, 600 );
					} else {
						$post_excerpt = mb_substr( wp_strip_all_tags( $post_obj->post_content ), 0, 600 );
					}
				}
			}

			// 4c. DataForSEO lookup (normalize trailing slashes)
			$url_path  = rtrim( (string) ( parse_url( $url, PHP_URL_PATH ) ?: $url ), '/' );
			$dfs_entry = $dfs_map[ $url_path ] ?? $dfs_map[ $url_path . '/' ] ?? null;

			// 4d. Cache resolved data to avoid double-calling WP APIs in batch build
			$resolved[ $url ] = compact(
				'post_id', 'post_type', 'lang',
				'rm_title', 'rm_desc', 'rm_kw',
				's_types', 's_issues', 'dfs_entry',
				'post_excerpt'
			);

			// 4e. Build INSERT — omit nullable columns when empty so DB uses DEFAULT NULL
			$row_data = [
				'post_id'            => (int) $post_id,
				'url'                => $url,
				'keyword'            => $entry['keyword'],
				'position'           => $entry['position'],
				'clicks'             => $entry['clicks'],
				'impressions'        => $entry['impressions'],
				'ctr'                => $entry['ctr'],
				'rank_math_title'    => $rm_title,
				'rank_math_desc'     => $rm_desc,
				'rank_math_focus_kw' => $rm_kw,
				'schema_types'       => $s_types,
				'schema_issues'      => $s_issues,
				'captured_at'        => $now,
			];
			$row_fmt = [ '%d', '%s', '%s', '%f', '%d', '%d', '%f', '%s', '%s', '%s', '%s', '%s', '%s' ];

			if ( $lang ) {
				$row_data['lang'] = $lang;
				$row_fmt[]        = '%s';
			}
			if ( $post_type ) {
				$row_data['post_type'] = $post_type;
				$row_fmt[]             = '%s';
			}
			if ( $dfs_entry ) {
				$row_data['dfs_volume'] = (int) $dfs_entry['volume'];
				$row_data['dfs_kd']     = (int) $dfs_entry['kd'];
				$row_fmt[]              = '%d';
				$row_fmt[]              = '%d';
			}

			$wpdb->insert( $wpdb->prefix . self::TABLE_SNAPS, $row_data, $row_fmt );
			$snap_ids[ $url ] = (int) $wpdb->insert_id;
		}

		// ── 5. Build batch_input (reuse resolved cache) and send to Claude ─────
		$batch_input = [];
		foreach ( $urls_map as $url => $entry ) {
			$r = $resolved[ $url ] ?? [];
			$d = $r['dfs_entry'] ?? null;

			$batch_input[] = array_merge( $entry, [
				'post_id'              => (int) ( $r['post_id']     ?? 0 ),
				'snapshot_id'          => $snap_ids[ $url ] ?? 0,
				'post_type'            => $r['post_type']    ?? '',
				'lang'                 => $r['lang']         ?? '',
				'dfs_volume'           => $d ? (int) $d['volume'] : null,
				'dfs_kd'               => $d ? (int) $d['kd']    : null,
				'rank_math_title'      => $r['rm_title']     ?? '',
				'rank_math_desc'       => $r['rm_desc']      ?? '',
				'rank_math_focus_kw'   => $r['rm_kw']        ?? '',
				'schema_types'         => $r['s_types']      ?? '',
				'schema_issues'        => $r['s_issues']     ?? '',
				'post_content_excerpt' => $r['post_excerpt'] ?? '',
			] );
		}

		$batches = array_chunk( $batch_input, 8 );
		foreach ( $batches as $i => $batch ) {
			RSA_SEO_Proposal_Engine::generate_from_snapshot( $batch );
			if ( $i < count( $batches ) - 1 ) {
				sleep( 3 );
			}
		}
	}

	/* ─────────────────────────────────────────
	 * Private helpers (data sources + enrichment)
	 * ───────────────────────────────────────── */

	/**
	 * Pull traffic data from the RankMath Analytics local DB table.
	 * Zero API calls, granular daily data synced by RankMath itself.
	 *
	 * @return array  Rows with url, keyword, clicks, impressions, position, ctr.
	 *                Empty array if table absent or no data in last 28 days.
	 */
	private function get_rankmath_analytics_data(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'rank_math_analytics_gsc';

		// Verify table existence without triggering a DB error
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
			return [];
		}

		$cutoff = date( 'Y-m-d', strtotime( '-28 days' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT
					page              AS url,
					query             AS keyword,
					SUM(clicks)       AS clicks,
					SUM(impressions)  AS impressions,
					AVG(position)     AS position,
					AVG(ctr)          AS ctr
				 FROM `{$table}`
				 WHERE created >= %s
				 GROUP BY page, query
				 ORDER BY SUM(clicks) DESC
				 LIMIT 400",
				$cutoff
			),
			ARRAY_A
		);

		if ( ! $rows ) {
			return [];
		}

		// RankMath stores relative paths (/slug/); url_to_postid() needs absolute URLs.
		$home = untrailingslashit( (string) home_url() );
		return array_map( fn( $r ) => [
			'url'         => strncmp( (string) $r['url'], 'http', 4 ) === 0
								? (string) $r['url']
								: $home . '/' . ltrim( (string) $r['url'], '/' ),
			'keyword'     => (string) $r['keyword'],
			'clicks'      => (int)    $r['clicks'],
			'impressions' => (int)    $r['impressions'],
			'position'    => round( (float) $r['position'], 1 ),
			'ctr'         => round( (float) $r['ctr'] * 100, 2 ),
		], $rows );
	}

	/**
	 * Fetch keyword volume + Adwords competition from DataForSEO for the whole domain.
	 * Returns a map of normalised URL-path → {volume, kd} (kd = competition * 100).
	 * Result is cached in a transient for 7 days to avoid burning API credits.
	 *
	 * @return array<string, array{volume: int, kd: int}>
	 */
	private function enrich_with_dataforseo(): array {
		$dfs = RSA_DataForSEO_Client::get_instance();
		if ( ! $dfs->is_configured() ) {
			return [];
		}

		$domain        = defined( 'RSA_DOMAIN' ) ? RSA_DOMAIN : (string) parse_url( get_site_url(), PHP_URL_HOST );
		$transient_key = 'rsa_dfs_enrich_' . md5( $domain );
		$cached        = get_transient( $transient_key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$result = $dfs->keywords_for_site( $domain, 'es', '2724', 500 );
		if ( is_wp_error( $result ) || empty( $result ) ) {
			return [];
		}

		$map = [];
		foreach ( $result as $item ) {
			$item_url = (string) ( $item['url'] ?? '' );
			if ( ! $item_url ) {
				continue;
			}
			$path = rtrim( (string) ( parse_url( $item_url, PHP_URL_PATH ) ?: '' ), '/' );
			if ( ! $path ) {
				continue;
			}

			$volume = (int) ( $item['search_vol'] ?? 0 );
			$kd     = (int) round( (float) ( $item['competition'] ?? 0 ) * 100 );

			if ( ! isset( $map[ $path ] ) || $volume > $map[ $path ]['volume'] ) {
				$map[ $path ] = [ 'volume' => $volume, 'kd' => $kd ];
			}
		}

		// Cache for one full snapshot cycle to avoid repeated DFS credit consumption
		set_transient( $transient_key, $map, 7 * DAY_IN_SECONDS );

		return $map;
	}

	/* ─────────────────────────────────────────
	 * Query helpers
	 * ───────────────────────────────────────── */

	/** Datetime of the most recent capture, or empty string if none. */
	public static function get_last_capture(): string {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_SNAPS;
		return (string) $wpdb->get_var( "SELECT MAX(captured_at) FROM `{$table}`" );
	}

	/**
	 * Position/clicks history for a URL — used by SERP tracker and sparklines.
	 *
	 * @param string $url   Relative or absolute URL as stored by GSC
	 * @param int    $limit Number of historical records to return
	 * @return array  Ordered newest→oldest
	 */
	public static function get_history( string $url, int $limit = 8 ): array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_SNAPS;
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT captured_at, position, clicks, impressions, ctr, keyword
				 FROM `{$table}`
				 WHERE url = %s
				 ORDER BY captured_at DESC
				 LIMIT %d",
				$url,
				$limit
			),
			ARRAY_A
		) ?: [];
	}

	/* ─────────────────────────────────────────
	 * Elementor text extraction (for interlink insert_after hints)
	 * ───────────────────────────────────────── */

	/**
	 * Walks Elementor's _elementor_data JSON and collects all visible text from
	 * text-editor and html widgets. Returns a plain-text string suitable for
	 * giving Claude real phrases to use as insert_after anchors.
	 *
	 * @param  string $el_raw  Raw JSON string from _elementor_data post meta.
	 * @return string          Plain text, whitespace-normalized.
	 */
	public static function extract_elementor_text( string $el_raw ): string {
		$elements = json_decode( $el_raw, true );
		if ( ! is_array( $elements ) ) {
			return '';
		}

		$parts = [];
		self::walk_elementor_elements( $elements, $parts );

		return wp_strip_all_tags( implode( ' ', $parts ) );
	}

	/**
	 * Recursive walker — collects text from known content widgets.
	 *
	 * @param array  $elements  Array of Elementor elements.
	 * @param array &$parts     Accumulator for text fragments.
	 */
	private static function walk_elementor_elements( array $elements, array &$parts ): void {
		foreach ( $elements as $el ) {
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				self::walk_elementor_elements( $el['elements'], $parts );
			}

			if ( ( $el['elType'] ?? '' ) !== 'widget' ) {
				continue;
			}

			$settings    = $el['settings'] ?? [];
			$widget_type = $el['widgetType'] ?? '';

			switch ( $widget_type ) {
				case 'text-editor':
					if ( ! empty( $settings['editor'] ) ) {
						$parts[] = (string) $settings['editor'];
					}
					break;

				case 'html':
					if ( ! empty( $settings['html_code'] ) ) {
						$parts[] = (string) $settings['html_code'];
					}
					break;

				case 'heading':
					if ( ! empty( $settings['title'] ) ) {
						$parts[] = (string) $settings['title'];
					}
					break;

				case 'theme-post-content':
					// This widget renders post_content — nothing to extract here at the meta level.
					break;
			}
		}
	}
}
