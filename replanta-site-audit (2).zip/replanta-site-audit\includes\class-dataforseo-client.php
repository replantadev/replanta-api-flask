<?php
/**
 * DataForSEO Client — Keywords, SERP y análisis competidor
 *
 * Wraps la API de DataForSEO v3 con Basic Auth (login:password).
 * Gestiona los endpoints más útiles para el agente SEO de Replanta.
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RSA_DataForSEO_Client {

	const OPTION_CREDENTIALS = 'rsa_dataforseo_credentials';
	const API_BASE           = 'https://api.dataforseo.com/v3';

	private static ?RSA_DataForSEO_Client $instance = null;

	public static function get_instance(): RSA_DataForSEO_Client {
		return self::$instance ??= new self();
	}

	private function __construct() {}

	/* ─────────── Credenciales ─────────── */

	public function get_credentials(): array {
		return (array) get_option( self::OPTION_CREDENTIALS, [
			'login'    => '',
			'password' => '',
		] );
	}

	public function save_credentials( string $login, string $password ): void {
		update_option( self::OPTION_CREDENTIALS, [
			'login'    => sanitize_text_field( $login ),
			'password' => sanitize_text_field( $password ),
		], false );
	}

	public function is_configured(): bool {
		$c = $this->get_credentials();
		return ! empty( $c['login'] ) && ! empty( $c['password'] );
	}

	/* ─────────── HTTP ─────────── */

	/**
	 * Cabecera de Basic Auth para DataForSEO.
	 */
	private function auth_header(): string {
		$c = $this->get_credentials();
		return 'Basic ' . base64_encode( $c['login'] . ':' . $c['password'] );
	}

	/**
	 * POST genérico a la API.
	 *
	 * @param string $endpoint  Ruta relativa, ej: "/dataforseo_labs/google/keywords_for_site/live"
	 * @param array  $payload   Cuerpo JSON (array)
	 *
	 * @return array|\WP_Error  Devuelve $response['tasks'][0]['result'] o WP_Error
	 */
	private function post( string $endpoint, array $payload ): array|\WP_Error {
		$response = wp_remote_post( self::API_BASE . $endpoint, [
			'headers' => [
				'Authorization' => $this->auth_header(),
				'Content-Type'  => 'application/json',
			],
			'body'      => wp_json_encode( [ $payload ] ),
			'timeout'   => 45,
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code === 401 ) {
			return new WP_Error( 'dfs_auth', 'Credenciales DataForSEO incorrectas.' );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['tasks'][0] ) ) {
			return new WP_Error( 'dfs_empty', 'Respuesta vacía de DataForSEO.' );
		}

		$task = $body['tasks'][0];

		if ( (int) ( $task['status_code'] ?? 0 ) >= 40000 ) {
			return new WP_Error( 'dfs_task_error', $task['status_message'] ?? 'Error en tarea DataForSEO' );
		}

		return $task['result'] ?? [];
	}

	/* ─────────── Keywords for Site ─────────── */

	/**
	 * Palabras clave orgánicas por las que rankea un dominio.
	 *
	 * @param string $domain    Dominio sin protocolo, ej: "replanta.net"
	 * @param string $language  Código de idioma, ej: "es"
	 * @param string $location  Código numérico de ubicación DataForSEO (España = 2724)
	 * @param int    $limit     Máx resultados
	 *
	 * @return array|\WP_Error
	 */
	public function keywords_for_site(
		string $domain,
		string $language  = 'es',
		string $location  = '2724',
		int    $limit     = 200
	): array|\WP_Error {

		$result = $this->post( '/dataforseo_labs/google/keywords_for_site/live', [
			'target'                 => $domain,
			'language_code'          => $language,
			'location_code'          => (int) $location,
			'limit'                  => $limit,
			'include_serp_info'      => false,
			'include_subdomains'     => false,
		] );

		if ( is_wp_error( $result ) ) return $result;

		$items = $result[0]['items'] ?? [];

		return array_map( fn( $item ) => [
			'keyword'     => $item['keyword']                       ?? '',
			'position'    => $item['ranked_serp_element']['serp_item']['rank_absolute'] ?? null,
			'search_vol'  => $item['keyword_info']['search_volume'] ?? 0,
			'cpc'         => $item['keyword_info']['cpc']           ?? 0,
			'competition' => $item['keyword_info']['competition']   ?? 0,
			'url'         => $item['ranked_serp_element']['serp_item']['url'] ?? '',
		], $items );
	}

	/* ─────────── Keyword Ideas ─────────── */

	/**
	 * Genera ideas de keywords relacionadas con una semilla.
	 *
	 * @param array  $seed_keywords  Array de palabras clave semilla
	 * @param string $language
	 * @param string $location
	 * @param int    $limit
	 *
	 * @return array|\WP_Error
	 */
	public function keyword_ideas(
		array  $seed_keywords,
		string $language = 'es',
		string $location = '2724',
		int    $limit    = 100
	): array|\WP_Error {

		$result = $this->post( '/dataforseo_labs/google/keyword_ideas/live', [
			'keywords'      => array_slice( $seed_keywords, 0, 20 ),
			'language_code' => $language,
			'location_code' => (int) $location,
			'limit'         => $limit,
		] );

		if ( is_wp_error( $result ) ) return $result;

		$items = $result[0]['items'] ?? [];

		return array_map( fn( $item ) => [
			'keyword'         => $item['keyword']                     ?? '',
			'search_vol'      => $item['keyword_info']['search_volume'] ?? 0,
			'cpc'             => $item['keyword_info']['cpc']           ?? 0,
			'competition'     => $item['keyword_info']['competition']   ?? 0,
			'keyword_difficulty' => $item['keyword_properties']['keyword_difficulty'] ?? null,
			'intent'          => $item['search_intent_info']['main_intent'] ?? '',
		], $items );
	}

	/* ─────────── Competitor Analysis ─────────── */

	/**
	 * Análisis de dominio: volumen de tráfico orgánico, keywords, etc.
	 *
	 * @param string $domain
	 * @param string $language
	 * @param string $location
	 *
	 * @return array|\WP_Error
	 */
	public function domain_metrics(
		string $domain,
		string $language = 'es',
		string $location = '2724'
	): array|\WP_Error {

		$result = $this->post( '/dataforseo_labs/google/domain_rank_overview/live', [
			'target'        => $domain,
			'language_code' => $language,
			'location_code' => (int) $location,
		] );

		if ( is_wp_error( $result ) ) return $result;

		$item = $result[0]['items'][0] ?? [];

		return [
			'domain'         => $domain,
			'organic_count'  => $item['metrics']['organic']['count']        ?? 0,
			'organic_pos1'   => $item['metrics']['organic']['pos_1']        ?? 0,
			'organic_pos3'   => $item['metrics']['organic']['pos_1_3']      ?? 0,
			'organic_pos10'  => $item['metrics']['organic']['pos_1_10']     ?? 0,
			'etv'            => $item['metrics']['organic']['etv']          ?? 0,
			'keywords_count' => $item['metrics']['organic']['count']        ?? 0,
		];
	}

	/**
	 * Detecta dominios competidores directos por solapamiento de keywords.
	 *
	 * @param string $domain
	 * @param string $language
	 * @param string $location
	 * @param int    $limit
	 *
	 * @return array|\WP_Error
	 */
	public function competitors(
		string $domain,
		string $language = 'es',
		string $location = '2724',
		int    $limit    = 20
	): array|\WP_Error {

		$result = $this->post( '/dataforseo_labs/google/competitors_domain/live', [
			'target'        => $domain,
			'language_code' => $language,
			'location_code' => (int) $location,
			'limit'         => $limit,
		] );

		if ( is_wp_error( $result ) ) return $result;

		$items = $result[0]['items'] ?? [];

		return array_map( fn( $item ) => [
			'domain'              => $item['domain']              ?? '',
			'competitor_metrics'  => [
				'organic_count'   => $item['metrics']['organic']['count'] ?? 0,
				'etv'             => $item['metrics']['organic']['etv']   ?? 0,
			],
			'intersections'       => $item['intersections']       ?? 0,
			'se_type'             => $item['se_type']             ?? '',
		], $items );
	}

	/* ─────────── Keyword Gap ─────────── */

	/**
	 * Keywords que tiene el competidor pero no el dominio propio.
	 * (Content gap / keyword gap)
	 *
	 * @param string $our_domain
	 * @param string $competitor_domain
	 * @param string $language
	 * @param string $location
	 * @param int    $limit
	 *
	 * @return array|\WP_Error
	 */
	public function keyword_gap(
		string $our_domain,
		string $competitor_domain,
		string $language = 'es',
		string $location = '2724',
		int    $limit    = 100
	): array|\WP_Error {

		$result = $this->post( '/dataforseo_labs/google/page_intersection/live', [
			'targets' => [
				$our_domain         => [ 'type' => 'domain', 'intersections' => false ],
				$competitor_domain  => [ 'type' => 'domain', 'intersections' => true  ],
			],
			'language_code' => $language,
			'location_code' => (int) $location,
			'limit'         => $limit,
		] );

		if ( is_wp_error( $result ) ) return $result;

		$items = $result[0]['items'] ?? [];

		return array_map( fn( $item ) => [
			'keyword'    => $item['keyword_data']['keyword']                     ?? '',
			'search_vol' => $item['keyword_data']['keyword_info']['search_volume'] ?? 0,
			'intent'     => $item['keyword_data']['search_intent_info']['main_intent'] ?? '',
		], $items );
	}

	/* ─────────── SERP ─────────── */

	/**
	 * Analiza los resultados SERP para una keyword concreta.
	 *
	 * @param string $keyword
	 * @param string $language
	 * @param string $location
	 *
	 * @return array|\WP_Error
	 */
	public function serp_analysis(
		string $keyword,
		string $language = 'es',
		string $location = '2724'
	): array|\WP_Error {

		$result = $this->post( '/serp/google/organic/live/advanced', [
			'keyword'       => $keyword,
			'language_code' => $language,
			'location_code' => (int) $location,
			'calculate_rectangles' => false,
		] );

		if ( is_wp_error( $result ) ) return $result;

		$items = $result[0]['items'] ?? [];

		$organic = array_filter( $items, fn( $i ) => ( $i['type'] ?? '' ) === 'organic' );
		$organic = array_values( $organic );

		return array_slice( array_map( fn( $item ) => [
			'position'    => $item['rank_absolute'] ?? 0,
			'title'       => $item['title']         ?? '',
			'url'         => $item['url']           ?? '',
			'description' => $item['description']   ?? '',
			'domain'      => $item['domain']        ?? '',
		], $organic ), 0, 10 );
	}
}
