<?php
/**
 * Claude SEO Agent — Análisis SEO con IA usando la API de Anthropic
 *
 * Recibe datos de GSC y DataForSEO, construye un contexto rico
 * y llama a Claude para obtener recomendaciones SEO accionables.
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RSA_Claude_SEO_Agent {

	const OPTION_API_KEY    = 'rsa_claude_seo_api_key';
	const OPTION_ANALYSIS   = 'rsa_claude_seo_last_analysis';
	const API_URL           = 'https://api.anthropic.com/v1/messages';
	const MODEL             = 'claude-sonnet-4-5';
	const MAX_TOKENS        = 8192;

	const OPTION_OPENAI_KEY = 'rsa_openai_api_key';
	const OPENAI_API_URL    = 'https://api.openai.com/v1/chat/completions';
	const OPENAI_MODEL      = 'gpt-4o';

	/**
	 * Tipos de análisis disponibles.
	 */
	const ANALYSIS_TYPES = [
		'quick_wins'    => 'Oportunidades rápidas (posiciones 8-20)',
		'content_plan'  => 'Plan de contenido y nuevos nichos',
		'competitors'   => 'Análisis de competidores y gaps',
		'page_audit'    => 'Auditoría de páginas con decaimiento',
		'meta_titles'   => 'Mejoras de meta titles y descriptions',
		'interlinking'  => 'Estrategia de enlazado interno',
		'image_audit'   => 'Auditoría de imágenes y alt texts',
	];

	private static ?RSA_Claude_SEO_Agent $instance = null;

	public static function get_instance(): RSA_Claude_SEO_Agent {
		return self::$instance ??= new self();
	}

	private function __construct() {}

	/* ─────────── API Key ─────────── */

	public function get_api_key(): string {
		return (string) get_option( self::OPTION_API_KEY, '' );
	}

	public function save_api_key( string $key ): void {
		update_option( self::OPTION_API_KEY, sanitize_text_field( $key ), false );
	}

	public function is_configured(): bool {
		return ! empty( $this->get_api_key() );
	}

	/* ─────────── OpenAI ─────────── */

	public function get_openai_key(): string {
		return (string) get_option( self::OPTION_OPENAI_KEY, '' );
	}

	public function save_openai_key( string $key ): void {
		update_option( self::OPTION_OPENAI_KEY, sanitize_text_field( $key ), false );
	}

	public function is_openai_configured(): bool {
		return ! empty( $this->get_openai_key() );
	}

	/* ─────────── Análisis guardados ─────────── */

	public function get_last_analysis(): array {
		return (array) get_option( self::OPTION_ANALYSIS, [] );
	}

	private function save_analysis( string $type, array $data ): void {
		$all              = $this->get_last_analysis();
		$all[ $type ]     = array_merge( $data, [ 'generated_at' => current_time( 'mysql' ) ] );
		update_option( self::OPTION_ANALYSIS, $all, false );
	}

	/* ─────────── Claude HTTP ─────────── */

	/**
	 * Llama a la API de Claude con un prompt estructurado.
	 * Si Claude falla (error HTTP o sin clave) y hay clave de OpenAI configurada,
	 * reintenta con OpenAI gpt-4o como fallback.
	 *
	 * @param string $system   System prompt
	 * @param string $user     User message
	 *
	 * @return string|\WP_Error  Texto de respuesta o WP_Error
	 */
	public function call_claude( string $system, string $user ): string|\WP_Error {
		$api_key = $this->get_api_key();

		if ( ! empty( $api_key ) ) {
			$response = wp_remote_post( self::API_URL, [
				'headers' => [
					'x-api-key'         => $api_key,
					'anthropic-version' => '2023-06-01',
					'content-type'      => 'application/json',
				],
				'body' => wp_json_encode( [
					'model'      => self::MODEL,
					'max_tokens' => self::MAX_TOKENS,
					'system'     => $system,
					'messages'   => [
						[ 'role' => 'user', 'content' => $user ],
					],
				] ),
				'timeout'   => 120,
				'sslverify' => true,
			] );

			if ( ! is_wp_error( $response ) ) {
				$code = wp_remote_retrieve_response_code( $response );
				$body = json_decode( wp_remote_retrieve_body( $response ), true );

				if ( $code === 200 ) {
					return $body['content'][0]['text'] ?? '';
				}
			}
			// Claude falló — intentar fallback
		}

		// Fallback a OpenAI
		if ( $this->is_openai_configured() ) {
			return $this->call_openai( $system, $user );
		}

		if ( empty( $api_key ) ) {
			return new \WP_Error( 'no_ai_key', 'No hay clave de Claude ni de OpenAI configurada.' );
		}

		// Claude falló y no hay fallback: devolver el error original
		$code = $code ?? 0;
		$body = $body ?? [];
		$msg  = $body['error']['message'] ?? "Error HTTP {$code} en Claude";
		return new \WP_Error( 'claude_api_error', $msg );
	}

	/**
	 * Llama directamente a OpenAI gpt-4o.
	 *
	 * @param string $system  System prompt
	 * @param string $user    User message
	 *
	 * @return string|\WP_Error
	 */
	public function call_openai( string $system, string $user ): string|\WP_Error {
		$api_key = $this->get_openai_key();
		if ( empty( $api_key ) ) {
			return new \WP_Error( 'openai_no_key', 'API Key de OpenAI no configurada.' );
		}

		$response = wp_remote_post( self::OPENAI_API_URL, [
			'headers' => [
				'Authorization' => 'Bearer ' . $api_key,
				'content-type'  => 'application/json',
			],
			'body' => wp_json_encode( [
				'model'    => self::OPENAI_MODEL,
				'messages' => [
					[ 'role' => 'system', 'content' => $system ],
					[ 'role' => 'user',   'content' => $user ],
				],
				'max_tokens' => self::MAX_TOKENS,
			] ),
			'timeout'   => 120,
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code !== 200 ) {
			$msg = $body['error']['message'] ?? "Error HTTP {$code} en OpenAI";
			return new \WP_Error( 'openai_api_error', $msg );
		}

		return $body['choices'][0]['message']['content'] ?? '';
	}

	/* ─────────── System Prompt ─────────── */

	public function get_system_prompt(): string {
		$domain = defined( 'RSA_DOMAIN' ) ? RSA_DOMAIN : get_site_url();
		return <<<PROMPT
Eres un estratega SEO senior especializado en el mercado hispanohablante, trabajando para Replanta ({$domain}).

Replanta es una agencia de desarrollo web sostenible que ofrece:
- Hosting sostenible y en España (diferenciador clave)
- Diseño web y mantenimiento WordPress
- Certificación de sostenibilidad digital (Sello Replanta)
- Calculadora de huella de carbono digital (TEW)

Tu objetivo es escalar el posicionamiento orgánico de replanta.net con recomendaciones CONCRETAS y ACCIONABLES, no genéricas.

Principios:
1. Prioriza siempre el impacto/esfuerzo. Primero las victorias rápidas.
2. El nicho de "web sostenible" en España es pequeño pero con muy baja competencia — explotarlo.
3. El interlazado interno es una palanca de bajo esfuerzo y alto impacto.
4. Responde SIEMPRE en español.
5. Cada recomendación debe incluir: acción específica, URL o keyword afectada, impacto estimado.
6. Usa formato Markdown estructurado (h2, h3, listas, tablas donde aplique).
7. No repitas datos que ya tienes en el contexto — ve directo a la conclusión y acción.
PROMPT;
	}

	/* ─────────── Análisis: Quick Wins ─────────── */

	/**
	 * Analiza las oportunidades rápidas de GSC y propone acciones concretas.
	 *
	 * @param array $quick_wins  Output de RSA_GSC_Client::get_quick_wins()
	 * @param array $perf_summary Output de RSA_GSC_Client::get_performance_summary()
	 *
	 * @return array  ['markdown' => string, 'generated_at' => string]|\WP_Error
	 */
	public function analyze_quick_wins( array $quick_wins, array $perf_summary = [] ): array|\WP_Error {
		$wins_text = $this->format_quick_wins_table( $quick_wins );

		$perf_text = '';
		if ( ! empty( $perf_summary['recent'] ) ) {
			$r = $perf_summary['recent'];
			$d = $perf_summary['delta'];
			$perf_text = "\n\n### Métricas últimos 28 días\n"
				. "- Clicks: {$r['clicks']} ({$d['clicks']}% vs periodo anterior)\n"
				. "- Impresiones: {$r['impressions']} ({$d['impressions']}%)\n"
				. "- CTR: {$r['ctr']}%\n"
				. "- Posición media: {$r['position']}\n";
		}

		$user = <<<USER
A continuación tienes las queries de replanta.net en posiciones 8-20 con más impresiones en los últimos 90 días.
Estas son las oportunidades más inmediatas para subir a la primera página.

{$wins_text}{$perf_text}

Por favor:
1. **Agrupa** las queries por tema/intención (máximo 8 grupos).
2. Para cada grupo, indica la **página actual** que debería rankear y qué acción concreta hacer (optimizar H1, añadir sección, mejorar meta title, crear contenido nuevo...).
3. **Prioriza** los 5 grupos con mayor potencial de impacto y explica por qué.
4. Identifica si hay **canibalización** de keywords entre páginas.
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result, 'raw_wins' => array_slice( $quick_wins, 0, 30 ) ];
		$this->save_analysis( 'quick_wins', $data );

		return $data;
	}

	/* ─────────── Análisis: Content Plan ─────────── */

	/**
	 * Propone un plan de contenido basado en keywords del dominio y gaps.
	 *
	 * @param array $domain_keywords  Output de RSA_DataForSEO_Client::keywords_for_site()
	 * @param array $keyword_ideas    Output de RSA_DataForSEO_Client::keyword_ideas()
	 * @param array $competitors      Output de RSA_DataForSEO_Client::competitors()
	 *
	 * @return array|\WP_Error
	 */
	public function analyze_content_plan(
		array $domain_keywords,
		array $keyword_ideas   = [],
		array $competitors     = []
	): array|\WP_Error {

		$kw_text    = $this->format_keywords_table( $domain_keywords, 30 );
		$ideas_text = ! empty( $keyword_ideas )   ? $this->format_keywords_table( $keyword_ideas, 30 )  : 'No disponible.';
		$comp_text  = ! empty( $competitors )      ? $this->format_competitors_table( $competitors )     : 'No disponible.';

		$user = <<<USER
Analiza la situación SEO de replanta.net y elabora un plan de contenido estratégico.

### Keywords actuales del dominio (muestra)
{$kw_text}

### Ideas de keywords relacionadas
{$ideas_text}

### Principales competidores detectados
{$comp_text}

Por favor elabora:
1. **Mapa de nichos** — identifica los 4-6 clústeres temáticos donde Replanta tiene o puede tener autoridad.
2. **Contenido prioritario a crear** — lista de 10 artículos/páginas específicos con: título SEO propuesto, keyword principal, volumen estimado, intención de búsqueda.
3. **Contenido a reforzar** — páginas existentes que con pequeñas mejoras podrían subir posiciones.
4. **Oportunidades de nicho** — keywords de baja competencia específicas del mercado "web sostenible España".
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result ];
		$this->save_analysis( 'content_plan', $data );

		return $data;
	}

	/* ─────────── Análisis: Competidores ─────────── */

	/**
	 * Analiza competidores y detecta gaps de contenido.
	 *
	 * @param array $competitors
	 * @param array $gap_keywords  Keywords del gap (competidor tiene, nosotros no)
	 * @param array $our_metrics
	 *
	 * @return array|\WP_Error
	 */
	public function analyze_competitors(
		array $competitors,
		array $gap_keywords = [],
		array $our_metrics  = []
	): array|\WP_Error {

		$comp_text = $this->format_competitors_table( $competitors );
		$gap_text  = ! empty( $gap_keywords ) ? $this->format_keywords_table( $gap_keywords, 40 ) : 'No disponible.';

		$our_text = '';
		if ( ! empty( $our_metrics ) ) {
			$our_text = "\n### Métricas propias\n"
				. "- Keywords orgánicas: {$our_metrics['organic_count']}\n"
				. "- Keywords en top 10: {$our_metrics['organic_pos10']}\n"
				. "- Tráfico estimado (ETV): {$our_metrics['etv']}\n";
		}

		$user = <<<USER
Analiza la competencia de replanta.net y detecta las mejores oportunidades de ataque.

### Competidores detectados
{$comp_text}

### Keyword gap (keywords del competidor principal que Replanta no rankea)
{$gap_text}
{$our_text}

Por favor:
1. **Evalúa** cada competidor: ¿es una amenaza real o están en otro mercado?
2. **Identifica** las 15 keywords del gap más valiosas para Replanta (alta relevancia, volumen razonable, baja KD).
3. **Propón** qué tipo de contenido crearía para cada una (artículo, landing, comparativa, guía...).
4. **Detecta** debilidades de los competidores que Replanta puede explotar (ej: no tienen contenido sobre hosting sostenible español).
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result ];
		$this->save_analysis( 'competitors', $data );

		return $data;
	}

	/* ─────────── Análisis: Decaimiento ─────────── */

	/**
	 * Analiza páginas con decaimiento de tráfico y propone plan de recuperación.
	 *
	 * @param array $decaying_pages  Output de RSA_GSC_Client::get_decaying_pages()
	 *
	 * @return array|\WP_Error
	 */
	public function analyze_decaying_pages( array $decaying_pages ): array|\WP_Error {
		if ( empty( $decaying_pages ) ) {
			return [ 'markdown' => "**No se han detectado páginas con decaimiento significativo.** Buen trabajo manteniendo el tráfico.", 'raw' => [] ];
		}

		$table = "| URL | Clicks antes | Clicks ahora | Caída |\n|-----|-----|-----|-----|\n";
		foreach ( array_slice( $decaying_pages, 0, 20 ) as $p ) {
			$table .= "| {$p['page']} | {$p['clicks_before']} | {$p['clicks_after']} | {$p['drop_percent']}% |\n";
		}

		$user = <<<USER
Estas páginas de replanta.net han perdido tráfico orgánico significativo en los últimos 45 días:

{$table}

Por favor:
1. **Agrupa** las páginas por posible causa del decaimiento (contenido desactualizado, cambio de algoritmo, pérdida de backlinks, canibalización, estacionalidad...).
2. Para las **5 más urgentes**, propón un plan de recuperación concreto: qué actualizar, qué añadir, cambios de estructura.
3. Identifica si hay un **patrón común** que explique las caídas.
4. ¿Hay alguna que debería **redirigirse o consolidarse** con otra página?
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result, 'raw' => array_slice( $decaying_pages, 0, 20 ) ];
		$this->save_analysis( 'page_audit', $data );

		return $data;
	}

	/* ─────────── Análisis: Meta Titles ─────────── */

	/**
	 * Genera propuestas de meta titles y descriptions para las queries con más impresiones.
	 *
	 * @param array $quick_wins  Las oportunidades 8-20 (tienen query + página + CTR)
	 *
	 * @return array|\WP_Error
	 */
	public function analyze_meta_titles( array $quick_wins ): array|\WP_Error {
		// Agrupa por página para no repetir
		$pages = [];
		foreach ( $quick_wins as $w ) {
			$page = $w['page'] ?? '';
			if ( empty( $page ) ) continue;
			if ( ! isset( $pages[ $page ] ) ) {
				$pages[ $page ] = [];
			}
			$pages[ $page ][] = $w;
		}

		// Tomar las 15 páginas con más impresiones acumuladas
		uasort( $pages, fn( $a, $b ) =>
			array_sum( array_column( $b, 'impressions' ) ) <=>
			array_sum( array_column( $a, 'impressions' ) )
		);
		$top_pages = array_slice( $pages, 0, 15, true );

		$context = '';
		foreach ( $top_pages as $url => $wins ) {
			$queries  = implode( ', ', array_slice( array_column( $wins, 'query' ), 0, 5 ) );
			$avg_ctr  = round( array_sum( array_column( $wins, 'ctr' ) ) / count( $wins ), 2 );
			$context .= "**URL:** {$url}\n**CTR actual:** {$avg_ctr}% | **Queries:** {$queries}\n\n";
		}

		$user = <<<USER
Genera propuestas de meta title y meta description optimizados para estas páginas de replanta.net.
El CTR actual es bajo — el objetivo es aumentarlo.

{$context}

Para cada URL propón:
- **Meta title** (máx 60 caracteres): incluye la keyword principal, sea atractivo, diferenciador de Replanta.
- **Meta description** (máx 155 caracteres): CTA claro, beneficio concreto, incluye keyword secundaria.
- **Razonamiento** breve: por qué esta versión mejorará el CTR.

Recuerda que Replanta se diferencia por: hosting en España, sostenibilidad, precio transparente.
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result ];
		$this->save_analysis( 'meta_titles', $data );

		return $data;
	}

	/* ─────────── Análisis: Interlinking ─────────── */

	/**
	 * Estrategia de enlazado interno basada en la estructura actual del sitio.
	 *
	 * @param array $domain_keywords  Para entender la arquitectura temática
	 * @param array $decaying_pages   Páginas que necesitan más linkjuice
	 *
	 * @return array|\WP_Error
	 */
	public function analyze_interlinking(
		array $domain_keywords,
		array $decaying_pages = []
	): array|\WP_Error {

		$kw_text    = $this->format_keywords_table( $domain_keywords, 20 );
		$decay_text = '';

		if ( ! empty( $decaying_pages ) ) {
			$decay_text = "\n### Páginas con decaimiento (necesitan linkjuice)\n";
			foreach ( array_slice( $decaying_pages, 0, 10 ) as $p ) {
				$decay_text .= "- {$p['page']} (-{$p['drop_percent']}%)\n";
			}
		}

		$user = <<<USER
Diseña una estrategia de enlazado interno para replanta.net.

### Keywords y páginas principales del dominio
{$kw_text}
{$decay_text}

Por favor:
1. **Identifica los hubs** temáticos del sitio (páginas que deberían recibir más links internos).
2. **Propón los 20 enlaces internos** más valiosos a crear: página fuente → página destino → anchor text sugerido.
3. **Estructura de silos**: ¿debería Replanta crear páginas pilares temáticas? ¿Cuáles?
4. **Reglas de enlazado** para el equipo: criterios simples para decidir cuándo y cómo enlazar internamente.
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result ];
		$this->save_analysis( 'interlinking', $data );

		return $data;
	}

	/* ─────────── Análisis: Imágenes y alt texts ─────────── */

	/**
	 * Analiza imágenes con alt text ausente o deficiente y propone mejoras.
	 *
	 * @param array $images_data  [{attachment_id, src, alt, page_url, title}, ...]
	 * @return array|\WP_Error
	 */
	public function analyze_images( array $images_data ): array|\WP_Error {
		if ( empty( $images_data ) ) {
			$data = [ 'markdown' => '**No se han encontrado imágenes con alt text ausente o deficiente** en la biblioteca de medios.', 'raw_images' => [] ];
			$this->save_analysis( 'image_audit', $data );
			return $data;
		}

		$table  = "| attachment_id | Título | alt actual | Página vinculada |\n";
		$table .= "|--------------|--------|-----------|------------------|\n";
		foreach ( array_slice( $images_data, 0, 60 ) as $img ) {
			$title    = mb_substr( $img['title']    ?? '', 0, 40 );
			$alt      = mb_substr( $img['alt']      ?? '', 0, 60 ) ?: '(vacío)';
			$page_url = mb_substr( $img['page_url'] ?? '', 0, 60 ) ?: '—';
			$att_id   = (int) ( $img['attachment_id'] ?? 0 );
			$table   .= "| {$att_id} | {$title} | {$alt} | {$page_url} |\n";
		}

		$user = <<<USER
Analiza las siguientes imágenes de replanta.net que tienen alt text vacío o deficiente.

{$table}

Para cada imagen:
1. **Propón un alt text** descriptivo, con keyword relevante para SEO cuando sea natural, máx 125 caracteres.
2. **Prioriza** las imágenes con página vinculada conocida (mayor impacto SEO directo).
3. El alt text debe describir la imagen Y aportar contexto de keyword cuando sea natural — evita relleno genérico.
4. No repitas la misma keyword en imágenes consecutivas de la misma página.

Devuelve primero un análisis general del estado del alt text en el sitio, luego una tabla con: attachment_id | alt text propuesto | razonamiento breve.
USER;

		$result = $this->call_claude( $this->get_system_prompt(), $user );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$data = [ 'markdown' => $result, 'raw_images' => array_slice( $images_data, 0, 60 ) ];
		$this->save_analysis( 'image_audit', $data );

		return $data;
	}

	/* ─────────── Extracción de propuestas ejecutables ─────────── */

	/**
	 * Toma el resultado guardado de un análisis y pide a Claude que lo
	 * convierta en propuestas estructuradas para el pipeline de aprobación.
	 *
	 * @param string $type  Tipo de análisis (meta_titles, quick_wins, etc.)
	 * @param array  $saved Datos del análisis guardado (markdown, raw_wins, raw…)
	 * @return array|\WP_Error  Array de items [{url, type, value_after, reasoning}]
	 */
	public function extract_proposals( string $type, array $saved ): array|\WP_Error {
		$markdown = $saved['markdown'] ?? '';
		$raw      = $saved['raw_wins'] ?? $saved['raw'] ?? [];

		$schema = '[ { "url": "https://ejemplo.com/pagina/", "type": "meta_title|meta_desc|focus_kw|interlink|new_draft", "value_after": "valor propuesto", "reasoning": "motivo ≤100 chars" } ]';

		$instructions = match ( $type ) {
			'meta_titles' =>
				"Extrae del análisis una propuesta de meta title (≤60 chars) y meta description (≤155 chars) para cada URL mencionada.\n"
				. "Tipos válidos: meta_title, meta_desc, h1 (titular H1 principal ≤70 chars).\n"
				. "Schema: {$schema}",

			'quick_wins' =>
				"Extrae las acciones prioritarias por página identificadas en el análisis.\n"
				. "Tipos válidos: meta_title (≤60 chars), meta_desc (≤155 chars), focus_kw (keyword principal), h1 (titular H1 ≤70 chars), intro_text (primer párrafo del cuerpo, texto plano ≤400 chars).\n"
				. "Schema: {$schema}",

			'page_audit' =>
				"Extrae propuestas de recuperación concretas para las páginas en declive analizadas.\n"
				. "Tipos válidos: meta_title (≤60 chars), focus_kw, h1 (titular H1 ≤70 chars), intro_text (primer párrafo del cuerpo reescrito, texto plano ≤400 chars).\n"
				. "Schema: {$schema}",

			'interlinking' =>
				"Extrae los enlaces internos propuestos en el análisis como propuestas ejecutables.\n"
				. "El campo 'url' es la página FUENTE del enlace.\n"
				. 'El campo value_after debe ser JSON: {"anchor":"texto","href":"https://dest/","insert_after":"primer párrafo"}' . "\n"
				. "Tipo: interlink. Schema: {$schema}",

			'content_plan' =>
				"Extrae los artículos/piezas de contenido nuevos propuestos en el análisis.\n"
				. "El campo 'url' debe ser vacío (son borradores nuevos).\n"
				. 'El campo value_after debe ser JSON: {"title":"Título","focus_kw":"keyword","outline":"Sección 1, Sección 2"}' . "\n"
				. "Tipo: new_draft. Schema: {$schema}",

			'image_audit' =>
				"Extrae propuestas de alt text para las imágenes de la tabla de análisis.\n"
				. "IMPORTANTE: cada item DEBE incluir el campo 'attachment_id' (integer) exactamente igual que en la tabla.\n"
				. "El campo 'url' debe estar vacío. Tipo: alt_text. El campo 'value_after' es el alt text propuesto (máx 125 chars).\n"
				. 'Schema: [ { "url": "", "attachment_id": 123, "type": "alt_text", "value_after": "alt text descriptivo", "reasoning": "motivo ≤100 chars" } ]',

			default => null,
		};

		if ( $instructions === null ) {
			return new \WP_Error( 'unsupported', "Tipo de análisis '{$type}' no soporta extracción de propuestas." );
		}

		$system = "Eres un extractor de propuestas SEO. Tu única tarea es analizar el texto dado y devolver un array JSON puro, sin explicaciones, sin markdown, sin texto adicional. Solo el array JSON.";

		$user  = $instructions . "\n\n--- ANÁLISIS ---\n" . $markdown;
		if ( ! empty( $raw ) ) {
			$user .= "\n\n--- DATA RAW ---\n" . wp_json_encode( array_slice( $raw, 0, 30 ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		}
		$user .= "\n\nDevuelve SOLO el array JSON válido, sin ningún texto adicional.";

		$response = $this->call_claude( $system, $user );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Strip optional fenced code block markers
		$clean = preg_replace( '/^```(?:json)?\s*/i', '', trim( $response ) );
		$clean = preg_replace( '/\s*```\s*$/', '', $clean );

		// Attempt 1: the cleaned string is already a valid JSON array
		$items = json_decode( trim( $clean ), true );

		// Attempt 2: extract the outer array greedily (handles stray text before/after).
		// NOTE: no /U flag — we need greedy matching so we capture the LAST ]
		if ( ! is_array( $items ) ) {
			if ( preg_match( '/\[[\s\S]+\]/', $clean, $m ) ) {
				$items = json_decode( $m[0], true );
			}
		}

		if ( ! is_array( $items ) ) {
			$preview = mb_substr( $response, 0, 400 );
			return new \WP_Error( 'parse', 'Claude no devolvió un JSON válido. Respuesta: ' . $preview );
		}

		return $items;
	}

	/* ─────────── Formateo de contexto ─────────── */

	private function format_quick_wins_table( array $wins ): string {
		if ( empty( $wins ) ) return 'No hay datos disponibles.';

		$table = "| Query | Posición | Impresiones | Clicks | CTR | Página |\n";
		$table .= "|-------|----------|-------------|--------|-----|--------|\n";

		foreach ( array_slice( $wins, 0, 50 ) as $w ) {
			$page   = basename( rtrim( parse_url( $w['page'] ?? '', PHP_URL_PATH ) ?? '', '/' ) ) ?: '/';
			$table .= "| {$w['query']} | {$w['position']} | {$w['impressions']} | {$w['clicks']} | {$w['ctr']}% | /{$page} |\n";
		}

		return $table;
	}

	private function format_keywords_table( array $keywords, int $limit = 30 ): string {
		if ( empty( $keywords ) ) return 'No hay datos disponibles.';

		$table = "| Keyword | Volumen | KD | CPC | Intención |\n";
		$table .= "|---------|---------|-----|-----|----------|\n";

		foreach ( array_slice( $keywords, 0, $limit ) as $kw ) {
			$vol    = number_format( $kw['search_vol'] ?? 0 );
			$kd     = $kw['keyword_difficulty'] ?? '-';
			$cpc    = isset( $kw['cpc'] ) ? '$' . number_format( (float) $kw['cpc'], 2 ) : '-';
			$intent = $kw['intent'] ?? '-';
			$table .= "| {$kw['keyword']} | {$vol} | {$kd} | {$cpc} | {$intent} |\n";
		}

		return $table;
	}

	private function format_competitors_table( array $competitors ): string {
		if ( empty( $competitors ) ) return 'No hay datos disponibles.';

		$table = "| Dominio | Keywords | Intersecciones | ETV |\n";
		$table .= "|---------|----------|---------------|-----|\n";

		foreach ( array_slice( $competitors, 0, 15 ) as $c ) {
			$domain   = $c['domain'] ?? '';
			$kw_count = $c['competitor_metrics']['organic_count'] ?? 0;
			$inter    = $c['intersections']                       ?? 0;
			$etv      = number_format( $c['competitor_metrics']['etv'] ?? 0 );
			$table .= "| {$domain} | {$kw_count} | {$inter} | {$etv} |\n";
		}

		return $table;
	}
}
