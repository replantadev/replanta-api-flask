<?php
/**
 * Schema Audit — Análisis y generación de Schema.org
 *
 * Pestaña integrada en Site Audit para:
 * - Analizar schemas existentes (RankMath, Yoast, custom)
 * - Detectar duplicados y errores
 * - Generar schemas complementarios con IA
 * - Auto-corregir problemas
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Schema_Audit {
    
    private static ?RSA_Schema_Audit $instance = null;
    
    const META_KEY = '_rsa_custom_schema';
    const CACHE_PREFIX = 'rsa_schema_';
    const CACHE_DURATION = 3600;
    
    private ?string $openai_key = null;
    
    public static function get_instance(): RSA_Schema_Audit {
        return self::$instance ??= new self();
    }
    
    private function __construct() {
        // AJAX handlers
        add_action('wp_ajax_rsa_schema_list',      [$this, 'ajax_list_pages']);
        add_action('wp_ajax_rsa_schema_analyze',   [$this, 'ajax_analyze_page']);
        add_action('wp_ajax_rsa_schema_validate',  [$this, 'ajax_validate_live']);
        add_action('wp_ajax_rsa_schema_generate',  [$this, 'ajax_generate']);
        add_action('wp_ajax_rsa_schema_save',      [$this, 'ajax_save']);
        add_action('wp_ajax_rsa_schema_delete',    [$this, 'ajax_delete']);
        add_action('wp_ajax_rsa_schema_autofix',   [$this, 'ajax_autofix']);
        add_action('wp_ajax_rsa_schema_stats',     [$this, 'ajax_stats']);
        add_action('wp_ajax_rsa_schema_clear_cache', [$this, 'ajax_clear_cache']);
        
        // Frontend output
        add_action('wp_head', [$this, 'output_custom_schema'], 1);
        
        // Load OpenAI key
        $this->openai_key = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : get_option('rsa_openai_api_key');
    }
    
    /* ═══════════════════════════════════════════
     * ADMIN TAB RENDER
     * ═══════════════════════════════════════════ */
    
    public function render_tab(): void {
        ?>
        <div class="rsa-schema-wrap">
            <!-- Stats Bar -->
            <div class="rsa-schema-stats" id="rsa-schema-stats">
                <div class="rsa-stat-item">
                    <span class="rsa-stat-value" id="stat-total">-</span>
                    <span class="rsa-stat-label">Total páginas</span>
                </div>
                <div class="rsa-stat-item">
                    <span class="rsa-stat-value rsa-stat-success" id="stat-ok">-</span>
                    <span class="rsa-stat-label">Schema OK</span>
                </div>
                <div class="rsa-stat-item">
                    <span class="rsa-stat-value rsa-stat-warning" id="stat-warnings">-</span>
                    <span class="rsa-stat-label">Avisos</span>
                </div>
                <div class="rsa-stat-item">
                    <span class="rsa-stat-value rsa-stat-error" id="stat-errors">-</span>
                    <span class="rsa-stat-label">Errores</span>
                </div>
                <div class="rsa-stat-item">
                    <span class="rsa-stat-value rsa-stat-custom" id="stat-custom">-</span>
                    <span class="rsa-stat-label">Custom</span>
                </div>
            </div>
            
            <!-- Filters -->
            <div class="rsa-schema-filters">
                <select id="rsa-schema-filter-type">
                    <option value="">Todos los tipos</option>
                </select>
                <select id="rsa-schema-filter-status">
                    <option value="">Todos los estados</option>
                    <option value="error">Con errores</option>
                    <option value="warning">Con avisos</option>
                    <option value="ok">Sin problemas</option>
                    <option value="custom">Con schema custom</option>
                </select>
                <input type="text" id="rsa-schema-search" placeholder="Buscar por título o URL...">
                <button type="button" class="button" id="rsa-schema-refresh">
                    <span class="dashicons dashicons-update"></span>
                </button>
                <button type="button" class="button" id="rsa-schema-clear-cache">
                    <span class="dashicons dashicons-trash"></span> Limpiar caché
                </button>
            </div>
            
            <!-- Bulk Actions Bar -->
            <div class="rsa-schema-bulk-bar" id="rsa-schema-bulk-bar" style="display:none;">
                <span id="rsa-schema-selected-count">0 seleccionados</span>
                <button type="button" class="button button-primary" id="rsa-bulk-generate">
                    <span class="dashicons dashicons-randomize"></span> Generar
                </button>
                <button type="button" class="button" id="rsa-bulk-validate">
                    <span class="dashicons dashicons-yes-alt"></span> Validar
                </button>
                <button type="button" class="button" id="rsa-bulk-fix">
                    <span class="dashicons dashicons-admin-tools"></span> Auto-Fix
                </button>
                <button type="button" class="button" id="rsa-bulk-cancel">Cancelar</button>
                <div class="rsa-bulk-progress" id="rsa-bulk-progress" style="display:none;">
                    <div class="rsa-progress-bar"><div class="rsa-progress-fill"></div></div>
                    <span class="rsa-progress-text">0%</span>
                </div>
            </div>
            
            <!-- Table -->
            <table class="rsa-schema-table widefat striped">
                <thead>
                    <tr>
                        <th class="rsa-col-check"><input type="checkbox" id="rsa-schema-select-all"></th>
                        <th class="rsa-col-title">Página</th>
                        <th class="rsa-col-types">Tipos Schema</th>
                        <th class="rsa-col-score">Score</th>
                        <th class="rsa-col-actions">Acciones</th>
                    </tr>
                </thead>
                <tbody id="rsa-schema-tbody">
                    <tr><td colspan="5" class="rsa-loading">Cargando...</td></tr>
                </tbody>
            </table>
            
            <!-- Pagination -->
            <div class="rsa-schema-pagination" id="rsa-schema-pagination"></div>
            
            <!-- Modal -->
            <div class="rsa-modal" id="rsa-schema-modal" style="display:none;">
                <div class="rsa-modal-overlay"></div>
                <div class="rsa-modal-content">
                    <div class="rsa-modal-header">
                        <h2 id="rsa-modal-title">Detalle</h2>
                        <button type="button" class="rsa-modal-close">&times;</button>
                    </div>
                    <div class="rsa-modal-body" id="rsa-modal-body"></div>
                    <div class="rsa-modal-footer">
                        <a href="#" id="rsa-google-validate-link" class="button" target="_blank">
                            <span class="dashicons dashicons-external"></span> Test en Google
                        </a>
                        <button type="button" class="button rsa-modal-close">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        <?php echo $this->get_inline_css(); ?>
        </style>
        
        <script>
        <?php echo $this->get_inline_js(); ?>
        </script>
        <?php
    }
    
    /* ═══════════════════════════════════════════
     * AJAX HANDLERS
     * ═══════════════════════════════════════════ */
    
    public function ajax_list_pages(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        $page     = max(1, intval($_GET['page'] ?? 1));
        $per_page = 20;
        $status   = sanitize_text_field($_GET['status'] ?? '');
        $type     = sanitize_text_field($_GET['type'] ?? '');
        $search   = sanitize_text_field($_GET['search'] ?? '');
        
        $args = [
            'post_type'      => ['page', 'post', 'product'],
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];
        
        if ($search) {
            $args['s'] = $search;
        }
        
        $query = new WP_Query($args);
        $items = [];
        
        foreach ($query->posts as $post) {
            $analysis = $this->analyze_post($post->ID);
            
            // Filtrar por status
            if ($status) {
                if ($status === 'custom' && !$analysis['has_custom']) continue;
                if ($status === 'error' && $analysis['status'] !== 'error') continue;
                if ($status === 'warning' && $analysis['status'] !== 'warning') continue;
                if ($status === 'ok' && $analysis['status'] !== 'ok') continue;
            }
            
            // Filtrar por tipo
            if ($type && !in_array($type, $analysis['types'])) continue;
            
            $items[] = [
                'id'         => $post->ID,
                'title'      => $post->post_title,
                'url'        => get_permalink($post->ID),
                'post_type'  => $post->post_type,
                'types'      => $analysis['types'],
                'score'      => $analysis['score'],
                'status'     => $analysis['status'],
                'has_custom' => $analysis['has_custom'],
                'issues'     => count($analysis['issues']),
            ];
        }
        
        wp_send_json_success([
            'items'       => $items,
            'total'       => $query->found_posts,
            'total_pages' => $query->max_num_pages,
            'current'     => $page,
        ]);
    }
    
    public function ajax_analyze_page(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        $post_id = intval($_GET['id'] ?? 0);
        $force   = !empty($_GET['force']);
        
        if (!$post_id) wp_send_json_error('ID requerido.');
        
        if ($force) {
            delete_transient(self::CACHE_PREFIX . $post_id);
        }
        
        $analysis = $this->analyze_post($post_id, true);
        $post = get_post($post_id);
        
        wp_send_json_success([
            'post'   => [
                'id'    => $post_id,
                'title' => $post->post_title,
                'url'   => get_permalink($post_id),
            ],
            'analysis' => $analysis,
        ]);
    }
    
    public function ajax_validate_live(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        $post_id = intval($_GET['id'] ?? 0);
        if (!$post_id) wp_send_json_error('ID requerido.');
        
        $url = get_permalink($post_id);
        $live_check = $this->validate_live($url);
        
        wp_send_json_success([
            'url'              => $url,
            'live_check'       => $live_check,
            'rich_results_url' => 'https://search.google.com/test/rich-results?url=' . urlencode($url),
        ]);
    }
    
    public function ajax_generate(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');

        $post_id = intval($_POST['id'] ?? 0);
        if (!$post_id) wp_send_json_error('ID requerido.');

        $result = $this->generate_schema($post_id);

        if ($result['success']) {
            // Re-analyze to get validation status
            delete_transient(self::CACHE_PREFIX . $post_id);
            $analysis = $this->analyze_post($post_id, true);
            $result['analysis'] = $analysis;
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['error']);
        }
    }
    
    public function ajax_save(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');

        $post_id = intval($_POST['id'] ?? 0);
        $raw     = stripslashes($_POST['schema'] ?? '');
        $schema  = json_decode($raw, true);

        if (!$post_id) wp_send_json_error('ID requerido.');
        if (!$schema) wp_send_json_error('Schema inválido — JSON malformado.');

        // Sanitize before saving
        $html = $this->get_rendered_html($post_id);
        $post = get_post($post_id);
        $signals = $this->extract_page_signals($html, $post);
        $existing_schemas = $this->extract_schemas($html);
        $signals['existing_types'] = [];
        foreach ($existing_schemas as $s) {
            if ($s['valid'] && $s['parsed'] && ($s['source'] ?? '') !== 'custom') {
                $signals['existing_types'] = array_merge($signals['existing_types'], $this->extract_types($s['parsed']));
            }
        }

        $schema = $this->sanitize_generated_schema($schema, $signals);

        if ($this->is_schema_empty($schema)) {
            wp_send_json_error('Schema vacío tras validación — contiene tipos duplicados o inválidos.');
        }

        $this->save_custom_schema($post_id, $schema);
        delete_transient(self::CACHE_PREFIX . $post_id);

        wp_send_json_success(['saved' => true, 'schema' => $schema]);
    }
    
    public function ajax_delete(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        $post_id = intval($_POST['id'] ?? 0);
        if (!$post_id) wp_send_json_error('ID requerido.');
        
        delete_post_meta($post_id, self::META_KEY);
        delete_transient(self::CACHE_PREFIX . $post_id);
        
        wp_send_json_success(['deleted' => true]);
    }
    
    public function ajax_autofix(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        $post_id = intval($_POST['id'] ?? 0);
        if (!$post_id) wp_send_json_error('ID requerido.');
        
        $result = $this->auto_fix($post_id);
        wp_send_json_success($result);
    }
    
    public function ajax_stats(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        $stats = $this->get_stats();
        wp_send_json_success($stats);
    }
    
    public function ajax_clear_cache(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');
        
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rsa_schema_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_rsa_schema_%'");
        
        wp_send_json_success(['cleared' => true]);
    }
    
    /* ═══════════════════════════════════════════
     * ANALYSIS
     * ═══════════════════════════════════════════ */
    
    public function analyze_post(int $post_id, bool $full = false): array {
        $cache_key = self::CACHE_PREFIX . $post_id;
        $cached = get_transient($cache_key);
        
        if ($cached !== false && !$full) {
            return $cached;
        }
        
        $post = get_post($post_id);
        if (!$post || $post->post_status !== 'publish') {
            return $this->empty_analysis();
        }
        
        // Get rendered HTML
        $html = $this->get_rendered_html($post_id);
        
        // Extract schemas from HTML
        $schemas = $this->extract_schemas($html);
        
        // Include custom schema
        $custom = $this->get_custom_schema($post_id);
        if ($custom) {
            $schemas[] = [
                'parsed' => $custom,
                'valid'  => true,
                'source' => 'custom',
            ];
        }
        
        // Analyze
        $analysis = $this->validate_schemas($schemas, $post);
        $analysis['has_custom'] = $custom !== null;
        $analysis['custom_schema'] = $custom;
        
        set_transient($cache_key, $analysis, self::CACHE_DURATION);
        
        return $analysis;
    }
    
    private function empty_analysis(): array {
        return [
            'types'      => [],
            'issues'     => [],
            'score'      => 0,
            'status'     => 'error',
            'has_custom' => false,
        ];
    }
    
    private function get_rendered_html(int $post_id): string {
        $url = get_permalink($post_id);
        
        $response = wp_remote_get($url, [
            'timeout'    => 15,
            'sslverify'  => false,
            'user-agent' => 'RSA-Schema-Analyzer/1.0',
        ]);
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            return wp_remote_retrieve_body($response);
        }
        
        $post = get_post($post_id);
        return apply_filters('the_content', $post->post_content);
    }
    
    private function extract_schemas(string $html): array {
        $schemas = [];
        $pattern = '/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is';
        
        if (preg_match_all($pattern, $html, $matches)) {
            foreach ($matches[1] as $json) {
                $json = trim($json);
                $decoded = json_decode($json, true);
                
                $schemas[] = [
                    'raw'    => $json,
                    'parsed' => $decoded,
                    'valid'  => json_last_error() === JSON_ERROR_NONE,
                    'error'  => json_last_error() !== JSON_ERROR_NONE ? json_last_error_msg() : null,
                    'source' => $this->detect_source($decoded, $html),
                ];
            }
        }
        
        return $schemas;
    }
    
    private function detect_source(?array $data, string $html): string {
        if (preg_match('/<!-- Rank Math/i', $html)) return 'rankmath';
        if (preg_match('/<!-- Yoast SEO/i', $html)) return 'yoast';
        if (preg_match('/<!-- Replanta Author SEO/i', $html)) return 'replanta-author-seo';
        
        if ($data && isset($data['@graph']) && count($data['@graph'] ?? []) > 2) {
            return 'seo-plugin';
        }
        
        return 'unknown';
    }
    
    private function validate_schemas(array $schemas, WP_Post $post): array {
        $types_found = [];
        $issues = [];

        $types_supporting_rating = [
            'Product', 'LocalBusiness', 'Organization', 'Book',
            'Course', 'Event', 'Movie', 'Recipe', 'SoftwareApplication',
        ];

        foreach ($schemas as $schema) {
            if (!$schema['valid'] || empty($schema['parsed'])) {
                $issues[] = [
                    'type'     => 'invalid_json',
                    'message'  => 'JSON inválido: ' . ($schema['error'] ?? 'Error desconocido'),
                    'severity' => 'error',
                ];
                continue;
            }

            $types = $this->extract_types($schema['parsed']);
            foreach ($types as $type) {
                $types_found[$type] = ($types_found[$type] ?? 0) + 1;
            }

            // Deep validation per schema item
            $items = isset($schema['parsed']['@graph'])
                ? $schema['parsed']['@graph']
                : [$schema['parsed']];

            foreach ($items as $item) {
                $item_type = $item['@type'] ?? '';

                // aggregateRating on unsupported type
                if (isset($item['aggregateRating']) && !in_array($item_type, $types_supporting_rating)) {
                    $issues[] = [
                        'type'     => 'invalid_property',
                        'message'  => "aggregateRating en {$item_type} — Google no lo soporta en este tipo",
                        'severity' => 'error',
                    ];
                }

                // FAQPage nested inside another type
                if (isset($item['faq']['@type']) && $item['faq']['@type'] === 'FAQPage') {
                    $issues[] = [
                        'type'     => 'invalid_structure',
                        'message'  => "FAQPage anidado dentro de {$item_type} — debe ser schema independiente",
                        'severity' => 'error',
                    ];
                }

                // Offer with price 0
                if (isset($item['offers']['price']) && (float)$item['offers']['price'] <= 0) {
                    $issues[] = [
                        'type'     => 'suspicious_data',
                        'message'  => "Offer con precio 0 — verifica si el producto/servicio es realmente gratuito",
                        'severity' => 'warning',
                    ];
                }

                // Missing @context at root level (not in @graph items)
                if (!isset($schema['parsed']['@context']) && !isset($schema['parsed']['@graph'])) {
                    if (!isset($schema['parsed']['@id'])) {
                        $issues[] = [
                            'type'     => 'missing_context',
                            'message'  => 'Falta @context en schema raíz',
                            'severity' => 'warning',
                        ];
                    }
                }
            }
        }

        // Detect duplicates
        $duplicates = array_filter($types_found, fn($c) => $c > 1);
        foreach ($duplicates as $type => $count) {
            $issues[] = [
                'type'     => 'duplicate',
                'message'  => "Schema duplicado: {$type} aparece {$count} veces",
                'severity' => 'error',
            ];
        }

        // Calculate score
        $score = 100;
        foreach ($issues as $issue) {
            $score -= ($issue['severity'] === 'error') ? 20 : 10;
        }
        $score = max(0, $score);

        // Determine status
        $has_errors = !empty(array_filter($issues, fn($i) => $i['severity'] === 'error'));
        $has_warnings = !empty(array_filter($issues, fn($i) => $i['severity'] === 'warning'));

        $status = 'ok';
        if ($has_errors) $status = 'error';
        elseif ($has_warnings) $status = 'warning';

        return [
            'types'   => array_keys($types_found),
            'issues'  => $issues,
            'score'   => $score,
            'status'  => $status,
        ];
    }
    
    private function extract_types($data): array {
        $types = [];
        
        if (is_array($data)) {
            if (isset($data['@graph'])) {
                foreach ($data['@graph'] as $item) {
                    $types = array_merge($types, $this->extract_types($item));
                }
            }
            if (isset($data['@type'])) {
                $t = $data['@type'];
                $types[] = is_array($t) ? $t[0] : $t;
            }
        }
        
        return array_unique($types);
    }
    
    /* ═══════════════════════════════════════════
     * LIVE VALIDATION
     * ═══════════════════════════════════════════ */
    
    private function validate_live(string $url): array {
        $response = wp_remote_get($url, [
            'timeout'    => 15,
            'sslverify'  => false,
            'user-agent' => 'RSA-Schema-Validator/1.0',
        ]);
        
        if (is_wp_error($response)) {
            return ['checked' => false, 'error' => $response->get_error_message()];
        }
        
        $html = wp_remote_retrieve_body($response);
        $schemas_found = [];
        $issues = [];
        
        $pattern = '/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is';
        
        if (preg_match_all($pattern, $html, $matches)) {
            foreach ($matches[1] as $idx => $json) {
                $decoded = json_decode(trim($json), true);
                
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $issues[] = "Schema #" . ($idx + 1) . ": JSON inválido";
                } else {
                    $types = $this->extract_types($decoded);
                    $source = $this->detect_source($decoded, $html);
                    $summary = $this->summarize_schema($decoded);
                    
                    $schemas_found[] = [
                        'index'   => $idx + 1,
                        'types'   => $types,
                        'source'  => $source,
                        'valid'   => true,
                        'summary' => $summary,
                        'raw'     => $json,
                    ];
                }
            }
        }
        
        return [
            'checked'       => true,
            'schemas_count' => count($schemas_found),
            'schemas'       => $schemas_found,
            'issues'        => $issues,
            'has_issues'    => !empty($issues),
        ];
    }
    
    private function summarize_schema(array $data): array {
        $summary = ['has_graph' => isset($data['@graph']), 'items' => []];
        
        $items = isset($data['@graph']) ? $data['@graph'] : [$data];
        
        foreach ($items as $item) {
            if (!isset($item['@type'])) continue;
            
            $type = is_array($item['@type']) ? implode(', ', $item['@type']) : $item['@type'];
            $s = ['type' => $type];
            
            if (isset($item['name'])) $s['name'] = mb_substr($item['name'], 0, 60);
            if (isset($item['@id'])) $s['id'] = $item['@id'];
            
            $summary['items'][] = $s;
        }
        
        return $summary;
    }
    
    /* ═══════════════════════════════════════════
     * GENERATION
     * ═══════════════════════════════════════════ */
    
    private function generate_schema(int $post_id): array {
        $post = get_post($post_id);
        if (!$post) {
            return ['success' => false, 'error' => 'Post no encontrado'];
        }

        // Collect real page signals
        $html = $this->get_rendered_html($post_id);
        $signals = $this->extract_page_signals($html, $post);

        // Detect existing schemas to avoid duplicates
        $existing_schemas = $this->extract_schemas($html);
        $existing_types = [];
        foreach ($existing_schemas as $s) {
            if ($s['valid'] && $s['parsed']) {
                $existing_types = array_merge($existing_types, $this->extract_types($s['parsed']));
            }
        }
        $signals['existing_types'] = array_unique($existing_types);

        // Try AI generation first
        if ($this->openai_key) {
            return $this->generate_with_ai($post, $signals);
        }

        // Fallback to template-based generation
        return $this->generate_from_template($post, $signals);
    }

    /**
     * Extract real content signals from rendered HTML
     */
    private function extract_page_signals(string $html, WP_Post $post): array {
        $signals = [
            'page_type'    => 'generic',
            'prices'       => [],
            'faqs'         => [],
            'features'     => [],
            'has_form'     => false,
            'has_video'    => false,
            'images'       => [],
            'testimonials' => [],
        ];

        $text = strip_tags($html);

        // Detect page type from content patterns
        $signals['page_type'] = $this->detect_page_type($text, $post);

        // Extract prices (€, EUR patterns)
        if (preg_match_all('/(\d+[.,]?\d*)\s*€|€\s*(\d+[.,]?\d*)|(\d+[.,]?\d*)\s*EUR/i', $text, $m)) {
            foreach ($m[0] as $idx => $match) {
                $price = $m[1][$idx] ?: ($m[2][$idx] ?: $m[3][$idx]);
                $price = str_replace(',', '.', $price);
                if ((float)$price > 0) {
                    $signals['prices'][] = (float)$price;
                }
            }
            $signals['prices'] = array_unique($signals['prices']);
            sort($signals['prices']);
        }

        // Extract FAQ-like Q&A from structured content (Elementor toggles/accordions)
        if (preg_match_all('/<(?:div|h[2-4]|span)[^>]*class="[^"]*(?:elementor-toggle-title|elementor-tab-title|faq[_-](?:question|title))[^"]*"[^>]*>(.*?)<\/(?:div|h[2-4]|span)>/is', $html, $qm)) {
            // Try to also find answers
            if (preg_match_all('/<div[^>]*class="[^"]*(?:elementor-toggle-content|elementor-tab-content|faq[_-](?:answer|content))[^"]*"[^>]*>(.*?)<\/div>/is', $html, $am)) {
                $count = min(count($qm[1]), count($am[1]));
                for ($i = 0; $i < $count; $i++) {
                    $q = trim(strip_tags($qm[1][$i]));
                    $a = trim(strip_tags($am[1][$i]));
                    if ($q && $a && mb_strlen($q) > 5 && mb_strlen($a) > 10) {
                        $signals['faqs'][] = ['question' => $q, 'answer' => mb_substr($a, 0, 500)];
                    }
                }
            }
        }

        // Extract features from lists
        if (preg_match_all('/<li[^>]*>(.*?)<\/li>/is', $html, $li)) {
            foreach ($li[1] as $item) {
                $clean = trim(strip_tags($item));
                if ($clean && mb_strlen($clean) > 5 && mb_strlen($clean) < 200) {
                    $signals['features'][] = $clean;
                }
            }
            $signals['features'] = array_slice(array_unique($signals['features']), 0, 15);
        }

        // Detect forms
        $signals['has_form'] = (bool)preg_match('/<form\b/i', $html);

        // Detect videos
        $signals['has_video'] = (bool)preg_match('/youtube\.com|vimeo\.com|<video\b/i', $html);

        // Extract key images (og:image or featured)
        if (preg_match('/<meta[^>]*property=["\']og:image["\'][^>]*content=["\']([^"\']+)/i', $html, $img)) {
            $signals['images'][] = $img[1];
        }
        $thumb = get_the_post_thumbnail_url($post->ID, 'full');
        if ($thumb) {
            $signals['images'][] = $thumb;
        }
        $signals['images'] = array_unique($signals['images']);

        return $signals;
    }

    /**
     * Detect the optimal schema type based on page content
     */
    private function detect_page_type(string $text, WP_Post $post): string {
        $text_lower = mb_strtolower($text);
        $title_lower = mb_strtolower($post->post_title);

        // WooCommerce product
        if ($post->post_type === 'product') {
            return 'product';
        }

        // Software/SaaS/Connector keywords
        if (preg_match('/\b(conector|connector|plugin|api|integración|software|saas|app|plataforma|herramienta|tool)\b/i', $title_lower . ' ' . $text_lower)) {
            if (preg_match('/\b(conector|connector|integración|sincroniz|sync|api)\b/i', $text_lower)) {
                return 'software';
            }
            return 'software';
        }

        // Service page patterns
        if (preg_match('/\b(servicio|service|mantenimiento|maintenance|consultoría|auditoría|diseño web|hosting|migración|soporte)\b/i', $title_lower . ' ' . $text_lower)) {
            return 'service';
        }

        // HowTo patterns
        if (preg_match('/\b(cómo|how to|paso a paso|step by step|tutorial|guía|guide)\b/i', $title_lower)) {
            return 'howto';
        }

        // Blog/article
        if ($post->post_type === 'post') {
            return 'article';
        }

        // Landing with pricing
        if (preg_match('/\b(precio|price|plan|tarifa|oferta)\b/i', $text_lower) && preg_match('/\d+\s*€/', $text_lower)) {
            return 'service';
        }

        return 'generic';
    }

    private function generate_with_ai(WP_Post $post, array $signals): array {
        $content = strip_tags($post->post_content);
        $content = mb_substr($content, 0, 3500);

        $context = [
            'title'          => $post->post_title,
            'url'            => get_permalink($post->ID),
            'excerpt'        => get_the_excerpt($post),
            'type'           => $post->post_type,
            'page_type'      => $signals['page_type'],
            'existing_types' => $signals['existing_types'],
        ];

        $prompt = $this->build_prompt($context, $content, $signals);

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->openai_key,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode([
                'model'       => 'gpt-4o-mini',
                'messages'    => [
                    ['role' => 'system', 'content' => $this->get_system_prompt()],
                    ['role' => 'user', 'content' => $prompt],
                ],
                'temperature' => 0.2,
                'max_tokens'  => 2500,
            ]),
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $ai_content = $body['choices'][0]['message']['content'] ?? '';

        // Extract JSON from response
        if (preg_match('/```json\s*([\s\S]*?)\s*```/', $ai_content, $m)) {
            $ai_content = $m[1];
        }
        // Also try to find a raw JSON object
        if (!str_starts_with(trim($ai_content), '{') && !str_starts_with(trim($ai_content), '[')) {
            if (preg_match('/(\{[\s\S]*\})/', $ai_content, $m)) {
                $ai_content = $m[1];
            }
        }

        $schema = json_decode(trim($ai_content), true);

        if (!$schema || json_last_error() !== JSON_ERROR_NONE) {
            // Fallback to template
            return $this->generate_from_template($post, $signals);
        }

        // Sanitize and validate the schema against Google Rich Results rules
        $schema = $this->sanitize_generated_schema($schema, $signals);

        if ($this->is_schema_empty($schema)) {
            return $this->generate_from_template($post, $signals);
        }

        // Save
        $this->save_custom_schema($post->ID, $schema);
        delete_transient(self::CACHE_PREFIX . $post->ID);

        return [
            'success' => true,
            'schema'  => $schema,
            'types'   => $this->extract_types($schema),
            'source'  => 'ai',
        ];
    }

    /**
     * System prompt with strict Google Rich Results rules
     */
    private function get_system_prompt(): string {
        return <<<'PROMPT'
You are an expert in Schema.org structured data for Google Search. You generate ONLY valid JSON-LD that passes Google Rich Results Test. You follow these rules strictly:

CRITICAL GOOGLE VALIDATION RULES:
1. aggregateRating is ONLY valid on: Product, LocalBusiness, Organization, Book, Course, Event, Movie, Recipe, SoftwareApplication — NEVER on WebPage or Service.
2. FAQPage MUST be a standalone schema with @type:"FAQPage" at root level, with mainEntity array of Question objects. NEVER nest FAQPage inside another type.
3. Each Question in FAQPage MUST have: @type:"Question", name (string), acceptedAnswer with @type:"Answer" and text (string).
4. Service type does NOT support aggregateRating in Google Rich Results. Use SoftwareApplication if you need ratings for software.
5. Offer.price MUST be a real price explicitly listed in the "Precios detectados" line of the prompt. If that line says "No se detectaron precios específicos", do NOT include Offer, price, or priceRange — omit the offers block entirely. NEVER estimate or invent prices.
6. Never invent fake reviews, ratings, or testimonials. Only include aggregateRating if real review data is provided.
7. Never include properties that the @type does not support per schema.org specification.
8. Always use @id for cross-referencing between schemas.
9. ABSOLUTE RULE: if you have no explicit price from the prompt, there is NO offers/price field anywhere in your output.

OUTPUT: Return ONLY valid JSON. No markdown, no explanation, no code fences.
PROMPT;
    }

    private function build_prompt(array $context, string $content, array $signals): string {
        $existing = implode(', ', $context['existing_types']);
        $prices_str = !empty($signals['prices'])
            ? 'Precios detectados: ' . implode(', ', array_map(fn($p) => $p . '€', $signals['prices']))
            : 'No se detectaron precios específicos';

        $faqs_str = '';
        if (!empty($signals['faqs'])) {
            $faqs_str = "PREGUNTAS REALES ENCONTRADAS EN LA PÁGINA:\n";
            foreach (array_slice($signals['faqs'], 0, 10) as $faq) {
                $faqs_str .= "  Q: {$faq['question']}\n  A: {$faq['answer']}\n\n";
            }
        }

        $features_str = !empty($signals['features'])
            ? "CARACTERÍSTICAS REALES: " . implode(' | ', array_slice($signals['features'], 0, 10))
            : '';

        $image = !empty($signals['images']) ? $signals['images'][0] : '';

        return "Genera schema JSON-LD COMPLEMENTARIO para esta página. Los schemas existentes ya cubren: [{$existing}]. NO dupliques esos tipos.

PÁGINA:
- Título: {$context['title']}
- URL: {$context['url']}
- Tipo detectado: {$context['page_type']}
- {$prices_str}
- Imagen principal: {$image}

{$faqs_str}
{$features_str}

CONTENIDO RESUMIDO:
{$content}

INSTRUCCIONES ESPECÍFICAS según tipo '{$context['page_type']}':
" . $this->get_type_instructions($context['page_type']) . "

FORMATO: Si generas múltiples schemas, usa un array JSON [] con cada schema como objeto independiente con su propio @context. Si generas uno solo, devuelve un objeto {}.

IMPORTANTE: Usa SOLO datos reales del contenido. No inventes precios, reseñas ni preguntas que no existan en la página.";
    }

    /**
     * Type-specific instructions for the AI prompt
     */
    private function get_type_instructions(string $page_type): string {
        return match ($page_type) {
            'software' => <<<'TXT'
- Genera SoftwareApplication (soporta aggregateRating en Google).
- Incluye: name, description, applicationCategory, operatingSystem:"Web", offers (solo si hay precio real).
- Si hay FAQs reales en la página, genera un SEGUNDO schema FAQPage separado.
- NO uses Service. Usa SoftwareApplication para conectores/plugins/herramientas.
TXT,
            'service' => <<<'TXT'
- Genera Service con: name, description, serviceType, provider (Organization con name y url).
- NO pongas aggregateRating en Service (Google no lo soporta).
- Solo añade offers si la sección "Precios detectados" del prompt lista un precio concreto. Si dice "No se detectaron precios específicos", NO incluyas offers.
- Si hay FAQs reales, genera un SEGUNDO schema FAQPage separado.
TXT,
            'product' => <<<'TXT'
- Genera Product con: name, description, image, offers (Offer con precio real).
- Product SÍ soporta aggregateRating, pero SOLO con datos reales de reviews.
- Si hay FAQs reales, genera un SEGUNDO schema FAQPage separado.
TXT,
            'howto' => <<<'TXT'
- Genera HowTo con: name, description, step[] (cada paso con @type:HowToStep, name, text).
- Extrae los pasos reales del contenido.
- Si hay FAQs reales, genera un SEGUNDO schema FAQPage separado.
TXT,
            'article' => <<<'TXT'
- Genera Article con: headline, description, image, datePublished, dateModified, author.
- Si hay FAQs reales, genera un SEGUNDO schema FAQPage separado.
TXT,
            default => <<<'TXT'
- Analiza el contenido y elige el tipo más apropiado: SoftwareApplication, Service, Product, HowTo, Article.
- Si hay FAQs reales, genera un schema FAQPage separado.
- Si no hay datos suficientes para un tipo específico, genera solo FAQPage si hay preguntas, o nada si no hay datos.
TXT,
        };
    }

    /**
     * Sanitize AI-generated schema to ensure Google Rich Results validity
     */
    private function sanitize_generated_schema(array $schema, array $signals): array {
        // If it's an array of schemas, sanitize each
        if (isset($schema[0]) && is_array($schema[0])) {
            $schemas = array_filter(array_map(fn($s) => $this->sanitize_single_schema($s, $signals), $schema));
            if (count($schemas) === 1) {
                return reset($schemas);
            }
            if (count($schemas) === 0) {
                return [];
            }
            // Wrap multiple schemas in @graph
            return [
                '@context' => 'https://schema.org',
                '@graph'   => array_values(array_map(function ($s) {
                    unset($s['@context']);
                    return $s;
                }, $schemas)),
            ];
        }

        // If it has @graph, sanitize each item
        if (isset($schema['@graph'])) {
            $schema['@graph'] = array_values(array_filter(
                array_map(fn($s) => $this->sanitize_single_schema($s, $signals), $schema['@graph'])
            ));
            if (empty($schema['@graph'])) return [];
            if (count($schema['@graph']) === 1) {
                return ['@context' => 'https://schema.org'] + $schema['@graph'][0];
            }
            return $schema;
        }

        return $this->sanitize_single_schema($schema, $signals);
    }

    private function sanitize_single_schema(array $schema, array $signals): array {
        $type = $schema['@type'] ?? '';

        // Remove forbidden types that RankMath already generates
        $forbidden_types = ['WebSite', 'WebPage', 'BreadcrumbList'];
        if (in_array($type, $forbidden_types) || in_array($type, $signals['existing_types'] ?? [])) {
            return [];
        }

        // Ensure @context exists at root level
        if (!isset($schema['@context']) && !isset($schema['@id'])) {
            $schema['@context'] = 'https://schema.org';
        }

        // aggregateRating: only valid on specific types
        $types_supporting_rating = [
            'Product', 'LocalBusiness', 'Organization', 'Book',
            'Course', 'Event', 'Movie', 'Recipe', 'SoftwareApplication',
        ];
        if (isset($schema['aggregateRating']) && !in_array($type, $types_supporting_rating)) {
            unset($schema['aggregateRating']);
        }

        // Remove nested FAQPage — extract it as separate schema
        if (isset($schema['faq']) || isset($schema['mainEntity']) && $this->looks_like_faq($schema['mainEntity'])) {
            // Don't nest FAQPage inside other types
            if ($type !== 'FAQPage') {
                unset($schema['faq']);
                // Only remove mainEntity if it looks like FAQ questions, not if it's a legit mainEntity
                if (isset($schema['mainEntity']) && $this->looks_like_faq($schema['mainEntity'])) {
                    unset($schema['mainEntity']);
                }
            }
        }

        // Validate FAQPage structure
        if ($type === 'FAQPage') {
            $schema = $this->sanitize_faq_schema($schema);
            if (empty($schema['mainEntity'])) {
                return [];
            }
        }

        // Validate Offer — remove if price is "0" or "0.00" and no real price detected
        if (isset($schema['offers'])) {
            $schema['offers'] = $this->sanitize_offers($schema['offers'], $signals);
            if (empty($schema['offers'])) {
                unset($schema['offers']);
            }
        }

        // Remove aggregateRating with obviously fake/placeholder data
        if (isset($schema['aggregateRating'])) {
            $rating = $schema['aggregateRating'];
            $ratingCount = (int)($rating['ratingCount'] ?? $rating['reviewCount'] ?? 0);
            // Remove if it looks fabricated (perfect 5/5 with very few reviews)
            if ($ratingCount < 1) {
                unset($schema['aggregateRating']);
            }
        }

        // Remove empty provider
        if (isset($schema['provider']) && empty(array_filter($schema['provider'], fn($v) => $v !== null && $v !== ''))) {
            unset($schema['provider']);
        }

        return $schema;
    }

    private function looks_like_faq($data): bool {
        if (!is_array($data)) return false;
        // Check if it's a FAQPage type
        if (isset($data['@type']) && $data['@type'] === 'FAQPage') return true;
        // Check if it's an array of Questions
        if (isset($data[0]['@type']) && $data[0]['@type'] === 'Question') return true;
        return false;
    }

    private function sanitize_faq_schema(array $schema): array {
        if (!isset($schema['mainEntity']) || !is_array($schema['mainEntity'])) {
            return $schema;
        }

        // Ensure mainEntity is an indexed array
        if (isset($schema['mainEntity']['@type'])) {
            $schema['mainEntity'] = [$schema['mainEntity']];
        }

        // Validate each question
        $valid_questions = [];
        foreach ($schema['mainEntity'] as $q) {
            if (!isset($q['@type']) || $q['@type'] !== 'Question') continue;
            if (empty($q['name'])) continue;
            if (!isset($q['acceptedAnswer']['@type']) || $q['acceptedAnswer']['@type'] !== 'Answer') continue;
            if (empty($q['acceptedAnswer']['text'])) continue;

            $valid_questions[] = [
                '@type' => 'Question',
                'name'  => $q['name'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text'  => $q['acceptedAnswer']['text'],
                ],
            ];
        }

        $schema['mainEntity'] = $valid_questions;
        return $schema;
    }

    private function sanitize_offers($offers, array $signals): array|null {
        if (!is_array($offers)) return null;

        // Single offer
        if (isset($offers['@type'])) {
            $price = (float)($offers['price'] ?? 0);
            // If price is 0 and no real prices detected, remove it
            if ($price <= 0 && empty($signals['prices'])) {
                return null;
            }
            // Ensure required fields
            $offers['@type'] = 'Offer';
            if (!isset($offers['priceCurrency'])) {
                $offers['priceCurrency'] = 'EUR';
            }
            return $offers;
        }

        // Array of offers
        $valid = [];
        foreach ($offers as $offer) {
            $sanitized = $this->sanitize_offers($offer, $signals);
            if ($sanitized) $valid[] = $sanitized;
        }
        return $valid ?: null;
    }

    /**
     * Template-based generation as fallback (no AI)
     */
    private function generate_from_template(WP_Post $post, array $signals): array {
        $url = get_permalink($post->ID);
        $schemas = [];

        switch ($signals['page_type']) {
            case 'software':
                $schema = [
                    '@context'            => 'https://schema.org',
                    '@type'               => 'SoftwareApplication',
                    '@id'                 => $url . '#software',
                    'name'                => $post->post_title,
                    'description'         => get_the_excerpt($post) ?: mb_substr(strip_tags($post->post_content), 0, 160),
                    'url'                 => $url,
                    'applicationCategory' => 'BusinessApplication',
                    'operatingSystem'     => 'Web',
                ];
                if (!empty($signals['prices'])) {
                    $schema['offers'] = [
                        '@type'         => 'Offer',
                        'price'         => (string)$signals['prices'][0],
                        'priceCurrency' => 'EUR',
                        'url'           => $url,
                    ];
                }
                if (!empty($signals['images'])) {
                    $schema['image'] = $signals['images'][0];
                }
                $schemas[] = $schema;
                break;

            case 'service':
                $schema = [
                    '@context'    => 'https://schema.org',
                    '@type'       => 'Service',
                    '@id'         => $url . '#service',
                    'name'        => $post->post_title,
                    'description' => get_the_excerpt($post) ?: mb_substr(strip_tags($post->post_content), 0, 160),
                    'url'         => $url,
                    'provider'    => [
                        '@type' => 'Organization',
                        'name'  => get_bloginfo('name'),
                        'url'   => home_url('/'),
                    ],
                ];
                if (!empty($signals['prices'])) {
                    $schema['offers'] = [
                        '@type'         => 'Offer',
                        'price'         => (string)$signals['prices'][0],
                        'priceCurrency' => 'EUR',
                        'url'           => $url,
                    ];
                }
                $schemas[] = $schema;
                break;

            case 'article':
                $schemas[] = [
                    '@context'      => 'https://schema.org',
                    '@type'         => 'Article',
                    '@id'           => $url . '#article',
                    'headline'      => $post->post_title,
                    'url'           => $url,
                    'datePublished' => get_the_date('c', $post),
                    'dateModified'  => get_the_modified_date('c', $post),
                    'author'        => [
                        '@type' => 'Person',
                        'name'  => get_the_author_meta('display_name', $post->post_author),
                    ],
                    'image' => !empty($signals['images']) ? $signals['images'][0] : null,
                ];
                break;

            default:
                // Generic: at minimum generate Article for posts, Service for pages
                $fallback_type = $post->post_type === 'post' ? 'Article' : 'Service';
                $schemas[] = [
                    '@context'    => 'https://schema.org',
                    '@type'       => $fallback_type,
                    '@id'         => $url . '#' . strtolower($fallback_type),
                    'name'        => $post->post_title,
                    'description' => get_the_excerpt($post) ?: mb_substr(strip_tags($post->post_content), 0, 160),
                    'url'         => $url,
                ];
                if ($fallback_type === 'Service') {
                    $schemas[0]['provider'] = [
                        '@type' => 'Organization',
                        'name'  => get_bloginfo('name'),
                        'url'   => home_url('/'),
                    ];
                }
                break;
        }

        // Add FAQPage if real FAQs detected
        if (!empty($signals['faqs'])) {
            $faq_schema = [
                '@context'   => 'https://schema.org',
                '@type'      => 'FAQPage',
                '@id'        => $url . '#faq',
                'mainEntity' => array_map(fn($faq) => [
                    '@type' => 'Question',
                    'name'  => $faq['question'],
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text'  => $faq['answer'],
                    ],
                ], array_slice($signals['faqs'], 0, 10)),
            ];
            $schemas[] = $faq_schema;
        }

        // Filter out null image values
        $schemas = array_map(function ($s) {
            if (isset($s['image']) && $s['image'] === null) unset($s['image']);
            return $s;
        }, $schemas);

        // Merge into final schema
        $final = count($schemas) === 1
            ? $schemas[0]
            : [
                '@context' => 'https://schema.org',
                '@graph'   => array_map(function ($s) {
                    unset($s['@context']);
                    return $s;
                }, $schemas),
            ];

        $this->save_custom_schema($post->ID, $final);
        delete_transient(self::CACHE_PREFIX . $post->ID);

        return [
            'success' => true,
            'schema'  => $final,
            'types'   => $this->extract_types($final),
            'source'  => 'template',
        ];
    }
    
    /* ═══════════════════════════════════════════
     * AUTO-FIX
     * ═══════════════════════════════════════════ */
    
    private function auto_fix(int $post_id): array {
        $analysis = $this->analyze_post($post_id, true);
        $fixes = [];
        
        // Check for duplicates between custom and page schemas
        $custom = $this->get_custom_schema($post_id);
        
        if ($custom) {
            // Get page schemas without custom
            $html = $this->get_rendered_html($post_id);
            $page_schemas = $this->extract_schemas($html);
            
            $page_types = [];
            foreach ($page_schemas as $s) {
                if ($s['valid'] && $s['parsed']) {
                    $page_types = array_merge($page_types, $this->extract_types($s['parsed']));
                }
            }
            $page_types = array_unique($page_types);
            
            $custom_types = $this->extract_types($custom);
            $duplicates = array_intersect($page_types, $custom_types);
            
            if (!empty($duplicates)) {
                // Remove duplicate types from custom schema
                $cleaned = $this->remove_types_from_schema($custom, $duplicates);
                
                if (empty($cleaned) || $this->is_schema_empty($cleaned)) {
                    delete_post_meta($post_id, self::META_KEY);
                    $fixes[] = ['type' => 'removed', 'label' => 'Schema custom eliminado (tipos duplicados)'];
                } else {
                    $this->save_custom_schema($post_id, $cleaned);
                    $fixes[] = ['type' => 'deduped', 'label' => 'Tipos duplicados eliminados: ' . implode(', ', $duplicates)];
                }
                
                delete_transient(self::CACHE_PREFIX . $post_id);
            }
        }
        
        // If no custom and has issues, try generating
        if (!$custom && $analysis['status'] !== 'ok' && $this->openai_key) {
            $gen = $this->generate_schema($post_id);
            if ($gen['success']) {
                $fixes[] = ['type' => 'generated', 'label' => 'Schema generado con IA'];
            }
        }
        
        // Re-analyze
        delete_transient(self::CACHE_PREFIX . $post_id);
        $new_analysis = $this->analyze_post($post_id, true);
        
        return [
            'fixes'    => $fixes,
            'analysis' => $new_analysis,
        ];
    }
    
    private function remove_types_from_schema(array $schema, array $types): array {
        if (isset($schema['@type'])) {
            $t = is_array($schema['@type']) ? $schema['@type'][0] : $schema['@type'];
            if (in_array($t, $types)) {
                return [];
            }
        }
        
        if (isset($schema['@graph'])) {
            $schema['@graph'] = array_values(array_filter($schema['@graph'], function($item) use ($types) {
                if (!isset($item['@type'])) return true;
                $t = is_array($item['@type']) ? $item['@type'][0] : $item['@type'];
                return !in_array($t, $types);
            }));
            
            if (count($schema['@graph']) === 1) {
                return ['@context' => 'https://schema.org'] + $schema['@graph'][0];
            }
            if (count($schema['@graph']) === 0) {
                return [];
            }
        }
        
        return $schema;
    }
    
    private function is_schema_empty(array $schema): bool {
        if (empty($schema)) return true;
        if (count($schema) === 1 && isset($schema['@context'])) return true;
        if (isset($schema['@graph']) && empty($schema['@graph'])) return true;
        return false;
    }
    
    /* ═══════════════════════════════════════════
     * STORAGE
     * ═══════════════════════════════════════════ */
    
    public function get_custom_schema(int $post_id): ?array {
        $meta = get_post_meta($post_id, self::META_KEY, true);
        if (empty($meta)) return null;
        
        if (is_string($meta)) {
            $meta = json_decode($meta, true);
        }
        
        return is_array($meta) ? $meta : null;
    }
    
    public function save_custom_schema(int $post_id, array $schema): bool {
        return (bool) update_post_meta($post_id, self::META_KEY, $schema);
    }
    
    /* ═══════════════════════════════════════════
     * FRONTEND OUTPUT
     * ═══════════════════════════════════════════ */
    
    public function output_custom_schema(): void {
        if (!is_singular()) return;

        $schema = $this->get_custom_schema(get_the_ID());
        if (!$schema) return;

        $flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;

        // If it has @graph, output each item as a separate script tag for cleaner validation
        if (isset($schema['@graph']) && is_array($schema['@graph'])) {
            foreach ($schema['@graph'] as $item) {
                $item['@context'] = 'https://schema.org';
                echo "\n<!-- RSA Custom Schema -->\n";
                echo '<script type="application/ld+json">';
                echo wp_json_encode($item, $flags);
                echo "</script>\n";
            }
            return;
        }

        echo "\n<!-- RSA Custom Schema -->\n";
        echo '<script type="application/ld+json">';
        echo wp_json_encode($schema, $flags);
        echo "</script>\n";
    }
    
    /* ═══════════════════════════════════════════
     * STATS
     * ═══════════════════════════════════════════ */
    
    private function get_stats(): array {
        global $wpdb;
        
        $total = $wpdb->get_var("
            SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_type IN ('page','post','product') 
            AND post_status = 'publish'
        ");
        
        $custom = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta}
            WHERE meta_key = %s
        ", self::META_KEY));
        
        return [
            'total'    => (int) $total,
            'custom'   => (int) $custom,
            'ok'       => 0, // Would need full scan
            'warnings' => 0,
            'errors'   => 0,
        ];
    }
    
    /* ═══════════════════════════════════════════
     * INLINE CSS
     * ═══════════════════════════════════════════ */
    
    private function get_inline_css(): string {
        return <<<'CSS'
.rsa-schema-wrap { padding: 0; }

/* Stats */
.rsa-schema-stats {
    display: flex;
    gap: 24px;
    padding: 20px 0;
    border-bottom: 1px solid #ddd;
    margin-bottom: 20px;
}
.rsa-stat-item { text-align: center; }
.rsa-stat-value { 
    display: block; 
    font-size: 28px; 
    font-weight: 600; 
    line-height: 1.2;
}
.rsa-stat-label { font-size: 12px; color: #666; text-transform: uppercase; }
.rsa-stat-success { color: #00a32a; }
.rsa-stat-warning { color: #dba617; }
.rsa-stat-error { color: #d63638; }
.rsa-stat-custom { color: #0073aa; }

/* Filters */
.rsa-schema-filters {
    display: flex;
    gap: 12px;
    align-items: center;
    padding: 12px 0;
    flex-wrap: wrap;
}
.rsa-schema-filters select,
.rsa-schema-filters input { min-width: 180px; }

/* Bulk Bar */
.rsa-schema-bulk-bar {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: #f0f6fc;
    border: 1px solid #0073aa;
    border-radius: 4px;
    margin-bottom: 16px;
}
.rsa-bulk-progress { flex: 1; display: flex; align-items: center; gap: 8px; }
.rsa-progress-bar { flex: 1; height: 8px; background: #ddd; border-radius: 4px; overflow: hidden; }
.rsa-progress-fill { height: 100%; background: #0073aa; transition: width 0.3s; }

/* Table */
.rsa-schema-table { margin-top: 0; }
.rsa-schema-table th { font-weight: 600; }
.rsa-col-check { width: 40px; }
.rsa-col-score { width: 80px; text-align: center; }
.rsa-col-actions { width: 200px; }

.rsa-schema-table tbody tr.loading { opacity: 0.5; pointer-events: none; }
.rsa-schema-table tbody tr.flash-success { animation: flashSuccess 0.5s; }
.rsa-schema-table tbody tr.flash-error { animation: flashError 0.5s; }

@keyframes flashSuccess { 0%,100% { background: transparent; } 50% { background: #d4edda; } }
@keyframes flashError { 0%,100% { background: transparent; } 50% { background: #f8d7da; } }

/* Score badges */
.rsa-score {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 13px;
}
.rsa-score-high { background: #d4edda; color: #155724; }
.rsa-score-medium { background: #fff3cd; color: #856404; }
.rsa-score-low { background: #f8d7da; color: #721c24; }

/* Type tags */
.rsa-type-tag {
    display: inline-block;
    background: #e9ecef;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 11px;
    margin: 1px;
}

/* Custom badge */
.rsa-custom-badge {
    background: #0073aa;
    color: #fff;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 10px;
    margin-left: 4px;
}

/* Actions */
.rsa-actions { display: flex; gap: 4px; }
.rsa-btn {
    padding: 4px 8px;
    border: 1px solid #ddd;
    background: #f7f7f7;
    border-radius: 3px;
    cursor: pointer;
    font-size: 12px;
}
.rsa-btn:hover { background: #e0e0e0; }
.rsa-btn--primary { background: #0073aa; color: #fff; border-color: #0073aa; }
.rsa-btn--primary:hover { background: #005a87; }
.rsa-btn--fix { background: #dba617; color: #fff; border-color: #dba617; }
.rsa-btn--fix:hover { background: #b08812; }
.rsa-btn .dashicons { font-size: 14px; width: 14px; height: 14px; vertical-align: middle; }

/* Loading */
.rsa-loading { text-align: center; padding: 40px; color: #666; }

/* Pagination */
.rsa-schema-pagination {
    display: flex;
    gap: 4px;
    justify-content: center;
    padding: 20px 0;
}
.rsa-schema-pagination button.current { background: #0073aa; color: #fff; }

/* Modal */
.rsa-modal {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
}
.rsa-modal-overlay {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.6);
}
.rsa-modal-content {
    position: relative;
    background: #fff;
    border-radius: 8px;
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    display: flex;
    flex-direction: column;
}
.rsa-modal-header {
    padding: 16px 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.rsa-modal-header h2 { margin: 0; font-size: 18px; }
.rsa-modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    line-height: 1;
}
.rsa-modal-body {
    padding: 20px;
    overflow-y: auto;
    flex: 1;
}
.rsa-modal-footer {
    padding: 16px 20px;
    border-top: 1px solid #ddd;
    display: flex;
    justify-content: flex-end;
    gap: 8px;
}

/* Schema items in modal */
.rsa-schema-item {
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-bottom: 8px;
}
.rsa-schema-header {
    padding: 10px 12px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    background: #f8f9fa;
}
.rsa-schema-header:hover { background: #eee; }
.rsa-schema-title { flex: 1; }
.rsa-schema-expand { transition: transform 0.2s; }
.rsa-schema-item.expanded .rsa-schema-expand { transform: rotate(180deg); }

.rsa-schema-summary,
.rsa-schema-code { display: none; padding: 12px; border-top: 1px solid #eee; }
.rsa-schema-item.expanded .rsa-schema-summary,
.rsa-schema-item.expanded .rsa-schema-code { display: block; }

.rsa-schema-code pre {
    background: #1e1e1e;
    color: #d4d4d4;
    padding: 12px;
    border-radius: 4px;
    overflow-x: auto;
    max-height: 250px;
    font-size: 11px;
    margin-top: 8px;
}

/* Source tags */
.rsa-source-tag {
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 3px;
    font-weight: 500;
    text-transform: uppercase;
}
.rsa-source-rankmath { background: #e91e63; color: #fff; }
.rsa-source-yoast { background: #a4286a; color: #fff; }
.rsa-source-replanta-author-seo { background: #41999F; color: #fff; }
.rsa-source-custom { background: #0073aa; color: #fff; }
.rsa-source-unknown { background: #9e9e9e; color: #fff; }

/* Issues */
.rsa-issue-error { color: #d63638; }
.rsa-issue-warning { color: #dba617; }
CSS;
    }
    
    /* ═══════════════════════════════════════════
     * INLINE JS
     * ═══════════════════════════════════════════ */
    
    private function get_inline_js(): string {
        $ajax_url = esc_url(admin_url('admin-ajax.php'));
        $nonce = wp_create_nonce('rsa_audit');
        
        // Config object with PHP variables, then nowdoc for the rest
        $config = "var rsaSchemaConfig={url:'{$ajax_url}',nonce:'{$nonce}'};";
        
        $js = <<<'JS'
(function() {
    'use strict';
    
    const ajaxUrl = rsaSchemaConfig.url;
    const nonce = rsaSchemaConfig.nonce;
    
    let currentPage = 1;
    let selectedIds = new Set();
    let pagesData = {};
    
    document.addEventListener('DOMContentLoaded', init);
    
    function init() {
        loadStats();
        loadPages();
        bindEvents();
    }
    
    function bindEvents() {
        document.getElementById('rsa-schema-filter-type')?.addEventListener('change', () => { currentPage = 1; loadPages(); });
        document.getElementById('rsa-schema-filter-status')?.addEventListener('change', () => { currentPage = 1; loadPages(); });
        document.getElementById('rsa-schema-search')?.addEventListener('input', debounce(() => { currentPage = 1; loadPages(); }, 400));
        document.getElementById('rsa-schema-refresh')?.addEventListener('click', () => { loadStats(); loadPages(); });
        document.getElementById('rsa-schema-clear-cache')?.addEventListener('click', clearCache);
        document.getElementById('rsa-schema-select-all')?.addEventListener('change', toggleSelectAll);
        document.getElementById('rsa-bulk-generate')?.addEventListener('click', bulkGenerate);
        document.getElementById('rsa-bulk-validate')?.addEventListener('click', bulkValidate);
        document.getElementById('rsa-bulk-fix')?.addEventListener('click', bulkFix);
        document.getElementById('rsa-bulk-cancel')?.addEventListener('click', clearSelection);
        
        document.querySelectorAll('.rsa-modal-close, .rsa-modal-overlay').forEach(el => {
            el.addEventListener('click', closeModal);
        });
    }
    
    async function loadStats() {
        try {
            const data = await ajaxCall('rsa_schema_stats');
            document.getElementById('stat-total').textContent = data.total;
            document.getElementById('stat-ok').textContent = data.ok || '-';
            document.getElementById('stat-warnings').textContent = data.warnings || '-';
            document.getElementById('stat-errors').textContent = data.errors || '-';
            document.getElementById('stat-custom').textContent = data.custom;
        } catch (e) {
            console.error('Stats error:', e);
        }
    }
    
    async function loadPages() {
        const tbody = document.getElementById('rsa-schema-tbody');
        tbody.innerHTML = '<tr><td colspan="5" class="rsa-loading">Cargando...</td></tr>';
        
        const params = new URLSearchParams({
            page: currentPage,
            status: document.getElementById('rsa-schema-filter-status')?.value || '',
            type: document.getElementById('rsa-schema-filter-type')?.value || '',
            search: document.getElementById('rsa-schema-search')?.value || '',
        });
        
        try {
            const data = await ajaxCall('rsa_schema_list', params);
            renderTable(data.items);
            renderPagination(data);
            data.items.forEach(item => { pagesData[item.id] = item; });
        } catch (e) {
            tbody.innerHTML = '<tr><td colspan="5" class="rsa-loading">Error al cargar</td></tr>';
        }
    }
    
    function renderTable(items) {
        const tbody = document.getElementById('rsa-schema-tbody');
        
        if (!items.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="rsa-loading">No hay resultados</td></tr>';
            return;
        }
        
        tbody.innerHTML = items.map(item => {
            const scoreClass = item.score >= 70 ? 'rsa-score-high' : (item.score >= 40 ? 'rsa-score-medium' : 'rsa-score-low');
            const types = (item.types || []).slice(0, 4).map(t => `<span class="rsa-type-tag">${t}</span>`).join('');
            const customBadge = item.has_custom ? '<span class="rsa-custom-badge">CUSTOM</span>' : '';
            
            return `
                <tr data-id="${item.id}">
                    <td><input type="checkbox" class="rsa-row-check" data-id="${item.id}" ${selectedIds.has(item.id) ? 'checked' : ''}></td>
                    <td>
                        <a href="${item.url}" target="_blank">${escHtml(item.title)}</a>
                        ${customBadge}
                        <div style="font-size:11px;color:#666;">${item.post_type}</div>
                    </td>
                    <td>${types || '<em style="color:#999">—</em>'}</td>
                    <td style="text-align:center;">
                        <span class="rsa-score ${scoreClass}">${item.score}</span>
                    </td>
                    <td>
                        <div class="rsa-actions">
                            <button class="rsa-btn rsa-btn--primary" onclick="rsaGenerate(${item.id})" title="Generar">
                                <span class="dashicons dashicons-randomize"></span>
                            </button>
                            <button class="rsa-btn" onclick="rsaDetail(${item.id})" title="Detalle">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                            <button class="rsa-btn" onclick="rsaValidate(${item.id})" title="Validar">
                                <span class="dashicons dashicons-yes-alt"></span>
                            </button>
                            <button class="rsa-btn rsa-btn--fix" onclick="rsaAutoFix(${item.id})" title="Auto-Fix">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
        
        tbody.querySelectorAll('.rsa-row-check').forEach(cb => {
            cb.addEventListener('change', () => {
                const id = parseInt(cb.dataset.id);
                cb.checked ? selectedIds.add(id) : selectedIds.delete(id);
                updateBulkBar();
            });
        });
    }
    
    function renderPagination(data) {
        const container = document.getElementById('rsa-schema-pagination');
        if (data.total_pages <= 1) { container.innerHTML = ''; return; }
        
        let html = '';
        for (let i = 1; i <= data.total_pages; i++) {
            if (i === 1 || i === data.total_pages || (i >= data.current - 2 && i <= data.current + 2)) {
                html += `<button class="button ${i === data.current ? 'current' : ''}" onclick="rsaGoToPage(${i})">${i}</button>`;
            } else if (i === data.current - 3 || i === data.current + 3) {
                html += '<span>...</span>';
            }
        }
        container.innerHTML = html;
    }
    
    function updateBulkBar() {
        const bar = document.getElementById('rsa-schema-bulk-bar');
        const count = document.getElementById('rsa-schema-selected-count');
        
        if (selectedIds.size > 0) {
            bar.style.display = 'flex';
            count.textContent = selectedIds.size + ' seleccionados';
        } else {
            bar.style.display = 'none';
        }
    }
    
    function toggleSelectAll() {
        const checked = document.getElementById('rsa-schema-select-all').checked;
        document.querySelectorAll('.rsa-row-check').forEach(cb => {
            cb.checked = checked;
            const id = parseInt(cb.dataset.id);
            checked ? selectedIds.add(id) : selectedIds.delete(id);
        });
        updateBulkBar();
    }
    
    function clearSelection() {
        selectedIds.clear();
        document.querySelectorAll('.rsa-row-check').forEach(cb => cb.checked = false);
        document.getElementById('rsa-schema-select-all').checked = false;
        updateBulkBar();
    }
    
    // Global functions
    window.rsaGoToPage = function(page) {
        currentPage = page;
        loadPages();
    };
    
    window.rsaGenerate = async function(postId) {
        setRowLoading(postId, true);
        try {
            const data = await ajaxCall('rsa_schema_generate', null, 'POST', { id: postId });
            setRowLoading(postId, false);
            flashRow(postId, 'success');
            
            // Show generated schema in modal for review
            const schema = data.schema;
            const types = (data.types || []).map(t => `<span class="rsa-type-tag">${t}</span>`).join(' ');
            const source = data.source === 'ai' ? 'IA' : 'Template';
            const analysis = data.analysis || {};
            
            let issuesHtml = '';
            if (analysis.issues && analysis.issues.length > 0) {
                issuesHtml = '<h4 style="color:#d63638;">Problemas detectados:</h4><ul>' +
                    analysis.issues.map(i => `<li class="rsa-issue-${i.severity}">${escHtml(i.message)}</li>`).join('') +
                    '</ul>';
            } else {
                issuesHtml = '<p style="color:#00a32a;">✓ Schema válido — sin problemas detectados</p>';
            }
            
            document.getElementById('rsa-modal-title').textContent = 'Schema generado — ' + source;
            document.getElementById('rsa-modal-body').innerHTML = `
                <p><strong>Tipos generados:</strong> ${types}</p>
                <p><strong>Score:</strong> <span class="rsa-score ${(analysis.score||0) >= 70 ? 'rsa-score-high' : ((analysis.score||0) >= 40 ? 'rsa-score-medium' : 'rsa-score-low')}">${analysis.score || '?'}</span></p>
                ${issuesHtml}
                <h4>Schema JSON-LD:</h4>
                <textarea id="rsa-schema-editor" style="width:100%;height:300px;font-family:monospace;font-size:12px;tab-size:2;">${escHtml(JSON.stringify(schema, null, 2))}</textarea>
                <div style="margin-top:12px;display:flex;gap:8px;">
                    <button class="button button-primary" onclick="rsaSaveEditedSchema(${postId})">Guardar cambios</button>
                    <button class="button" onclick="navigator.clipboard.writeText(document.getElementById('rsa-schema-editor').value).then(()=>alert('Copiado'))">Copiar</button>
                    <button class="button" onclick="rsaDeleteSchema(${postId})">Eliminar</button>
                </div>
            `;
            document.getElementById('rsa-schema-modal').style.display = 'flex';
            
            loadPages();
        } catch (e) {
            setRowLoading(postId, false);
            flashRow(postId, 'error');
            alert('Error: ' + (e.message || 'Error al generar schema'));
        }
    };
    
    window.rsaSaveEditedSchema = async function(postId) {
        const editor = document.getElementById('rsa-schema-editor');
        if (!editor) return;
        
        try {
            JSON.parse(editor.value); // validate JSON
        } catch(e) {
            alert('JSON inválido: ' + e.message);
            return;
        }
        
        try {
            await ajaxCall('rsa_schema_save', null, 'POST', { id: postId, schema: editor.value });
            alert('Schema guardado correctamente');
            closeModal();
            loadPages();
        } catch(e) {
            alert('Error al guardar: ' + (e.message || 'Error'));
        }
    };
    
    window.rsaDeleteSchema = async function(postId) {
        if (!confirm('¿Eliminar el schema custom de esta página?')) return;
        try {
            await ajaxCall('rsa_schema_delete', null, 'POST', { id: postId });
            alert('Schema eliminado');
            closeModal();
            loadPages();
        } catch(e) {
            alert('Error: ' + (e.message || 'Error'));
        }
    };
    
    window.rsaDetail = async function(postId) {
        openModal('Cargando...');
        try {
            const data = await ajaxCall('rsa_schema_analyze', { id: postId, force: 1 });
            renderDetailModal(data);
        } catch (e) {
            document.getElementById('rsa-modal-body').innerHTML = '<p>Error al cargar</p>';
        }
    };
    
    window.rsaValidate = async function(postId) {
        setRowLoading(postId, true);
        try {
            const data = await ajaxCall('rsa_schema_validate', { id: postId });
            setRowLoading(postId, false);
            renderValidationModal(data);
        } catch (e) {
            setRowLoading(postId, false);
            flashRow(postId, 'error');
        }
    };
    
    window.rsaAutoFix = async function(postId) {
        setRowLoading(postId, true);
        try {
            const data = await ajaxCall('rsa_schema_autofix', null, 'POST', { id: postId });
            setRowLoading(postId, false);
            if (data.fixes && data.fixes.length > 0) {
                flashRow(postId, 'success');
            }
            loadPages();
        } catch (e) {
            setRowLoading(postId, false);
            flashRow(postId, 'error');
        }
    };
    
    async function bulkGenerate() {
        const ids = Array.from(selectedIds);
        const progress = document.getElementById('rsa-bulk-progress');
        const fill = progress.querySelector('.rsa-progress-fill');
        const text = progress.querySelector('.rsa-progress-text');
        
        progress.style.display = 'flex';
        
        for (let i = 0; i < ids.length; i++) {
            try {
                await ajaxCall('rsa_schema_generate', null, 'POST', { id: ids[i] });
                flashRow(ids[i], 'success');
            } catch (e) {
                flashRow(ids[i], 'error');
            }
            
            const pct = Math.round(((i + 1) / ids.length) * 100);
            fill.style.width = pct + '%';
            text.textContent = pct + '%';
        }
        
        progress.style.display = 'none';
        clearSelection();
        loadPages();
    }
    
    async function bulkValidate() {
        const ids = Array.from(selectedIds);
        for (const id of ids) {
            await rsaValidate(id);
        }
    }
    
    async function bulkFix() {
        const ids = Array.from(selectedIds);
        for (const id of ids) {
            await rsaAutoFix(id);
        }
        clearSelection();
    }
    
    async function clearCache() {
        try {
            await ajaxCall('rsa_schema_clear_cache', null, 'POST');
            alert('Caché limpiada');
            loadPages();
        } catch (e) {
            alert('Error al limpiar caché');
        }
    }
    
    function renderDetailModal(data) {
        const p = data.post;
        const a = data.analysis;
        
        let issuesHtml = '';
        if (a.issues && a.issues.length > 0) {
            issuesHtml = '<h3>Problemas</h3><ul>' + 
                a.issues.map(i => `<li class="rsa-issue-${i.severity}">${escHtml(i.message)}</li>`).join('') +
                '</ul>';
        } else {
            issuesHtml = '<p style="color:#00a32a;">✓ Sin problemas detectados</p>';
        }
        
        let customHtml = '';
        if (a.custom_schema) {
            customHtml = `<h3>Schema Custom <span class="rsa-custom-badge">EDITABLE</span></h3>
                <textarea id="rsa-schema-editor" style="width:100%;height:250px;font-family:monospace;font-size:11px;tab-size:2;">${escHtml(JSON.stringify(a.custom_schema, null, 2))}</textarea>
                <div style="margin-top:8px;display:flex;gap:8px;">
                    <button class="button button-primary" onclick="rsaSaveEditedSchema(${p.id})">Guardar</button>
                    <button class="button" onclick="navigator.clipboard.writeText(document.getElementById('rsa-schema-editor').value).then(()=>alert('Copiado'))">Copiar</button>
                    <button class="button" style="color:#d63638;" onclick="rsaDeleteSchema(${p.id})">Eliminar</button>
                </div>`;
        }
        
        document.getElementById('rsa-modal-title').textContent = p.title;
        document.getElementById('rsa-google-validate-link').href = 'https://search.google.com/test/rich-results?url=' + encodeURIComponent(p.url);
        document.getElementById('rsa-modal-body').innerHTML = `
            <p><strong>URL:</strong> <a href="${p.url}" target="_blank">${p.url}</a></p>
            <p><strong>Score:</strong> <span class="rsa-score ${a.score >= 70 ? 'rsa-score-high' : (a.score >= 40 ? 'rsa-score-medium' : 'rsa-score-low')}">${a.score}</span></p>
            <p><strong>Tipos:</strong> ${(a.types || []).map(t => `<span class="rsa-type-tag">${t}</span>`).join(' ') || '—'}</p>
            ${issuesHtml}
            ${customHtml}
        `;
        
        document.getElementById('rsa-schema-modal').style.display = 'flex';
    }
    
    function renderValidationModal(data) {
        const lc = data.live_check;
        
        let schemasHtml = '';
        if (lc.schemas && lc.schemas.length > 0) {
            schemasHtml = '<h3>Schemas detectados</h3>';
            lc.schemas.forEach((s, idx) => {
                const sourceTag = s.source ? `<span class="rsa-source-tag rsa-source-${s.source}">${s.source}</span>` : '';
                const summaryHtml = s.summary?.items?.map(i => `<li><strong>${i.type}</strong>${i.name ? ': ' + i.name : ''}</li>`).join('') || '';
                
                schemasHtml += `
                    <div class="rsa-schema-item">
                        <div class="rsa-schema-header" onclick="this.parentElement.classList.toggle('expanded')">
                            <span>${s.valid ? '✓' : '✗'}</span>
                            <span class="rsa-schema-title">Schema #${s.index}: <strong>${s.types.join(', ')}</strong></span>
                            ${sourceTag}
                            <span class="dashicons dashicons-arrow-down-alt2 rsa-schema-expand"></span>
                        </div>
                        <div class="rsa-schema-summary"><ul>${summaryHtml}</ul></div>
                        <div class="rsa-schema-code">
                            <button class="button button-small" onclick="navigator.clipboard.writeText(this.nextElementSibling.textContent)">Copiar</button>
                            <pre>${escHtml(formatJson(s.raw))}</pre>
                        </div>
                    </div>
                `;
            });
        }
        
        let issuesHtml = '';
        if (lc.issues && lc.issues.length > 0) {
            issuesHtml = '<h3>Problemas</h3><ul>' + lc.issues.map(i => `<li>${escHtml(i)}</li>`).join('') + '</ul>';
        } else {
            issuesHtml = '<p style="color:#00a32a;">✓ No se encontraron problemas estructurales</p>';
        }
        
        document.getElementById('rsa-modal-title').textContent = 'Validación en vivo';
        document.getElementById('rsa-google-validate-link').href = data.rich_results_url;
        document.getElementById('rsa-modal-body').innerHTML = `
            <p><strong>URL:</strong> <a href="${data.url}" target="_blank">${data.url}</a></p>
            <p><strong>Schemas encontrados:</strong> ${lc.schemas_count}</p>
            ${schemasHtml}
            ${issuesHtml}
        `;
        
        document.getElementById('rsa-schema-modal').style.display = 'flex';
    }
    
    function openModal(title) {
        document.getElementById('rsa-modal-title').textContent = title;
        document.getElementById('rsa-modal-body').innerHTML = '<p>Cargando...</p>';
        document.getElementById('rsa-schema-modal').style.display = 'flex';
    }
    
    function closeModal() {
        document.getElementById('rsa-schema-modal').style.display = 'none';
    }
    
    function setRowLoading(postId, loading) {
        const row = document.querySelector(`tr[data-id="${postId}"]`);
        if (row) row.classList.toggle('loading', loading);
    }
    
    function flashRow(postId, type) {
        const row = document.querySelector(`tr[data-id="${postId}"]`);
        if (!row) return;
        row.classList.add('flash-' + type);
        setTimeout(() => row.classList.remove('flash-' + type), 500);
    }
    
    async function ajaxCall(action, params, method = 'GET', postData = null) {
        let url = `${ajaxUrl}?action=${action}&_nonce=${nonce}`;
        
        if (params) {
            // Convert plain object to URLSearchParams if needed
            const searchParams = params instanceof URLSearchParams 
                ? params 
                : new URLSearchParams(params);
            url += '&' + searchParams.toString();
        }
        
        const opts = { method };
        
        if (method === 'POST' && postData) {
            const fd = new FormData();
            fd.append('_nonce', nonce);
            for (const [k, v] of Object.entries(postData)) {
                fd.append(k, v);
            }
            opts.body = fd;
        }
        
        const response = await fetch(url, opts);
        const json = await response.json();
        
        if (!json.success) {
            throw new Error(json.data || 'Error');
        }
        
        return json.data;
    }
    
    function debounce(fn, ms) {
        let timer;
        return function(...args) {
            clearTimeout(timer);
            timer = setTimeout(() => fn.apply(this, args), ms);
        };
    }
    
    function escHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
    
    function formatJson(str) {
        try {
            return JSON.stringify(JSON.parse(str), null, 2);
        } catch (e) {
            return str;
        }
    }
})();
JS;
        
        return $config . $js;
    }
}
