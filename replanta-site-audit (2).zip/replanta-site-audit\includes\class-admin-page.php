<?php
/**
 * Admin Page — Dashboard de Auditoría v2.0
 *
 * Panel premium con score global, módulos, historial
 * y botones de auto-fix para problemas corregibles.
 *
 * @package Replanta_Site_Audit
 * @version 2.4.3
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Admin_Page {

    private static ?RSA_Admin_Page $instance = null;

    public static function get_instance(): RSA_Admin_Page {
        return self::$instance ??= new self();
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_rsa_run_audit',    [$this, 'ajax_run_audit']);
        add_action('wp_ajax_rsa_run_fix',      [$this, 'ajax_run_fix']);
        add_action('wp_ajax_rsa_run_fix_all',  [$this, 'ajax_run_fix_all']);
    }

    /* ─────────── Menu ─────────── */

    public function add_menu(): void {
        $hook = add_menu_page(
            'Site Audit — Replanta', 'Site Audit', 'manage_options',
            'replanta-site-audit', [$this, 'render_page'],
            'dashicons-shield-alt', 3
        );

        // Suppress other plugins' admin notices on this page — they clutter
        // the plugin header. This plugin has its own notification system.
        add_action("load-{$hook}", static function () {
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
        });
    }

    /* ─────────── Assets ─────────── */

    public function enqueue_assets(string $hook): void {
        if ($hook !== 'toplevel_page_replanta-site-audit') return;
        wp_enqueue_style('rsa-dashboard', RSA_PLUGIN_URL . 'assets/css/audit-dashboard.css', [], RSA_VERSION);
        wp_enqueue_script('rsa-dashboard', RSA_PLUGIN_URL . 'assets/js/audit-dashboard.js', ['jquery'], RSA_VERSION, true);

        $bot     = RSA_Bot_Healer::get_instance();
        $bset    = $bot->get_settings();
        $bstats  = $bot->get_log_stats();

        wp_localize_script('rsa-dashboard', 'rsaAjax', [
            'url'   => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rsa_audit'),
        ]);
        // Chart.js para la gráfica de histórico (solo en esta página)
        wp_register_script(
            'chartjs',
            'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js',
            [],
            '4.4.3',
            true
        );
        wp_enqueue_script('chartjs');
        wp_register_script('phosphor-icons', 'https://unpkg.com/@phosphor-icons/web@2.1.1', [], '2.1.1', true);
        wp_enqueue_script('phosphor-icons');
        wp_localize_script('rsa-dashboard', 'rsaHistory', RSA_Audit_Engine::get_history());

        wp_localize_script('rsa-dashboard', 'rsaBot', [
            'enabled'                  => $bset['enabled'],
            'schedule'                 => $bset['schedule'],
            'fill_metas'               => $bset['fill_metas'],
            'max_per_run'              => $bset['meta_max_per_run'],
            'post_types'               => $bset['meta_post_types'],
            'sync_translations'        => $bset['sync_translations'],
            'translations_max_per_run' => $bset['translations_max_per_run'],
            'next_run'                 => $bot->get_next_run(),
            'last_run'                 => $bot->get_last_run(),
            'stats'                    => $bstats,
            'polylang_active'          => RSA_Translation_Sync::is_available(),
        ]);
    }

    /* ─────────── AJAX ─────────── */

    public function ajax_run_audit(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');

        @set_time_limit(120);
        if (function_exists('wp_raise_memory_limit')) wp_raise_memory_limit('admin');

        // Rate limit: 1 auditoría fresca por usuario cada 2 minutos
        $rate_key = 'rsa_audit_rate_' . get_current_user_id();
        if (get_transient($rate_key)) {
            wp_send_json_success(RSA_Audit_Engine::run(false)); // devuelve caché
            return;
        }
        set_transient($rate_key, 1, 120);

        try {
            wp_send_json_success(RSA_Audit_Engine::run(true));
        } catch (\Throwable $e) {
            error_log('RSA ajax_run_audit fatal: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
            wp_send_json_error('Error en auditoría: ' . $e->getMessage());
        }
    }

    public function ajax_run_fix(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');

        $fix_id = sanitize_text_field($_POST['fix_id'] ?? '');
        if (empty($fix_id)) wp_send_json_error('fix_id requerido.');

        $result = RSA_Audit_Engine::execute_fix($fix_id);
        $result['success'] ? wp_send_json_success($result) : wp_send_json_error($result['message']);
    }

    public function ajax_run_fix_all(): void {
        check_ajax_referer('rsa_audit', '_nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Permisos insuficientes.');

        $result = RSA_Audit_Engine::execute_all_fixes();
        wp_send_json_success($result);
    }

    /* ─────────── Render ─────────── */

    public function render_page(): void {
        $result     = get_transient(RSA_Audit_Engine::TRANSIENT_KEY) ?: null;
        $history    = RSA_Audit_Engine::get_history();
        $bot        = RSA_Bot_Healer::get_instance();
        $bset       = $bot->get_settings();
        $active_tab = sanitize_text_field($_GET['rsa_tab'] ?? 'audit');

        // Spawn cron if it's overdue (WP-Cron is pseudo-cron, needs a request to fire)
        if ($bset['enabled']) {
            $next_cron = wp_next_scheduled(RSA_Bot_Healer::CRON_HOOK);
            if ($next_cron && $next_cron < time()) {
                if (function_exists('wp_spawn_cron')) {
                    wp_spawn_cron(); // WP >= 5.9
                } else {
                    // Fallback: non-blocking ping to wp-cron.php (WP < 5.9)
                    wp_remote_post(site_url('wp-cron.php'), [
                        'timeout'   => 0.01,
                        'blocking'  => false,
                        'sslverify' => apply_filters('https_local_ssl_verify', false),
                    ]);
                }
            }
        }
        ?>
        <div class="wrap rsa-wrap">
            <div class="rsa-header">
                <div class="rsa-header-left">
                    <h1>Site Audit <span class="rsa-version">v<?php echo RSA_VERSION; ?></span></h1>
                    <p class="rsa-subtitle">Diagnóstico de <strong><?php echo esc_html(RSA_DOMAIN); ?></strong> &mdash; Cloudflare &middot; SEO &middot; Rendimiento</p>
                </div>
                <div class="rsa-header-right">
                    <!-- Audit buttons — toggled by JS when switching tabs -->
                    <div id="rsa-header-audit-btns" style="display:flex;gap:8px;align-items:center;">
                        <?php if ($result && !empty($result['summary']['fixable'])): ?>
                            <button id="rsa-fix-all" class="button button-secondary button-hero rsa-btn-fix-all">
                                <span class="dashicons dashicons-admin-tools"></span> Corregir Todo (<?php echo $result['summary']['fixable']; ?>)
                            </button>
                        <?php endif; ?>
                        <button id="rsa-run-audit" class="button button-primary button-hero">
                            <span class="dashicons dashicons-update"></span> Ejecutar Auditoría
                        </button>
                    </div>
                    <!-- Bot buttons: NO buttons here — they live inside the bot tab card to avoid duplicate IDs -->
                    <div id="rsa-header-bot-btns" style="display:none;"></div>
                </div>
            </div>

            <!-- JS-driven tab nav (no page reload = no scan interruption) -->
            <nav class="rsa-tab-nav">
                <button type="button" class="rsa-tab <?php echo $active_tab === 'audit' ? 'rsa-tab-active' : ''; ?>" data-tab="audit">
                    <span class="dashicons dashicons-shield-alt"></span> Auditoría
                </button>
                <button type="button" class="rsa-tab <?php echo $active_tab === 'bot' ? 'rsa-tab-active' : ''; ?>" data-tab="bot">
                    <span class="dashicons dashicons-superhero"></span> Bot de Salud
                    <?php if ($bset['enabled']): ?>
                        <span class="rsa-tab-badge rsa-badge-pass">ON</span>
                    <?php else: ?>
                        <span class="rsa-tab-badge">OFF</span>
                    <?php endif; ?>
                </button>
                <button type="button" class="rsa-tab <?php echo $active_tab === 'deps' ? 'rsa-tab-active' : ''; ?>" data-tab="deps">
                    <span class="dashicons dashicons-admin-plugins"></span> Dependencias
                    <?php
                    $ready = RSA_Dependencies::ready_count();
                    $total = count(RSA_Dependencies::get_all());
                    $badge_class = $ready === $total ? 'rsa-badge-pass' : ($ready >= $total - 1 ? 'rsa-badge-warn' : 'rsa-badge-fail');
                    ?>
                    <span class="rsa-tab-badge <?php echo $badge_class; ?>"><?php echo $ready; ?>/<?php echo $total; ?></span>
                </button>
                <button type="button" class="rsa-tab <?php echo $active_tab === 'schema' ? 'rsa-tab-active' : ''; ?>" data-tab="schema">
                    <span class="dashicons dashicons-code-standards"></span> Schema
                </button>
                <button type="button" class="rsa-tab <?php echo $active_tab === 'config' ? 'rsa-tab-active' : ''; ?>" data-tab="config">
                    <span class="dashicons dashicons-admin-generic"></span> Configuración
                </button>
                <button type="button" class="rsa-tab <?php echo $active_tab === 'seo' ? 'rsa-tab-active' : ''; ?>" data-tab="seo">
                    <span class="dashicons dashicons-chart-line"></span> Agente SEO
                    <span class="rsa-tab-badge rsa-badge-info">IA</span>
                </button>
            </nav>

            <!-- Tab: Auditoría -->
            <div id="rsa-tab-audit" class="rsa-tab-content" <?php echo $active_tab !== 'audit' ? 'style="display:none"' : ''; ?>>
                <?php if ($result): ?>
                    <?php $this->render_dashboard($result, $history); ?>
                <?php else: ?>
                    <div class="rsa-empty-state">
                        <div class="rsa-empty-icon"></div>
                        <h2>No hay auditoría disponible</h2>
                        <p>Haz clic en <strong>"Ejecutar Auditoría"</strong> para analizar tu sitio.</p>
                    </div>
                <?php endif; ?>

                <div id="rsa-results-container" style="display:none;"></div>

                <div id="rsa-loading" style="display:none;">
                    <div class="rsa-loading-inner">
                        <div class="rsa-spinner"></div>
                        <h3>Analizando <?php echo esc_html(RSA_DOMAIN); ?>&hellip;</h3>
                        <p>Consultando API de Cloudflare, verificando SEO y midiendo rendimiento.</p>
                        <ul id="rsa-progress-steps">
                            <li id="rsp-cf"   class="rsp-step">&#x1F50D; Auditando Cloudflare&hellip;</li>
                            <li id="rsp-seo"  class="rsp-step">&#x1F4C8; Analizando SEO&hellip;</li>
                            <li id="rsp-perf" class="rsp-step">&#x26A1; Midiendo rendimiento&hellip;</li>
                            <li id="rsp-done" class="rsp-step">&#x2705; Consolidando resultados&hellip;</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Tab: Bot de Salud -->
            <div id="rsa-tab-bot" class="rsa-tab-content" <?php echo $active_tab !== 'bot' ? 'style="display:none"' : ''; ?>>
                <?php $this->render_bot_tab($bot); ?>
            </div>

            <!-- Tab: Dependencias -->
            <div id="rsa-tab-deps" class="rsa-tab-content" <?php echo $active_tab !== 'deps' ? 'style="display:none"' : ''; ?>>
                <div class="rsa-module-card" style="margin-top:20px;padding:28px 32px">
                    <?php RSA_Dependencies::render_panel(); ?>
                </div>
            </div>

            <!-- Tab: Schema -->
            <div id="rsa-tab-schema" class="rsa-tab-content" <?php echo $active_tab !== 'schema' ? 'style="display:none"' : ''; ?>>
                <div class="rsa-module-card" style="margin-top:20px;padding:28px 32px">
                    <?php RSA_Schema_Audit::get_instance()->render_tab(); ?>
                </div>
            </div>

            <!-- Tab: Configuración -->
            <div id="rsa-tab-config" class="rsa-tab-content" <?php echo $active_tab !== 'config' ? 'style="display:none"' : ''; ?>>
                <?php RSA_SEO_Agent::get_instance()->render_config_tab(); ?>
            </div>

            <!-- Tab: Agente SEO -->
            <div id="rsa-tab-seo" class="rsa-tab-content" <?php echo $active_tab !== 'seo' ? 'style="display:none"' : ''; ?>>
                <?php RSA_SEO_Agent::get_instance()->render_tab(); ?>
            </div>

        </div><?php /* .rsa-wrap */
    }

    private function render_dashboard(array $result, array $history): void {
        $score      = $result['global_score'];
        $modules    = $result['modules'];
        $summary    = $result['summary'];
        $checks     = $result['checks'];
        $from_cache = $result['from_cache'] ?? false;
        $timestamp  = $result['timestamp'] ?? '';
        $duration   = $result['duration'] ?? 0;

        $grouped = RSA_Audit_Engine::group_checks($checks);
        $issues  = RSA_Audit_Engine::get_issues($checks);
        ?>

        <!-- ── Score Cards ── -->
        <div class="rsa-score-grid" id="rsa-dashboard">
            <div class="rsa-card rsa-card-score rsa-score-<?php echo $this->score_class((int)($score ?? 0)); ?>">
                <div class="rsa-score-ring">
                    <svg viewBox="0 0 120 120">
                        <circle cx="60" cy="60" r="54" fill="none" stroke="#eee" stroke-width="8"/>
                        <circle cx="60" cy="60" r="54" fill="none" stroke="currentColor" stroke-width="8"
                                stroke-dasharray="<?php echo round(339.292 * $score / 100); ?> 339.292"
                                stroke-linecap="round" transform="rotate(-90 60 60)"/>
                    </svg>
                    <span class="rsa-score-number"><?php echo $score; ?></span>
                </div>
                <div class="rsa-score-label">Score Global</div>
                <div class="rsa-score-meta">
                    <?php if ($from_cache): ?><span class="rsa-cache-badge">Cache</span><?php endif; ?>
                    <span title="<?php echo esc_attr($timestamp); ?>"><?php echo esc_html($timestamp); ?></span>
                    <span><?php echo $duration; ?>s</span>
                </div>
            </div>

            <div class="rsa-card rsa-card-module">
                <div class="rsa-module-icon">CF</div>
                <div class="rsa-module-score rsa-score-<?php echo $this->score_class($modules['cloudflare']['score'] ?? 0); ?>">
                    <?php echo $modules['cloudflare']['score'] ?? 0; ?>%
                </div>
                <div class="rsa-module-label">Cloudflare</div>
                <?php if (!($modules['cloudflare']['ok'] ?? false)): ?>
                    <div class="rsa-module-error"><?php echo esc_html($modules['cloudflare']['error'] ?? ''); ?></div>
                <?php endif; ?>
            </div>

            <div class="rsa-card rsa-card-module">
                <div class="rsa-module-icon">SEO</div>
                <div class="rsa-module-score rsa-score-<?php echo $this->score_class($modules['seo']['score'] ?? 0); ?>"><?php echo $modules['seo']['score'] ?? 0; ?>%</div>
                <div class="rsa-module-label">SEO</div>
            </div>

            <div class="rsa-card rsa-card-module">
                <div class="rsa-module-icon">PERF</div>
                <div class="rsa-module-score rsa-score-<?php echo $this->score_class($modules['performance']['score'] ?? 0); ?>"><?php echo $modules['performance']['score'] ?? 0; ?>%</div>
                <div class="rsa-module-label">Rendimiento</div>
            </div>
        </div>

        <!-- ── Summary Bar ── -->
        <div class="rsa-summary-bar">
            <span class="rsa-badge rsa-badge-pass"><?php echo $summary['passed']; ?> OK</span>
            <span class="rsa-badge rsa-badge-info"><?php echo $summary['info']; ?> Info</span>
            <span class="rsa-badge rsa-badge-warning"><?php echo $summary['warnings']; ?> Avisos</span>
            <span class="rsa-badge rsa-badge-critical"><?php echo $summary['critical']; ?> Críticos</span>
            <?php if (!empty($summary['fixable'])): ?>
                <span class="rsa-badge rsa-badge-fixable"><?php echo $summary['fixable']; ?> Corregibles</span>
            <?php endif; ?>
            <span class="rsa-badge rsa-badge-total">Total: <?php echo $summary['total']; ?> checks</span>
        </div>

        <!-- ── Issues with Fix Buttons ── -->
        <?php if (!empty($issues)): ?>
        <div class="rsa-card rsa-card-issues">
            <h2>Problemas que requieren atención</h2>
            <div class="rsa-issues-list">
                <?php foreach ($issues as $check): ?>
                    <div class="rsa-issue rsa-issue-<?php echo esc_attr($check['status']); ?>">
                        <div class="rsa-issue-status"><span class="rsa-dot rsa-dot-<?php echo esc_attr($check['status']); ?>"></span></div>
                        <div class="rsa-issue-content">
                            <strong><?php echo esc_html($check['label']); ?></strong>
                            <span class="rsa-issue-value"><?php echo esc_html($check['value']); ?></span>
                            <p><?php echo nl2br(esc_html($check['detail'])); ?></p>
                        </div>
                        <div class="rsa-issue-actions">
                            <span class="rsa-issue-cat"><?php echo esc_html(ucfirst($check['category'])); ?></span>
                            <?php if (!empty($check['fixable'])): ?>
                                <button class="button rsa-fix-btn" data-fix-id="<?php echo esc_attr($check['fix_id']); ?>">
                                    <span class="dashicons dashicons-admin-tools"></span>
                                    <?php echo esc_html($check['fix_label'] ?? 'Corregir'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- ── Detailed Checks ── -->
        <div class="rsa-checks-wrapper">
            <?php
            $cat_labels = [
                'security'    => ['Seguridad', 'Cloudflare y WordPress'],
                'seo'         => ['SEO', 'Indexación, meta tags, hreflang'],
                'performance' => ['Rendimiento', 'Cache, compresión, TTFB'],
                'dns'         => ['DNS', 'Registros DNS y resolución'],
                'general'     => ['General', 'Estado general del sitio'],
            ];

            foreach ($cat_labels as $cat_key => [$cat_title, $cat_desc]):
                $cat_checks = $grouped[$cat_key] ?? [];
                if (empty($cat_checks)) continue;
                $cat_passed = count(array_filter($cat_checks, fn($c) => $c['status'] === 'pass'));
                $cat_total  = count($cat_checks);
            ?>
            <div class="rsa-card rsa-card-category">
                <div class="rsa-category-header" data-toggle="rsa-cat-<?php echo $cat_key; ?>">
                    <div class="rsa-category-title">
                        <h3><?php echo $cat_title; ?></h3><p><?php echo $cat_desc; ?></p>
                    </div>
                    <div class="rsa-category-score">
                        <span class="rsa-cat-ratio"><?php echo $cat_passed; ?>/<?php echo $cat_total; ?></span>
                        <span class="dashicons dashicons-arrow-down-alt2 rsa-toggle-icon"></span>
                    </div>
                </div>
                <div class="rsa-category-checks" id="rsa-cat-<?php echo $cat_key; ?>">
                    <table class="rsa-checks-table">
                        <tbody>
                        <?php foreach ($cat_checks as $check): ?>
                            <tr class="rsa-check-row rsa-check-<?php echo esc_attr($check['status']); ?>">
                                <td class="rsa-check-icon"><?php echo $this->status_icon($check['status']); ?></td>
                                <td class="rsa-check-label"><?php echo esc_html($check['label']); ?></td>
                                <td class="rsa-check-value"><?php echo esc_html($check['value']); ?></td>
                                <td class="rsa-check-detail"><?php echo nl2br(esc_html($check['detail'])); ?></td>
                                <td class="rsa-check-fix">
                                    <?php if (!empty($check['fixable'])): ?>
                                        <button class="button button-small rsa-fix-btn" data-fix-id="<?php echo esc_attr($check['fix_id']); ?>">
                                            <?php echo esc_html($check['fix_label'] ?? 'Fix'); ?>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- ── History ── -->
        <?php if (count($history) > 1): ?>
        <div class="rsa-card rsa-card-history-chart">
            <h2>Evolución del score</h2>
            <canvas id="rsa-history-chart" height="80"></canvas>
        </div>
        <div class="rsa-card rsa-card-history">
            <h2>Historial de Auditorías</h2>
            <table class="rsa-history-table">
                <thead>
                    <tr><th>Fecha</th><th>Score</th><th>CF</th><th>SEO</th><th>Perf</th><th>Crit</th><th>Warn</th></tr>
                </thead>
                <tbody>
                <?php foreach (array_reverse($history) as $entry): ?>
                    <tr>
                        <td><?php echo esc_html($entry['timestamp']); ?></td>
                        <td class="rsa-score-<?php echo $this->score_class($entry['global_score'] ?? 0); ?>"><strong><?php echo $entry['global_score'] ?? 0; ?>%</strong></td>
                        <td><?php echo $entry['cf_score'] ?? '-'; ?>%</td>
                        <td><?php echo $entry['seo_score'] ?? '-'; ?>%</td>
                        <td><?php echo $entry['perf_score'] ?? '-'; ?>%</td>
                        <td><?php echo $entry['critical'] ?? 0; ?></td>
                        <td><?php echo $entry['warnings'] ?? 0; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        <?php
    }

    /* ─────────── UI Helpers ─────────── */

    private function render_bot_tab(RSA_Bot_Healer $bot): void {
        $settings  = $bot->get_settings();
        $stats     = $bot->get_log_stats();
        $log       = array_slice($bot->get_log(), 0, 100);
        $schedules = [
            'hourly'     => 'Cada hora',
            'twicedaily' => 'Dos veces al día',
            'daily'      => 'Diariamente',
            'weekly'     => 'Semanalmente',
        ];
        $has_meta_fill  = class_exists('Replanta_Meta_Fill_OpenAI_Handler');
        $has_polylang   = RSA_Translation_Sync::is_available();
        ?>
        <div class="rsa-bot-wrap">

            <!-- ── Status + Toggle ── -->
            <div class="rsa-card rsa-bot-status-card">
                <div class="rsa-bot-status-header">
                    <div>
                        <h2>Bot de Salud</h2>
                        <p>Ejecuta la auditoría automáticamente, aplica fixes, rellena metas vacíos y sincroniza traducciones con IA.</p>
                    </div>
                    <div class="rsa-bot-toggle-wrap">
                        <label class="rsa-toggle-switch">
                            <input type="checkbox" id="rsa-bot-toggle" <?php checked($settings['enabled']); ?>>
                            <span class="rsa-toggle-slider"></span>
                        </label>
                        <span id="rsa-bot-toggle-label" class="rsa-bot-status-label">
                            <?php echo $settings['enabled'] ? '<strong style="color:#00a32a">Activo</strong>' : '<strong style="color:#999">Inactivo</strong>'; ?>
                        </span>
                    </div>
                </div>

                <!-- Scan + Run buttons -->
                <div class="rsa-bot-action-row">
                    <button id="rsa-bot-scan-only" class="button button-primary">
                        <span class="dashicons dashicons-search"></span> Iniciar Scan
                    </button>
                    <button id="rsa-bot-run-now" class="button button-secondary">
                        <span class="dashicons dashicons-controls-play"></span> Ejecutar ahora (scan + fixes)
                    </button>
                    <span id="rsa-bot-loading" style="display:none;">
                        <span class="spinner is-active" style="float:none;margin:0 5px;"></span>
                        Procesando&hellip;
                    </span>
                </div>

                <!-- Scan results (shown after scan) -->
                <div id="rsa-bot-scan-results" style="display:none;"></div>

                <div class="rsa-bot-stats-row">
                    <div class="rsa-bot-stat">
                        <span class="rsa-bot-stat-num"><?php echo $stats['fixes']; ?></span>
                        <span class="rsa-bot-stat-label">Fixes aplicados</span>
                    </div>
                    <div class="rsa-bot-stat">
                        <span class="rsa-bot-stat-num"><?php echo $stats['meta_fills']; ?></span>
                        <span class="rsa-bot-stat-label">Metas rellenadas</span>
                    </div>
                    <div class="rsa-bot-stat">
                        <span class="rsa-bot-stat-num"><?php echo $stats['translations_synced'] ?? 0; ?></span>
                        <span class="rsa-bot-stat-label">Traducciones sincronizadas</span>
                    </div>
                    <div class="rsa-bot-stat">
                        <span class="rsa-bot-stat-num"><?php echo $stats['error']; ?></span>
                        <span class="rsa-bot-stat-label">Errores</span>
                    </div>
                </div>
                <div class="rsa-bot-timing">
                    <span><strong>Última ejecución:</strong> <?php echo esc_html($bot->get_last_run()); ?></span>
                    <span><strong>Próxima ejecución:</strong> <span id="rsa-bot-next-run"><?php echo esc_html($bot->get_next_run()); ?></span></span>
                </div>
            </div>

            <!-- ── Traducciones desactualizadas ── -->
            <?php if ($has_polylang): ?>
            <div class="rsa-card rsa-bot-translations-card">
                <div class="rsa-bot-translations-header">
                    <div>
                        <h2>Traducciones EN desactualizadas</h2>
                        <p>Páginas/posts en inglés cuya versión en español fue modificada después de la última sincronización. El bot copia la estructura Elementor y traduce el texto con IA.</p>
                    </div>
                    <button id="rsa-bot-reload-translations" class="button button-small">
                        <span class="dashicons dashicons-update"></span> Actualizar lista
                    </button>
                </div>
                <div id="rsa-bot-translations-container">
                    <p class="rsa-bot-log-empty">Cargando&hellip;</p>
                </div>
            </div>
            <?php else: ?>
            <div class="rsa-card rsa-bot-translations-card rsa-bot-translations-unavailable">
                <h2>Traducciones EN desactualizadas</h2>
                <p class="description" style="color:#c02b0a; margin-top:8px">
                    Requiere <strong>Polylang</strong> activo. Instala y configura Polylang con idioma por defecto Español para habilitar esta función.
                </p>
            </div>
            <?php endif; ?>

            <!-- ── Settings ── -->
            <div class="rsa-card rsa-bot-settings-card">
                <h2>Configuración del Bot</h2>
                <table class="form-table rsa-bot-form">
                    <tr>
                        <th>Frecuencia del cron</th>
                        <td>
                            <select id="rsa-bot-schedule">
                                <?php foreach ($schedules as $key => $label): ?>
                                    <option value="<?php echo $key; ?>" <?php selected($settings['schedule'], $key); ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Rellenar metas vacíos con IA</th>
                        <td>
                            <label>
                                <input type="checkbox" id="rsa-bot-fill-metas" <?php checked($settings['fill_metas']); ?>>
                                Activar relleno automático de meta descripciones
                            </label>
                            <?php if (!$has_meta_fill): ?>
                                <p class="description" style="color:#c02b0a">Requiere el plugin <strong>replanta-meta-fill</strong> activo.</p>
                            <?php else: ?>
                                <p class="description">replanta-meta-fill detectado y disponible.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Máximo metas por ejecución</th>
                        <td>
                            <input type="number" id="rsa-bot-max-per-run" value="<?php echo (int)$settings['meta_max_per_run']; ?>" min="1" max="50" class="small-text">
                            <p class="description">Posts a procesar por ciclo del bot (1-50). Recomendado: 10.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Tipos de post</th>
                        <td>
                            <?php
                            $all_types = get_post_types(['public' => true], 'objects');
                            foreach ($all_types as $ptype):
                                $checked = in_array($ptype->name, $settings['meta_post_types'], true);
                            ?>
                                <label style="margin-right:15px;">
                                    <input type="checkbox" name="rsa_bot_post_types[]"
                                           value="<?php echo esc_attr($ptype->name); ?>"
                                           <?php checked($checked); ?>>
                                    <?php echo esc_html($ptype->labels->singular_name); ?>
                                </label>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <!-- Translation Sync Settings -->
                    <tr class="rsa-settings-separator">
                        <td colspan="2"><hr><strong>Sincronización de traducciones</strong></td>
                    </tr>
                    <tr>
                        <th>Sincronizar traducciones EN</th>
                        <td>
                            <label>
                                <input type="checkbox" id="rsa-bot-sync-translations" <?php checked($settings['sync_translations']); ?>>
                                Detectar y actualizar páginas EN desactualizadas en cada ciclo del bot
                            </label>
                            <?php if (!$has_polylang): ?>
                                <p class="description" style="color:#c02b0a">Requiere <strong>Polylang</strong> activo.</p>
                            <?php else: ?>
                                <p class="description">Copia estructura Elementor del original ES y traduce el texto con IA (OpenAI).</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Máximo traducciones por ciclo</th>
                        <td>
                            <input type="number" id="rsa-bot-translations-max" value="<?php echo (int)$settings['translations_max_per_run']; ?>" min="1" max="10" class="small-text">
                            <p class="description">Páginas a sincronizar por ciclo (1-10). Cada página hace una llamada a OpenAI. Recomendado: 2.</p>
                        </td>
                    </tr>
                    <!-- Notificaciones -->
                    <tr class="rsa-settings-separator">
                        <td colspan="2"><hr><strong>Notificaciones por email</strong></td>
                    </tr>
                    <tr>
                        <th>Email de notificaciones</th>
                        <td>
                            <input type="email" id="rsa-bot-notify-email"
                                   value="<?php echo esc_attr($settings['notify_email'] ?? get_option('admin_email', '')); ?>"
                                   class="regular-text">
                            <p class="description">Dirección donde se envían las alertas. Por defecto: email del administrador.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Alerta en caídas críticas</th>
                        <td>
                            <label>
                                <input type="checkbox" id="rsa-bot-notify-critical" <?php checked($settings['notify_on_critical'] ?? false); ?>>
                                Enviar email si aparece un nuevo CRITICAL o el score cae más de 10 puntos
                            </label>
                            <p class="description">Máximo 1 email por día para evitar spam.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Digest semanal</th>
                        <td>
                            <label>
                                <input type="checkbox" id="rsa-bot-notify-weekly" <?php checked($settings['notify_weekly_digest'] ?? false); ?>>
                                Recibir resumen semanal cada lunes con estadísticas del bot
                            </label>
                        </td>
                    </tr>
                </table>
                <button id="rsa-bot-save-settings" class="button button-primary">
                    <span class="dashicons dashicons-saved"></span> Guardar configuración
                </button>
                <span id="rsa-bot-settings-msg" class="rsa-bot-inline-msg" style="display:none;"></span>
            </div>

            <!-- ── Log ── -->
            <div class="rsa-card rsa-bot-log-card">
                <div class="rsa-bot-log-header">
                    <h2>Registro de actividad</h2>
                    <div class="rsa-bot-log-actions">
                        <select id="rsa-bot-log-filter">
                            <option value="all">Todas las entradas</option>
                            <option value="success">Exitos</option>
                            <option value="error">Errores</option>
                            <option value="meta_fill">Meta Fill</option>
                            <option value="audit_fix">Fixes</option>
                            <option value="audit">Auditorias</option>
                            <option value="translation_sync">Traducciones</option>
                        </select>
                        <button id="rsa-bot-clear-log" class="button button-small button-link-delete">
                            Limpiar log
                        </button>
                    </div>
                </div>

                <div id="rsa-bot-log-container">
                    <?php if (empty($log)): ?>
                        <p class="rsa-bot-log-empty">No hay entradas en el log todavía. Ejecuta el bot para ver la actividad.</p>
                    <?php else: ?>
                        <?php $this->render_log_table($log); ?>
                    <?php endif; ?>
                </div>
            </div>

        </div><!-- .rsa-bot-wrap -->
        <?php
    }

    private function render_log_table(array $log): void {
        $icons = [
            'success' => '<i class="ph ph-check-circle" style="color:#16a34a"></i>',
            'error'   => '<i class="ph ph-x-circle" style="color:#dc2626"></i>',
            'info'    => '<i class="ph ph-info" style="color:#2563eb"></i>',
        ];
        $type_labels = [
            'bot_run'          => 'Ciclo',
            'audit'            => 'Auditoria',
            'audit_fix'        => 'Fix',
            'meta_fill'        => 'Meta Fill',
            'config'           => 'Config',
            'translation_sync' => 'Traduccion EN',
        ];
        ?>
        <table class="rsa-bot-log-table widefat striped">
            <thead>
                <tr>
                    <th style="width:140px">Fecha/Hora</th>
                    <th style="width:80px">Estado</th>
                    <th style="width:90px">Tipo</th>
                    <th>Mensaje</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($log as $entry): ?>
                <tr class="rsa-log-row rsa-log-<?php echo esc_attr($entry['status']); ?>">
                    <td class="rsa-log-time"><?php echo esc_html($entry['time']); ?></td>
                    <td class="rsa-log-status">
                        <?php echo $icons[$entry['status']] ?? '?'; ?>
                    </td>
                    <td class="rsa-log-type">
                        <span class="rsa-log-type-badge"><?php echo $type_labels[$entry['type']] ?? esc_html($entry['type']); ?></span>
                    </td>
                    <td class="rsa-log-message">
                        <?php echo esc_html($entry['message']); ?>
                        <?php if (!empty($entry['post_id'])): ?>
                            <a href="<?php echo get_edit_post_link($entry['post_id']); ?>" target="_blank" class="rsa-log-post-link">
                                #<?php echo $entry['post_id']; ?>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    /* ─────────── UI Helpers ─────────── */

    private function score_class(int|null $score): string {
        $score = (int) ($score ?? 0);
        if ($score >= 80) return 'green';
        if ($score >= 50) return 'orange';
        return 'red';
    }

    private function status_icon(string $status): string {
        return match ($status) {
            'pass'     => '<span class="rsa-icon-pass">OK</span>',
            'info'     => '<span class="rsa-icon-info">i</span>',
            'warning'  => '<span class="rsa-icon-warning">!</span>',
            'critical' => '<span class="rsa-icon-critical">X</span>',
            default    => '<span class="rsa-icon-unknown">?</span>',
        };
    }
}
