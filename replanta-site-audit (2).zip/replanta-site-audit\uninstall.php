<?php
/**
 * Uninstall handler — fires when the plugin is deleted from WP Admin → Plugins.
 * Drops all Autopilot DB tables and removes plugin options.
 *
 * @package Replanta_Site_Audit
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Drop Autopilot tables
$tables = [
	'rsa_seo_snapshots',
	'rsa_seo_proposals',
	'rsa_seo_execution_log',
];
foreach ( $tables as $suffix ) {
	// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}{$suffix}`" );
}

// Remove plugin options
$options = [
	'rsa_autopilot_db_ver',
	'rsa_claude_seo_api_key',
	'rsa_claude_seo_last_analysis',
	'rsa_gsc_access_token',
	'rsa_gsc_refresh_token',
	'rsa_gsc_token_expires',
	'rsa_gsc_selected_site',
	'rsa_dataforseo_login',
	'rsa_dataforseo_password',
];
foreach ( $options as $opt ) {
	delete_option( $opt );
}

// Remove transients (rsa_* prefix covers all plugin transients)
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
$wpdb->query( "DELETE FROM `{$wpdb->options}` WHERE option_name LIKE '_transient_rsa_%'" );
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
$wpdb->query( "DELETE FROM `{$wpdb->options}` WHERE option_name LIKE '_transient_timeout_rsa_%'" );
