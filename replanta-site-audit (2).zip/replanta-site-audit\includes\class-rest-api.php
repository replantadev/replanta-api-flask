<?php
/**
 * REST API — Replanta Site Audit v1.0
 *
 * Expone endpoints REST para integración con herramientas externas.
 * Autenticación via WP Application Passwords (nativo WP 5.6+).
 *
 * Namespace: replanta-site-audit/v1
 * Endpoints:
 *   GET  /audit            — último resultado cacheado
 *   POST /audit/run        — fuerza auditoría fresca
 *   GET  /audit/history    — últimas 30 auditorías
 *   POST /fix/{fix_id}     — ejecuta un fix atómico por ID
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class RSA_Rest_Api {

    const NS = 'replanta-site-audit/v1';

    private static ?RSA_Rest_Api $instance = null;

    public static function get_instance(): RSA_Rest_Api {
        return self::$instance ??= new self();
    }

    private function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        register_rest_route( self::NS, '/audit', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_audit' ],
            'permission_callback' => [ $this, 'require_admin' ],
        ] );

        register_rest_route( self::NS, '/audit/run', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'run_audit' ],
            'permission_callback' => [ $this, 'require_admin' ],
        ] );

        register_rest_route( self::NS, '/audit/history', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_history' ],
            'permission_callback' => [ $this, 'require_admin' ],
        ] );

        register_rest_route( self::NS, '/fix/(?P<fix_id>[a-z0-9_]+)', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'run_fix' ],
            'permission_callback' => [ $this, 'require_admin' ],
            'args'                => [
                'fix_id' => [
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => function ( string $v ): bool {
                        return array_key_exists( $v, RSA_Auto_Fixer::get_catalogue() );
                    },
                ],
            ],
        ] );
    }

    /**
     * Permission callback — requires manage_options capability.
     * Works with WP Application Passwords and cookie-based auth.
     *
     * @return true|WP_Error
     */
    public function require_admin(): bool|WP_Error {
        if ( ! current_user_can( 'manage_options' ) ) {
            return new WP_Error(
                'rest_forbidden',
                'Requiere capacidad manage_options.',
                [ 'status' => 403 ]
            );
        }
        return true;
    }

    /** GET /audit */
    public function get_audit(): WP_REST_Response {
        $result = get_transient( RSA_Audit_Engine::TRANSIENT_KEY );
        if ( $result === false ) {
            return new WP_REST_Response(
                [ 'error' => 'No hay auditoría disponible. Ejecuta POST /audit/run primero.' ],
                404
            );
        }
        return new WP_REST_Response( $result, 200 );
    }

    /** POST /audit/run */
    public function run_audit(): WP_REST_Response {
        try {
            $result = RSA_Audit_Engine::run( true );
            return new WP_REST_Response( $result, 200 );
        } catch ( \Throwable $e ) {
            return new WP_REST_Response( [ 'error' => $e->getMessage() ], 500 );
        }
    }

    /** GET /audit/history */
    public function get_history(): WP_REST_Response {
        return new WP_REST_Response( RSA_Audit_Engine::get_history(), 200 );
    }

    /** POST /fix/{fix_id} */
    public function run_fix( WP_REST_Request $request ): WP_REST_Response {
        $fix_id = $request->get_param( 'fix_id' );
        $result = RSA_Audit_Engine::execute_fix( $fix_id );
        $status = $result['success'] ? 200 : 422;
        return new WP_REST_Response( $result, $status );
    }
}
