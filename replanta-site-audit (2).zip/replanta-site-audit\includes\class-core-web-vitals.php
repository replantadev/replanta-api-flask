<?php
/**
 * Core Web Vitals — PageSpeed Insights API v5
 *
 * Obtiene LCP, CLS, INP y FCP reales (CrUX) + puntuación Lighthouse.
 * Cachea 24 horas para no saturar la API (400 req/día sin key, 25k con key).
 * El Bot de Salud refresca los datos en cada ejecución diaria.
 *
 * Configuración: Site Audit → Bot de Salud → "API Key PageSpeed" (opcional).
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Core_Web_Vitals {

    const API_ENDPOINT   = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
    const TRANSIENT_KEY  = 'rsa_cwv_result';
    const TRANSIENT_TTL  = 86400; // 24 horas
    const OPTION_API_KEY = 'rsa_psi_api_key';

    /* ─────────────────────────── Public API ─────────────────────────── */

    /**
     * Devuelve resultado desde caché. Si no hay caché devuelve checks vacíos
     * con un aviso "info" para que el usuario sepa que faltan datos.
     * El bot llama a refresh() para actualizar los datos periódicamente.
     */
    public function run(): array {
        $cached = get_transient(self::TRANSIENT_KEY);
        if ($cached !== false && !empty($cached['checks'])) {
            return [
                'score'   => $cached['score'] ?? 0,
                'summary' => ['total' => count($cached['checks']), 'passed' => $cached['passed'] ?? 0],
                'checks'  => $cached['checks'],
            ];
        }

        // Sin caché — mostrar aviso para que el usuario lance una auditoría fresca
        $pending = $this->make_check(
            'cwv_pending', 'Core Web Vitals', 'info', 'Pendiente',
            'Los datos de Core Web Vitals (LCP, CLS, INP) aún no se han obtenido. '
            . 'Se actualizarán automáticamente en la próxima ejecución del Bot de Salud '
            . 'o puedes hacer clic en "Ejecutar Bot ahora" en la pestaña Bot de Salud.'
        );
        return ['score' => 0, 'summary' => ['total' => 1, 'passed' => 0], 'checks' => [$pending]];
    }

    /**
     * Llama a la API de PageSpeed Insights y actualiza la caché.
     * Ejecutar desde Bot Healer — no llamar en cada request de admin.
     */
    public function refresh(): void {
        $url    = home_url('/');
        $checks = $this->fetch_and_build($url, 'mobile');

        $passed = count(array_filter($checks, fn($c) => $c['status'] === 'pass'));
        $total  = count($checks);
        $score  = $total > 0 ? round(($passed / $total) * 100) : 0;

        set_transient(self::TRANSIENT_KEY, [
            'score'   => $score,
            'passed'  => $passed,
            'checks'  => $checks,
            'fetched' => current_time('mysql'),
        ], self::TRANSIENT_TTL);
    }

    public static function clear_cache(): void {
        delete_transient(self::TRANSIENT_KEY);
    }

    /* ─────────────────────────── Internal ─────────────────────────── */

    private function fetch_and_build(string $url, string $strategy): array {
        $data = $this->call_api($url, $strategy);
        if (isset($data['_error'])) {
            return [$this->make_check(
                'cwv_error', 'Core Web Vitals (PSI)', 'info', 'Sin datos',
                'PageSpeed Insights no disponible: ' . $data['_error'] . '. '
                . 'Añade una API Key en WP Admin → Site Audit → Bot de Salud → "API Key PageSpeed" '
                . 'para aumentar el límite a 25.000 peticiones/día.'
            )];
        }

        return $this->build_checks($data, $strategy);
    }

    private function call_api(string $url, string $strategy): array {
        $api_key = get_option(self::OPTION_API_KEY, '');
        $params  = [
            'url'      => $url,
            'strategy' => $strategy,
            'category' => 'performance',
        ];
        if ($api_key) {
            $params['key'] = $api_key;
        }

        $endpoint = add_query_arg($params, self::API_ENDPOINT);
        $response = wp_remote_get($endpoint, [
            'timeout'   => 60,
            'sslverify' => true,
        ]);

        if (is_wp_error($response)) {
            return ['_error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200 || empty($body)) {
            $msg = $body['error']['message'] ?? "HTTP {$code}";
            return ['_error' => $msg];
        }

        return $body;
    }

    private function build_checks(array $data, string $strategy): array {
        $lhr     = $data['lighthouseResult']  ?? [];
        $crux    = $data['loadingExperience'] ?? [];
        $audits  = $lhr['audits'] ?? [];
        $crux_m  = $crux['metrics'] ?? [];
        $has_crux = !empty($crux_m);
        $suffix  = $strategy === 'mobile' ? ' · Móvil' : ' · Escritorio';
        $p       = $strategy === 'mobile' ? 'cwv_m' : 'cwv_d';

        $checks = [];

        // ── Puntuación global Lighthouse ──
        $score_raw = (float) ($lhr['categories']['performance']['score'] ?? 0);
        $score_pct = (int) round($score_raw * 100);
        $checks[] = $this->make_check(
            $p . '_score', 'PSI Score' . $suffix,
            $score_pct >= 90 ? 'pass' : ($score_pct >= 50 ? 'warning' : 'critical'),
            $score_pct . '/100',
            "Puntuación Lighthouse Performance ({$strategy}): {$score_pct}/100. "
            . ($score_pct >= 90 ? 'Excelente.' : ($score_pct >= 50 ? 'Mejorable — revisa las métricas individuales.' : 'Crítico — prioriza optimización de rendimiento.'))
        );

        // ── LCP (Largest Contentful Paint) ──
        if ($has_crux && isset($crux_m['LARGEST_CONTENTFUL_PAINT_MS'])) {
            $lcp_ms  = (int) ($crux_m['LARGEST_CONTENTFUL_PAINT_MS']['percentile'] ?? 0);
            $lcp_cat = $crux_m['LARGEST_CONTENTFUL_PAINT_MS']['category'] ?? '';
            $lcp_s   = round($lcp_ms / 1000, 1);
            $status  = $lcp_cat === 'FAST' ? 'pass' : ($lcp_cat === 'AVERAGE' ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_lcp', 'LCP' . $suffix, $status, $lcp_s . 's',
                "LCP real (datos de usuarios Chrome, 75º percentil): {$lcp_s}s. Meta: <2.5s. "
                . ($status === 'pass'
                    ? 'Buen tiempo de carga del elemento principal.'
                    : 'Optimiza: imagen/bloque hero con preload, elimina CSS bloqueante, mejora TTFB.')
            );
        } elseif (isset($audits['largest-contentful-paint'])) {
            $lcp_ms  = (int) ($audits['largest-contentful-paint']['numericValue'] ?? 0);
            $lcp_s   = round($lcp_ms / 1000, 1);
            $status  = $lcp_ms <= 2500 ? 'pass' : ($lcp_ms <= 4000 ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_lcp', 'LCP (lab)' . $suffix, $status, $lcp_s . 's',
                "LCP Lighthouse (lab, sin datos CrUX reales): {$lcp_s}s. Meta: <2.5s."
            );
        }

        // ── CLS (Cumulative Layout Shift) ──
        if ($has_crux && isset($crux_m['CUMULATIVE_LAYOUT_SHIFT_SCORE'])) {
            $cls_raw = (int) ($crux_m['CUMULATIVE_LAYOUT_SHIFT_SCORE']['percentile'] ?? 0);
            $cls     = round($cls_raw / 100, 2);
            $cls_cat = $crux_m['CUMULATIVE_LAYOUT_SHIFT_SCORE']['category'] ?? '';
            $status  = $cls_cat === 'FAST' ? 'pass' : ($cls_cat === 'AVERAGE' ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_cls', 'CLS' . $suffix, $status, (string) $cls,
                "CLS real (75º percentil): {$cls}. Meta: <0.1. "
                . ($status === 'pass'
                    ? 'Buena estabilidad visual — sin saltos de layout.'
                    : 'Hay saltos de contenido que afectan UX y ranking. Reserva espacio para imágenes/ads (width+height en <img>).')
            );
        } elseif (isset($audits['cumulative-layout-shift'])) {
            $cls    = round((float) ($audits['cumulative-layout-shift']['numericValue'] ?? 0), 3);
            $status = $cls <= 0.1 ? 'pass' : ($cls <= 0.25 ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_cls', 'CLS (lab)' . $suffix, $status, (string) $cls,
                "CLS Lighthouse (lab): {$cls}. Meta: <0.1."
            );
        }

        // ── INP (Interaction to Next Paint) — Google Signal 2024 ──
        if ($has_crux && isset($crux_m['INTERACTION_TO_NEXT_PAINT'])) {
            $inp_ms  = (int) ($crux_m['INTERACTION_TO_NEXT_PAINT']['percentile'] ?? 0);
            $inp_cat = $crux_m['INTERACTION_TO_NEXT_PAINT']['category'] ?? '';
            $status  = $inp_cat === 'FAST' ? 'pass' : ($inp_cat === 'AVERAGE' ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_inp', 'INP' . $suffix, $status, $inp_ms . 'ms',
                "INP real (75º percentil): {$inp_ms}ms. Meta: <200ms. "
                . ($status === 'pass'
                    ? 'Buena respuesta a interacciones del usuario.'
                    : 'JS bloqueante o tareas largas retrasan la respuesta. Reduce JS de terceros, aplica code splitting.')
            );
        }

        // ── FCP (First Contentful Paint) ──
        if (isset($audits['first-contentful-paint'])) {
            $fcp_ms  = (int) ($audits['first-contentful-paint']['numericValue'] ?? 0);
            $fcp_s   = round($fcp_ms / 1000, 1);
            $status  = $fcp_ms <= 1800 ? 'pass' : ($fcp_ms <= 3000 ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_fcp', 'FCP' . $suffix, $status, $fcp_s . 's',
                "First Contentful Paint (Lighthouse): {$fcp_s}s. Meta: <1.8s. "
                . ($status !== 'pass' ? 'Elimina render-blocking CSS/fonts, activa Critical CSS en LiteSpeed.' : 'Correcto.')
            );
        }

        // ── TTFB (Time to First Byte via PSI) ──
        if (isset($audits['server-response-time'])) {
            $ttfb_ms = (int) ($audits['server-response-time']['numericValue'] ?? 0);
            $status  = $ttfb_ms <= 800 ? 'pass' : ($ttfb_ms <= 1800 ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_ttfb', 'TTFB (PSI)' . $suffix, $status, $ttfb_ms . 'ms',
                "TTFB según PageSpeed Insights: {$ttfb_ms}ms. Meta: <800ms. "
                . ($status !== 'pass' ? 'Activa Full Page Cache en LiteSpeed, usa Cloudflare como CDN y revisa el TTFB de origen.' : 'Correcto.')
            );
        }

        // ── Estado CrUX global ──
        $overall = $crux['overall_category'] ?? '';
        if ($overall) {
            $labels = ['FAST' => 'Rápido ✓', 'AVERAGE' => 'Promedio', 'SLOW' => 'Lento'];
            $status = $overall === 'FAST' ? 'pass' : ($overall === 'AVERAGE' ? 'warning' : 'critical');
            $checks[] = $this->make_check(
                $p . '_crux', 'CrUX Global' . $suffix, $status,
                $labels[$overall] ?? $overall,
                "Estado global de Core Web Vitals ({$strategy}) según datos reales de Chrome (últimos 28 días): {$overall}. "
                . ($status === 'pass'
                    ? 'Tu sitio pasa el umbral de CWV para este dispositivo.'
                    : 'Tu sitio NO pasa el umbral de CWV — puede afectar al ranking en Google.')
            );
        }

        return $checks;
    }

    private function make_check(
        string  $id,
        string  $label,
        string  $status,
        string  $value,
        string  $detail,
        ?string $fix_id    = null,
        ?string $fix_label = null
    ): array {
        $c = [
            'id' => $id, 'label' => $label, 'status' => $status,
            'value' => $value, 'detail' => $detail, 'category' => 'performance',
        ];
        if ($fix_id && in_array($status, ['warning', 'critical', 'info'], true)) {
            $c['fixable']   = true;
            $c['fix_id']    = $fix_id;
            $c['fix_label'] = $fix_label ?? 'Corregir';
        }
        return $c;
    }
}
