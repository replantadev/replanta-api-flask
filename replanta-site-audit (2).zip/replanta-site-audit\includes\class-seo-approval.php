<?php
/**
 * RSA_SEO_Approval
 *
 * Handles the human-in-the-loop layer of the SEO Autopilot:
 *  - Weekly email digest hooked into the existing rsa_weekly_digest cron action
 *    (scheduled by RSA_Bot_Healer — no extra cron needed).
 *  - Signed one-click approve/reject links in the email.
 *  - AJAX handlers for the admin panel (approve, reject, bulk, run now).
 *  - Renders the Autopilot section inside the SEO Agent tab.
 *
 * @package Replanta_Site_Audit
 * @since   3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class RSA_SEO_Approval {

	/* ─── Singleton ─── */
	private static ?self $instance = null;

	public static function get_instance(): self {
		return self::$instance ??= new self();
	}

	private function __construct() {
		add_action( 'wp_ajax_rsa_autopilot_decide',       [ $this, 'ajax_decide' ] );
		add_action( 'wp_ajax_rsa_autopilot_bulk_decide',  [ $this, 'ajax_bulk_decide' ] );
		add_action( 'wp_ajax_rsa_autopilot_run_now',      [ $this, 'ajax_run_now' ] );
		add_action( 'wp_ajax_rsa_autopilot_get_proposals',[ $this, 'ajax_get_proposals' ] );
		add_action( 'wp_ajax_rsa_autopilot_rollback',     [ $this, 'ajax_rollback' ] );
		// Hook into the existing weekly digest action (managed by RSA_Bot_Healer cron)
		add_action( 'rsa_weekly_digest', [ $this, 'send_digest' ] );
		add_action( 'admin_init',        [ $this, 'handle_email_approval' ] );
	}

	/* ─────────────────────────────────────────
	 * Weekly email digest
	 * ───────────────────────────────────────── */

	public function send_digest(): void {
		$pending = RSA_SEO_Proposal_Engine::get_all( 'pending', 50 );
		if ( empty( $pending ) ) return;

		$counts     = RSA_SEO_Proposal_Engine::get_counts();
		$admin_url  = admin_url( 'admin.php?page=replanta-site-audit&rsa_tab=seo' );
		$to         = (string) get_option( 'admin_email' );
		$domain     = defined( 'RSA_DOMAIN' ) ? RSA_DOMAIN : parse_url( get_site_url(), PHP_URL_HOST );
		$last_cap   = RSA_SEO_Snapshot::get_last_capture();

		$subject = sprintf( '🌱 %s — %d propuestas SEO pendientes de aprobación', $domain, $counts['pending'] );

		// Group by type
		$by_type = [];
		foreach ( $pending as $p ) {
			$by_type[ $p['type'] ][] = $p;
		}

		$type_labels = self::type_labels();

		$body  = '<html><body style="font-family:sans-serif;color:#1a1a1a;max-width:680px;margin:auto">';
		$body .= '<h2 style="color:#16a34a">🌱 Replanta SEO Autopilot</h2>';
		$body .= '<p><strong>' . $counts['pending'] . ' propuestas pendientes</strong> · '
			. $counts['applied'] . ' aplicadas en total</p>';
		if ( $last_cap ) {
			$body .= '<p style="color:#6b7280">Última captura: ' . esc_html( $last_cap ) . '</p>';
		}

		// ── Regression alert ──────────────────────────────────────────────────
		$regressions = RSA_SERP_Tracker::get_regressions();
		if ( ! empty( $regressions ) ) {
			$body .= '<div style="border:2px solid #dc2626;border-radius:6px;padding:12px 16px;margin:16px 0;background:#fef2f2">';
			$body .= '<strong style="color:#dc2626">⚠️ ' . count( $regressions ) . ' página(s) con regresión SERP detectada</strong>';
			$body .= '<ul style="margin:8px 0 0;padding-left:16px;color:#1a1a1a">';
			foreach ( array_slice( $regressions, 0, 5 ) as $reg ) {
				$pos_d    = round( (float) $reg['position_delta'], 1 );
				$clicks_d = (int) $reg['clicks_delta'];
				$sign     = $clicks_d >= 0 ? '+' : '';
				$body    .= '<li>' . esc_html( $reg['url'] )
					. ' — posición empeoró <strong>+' . $pos_d . '</strong> puestos'
					. ' · clicks Δ ' . $sign . $clicks_d . '</li>';
			}
			$body .= '</ul>';
			$body .= '<p style="margin:8px 0 0;font-size:13px;color:#6b7280">Considera revertir estos cambios desde el panel de Autopilot.</p>';
			$body .= '</div>';
		}

		foreach ( $by_type as $type => $props ) {
			$info  = $type_labels[ $type ] ?? [ 'icon' => '•', 'label' => $type ];
			$body .= '<h3 style="border-bottom:1px solid #e5e7eb;padding-bottom:4px">'
				. $info['icon'] . ' ' . $info['label']
				. ' <span style="color:#6b7280;font-size:14px">(' . count( $props ) . ')</span></h3>';
			$body .= '<ul style="padding-left:16px">';

			foreach ( array_slice( $props, 0, 6 ) as $p ) {
				$approve_url = add_query_arg( [
					'rsa_ap_token'  => rawurlencode( $p['approval_token'] ),
					'rsa_ap_action' => 'approve',
					'rsa_ap_id'     => (int) $p['id'],
					'_wpnonce'      => wp_create_nonce( 'rsa_ap_email_' . $p['id'] ),
				], admin_url( 'admin.php?page=replanta-site-audit' ) );

				$reject_url = add_query_arg( [
					'rsa_ap_token'  => rawurlencode( $p['approval_token'] ),
					'rsa_ap_action' => 'reject',
					'rsa_ap_id'     => (int) $p['id'],
					'_wpnonce'      => wp_create_nonce( 'rsa_ap_email_' . $p['id'] ),
				], admin_url( 'admin.php?page=replanta-site-audit' ) );

				$before = esc_html( mb_substr( (string) $p['value_before'], 0, 70 ) );
				$after  = esc_html( mb_substr( (string) $p['value_after'],  0, 90 ) );
				$reason = esc_html( (string) $p['claude_reasoning'] );

				$body .= '<li style="margin-bottom:14px">';
				$body .= '<strong>' . esc_html( $p['url'] ) . '</strong><br>';
				$body .= 'Antes: <code style="background:#f3f4f6;padding:1px 4px">' . $before . '</code><br>';
				$body .= 'Después: <code style="background:#dcfce7;padding:1px 4px">' . $after . '</code><br>';
				$body .= '<em style="color:#6b7280">' . $reason . '</em><br>';
				$body .= '<a href="' . esc_url( $approve_url ) . '" '
					. 'style="background:#16a34a;color:#fff;padding:5px 14px;border-radius:4px;text-decoration:none;font-size:13px;margin-right:8px">✅ Aprobar</a>';
				$body .= '<a href="' . esc_url( $reject_url ) . '" '
					. 'style="color:#6b7280;font-size:13px">✕ Rechazar</a>';
				$body .= '</li>';
			}

			if ( count( $props ) > 6 ) {
				$body .= '<li style="color:#6b7280"><em>+ ' . ( count( $props ) - 6 ) . ' más...</em></li>';
			}
			$body .= '</ul>';
		}

		$body .= '<p style="margin-top:28px">'
			. '<a href="' . esc_url( $admin_url ) . '" '
			. 'style="background:#2563eb;color:#fff;padding:11px 22px;border-radius:6px;text-decoration:none;font-weight:600">'
			. 'Ver todas en el panel →</a></p>';
		$body .= '</body></html>';

		add_filter( 'wp_mail_content_type', [ $this, '_html_content_type' ] );
		wp_mail( $to, $subject, $body );
		remove_filter( 'wp_mail_content_type', [ $this, '_html_content_type' ] );
	}

	/** @internal */
	public function _html_content_type(): string {
		return 'text/html';
	}

	/* ─────────────────────────────────────────
	 * Email-link approval handler
	 * ───────────────────────────────────────── */

	public function handle_email_approval(): void {
		if ( empty( $_GET['rsa_ap_token'] ) || empty( $_GET['rsa_ap_action'] ) ) return;
		if ( ! current_user_can( 'manage_options' ) ) return;

		$token  = sanitize_text_field( wp_unslash( $_GET['rsa_ap_token'] ) );
		$action = sanitize_key( wp_unslash( $_GET['rsa_ap_action'] ) );
		$id     = (int) ( $_GET['rsa_ap_id'] ?? 0 );

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), 'rsa_ap_email_' . $id ) ) {
			wp_die( 'Enlace de aprobación inválido o expirado.', 'Error', [ 'response' => 403 ] );
		}

		$proposal = RSA_SEO_Proposal_Engine::get_by_token( $token );
		if ( ! $proposal || $proposal['status'] !== 'pending' ) {
			wp_die( 'Esta propuesta ya fue procesada o no existe.', 'Error', [ 'response' => 400 ] );
		}

		if ( $action === 'approve' ) {
			RSA_SEO_Proposal_Engine::update_status( (int) $proposal['id'], 'approved' );
			$result = RSA_SEO_Executor::apply( $proposal );
			RSA_SEO_Proposal_Engine::update_status( (int) $proposal['id'], $result['success'] ? 'applied' : 'failed' );
			$notice = $result['success']
				? '<div class="notice notice-success is-dismissible"><p><i class="ph ph-check-circle"></i> Propuesta SEO aplicada: ' . esc_html( $result['message'] ) . '</p></div>'
				: '<div class="notice notice-error is-dismissible"><p><i class="ph ph-warning"></i> Error al aplicar: ' . esc_html( $result['message'] ) . '</p></div>';
		} else {
			RSA_SEO_Proposal_Engine::update_status( (int) $proposal['id'], 'rejected' );
			$notice = '<div class="notice notice-info is-dismissible"><p>Propuesta rechazada.</p></div>';
		}

		add_action( 'admin_notices', function() use ( $notice ) { echo $notice; } ); // phpcs:ignore
		wp_safe_redirect( admin_url( 'admin.php?page=replanta-site-audit&rsa_tab=seo' ) );
		exit;
	}

	/* ─────────────────────────────────────────
	 * AJAX: single decision
	 * ───────────────────────────────────────── */

	public function ajax_decide(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

		RSA_SEO_Snapshot::create_tables();

		$id       = (int) ( $_POST['proposal_id'] ?? 0 );
		$decision = sanitize_key( $_POST['decision'] ?? '' );

		if ( ! $id || ! in_array( $decision, [ 'approve', 'reject' ], true ) ) {
			wp_send_json_error( 'Parámetros inválidos.' );
		}

		$proposal = RSA_SEO_Proposal_Engine::get_by_id( $id );
		if ( ! $proposal ) wp_send_json_error( 'Propuesta no encontrada.' );

		if ( $decision === 'reject' ) {
			RSA_SEO_Proposal_Engine::update_status( $id, 'rejected' );
			wp_send_json_success( [ 'status' => 'rejected' ] );
		}

		// Approve + execute immediately
		RSA_SEO_Proposal_Engine::update_status( $id, 'approved' );
		$result = RSA_SEO_Executor::apply( $proposal );
		RSA_SEO_Proposal_Engine::update_status( $id, $result['success'] ? 'applied' : 'failed' );

		if ( $result['success'] ) {
			wp_send_json_success( [ 'status' => 'applied', 'message' => $result['message'] ] );
		} else {
			wp_send_json_error( $result['message'] );
		}
	}

	/* ─────────────────────────────────────────
	 * AJAX: bulk decision
	 * ───────────────────────────────────────── */

	public function ajax_bulk_decide(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

		RSA_SEO_Snapshot::create_tables();

		$ids      = array_map( 'intval', (array) ( $_POST['ids'] ?? [] ) );
		$decision = sanitize_key( $_POST['decision'] ?? '' );

		if ( empty( $ids ) || ! in_array( $decision, [ 'approve', 'reject' ], true ) ) {
			wp_send_json_error( 'Parámetros inválidos.' );
		}

		$applied = 0;
		$failed  = 0;

		foreach ( $ids as $id ) {
			$proposal = RSA_SEO_Proposal_Engine::get_by_id( $id );
			if ( ! $proposal || $proposal['status'] !== 'pending' ) continue;

			if ( $decision === 'reject' ) {
				RSA_SEO_Proposal_Engine::update_status( $id, 'rejected' );
				$applied++;
				continue;
			}

			RSA_SEO_Proposal_Engine::update_status( $id, 'approved' );
			$result = RSA_SEO_Executor::apply( $proposal );
			RSA_SEO_Proposal_Engine::update_status( $id, $result['success'] ? 'applied' : 'failed' );
			$result['success'] ? $applied++ : $failed++;
		}

		wp_send_json_success( [
			'processed' => $applied,
			'failed'    => $failed,
			'message'   => "{$applied} procesadas" . ( $failed ? ", {$failed} fallidas" : '' ) . '.',
		] );
	}

	/* ─────────────────────────────────────────
	 * AJAX: manual capture trigger
	 * ───────────────────────────────────────── */

	public function ajax_run_now(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

		// Schedule a one-off event slightly in the future so it runs on the next WP load,
		// avoiding request-timeout issues with the full snapshot + Claude calls.
		wp_schedule_single_event( time() + 10, RSA_SEO_Snapshot::CRON_CAPTURE );

		wp_send_json_success( [ 'message' => 'Captura programada. Los resultados aparecerán en ~2 minutos.' ] );
	}

	/* ─────────────────────────────────────────
	 * AJAX: get fresh proposals list (for polling after run_now)
	 * ───────────────────────────────────────── */

	public function ajax_get_proposals(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permisos insuficientes.' );

		$pending  = RSA_SEO_Proposal_Engine::get_all( 'pending',  100 );
		$applied  = RSA_SEO_Proposal_Engine::get_all( 'applied',  20 );
		$counts   = RSA_SEO_Proposal_Engine::get_counts();
		$last_cap = RSA_SEO_Snapshot::get_last_capture();

		wp_send_json_success( compact( 'pending', 'applied', 'counts', 'last_cap' ) );
	}

	/* ─────────────────────────────────────────
	 * AJAX: rollback an applied change
	 * ───────────────────────────────────────── */

	public function ajax_rollback(): void {
		check_ajax_referer( 'rsa_audit', '_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permisos insuficientes.' );
		}

		$proposal_id = (int) ( $_POST['proposal_id'] ?? 0 );
		if ( ! $proposal_id ) {
			wp_send_json_error( 'ID de propuesta inválido.' );
		}

		$result = RSA_SEO_Executor::rollback( $proposal_id );

		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result['message'] );
		}
	}

	/* ─────────────────────────────────────────
	 * Render autopilot section (called from RSA_SEO_Agent::render_tab)
	 * ───────────────────────────────────────── */

	public function render_section(): void {
		$counts   = RSA_SEO_Proposal_Engine::get_counts();
		$pending  = RSA_SEO_Proposal_Engine::get_all( 'pending', 50 );
		$applied  = RSA_SEO_Proposal_Engine::get_all( 'applied', 20 );
		$last_cap = RSA_SEO_Snapshot::get_last_capture();
		$next_cap = wp_next_scheduled( RSA_SEO_Snapshot::CRON_CAPTURE );
		$labels   = self::type_labels();
		?>
		<div class="rsa-seo-section rsa-autopilot-section" id="rsa-autopilot">

			<div class="rsa-ap-header">
				<h2 class="rsa-ap-title">
					<i class="ph ph-robot"></i> SEO Autopilot
					<?php if ( $counts['pending'] > 0 ) : ?>
						<span class="rsa-tab-badge rsa-badge-warning"><?php echo (int) $counts['pending']; ?></span>
					<?php endif; ?>
				</h2>
				<button class="button button-secondary" id="rsa-autopilot-capture-now" type="button">
					<i class="ph ph-lightning"></i> Capturar ahora
				</button>
			</div>

			<div class="rsa-autopilot-status-bar">
				<span class="rsa-ap-stat rsa-ap-stat-pending">
					<strong><?php echo (int) $counts['pending']; ?></strong> pendientes
				</span>
				<span class="rsa-ap-stat rsa-ap-stat-applied">
					<strong><?php echo (int) $counts['applied']; ?></strong> aplicadas
				</span>
				<span class="rsa-ap-stat">
					<strong><?php echo (int) $counts['rejected']; ?></strong> rechazadas
				</span>
				<span class="rsa-ap-divider"></span>
				<span class="rsa-ap-stat">
					Última captura:
					<strong><?php echo $last_cap
						? esc_html( date_i18n( get_option( 'date_format' ) . ' H:i', strtotime( $last_cap ) ) )
						: 'Nunca'; ?></strong>
				</span>
				<?php if ( $next_cap ) : ?>
					<span class="rsa-ap-stat">
						Próxima: <strong><?php echo esc_html( date_i18n( 'D d/m', $next_cap ) ); ?></strong>
					</span>
				<?php endif; ?>
			</div>

			<?php if ( empty( $pending ) ) : ?>
				<div class="rsa-seo-notice rsa-ap-empty-state">
					<?php if ( $last_cap ) : ?>
						<i class="ph ph-check-circle"></i> Sin propuestas pendientes. El autopilot capturará datos semanalmente.
					<?php else : ?>
						<i class="ph ph-rocket-launch"></i> <strong>Primera captura</strong> — Haz clic en <strong>«Capturar ahora»</strong>
						para que Claude analice tus URLs y genere las primeras propuestas SEO.
					<?php endif; ?>
				</div>
			<?php else : ?>

				<div class="rsa-ap-toolbar">
					<div class="rsa-ap-bulk-bar">
						<label class="rsa-ap-select-all-label">
							<input type="checkbox" id="rsa-ap-select-all">
							Seleccionar todo
						</label>
						<button class="button button-primary" id="rsa-ap-approve-selected" disabled>
							<i class="ph ph-check"></i> Aprobar seleccionados
						</button>
						<button class="button" id="rsa-ap-reject-selected" disabled>
							<i class="ph ph-x"></i> Rechazar seleccionados
						</button>
						<span class="rsa-ap-sel-count" id="rsa-ap-sel-count"></span>
					</div>
					<div class="rsa-ap-filter-bar">
						<input type="text" id="rsa-ap-url-filter" placeholder="Filtrar por URL…"
							   style="width:260px" class="regular-text">
						<span id="rsa-ap-filter-count" style="margin-left:8px;color:#666;font-size:13px"></span>
					</div>
				</div>

				<table class="rsa-proposals-table widefat striped">
					<thead>
						<tr>
							<th class="rsa-col-check"></th>
							<th>Tipo</th>
							<th>URL</th>
							<th>Lang</th>
							<th>Antes</th>
							<th>Propuesta</th>
							<th>Razonamiento IA</th>
							<th class="rsa-col-actions">Acción</th>
						</tr>
					</thead>
					<tbody id="rsa-proposals-tbody">
					<?php
					foreach ( $pending as $p ) :
						$info   = $labels[ $p['type'] ] ?? [ 'icon' => '•', 'label' => $p['type'] ];
						$before = mb_substr( (string) $p['value_before'], 0, 80 );
						// Render new_draft as human-readable title instead of raw JSON
						if ( $p['type'] === 'new_draft' ) {
							$draft_data = json_decode( (string) $p['value_after'], true );
							$after      = isset( $draft_data['title'] )
								? $draft_data['title']
									. ( ! empty( $draft_data['focus_kw'] ) ? ' · kw: ' . $draft_data['focus_kw'] : '' )
								: mb_substr( (string) $p['value_after'], 0, 120 );
						} else {
							$after = mb_substr( (string) $p['value_after'], 0, 120 );
						}
					?>
						<tr class="rsa-proposal-row" data-id="<?php echo (int) $p['id']; ?>">
							<td><input type="checkbox" class="rsa-ap-check" value="<?php echo (int) $p['id']; ?>"></td>
							<td>
								<span class="rsa-proposal-badge rsa-ptype-<?php echo esc_attr( $p['type'] ); ?>">
									<?php echo $info['icon'] . ' ' . esc_html( $info['label'] ); ?>
								</span>
							</td>
							<td class="rsa-proposal-url">
								<a href="<?php echo esc_url( home_url( $p['url'] ) ); ?>"
								   target="_blank" rel="noopener noreferrer">
									<?php echo esc_html( $p['url'] ); ?>
								</a>
							</td>
							<td>
								<?php if ( $p['lang'] ) : ?>
									<span class="rsa-lang-badge"><?php echo esc_html( $p['lang'] ); ?></span>
								<?php else : ?>—<?php endif; ?>
							</td>
							<td class="rsa-proposal-before">
								<span class="rsa-val-before"><?php echo esc_html( $before ); ?></span>
							</td>
							<td class="rsa-proposal-after">
								<span class="rsa-val-after"><?php echo esc_html( $after ); ?></span>
							</td>
							<td class="rsa-proposal-reasoning">
								<small><?php echo esc_html( (string) $p['claude_reasoning'] ); ?></small>
							</td>
							<td class="rsa-proposal-actions">
								<button class="button button-small rsa-ap-diff-toggle"
										data-id="<?php echo (int) $p['id']; ?>" title="Ver cambio completo"><i class="ph ph-eye"></i></button>
								<button class="button button-primary button-small rsa-ap-approve"
										data-id="<?php echo (int) $p['id']; ?>" title="Aprobar y aplicar"><i class="ph ph-check-circle"></i></button>
								<button class="button button-small rsa-ap-reject"
										data-id="<?php echo (int) $p['id']; ?>" title="Rechazar"><i class="ph ph-x"></i></button>
							</td>
						</tr>
						<tr class="rsa-diff-row" id="rsa-diff-<?php echo (int) $p['id']; ?>" style="display:none">
							<td colspan="8" class="rsa-diff-cell">
								<div class="rsa-diff-container">
									<div class="rsa-diff-panel rsa-diff-before">
										<div class="rsa-diff-label">ANTES</div>
										<div class="rsa-diff-text"><?php echo self::format_diff_value( $p['type'], (string) $p['value_before'] ); ?></div>
									</div>
									<div class="rsa-diff-panel rsa-diff-after">
										<div class="rsa-diff-label">PROPUESTA</div>
										<div class="rsa-diff-text"><?php echo self::format_diff_value( $p['type'], (string) $p['value_after'] ); ?></div>
									</div>
								</div>
								<?php if ( ! empty( $p['claude_reasoning'] ) ) : ?>
									<div class="rsa-diff-reasoning"><i class="ph ph-lightbulb"></i> <?php echo esc_html( (string) $p['claude_reasoning'] ); ?></div>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php if ( $counts['pending'] > 50 ) : ?>
					<p class="rsa-ap-table-note">
						<em>Mostrando 50 de <?php echo (int) $counts['pending']; ?> propuestas pendientes.
						Aprueba o rechaza estas para ver las siguientes.</em>
					</p>
				<?php endif; ?>

			<?php endif; ?>

			<?php
			// ── Regression alert (show in panel, same logic as email digest) ──
			$regressions = RSA_SERP_Tracker::get_regressions();
			if ( ! empty( $regressions ) ) : ?>
				<div class="rsa-regression-alert" style="border:2px solid #dc2626;border-radius:6px;padding:14px 18px;margin:16px 0;background:#fef2f2">
					<strong style="color:#dc2626"><i class="ph ph-warning"></i> <?php echo count( $regressions ); ?> página(s) con regresión SERP detectada — considera revertir estos cambios</strong>
					<ul style="margin:8px 0 0;padding-left:18px">
						<?php foreach ( array_slice( $regressions, 0, 5 ) as $reg ) :
							$pos_d    = round( (float) $reg['position_delta'], 1 );
							$clicks_d = (int) $reg['clicks_delta'];
							$sign     = $clicks_d >= 0 ? '+' : '';
						?>
							<li>
								<a href="<?php echo esc_url( home_url( $reg['url'] ) ); ?>" target="_blank" rel="noopener">
									<?php echo esc_html( $reg['url'] ); ?>
								</a>
								— posición empeoró <strong>+<?php echo $pos_d; ?></strong> puestos,
								clicks Δ <?php echo $sign . $clicks_d; ?>
								<button class="button button-small rsa-ap-rollback"
										data-id="<?php echo (int) $reg['id']; ?>"
										style="margin-left:8px" title="Revertir"><i class="ph ph-arrow-counter-clockwise"></i> Revertir</button>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $applied ) ) : ?>
				<div class="rsa-ap-impact-section">
					<h3><i class="ph ph-trend-up"></i> Seguimiento — Propuestas aplicadas</h3>
					<p class="rsa-seo-agent-desc">Evolución de posición SERP desde la aplicación de cada cambio. Los datos aparecen tras 7+ días.</p>
					<table class="rsa-proposals-table widefat striped">
						<thead>
							<tr>
								<th>URL</th>
								<th>Tipo</th>
								<th>Aplicado</th>
								<th>Propagado</th>
								<th>Pos. Δ</th>
								<th>Clicks Δ</th>
								<th style="width:90px">Tendencia</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
						<?php
						foreach ( $applied as $p ) :
							$info         = $labels[ $p['type'] ] ?? [ 'icon' => '•', 'label' => $p['type'] ];
							$impact       = RSA_SERP_Tracker::get_proposal_impact( $p );
							$prop_langs   = ! empty( $p['propagated_langs'] )
								? implode( ', ', (array) json_decode( (string) $p['propagated_langs'], true ) )
								: '';
							$can_rollback = in_array(
								$p['type'],
								[ 'meta_title', 'meta_desc', 'focus_kw', 'h1', 'intro_text', 'body_text', 'alt_text', 'interlink', 'schema_add', 'schema_fix' ],
								true
							);
							$sparkline    = RSA_SERP_Tracker::get_sparkline_data( $p['url'], 8 );
						?>
							<tr class="rsa-ap-applied-row" data-id="<?php echo (int) $p['id']; ?>">
								<td>
									<a href="<?php echo esc_url( home_url( $p['url'] ) ); ?>"
									   target="_blank" rel="noopener noreferrer">
										<?php echo esc_html( $p['url'] ); ?>
									</a>
								</td>
								<td>
									<span class="rsa-proposal-badge rsa-ptype-<?php echo esc_attr( $p['type'] ); ?>">
										<?php echo $info['icon'] . ' ' . esc_html( $info['label'] ); ?>
									</span>
								</td>
								<td><small><?php echo esc_html( $p['applied_at'] ?: ( $p['decided_at'] ?? '' ) ); ?></small></td>
								<td>
									<?php if ( $prop_langs ) : ?>
										<span class="rsa-propagated" title="Propagado a: <?php echo esc_attr( $prop_langs ); ?>">
											<i class="ph ph-check"></i> <?php echo esc_html( $prop_langs ); ?>
										</span>
									<?php else : ?><span class="rsa-ap-no-data">—</span><?php endif; ?>
								</td>
								<td>
									<?php $d = $impact['position_delta'];
									if ( $d !== null ) :
										$col  = $d <= 0 ? '#16a34a' : '#dc2626';
										$sign = $d <= 0 ? '▲ ' : '▼ ';
									?>
										<span style="color:<?php echo $col; ?>;font-weight:700">
											<?php echo $sign . abs( $d ); ?>
										</span>
									<?php else : ?>
										<span class="rsa-ap-no-data">—</span>
									<?php endif; ?>
								</td>
								<td>
									<?php $dc = $impact['clicks_delta'];
									if ( $dc !== null ) :
										$col  = $dc >= 0 ? '#16a34a' : '#dc2626';
										$sign = $dc >= 0 ? '+' : '';
									?>
										<span style="color:<?php echo $col; ?>;font-weight:700">
											<?php echo $sign . $dc; ?>
										</span>
									<?php else : ?>
										<span class="rsa-ap-no-data">—</span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( ! empty( $sparkline['positions'] ) ) : ?>
										<canvas class="rsa-sparkline" width="86" height="28"
											data-history="<?php echo esc_attr( wp_json_encode( $sparkline ) ); ?>">
										</canvas>
									<?php else : ?>
										<span class="rsa-ap-no-data" style="font-size:11px">sin datos</span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( $can_rollback ) : ?>
										<button class="button button-small rsa-ap-rollback"
												data-id="<?php echo (int) $p['id']; ?>"
												title="Revertir este cambio"><i class="ph ph-arrow-counter-clockwise"></i></button>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>

		</div><!-- .rsa-autopilot-section -->
		<?php
	}

	/* ─────────────────────────────────────────
	 * Internal helpers
	 * ───────────────────────────────────────── */

	/** Returns display labels and icons for each proposal type. */
	private static function type_labels(): array {
		return [
			'meta_title'  => [ 'icon' => '<i class="ph ph-tag"></i>',           'label' => 'Meta Title'     ],
			'meta_desc'   => [ 'icon' => '<i class="ph ph-note-pencil"></i>',   'label' => 'Meta Desc'      ],
			'focus_kw'    => [ 'icon' => '<i class="ph ph-target"></i>',        'label' => 'Focus KW'       ],
			'h1'          => [ 'icon' => '<i class="ph ph-text-h"></i>',        'label' => 'H1'             ],
			'intro_text'  => [ 'icon' => '<i class="ph ph-paragraph"></i>',     'label' => 'Intro párrafo'  ],
			'body_text'   => [ 'icon' => '<i class="ph ph-pencil"></i>',        'label' => 'Párrafo cuerpo' ],
			'alt_text'    => [ 'icon' => '<i class="ph ph-image"></i>',         'label' => 'Alt Text'       ],
			'schema_add'  => [ 'icon' => '<i class="ph ph-code"></i>',          'label' => 'Schema nuevo'   ],
			'schema_fix'  => [ 'icon' => '<i class="ph ph-wrench"></i>',        'label' => 'Schema fix'     ],
			'interlink'   => [ 'icon' => '<i class="ph ph-link"></i>',          'label' => 'Interlink'      ],
			'new_draft'   => [ 'icon' => '<i class="ph ph-file-text"></i>',     'label' => 'Borrador'       ],
		];
	}

	/**
	 * Format a raw proposal value for diff display.
	 * JSON types are pretty-printed; HTML content types show stripped text + raw details.
	 */
	private static function format_diff_value( string $type, string $raw ): string {
		if ( $raw === '' || $raw === '(vacío)' ) {
			return '<em class="rsa-diff-empty">(vacío)</em>';
		}

		// JSON types: pretty-print
		if ( in_array( $type, [ 'interlink', 'body_text', 'new_draft', 'schema_add', 'schema_fix' ], true ) ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				$pretty = json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				return '<pre class="rsa-diff-json">' . esc_html( (string) $pretty ) . '</pre>';
			}
		}

		// Build plain-text output; append raw-HTML toggle for HTML content types
		$plain  = wp_strip_all_tags( $raw );
		$output = '<div class="rsa-diff-plain">' . nl2br( esc_html( $plain ) ) . '</div>';
		if ( in_array( $type, [ 'intro_text' ], true ) && $plain !== $raw ) {
			$output .= '<details class="rsa-diff-html-raw"><summary>Ver HTML</summary>'
				. '<pre>' . esc_html( $raw ) . '</pre></details>';
		}

		return $output;
	}
}
