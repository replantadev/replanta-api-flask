<?php
/**
 * Cloudflare Audit Module — v2.1
 *
 * Audita la configuración de una zona CF buscando problemas
 * que puedan afectar al SEO / tráfico orgánico.
 * Ahora con soporte de auto-fix por cada check.
 *
 * DEPENDENCIA: Dominios Reseller (soft)
 *   Acceso al servicio CF únicamente a través de RSA_DR_Bridge::get_service().
 *   Nunca usar class_exists('Dominios_Reseller_Cloudflare_Service') directamente.
 *
 * @package Replanta_Site_Audit
 * @version 2.1.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Cloudflare_Audit {

    private $cf = null;
    private ?string $zone_id = null;
    private ?string $zone_name = null;
    private bool $cf_available = false;

    public function __construct() {
        // Acceso al servicio CF siempre a través del bridge — nunca directo.
        $service = RSA_DR_Bridge::get_service();
        if ($service !== null) {
            $this->cf           = $service;
            $this->cf_available = true;
        }
    }

    /**
     * Run the audit - returns empty if CF not available
     */
    public function run(): array {
        if (!$this->cf_available || !$this->cf) {
            return [
                'ok'      => false,
                'error'   => 'Cloudflare no configurado. Instala Dominios Reseller para auditoría CF.',
                'score'   => 0,
                'checks'  => [],
                'summary' => ['total' => 0, 'passed' => 0],
            ];
        }

        // Continue with normal audit...
        return $this->run_audit();
    }

    /* ─────────────────────────── helpers ─────────────────────────── */

    private function resolve_zone(): bool {
        if ($this->zone_id) return true;

        $match = $this->cf->match_domain_to_zone(RSA_DOMAIN);
        if ($match) {
            $this->zone_id   = $match['zone_id'];
            $this->zone_name = $match['zone_name'];
            return true;
        }
        $zone = $this->cf->get_zone(RSA_DOMAIN);
        if ($zone) {
            $this->zone_id   = $zone['zone_id'];
            $this->zone_name = $zone['name'];
            return true;
        }
        return false;
    }

    private function safe_get(string $endpoint, array $args = []): array {
        try {
            $result = $this->cf->api_get($endpoint, $args);
        } catch (\Throwable $e) {
            return ['_error' => $e->getMessage()];
        }
        if (is_wp_error($result)) {
            return ['_error' => $result->get_error_message()];
        }
        return $result;
    }

    /**
     * Get server IP and geolocation info
     * This is crucial to detect if firewall rules block the server itself
     */
    private function get_server_info(): array {
        static $cache = null;
        if ($cache !== null) return $cache;

        $info = [
            'ip' => null,
            'country' => null,
            'country_name' => null,
            'is_datacenter' => false,
        ];

        // Method 1: ipify + ip-api for geolocation
        $resp = wp_remote_get('https://api.ipify.org?format=json', [
            'timeout' => 5, 'sslverify' => true
        ]);
        if (!is_wp_error($resp)) {
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($body['ip'])) {
                $info['ip'] = $body['ip'];
                
                // Get geolocation (HTTP endpoint — no SSL needed)
                $geo = wp_remote_get("http://ip-api.com/json/{$info['ip']}?fields=country,countryCode,hosting", [
                    'timeout' => 5
                ]);
                if (!is_wp_error($geo)) {
                    $geo_data = json_decode(wp_remote_retrieve_body($geo), true);
                    $info['country'] = $geo_data['countryCode'] ?? null;
                    $info['country_name'] = $geo_data['country'] ?? null;
                    $info['is_datacenter'] = $geo_data['hosting'] ?? false;
                }
            }
        }

        // Fallback: CF trace
        if (!$info['ip']) {
            $resp = wp_remote_get('https://www.cloudflare.com/cdn-cgi/trace', [
                'timeout' => 5, 'sslverify' => true
            ]);
            if (!is_wp_error($resp)) {
                $body = wp_remote_retrieve_body($resp);
                if (preg_match('/ip=([0-9.]+)/', $body, $m)) {
                    $info['ip'] = $m[1];
                }
                if (preg_match('/loc=([A-Z]{2})/', $body, $m)) {
                    $info['country'] = $m[1];
                }
            }
        }

        $cache = $info;
        return $info;
    }

    private function get_setting(array $settings, string $id): mixed {
        if (isset($settings['_error']) || !isset($settings['result'])) return null;
        foreach ($settings['result'] as $s) {
            if ($s['id'] === $id) return $s['value'];
        }
        return null;
    }

    /**
     * Extended make_check — supports optional auto-fix metadata.
     */
    private function make_check(
        string  $id,
        string  $label,
        string  $status,
        string  $value,
        string  $detail,
        string  $category  = 'security',
        ?string $fix_id    = null,
        ?string $fix_label = null
    ): array {
        $c = compact('id', 'label', 'status', 'value', 'detail', 'category');
        if ($fix_id && in_array($status, ['warning', 'critical', 'info'], true)) {
            $c['fixable']   = true;
            $c['fix_id']    = $fix_id;
            $c['fix_label'] = $fix_label ?? 'Corregir';
        }
        return $c;
    }

    /* ────────────────────────── RUN AUDIT INTERNAL ──────────────────────── */

    private function run_audit(): array {
        if (!$this->resolve_zone()) {
            return [
                'ok' => false,
                'error' => 'No se encontró la zona de ' . RSA_DOMAIN . ' en Cloudflare.',
                'checks' => [], 'score' => 0,
                'summary' => ['total' => 0, 'passed' => 0, 'critical' => 0, 'warnings' => 0],
            ];
        }

        $z = $this->zone_id;
        $settings   = $this->safe_get("/zones/{$z}/settings");
        $page_rules = $this->safe_get("/zones/{$z}/pagerules", ['status' => 'active']);
        $dns        = $this->safe_get("/zones/{$z}/dns_records", ['per_page' => 100]);
        $zone_info  = $this->safe_get("/zones/{$z}");
        $firewall   = $this->safe_get("/zones/{$z}/rulesets/phases/http_request_firewall_custom/entrypoint");
        $bots       = $this->safe_get("/zones/{$z}/bot_management");
        
        // NEW: Additional security checks
        $waf_packages = $this->safe_get("/zones/{$z}/firewall/waf/packages");
        $rate_limits  = $this->safe_get("/zones/{$z}/rate_limits");
        $ip_access    = $this->safe_get("/zones/{$z}/firewall/access_rules/rules", ['per_page' => 50]);
        
        // NEW: Security analytics (last 24h)
        $analytics    = $this->get_security_analytics($z);

        // v2.6: Cache performance
        $cache_ruleset  = $this->safe_get("/zones/{$z}/rulesets/phases/http_request_cache_settings/entrypoint");
        $dash_analytics = $this->get_cache_analytics_graphql($z);

        // v2.7: Managed Headers
        $managed_headers = $this->safe_get("/zones/{$z}/managed_headers");

        $checks = array_merge(
            $this->check_security_level($settings),
            $this->check_ssl_mode($settings),
            $this->check_hsts($settings),               // v2.7
            $this->check_tls_version($settings),         // v2.7
            $this->check_bot_fight($settings, $bots),
            $this->check_browser_integrity($settings),
            $this->check_dev_mode($settings),
            $this->check_always_https($settings),
            $this->check_minify($settings),
            $this->check_brotli($settings),
            $this->check_cache_ttl($settings),
            $this->check_always_online($settings),
            $this->check_rocket_loader($settings),
            $this->check_early_hints($settings),
            $this->check_http_protocols($settings),
            $this->check_auto_https_rewrites($settings),
            $this->check_hotlink_protection($settings),
            $this->check_email_obfuscation($settings),
            $this->check_page_rules($page_rules),
            $this->check_cache_rules($cache_ruleset),      // v2.6 ─ Cache Rules
            $this->check_cache_analytics($dash_analytics), // v2.6 ─ Hit ratio (GraphQL)
            $this->check_firewall_rules($firewall),
            $this->check_server_self_block($firewall),
            // Security checks
            $this->check_waf_rules($waf_packages),
            $this->check_rate_limiting($rate_limits),
            $this->check_ip_access_rules($ip_access),
            $this->check_security_analytics($analytics),
            // DNS + Zone
            $this->check_dns_records($dns),
            $this->check_dkim_proxy($dns),               // v2.7
            $this->check_zone_status($zone_info),
            $this->check_crawler_hints($settings),
            $this->check_managed_headers($managed_headers), // v2.7
        );

        $total    = count($checks);
        $passed   = count(array_filter($checks, fn($c) => $c['status'] === 'pass'));
        $critical = count(array_filter($checks, fn($c) => $c['status'] === 'critical'));
        $warnings = count(array_filter($checks, fn($c) => $c['status'] === 'warning'));

        return [
            'ok' => true, 'zone_id' => $z, 'zone_name' => $this->zone_name,
            'score'   => $total > 0 ? round(($passed / $total) * 100) : 0,
            'summary' => compact('total', 'passed', 'critical', 'warnings'),
            'checks'  => $checks,
        ];
    }

    /* ═════════════════════════ INDIVIDUAL CHECKS ═════════════════════════ */

    private function check_security_level(array $s): array {
        $v = $this->get_setting($s, 'security_level');
        if ($v === null) return [$this->make_check('security_level', 'Nivel de Seguridad', 'info', '?', 'No se pudo leer.')];
        if ($v === 'under_attack')
            return [$this->make_check('security_level', 'Nivel de Seguridad', 'critical', $v,
                'MODO "Under Attack" ACTIVO. Challenge JS a TODAS las visitas (incluido Googlebot). Desactívalo ya.',
                'security', 'cf_security_medium', 'Cambiar a Medium')];
        if ($v === 'high')
            return [$this->make_check('security_level', 'Nivel de Seguridad', 'warning', $v,
                'Nivel "High" puede mostrar CAPTCHA a bots no reconocidos. Se recomienda "Medium".',
                'security', 'cf_security_medium', 'Cambiar a Medium')];
        return [$this->make_check('security_level', 'Nivel de Seguridad', 'pass', $v, 'Nivel correcto.')];
    }

    private function check_ssl_mode(array $s): array {
        $v = $this->get_setting($s, 'ssl');
        if ($v === null) return [$this->make_check('ssl_mode', 'Modo SSL', 'info', '?', 'No se pudo leer.')];
        if ($v === 'off')
            return [$this->make_check('ssl_mode', 'Modo SSL', 'critical', 'OFF', 'SSL desactivado. Google penaliza.')];
        if ($v === 'flexible')
            return [$this->make_check('ssl_mode', 'Modo SSL', 'warning', 'Flexible', 'Puede causar bucles de redirección. Usa "Full (Strict)".')];
        return [$this->make_check('ssl_mode', 'Modo SSL', 'pass', ucfirst($v), 'Configuración SSL correcta.')];
    }

    private function check_bot_fight(array $s, array $bots): array {
        $checks = [];
        if (!isset($bots['_error']) && isset($bots['result'])) {
            $r = $bots['result'];

            // Detect plan format: Pro+ has sbfm_* keys, Free has fight_mode/ai_bots_protection
            $has_sbfm = isset($r['sbfm_definitely_automated']) || isset($r['sbfm_likely_automated']);

            if ($has_sbfm) {
                // Pro/Biz/Ent: Super Bot Fight Mode granular controls
                $def = $r['sbfm_definitely_automated'] ?? null;
                $lik = $r['sbfm_likely_automated'] ?? null;
                $ver = $r['sbfm_verified_bots'] ?? null;

                if ($def === 'block' || $lik === 'block')
                    $checks[] = $this->make_check('sbfm', 'Super Bot Fight Mode', 'critical', 'Bloqueando bots',
                        'SBFM BLOQUEA tráfico automatizado. Puede afectar crawlers y herramientas SEO.');
                elseif ($ver === 'block')
                    $checks[] = $this->make_check('sbfm', 'Super Bot Fight Mode', 'critical', 'Bloquea verificados',
                        'SBFM bloquea BOTS VERIFICADOS (Googlebot). Cambia "Verified Bots" a "Allow".');
                elseif ($def === 'managed_challenge' || $lik === 'managed_challenge')
                    $checks[] = $this->make_check('sbfm', 'Super Bot Fight Mode', 'info', 'Challenge activo',
                        'SBFM desafía bots no verificados. Googlebot no se bloquea pero herramientas SEO pueden fallar.');
                else
                    $checks[] = $this->make_check('sbfm', 'Super Bot Fight Mode', 'pass', 'OK',
                        'SBFM bien configurado. Bots verificados permitidos.');
            } else {
                // Free plan: simplified Bot Fight Mode
                $fight_mode      = $r['fight_mode'] ?? false;
                $ai_protection   = $r['ai_bots_protection'] ?? 'disabled';
                $crawler_protect = $r['crawler_protection'] ?? 'disabled';
                $enable_js       = $r['enable_js'] ?? false;

                $issues = [];
                if ($fight_mode) {
                    $issues[] = 'Bot Fight Mode activo (puede bloquear crawlers legítimos no verificados)';
                }
                if ($enable_js) {
                    $issues[] = 'JS Challenge activo para bots';
                }

                $info_parts = [];
                if ($ai_protection === 'enabled' || $ai_protection === 'block') {
                    $info_parts[] = 'AI Bots: bloqueados';
                }
                if ($crawler_protect === 'enabled' || $crawler_protect === 'block') {
                    $info_parts[] = 'Crawler Protection: activo';
                }

                if ($fight_mode) {
                    $detail = 'Bot Fight Mode ACTIVO. ' . implode('. ', $issues) . '.';
                    if (!empty($info_parts)) $detail .= ' ' . implode('. ', $info_parts) . '.';
                    $detail .= ' En plan Free no se puede excluir Googlebot de BFM — considera desactivarlo si hay problemas de rastreo.';
                    $checks[] = $this->make_check('bfm', 'Bot Fight Mode', 'warning', 'Activo', $detail);
                } else {
                    $status_parts = ['BFM: off'];
                    if (!empty($info_parts)) $status_parts = array_merge($status_parts, $info_parts);
                    $checks[] = $this->make_check('bfm', 'Bot Fight Mode', 'pass', 'OK',
                        'Bot Fight Mode desactivado. ' . implode('. ', $info_parts ?: ['Sin restricciones de bots.']));
                }
            }
        } else {
            $checks[] = $this->make_check('bfm', 'Bot Fight Mode', 'info', 'No disponible',
                'No se pudo consultar Bot Management. Verifica manualmente en CF Dashboard → Security → Bots.');
        }
        return $checks;
    }

    private function check_browser_integrity(array $s): array {
        $v = $this->get_setting($s, 'browser_check');
        if ($v === 'on') return [$this->make_check('browser_integrity', 'Browser Integrity Check', 'info', 'Activado',
            'BIC evalúa headers HTTP. Normalmente no afecta Googlebot.')];
        return [$this->make_check('browser_integrity', 'Browser Integrity Check', 'pass', 'Desactivado', 'OK.')];
    }

    private function check_dev_mode(array $s): array {
        $v = $this->get_setting($s, 'development_mode');
        if ($v !== null && $v !== 'off')
            return [$this->make_check('dev_mode', 'Modo Desarrollo', 'warning', 'ACTIVO',
                'Development Mode activo: se desactivan cache y optimizaciones.',
                'performance', 'cf_dev_mode_off', 'Desactivar')];
        return [$this->make_check('dev_mode', 'Modo Desarrollo', 'pass', 'Off', 'Cache y optimizaciones activas.', 'performance')];
    }

    private function check_always_https(array $s): array {
        $v = $this->get_setting($s, 'always_use_https');
        if ($v === 'on') return [$this->make_check('always_https', 'Always Use HTTPS', 'pass', 'Activado', 'Redirige HTTP → HTTPS.')];
        return [$this->make_check('always_https', 'Always Use HTTPS', 'warning', 'Desactivado',
            'Activa para forzar HTTPS.', 'security', 'cf_always_https', 'Activar')];
    }

    private function check_minify(array $s): array {
        $v = $this->get_setting($s, 'minify');

        // Cloudflare deprecated Auto Minify (Aug 2024).
        // The setting may no longer appear in the API response (null),
        // or may return {css:off, html:off, js:off} but ignore PATCH updates.
        if ($v === null) {
            return [$this->make_check('minify', 'Minificación CF', 'pass', 'N/A',
                'Auto Minify fue deprecado por Cloudflare (Ago 2024). Usa plugins de optimización (LiteSpeed, Autoptimize) para minificar.', 'performance')];
        }

        $parts = [];
        if (is_array($v)) {
            if (($v['html'] ?? '') === 'on') $parts[] = 'HTML';
            if (($v['css'] ?? '') === 'on')  $parts[] = 'CSS';
            if (($v['js'] ?? '') === 'on')   $parts[] = 'JS';
        }

        // Si existe pero todo está a off, es deprecated funcional — NO ofrecer fix
        if (empty($parts)) {
            return [$this->make_check('minify', 'Minificación CF', 'pass', 'N/A (deprecated)',
                'Auto Minify fue deprecado por Cloudflare (Ago 2024). La opción existe pero ya no se aplica. '
                . 'Usa LiteSpeed Cache o Autoptimize para minificar CSS/JS/HTML.', 'performance')];
        }

        return [$this->make_check('minify', 'Minificación CF', 'pass', implode('+', $parts),
            'Minificación activa: ' . implode(', ', $parts) . '.', 'performance')];
    }

    private function check_brotli(array $s): array {
        $v = $this->get_setting($s, 'brotli');
        if ($v === 'on') return [$this->make_check('brotli', 'Brotli Compression', 'pass', 'Activado',
            'Brotli ofrece ~20% mejor compresión que gzip.', 'performance')];
        return [$this->make_check('brotli', 'Brotli Compression', 'warning', 'Desactivado',
            'Activa Brotli para mejor compresión.', 'performance', 'cf_brotli', 'Activar')];
    }

    private function check_cache_ttl(array $s): array {
        $v = $this->get_setting($s, 'browser_cache_ttl');
        if ($v === null) return [$this->make_check('cache_ttl', 'Browser Cache TTL', 'info', '?', 'No se pudo leer.', 'performance')];
        if ($v == 0)     return [$this->make_check('cache_ttl', 'Browser Cache TTL', 'pass', 'Respetar origen', 'CF respeta headers del origen.', 'performance')];
        $h = round($v / 3600, 1);
        if ($v < 14400) return [$this->make_check('cache_ttl', 'Browser Cache TTL', 'warning', $h . 'h', 'TTL bajo. Recomendar ≥ 4h.', 'performance')];
        return [$this->make_check('cache_ttl', 'Browser Cache TTL', 'pass', $h . 'h', 'TTL adecuado.', 'performance')];
    }

    private function check_always_online(array $s): array {
        $v = $this->get_setting($s, 'always_online');
        if ($v === 'on') return [$this->make_check('always_online', 'Always Online', 'pass', 'Activado',
            'Sirve cache si el servidor cae.', 'performance')];
        return [$this->make_check('always_online', 'Always Online', 'info', 'Desactivado',
            'Activar para evitar 5xx al usuario.', 'performance', 'cf_always_online', 'Activar')];
    }

    private function check_rocket_loader(array $s): array {
        $v = $this->get_setting($s, 'rocket_loader');
        if ($v === 'on') return [$this->make_check('rocket_loader', 'Rocket Loader', 'warning', 'Activado',
            'Puede romper JS (analytics, chat, GeoPrice). Con LiteSpeed ya tienes defer/async.',
            'performance', 'cf_rocket_loader_off', 'Desactivar')];
        return [$this->make_check('rocket_loader', 'Rocket Loader', 'pass', 'Desactivado', 'Correcto.', 'performance')];
    }

    private function check_early_hints(array $s): array {
        $v = $this->get_setting($s, 'early_hints');
        if ($v === 'on') return [$this->make_check('early_hints', 'Early Hints (103)', 'pass', 'Activado',
            'Navegadores precargan recursos antes de que el HTML llegue → mejor LCP.', 'performance')];
        return [$this->make_check('early_hints', 'Early Hints (103)', 'info', 'Desactivado',
            'Activar mejora LCP.', 'performance', 'cf_early_hints', 'Activar')];
    }

    private function check_http_protocols(array $s): array {
        $checks = [];
        $checks[] = $this->make_check('http2', 'HTTP/2', 'pass', 'Activado', 'Estándar en CF.', 'performance');
        $h3 = $this->get_setting($s, 'http3');
        if ($h3 === 'on') $checks[] = $this->make_check('http3', 'HTTP/3 (QUIC)', 'pass', 'Activado', 'Mejor rendimiento móvil.', 'performance');
        elseif ($h3 !== null) $checks[] = $this->make_check('http3', 'HTTP/3 (QUIC)', 'info', 'Desactivado',
            'Activar mejora redes con pérdida de paquetes.', 'performance', 'cf_http3', 'Activar');
        return $checks;
    }

    private function check_auto_https_rewrites(array $s): array {
        $v = $this->get_setting($s, 'automatic_https_rewrites');
        if ($v === 'on') return [$this->make_check('https_rewrites', 'Auto HTTPS Rewrites', 'pass', 'Activado', 'Evita mixed content.')];
        return [$this->make_check('https_rewrites', 'Auto HTTPS Rewrites', 'warning', 'Desactivado',
            'Activar para evitar contenido mixto.', 'security', 'cf_auto_https_rewrites', 'Activar')];
    }

    private function check_hotlink_protection(array $s): array {
        $v = $this->get_setting($s, 'hotlink_protection');
        if ($v === 'on') return [$this->make_check('hotlink', 'Hotlink Protection', 'warning', 'Activado',
            'Puede bloquear Google Images. Verifica indexación de imágenes.', 'security', 'cf_hotlink_off', 'Desactivar')];
        return [$this->make_check('hotlink', 'Hotlink Protection', 'pass', 'Desactivado', 'No interfiere con imágenes.')];
    }

    private function check_email_obfuscation(array $s): array {
        $v = $this->get_setting($s, 'email_obfuscation');
        if ($v === 'on') return [$this->make_check('email_obfuscation', 'Email Obfuscation', 'info', 'Activado',
            'CF ofusca emails con JS. Mínimo impacto.', 'performance')];
        return [$this->make_check('email_obfuscation', 'Email Obfuscation', 'pass', 'Desactivado', 'OK.', 'performance')];
    }

    private function check_page_rules(array $pr): array {
        if (isset($pr['_error'])) return [$this->make_check('page_rules', 'Page Rules', 'info', '?', 'Error: ' . $pr['_error'], 'seo')];
        $rules = $pr['result'] ?? [];
        if (empty($rules)) return [$this->make_check('page_rules', 'Page Rules', 'pass', '0 reglas', 'Limpio.', 'seo')];
        $issues = [];
        foreach ($rules as $i => $rule) {
            $target = $rule['targets'][0]['constraint']['value'] ?? '';
            foreach ($rule['actions'] ?? [] as $a) {
                if (($a['id'] ?? '') === 'forwarding_url' && ($a['value']['status_code'] ?? 302) == 302)
                    $issues[] = "#{$i}: \"{$target}\" → 302. Usa 301 si permanente.";
            }
        }
        if (!empty($issues))
            return [$this->make_check('page_rules', 'Page Rules', 'warning', count($rules) . ' reglas',
                "Problemas:\n• " . implode("\n• ", $issues), 'seo')];
        return [$this->make_check('page_rules', 'Page Rules', 'pass', count($rules) . ' reglas', 'Sin problemas SEO.', 'seo')];
    }

    /* ─── Firewall Rules (Rulesets API — WAF Custom Rules) ─── */

    private function check_firewall_rules(array $fw): array {
        if (isset($fw['_error'])) return [$this->make_check('firewall_rules', 'WAF Custom Rules', 'info', '?', 'Error: ' . $fw['_error'])];
        // Rulesets API: rules are in result.rules[]
        $rules = $fw['result']['rules'] ?? [];
        if (empty($rules)) return [$this->make_check('firewall_rules', 'WAF Custom Rules', 'pass', '0 reglas', 'Sin reglas personalizadas.')];

        $issues = []; $warnings = []; $good = [];

        foreach ($rules as $rule) {
            // Rulesets API format: expression and action at top level
            $expr   = $rule['expression'] ?? '';
            $action = $rule['action'] ?? '';
            $desc   = $rule['description'] ?? 'Sin nombre';
            $enabled = $rule['enabled'] ?? true;

            if (!$enabled) continue;

            if (preg_match('/ip\.geoip\.country/i', $expr)
                && in_array($action, ['block', 'challenge', 'js_challenge', 'managed_challenge'])) {

                $has_bot  = (bool)preg_match('/cf\.client\.bot|cf\.bot_management\.verified_bot/i', $expr);
                $has_path = (bool)preg_match('/robots\.txt|sitemap/i', $expr);

                if ($has_bot) {
                    preg_match_all('/"([A-Z]{2})"/', $expr, $cm);
                    $cc = count(array_unique($cm[1] ?? []));
                    $good[] = "\"{$desc}\" → {$action}. Bots excluidos, {$cc} países.";
                    if (!$has_path) $warnings[] = "Sugerencia: Excluir /robots.txt y /sitemap*.xml de \"{$desc}\".";
                } else {
                    $issues[] = "\"{$desc}\" → {$action}. SIN excepción para bots verificados. "
                        . "Googlebot recibirá {$action}. Añade 'not cf.bot_management.verified_bot'.";
                }
            } elseif (preg_match('/http\.user_agent/i', $expr) && !preg_match('/ip\.geoip/i', $expr)
                && in_array($action, ['block', 'challenge', 'js_challenge', 'managed_challenge'])
                && preg_match('/bot|crawl|spider/i', $expr)) {
                $issues[] = "\"{$desc}\" → {$action}. Bloqueo por UA con patrones genéricos.";
            }
        }

        if (!empty($issues)) {
            $detail = "PROBLEMAS:\n- " . implode("\n- ", $issues);
            if (!empty($good)) $detail .= "\n\nREGLAS OK:\n- " . implode("\n- ", $good);
            return [$this->make_check('firewall_rules', 'WAF Custom Rules', 'critical', count($rules) . ' reglas',
                $detail, 'security', 'cf_firewall_bot_exception', 'Añadir excepción bots')];
        }
        if (!empty($good)) {
            $detail = implode("\n", $good);
            if (!empty($warnings)) $detail .= "\n\n" . implode("\n", $warnings);
            return [$this->make_check('firewall_rules', 'WAF Custom Rules', empty($warnings) ? 'pass' : 'info',
                count($rules) . ' reglas', $detail)];
        }
        return [$this->make_check('firewall_rules', 'WAF Custom Rules', 'pass', count($rules) . ' reglas', 'Sin bloqueo de crawlers.')];
    }

    /* ─── Server Self-Block Detection ─── */

    /**
     * Check if firewall rules are blocking the server itself
     * This is a common misconfiguration when server is in a different country than allowed
     */
    private function check_server_self_block(array $fw): array {
        if (isset($fw['_error'])) return [];
        
        // Rulesets API: rules are in result.rules[]
        $rules = $fw['result']['rules'] ?? [];
        if (empty($rules)) return [];

        // Get server info
        $server = $this->get_server_info();
        if (!$server['ip'] || !$server['country']) {
            return [$this->make_check('server_geo', 'Servidor Geo-Block', 'info', 
                'No detectado',
                'No se pudo determinar la IP/pais del servidor. IP detectada: ' . ($server['ip'] ?? 'ninguna'))];
        }

        $server_country = $server['country'];
        $server_ip = $server['ip'];
        $country_name = $server['country_name'] ?? $server_country;

        $blocking_rules = [];
        $ua_audit = 'Replanta-Site-Audit';

        foreach ($rules as $rule) {
            $expr   = $rule['expression'] ?? '';
            $action = $rule['action'] ?? '';
            $desc   = $rule['description'] ?? 'Sin nombre';
            $paused = !($rule['enabled'] ?? true);

            if ($paused) continue;
            if (!in_array($action, ['block', 'challenge', 'js_challenge', 'managed_challenge'])) continue;

            // Check for geo-blocking rules
            if (preg_match('/ip\.geoip\.country/i', $expr)) {
                // Extract allowed countries
                preg_match_all('/"([A-Z]{2})"/', $expr, $matches);
                $countries_in_rule = array_unique($matches[1] ?? []);

                // Determine if it's a whitelist (NOT in countries = block) or blacklist (in countries = block)
                $is_whitelist = preg_match('/not\s*\(.*ip\.geoip\.country\s+in/i', $expr) 
                             || preg_match('/ip\.geoip\.country\s+in.*\)\s*$/i', $expr);

                $server_blocked = false;
                if ($is_whitelist && !in_array($server_country, $countries_in_rule)) {
                    $server_blocked = true;
                } elseif (!$is_whitelist && in_array($server_country, $countries_in_rule)) {
                    $server_blocked = true;
                }

                // Check if server IP is explicitly whitelisted
                if ($server_blocked && preg_match('/ip\.src\s+in\s*\{[^}]*' . preg_quote($server_ip) . '/i', $expr)) {
                    $server_blocked = false; // IP is whitelisted
                }

                // Check if User-Agent is excluded
                if ($server_blocked && preg_match('/http\.user_agent\s+contains\s+"' . preg_quote($ua_audit) . '"/i', $expr)) {
                    $server_blocked = false; // UA is whitelisted
                }

                if ($server_blocked) {
                    $blocking_rules[] = [
                        'name' => $desc,
                        'action' => $action,
                        'countries' => $countries_in_rule,
                    ];
                }
            }
        }

        if (!empty($blocking_rules)) {
            $rule_names = array_column($blocking_rules, 'name');
            $detail = "PROBLEMA CRITICO: Tu servidor esta en {$country_name} ({$server_country}) "
                    . "pero tus reglas de firewall solo permiten otros paises.\n\n"
                    . "IP del servidor: {$server_ip}\n"
                    . "Reglas afectadas: " . implode(', ', $rule_names) . "\n\n"
                    . "SOLUCION: Anade a tu regla de CF:\n"
                    . "- or http.user_agent contains \"Replanta-Site-Audit\"\n"
                    . "- or ip.src in {{$server_ip}}\n\n"
                    . "Esto permite que el plugin haga auditorias sin ser bloqueado.";

            return [$this->make_check(
                'server_geo_block', 
                'Servidor Auto-Bloqueado', 
                'critical',
                "{$country_name} ({$server_country})",
                $detail,
                'security',
                'cf_whitelist_server',
                'Whitelist IP servidor'
            )];
        }

        // Server is not being blocked
        return [$this->make_check(
            'server_geo', 
            'Servidor vs Geo-Block', 
            'pass',
            "{$country_name} ({$server_ip})",
            "El servidor en {$country_name} no esta siendo bloqueado por las reglas de firewall."
        )];
    }

    /* ─── DNS Records (enhanced with SPF/DKIM/DMARC) ─── */

    private function check_dns_records(array $dns): array {
        if (isset($dns['_error'])) return [$this->make_check('dns', 'DNS', 'info', '?', 'Error: ' . $dns['_error'], 'dns')];
        $recs = $dns['result'] ?? [];
        $f = ['a' => false, 'aaaa' => false, 'www' => false, 'gsc' => false, 'spf' => false, 'dmarc' => false, 'dkim' => false];
        $prx = 0;
        foreach ($recs as $r) {
            $t = $r['type'] ?? ''; $n = $r['name'] ?? ''; $c = $r['content'] ?? '';
            if ($t === 'A' && $n === RSA_DOMAIN) $f['a'] = true;
            if ($t === 'AAAA' && $n === RSA_DOMAIN) $f['aaaa'] = true;
            if ($t === 'CNAME' && $n === 'www.' . RSA_DOMAIN) $f['www'] = true;
            if ($t === 'TXT' && stripos($c, 'google-site-verification') !== false) $f['gsc'] = true;
            if ($t === 'TXT' && stripos($c, 'v=spf') !== false) $f['spf'] = true;
            if ($t === 'TXT' && strpos($n, '_dmarc') !== false) $f['dmarc'] = true;
            if ($t === 'TXT' && strpos($n, '_domainkey') !== false) $f['dkim'] = true;
            if ($r['proxied'] ?? false) $prx++;
        }
        $checks = [];
        $checks[] = $f['a']
            ? $this->make_check('dns_a', 'Registro A', 'pass', 'OK', 'Configurado.', 'dns')
            : $this->make_check('dns_a', 'Registro A', 'critical', 'Falta', 'Sin registro A.', 'dns');
        $checks[] = $f['www']
            ? $this->make_check('dns_www', 'CNAME www', 'pass', 'OK', 'OK.', 'dns')
            : $this->make_check('dns_www', 'CNAME www', 'warning', 'Falta', 'Recomendar CNAME www.', 'dns');
        $checks[] = $f['aaaa']
            ? $this->make_check('dns_ipv6', 'IPv6 (AAAA)', 'pass', 'OK', 'Soporte IPv6 activo.', 'dns')
            : $this->make_check('dns_ipv6', 'IPv6 (AAAA)', 'info', 'No', 'Sin IPv6. No crítico.', 'dns');

        $ep = array_filter(['SPF' => $f['spf'], 'DKIM' => $f['dkim'], 'DMARC' => $f['dmarc']]);
        $ep_names = array_keys($ep);
        $all_email = ['SPF', 'DKIM', 'DMARC'];
        $miss_email = array_diff($all_email, $ep_names);
        if (count($ep_names) >= 2)
            $checks[] = $this->make_check('dns_email', 'Email Auth', 'pass', implode('+', $ep_names), 'Configurado.', 'dns');
        elseif (!empty($ep_names))
            $checks[] = $this->make_check('dns_email', 'Email Auth', 'warning', implode('+', $ep_names),
                'Faltan: ' . implode(', ', $miss_email) . '.', 'dns');
        else
            $checks[] = $this->make_check('dns_email', 'Email Auth', 'warning', 'Ninguno',
                'Sin SPF/DKIM/DMARC. Emails pueden ir a spam.', 'dns');

        if ($f['gsc'])
            $checks[] = $this->make_check('dns_gsc', 'TXT Verificación', 'pass', 'OK', 'GSC verificado por DNS.', 'dns');

        $checks[] = $this->make_check('dns_proxied', 'Registros Proxied', 'info', $prx . '/' . count($recs),
            "$prx registros pasan por CF proxy.", 'dns');
        return $checks;
    }

    private function check_zone_status(array $zi): array {
        if (isset($zi['_error'])) return [$this->make_check('zone_status', 'Zona CF', 'info', '?', 'No se pudo leer.', 'general')];
        $zone = $zi['result'] ?? [];
        $status = $zone['status'] ?? 'unknown';
        $paused = $zone['paused'] ?? false;
        $plan   = $zone['plan']['name'] ?? '?';
        $checks = [];
        if ($paused) $checks[] = $this->make_check('zone_paused', 'Zona Pausada', 'critical', 'PAUSADA',
            'Tráfico NO pasa por CF.', 'general');
        $checks[] = ($status === 'active')
            ? $this->make_check('zone_status', 'Estado Zona', 'pass', "Activa — $plan", 'Zona operativa.', 'general')
            : $this->make_check('zone_status', 'Estado Zona', 'warning', ucfirst($status), 'No activa.', 'general');
        return $checks;
    }

    private function check_crawler_hints(array $s): array {
        $v = $this->get_setting($s, 'crawler_hints');
        if ($v === 'on') return [$this->make_check('crawler_hints', 'Crawler Hints (IndexNow)', 'pass', 'Activado',
            'CF notifica a buscadores cuando hay cambios.', 'seo')];
        // crawler_hints may not appear in /settings for some plans — separate dashboard setting
        return [$this->make_check('crawler_hints', 'Crawler Hints (IndexNow)', 'info',
            $v === null ? 'No en API' : 'Desactivado',
            'Activa Crawler Hints en CF Dashboard → Caching → Configuration. Notifica a buscadores (IndexNow) automáticamente.', 'seo')];
    }

    /* ═════════════════════════ v2.7 NEW CHECKS ═════════════════════════ */

    /**
     * Check HSTS (HTTP Strict Transport Security) via CF zone setting
     */
    private function check_hsts(array $s): array {
        $v = $this->get_setting($s, 'security_header');
        if ($v === null) {
            return [$this->make_check('hsts', 'HSTS', 'info', '?',
                'No se pudo leer la configuración HSTS. Verifica en CF Dashboard → SSL/TLS → Edge Certificates.', 'security')];
        }

        $sts = $v['strict_transport_security'] ?? [];
        $enabled = $sts['enabled'] ?? false;
        $max_age = $sts['max_age'] ?? 0;
        $include_subs = $sts['include_subdomains'] ?? false;

        if (!$enabled) {
            return [$this->make_check('hsts', 'HSTS', 'warning', 'Desactivado',
                'HSTS no activo. Sin HSTS, navegadores no fuerzan HTTPS y son vulnerables a downgrade attacks. '
                . 'Activa HSTS con max-age ≥ 6 meses (15768000s).', 'security', 'cf_hsts', 'Activar HSTS')];
        }

        if ($max_age < 15768000) {
            return [$this->make_check('hsts', 'HSTS', 'info', 'max-age=' . $max_age,
                "HSTS activo pero max-age bajo ({$max_age}s). Recomendado ≥ 15768000 (6 meses) para HSTS preload.", 'security')];
        }

        $detail = "HSTS activo: max-age={$max_age}";
        if ($include_subs) $detail .= ', includeSubDomains';
        return [$this->make_check('hsts', 'HSTS', 'pass', 'Activo', $detail . '.', 'security')];
    }

    /**
     * Check minimum TLS version — should be at least 1.2
     */
    private function check_tls_version(array $s): array {
        $v = $this->get_setting($s, 'min_tls_version');
        if ($v === null) {
            return [$this->make_check('tls_version', 'TLS Mínimo', 'info', '?', 'No se pudo leer.', 'security')];
        }

        if ($v === '1.0' || $v === '1.1') {
            return [$this->make_check('tls_version', 'TLS Mínimo', 'warning', 'TLS ' . $v,
                "TLS {$v} es inseguro y obsoleto (CVE múltiples). Configura mínimo TLS 1.2. "
                . "PCI DSS requiere TLS 1.2+.", 'security', 'cf_tls_12', 'Subir a TLS 1.2')];
        }

        return [$this->make_check('tls_version', 'TLS Mínimo', 'pass', 'TLS ' . $v,
            "TLS mínimo {$v}. Correcto.", 'security')];
    }

    /**
     * Check if DKIM CNAME records are proxied (breaks DKIM verification)
     */
    private function check_dkim_proxy(array $dns): array {
        if (isset($dns['_error'])) return [];
        $recs = $dns['result'] ?? [];
        $proxied_dkim = [];

        foreach ($recs as $r) {
            $name    = $r['name'] ?? '';
            $type    = $r['type'] ?? '';
            $proxied = $r['proxied'] ?? false;

            // DKIM records contain _domainkey in the name
            if (strpos($name, '_domainkey') !== false && $proxied) {
                $proxied_dkim[] = $name . ' (' . $type . ')';
            }
        }

        if (!empty($proxied_dkim)) {
            return [$this->make_check('dkim_proxy', 'DKIM Proxied', 'critical',
                count($proxied_dkim) . ' proxied',
                'Los registros DKIM están proxied (nube naranja): ' . implode(', ', $proxied_dkim) . '. '
                . 'Esto ROMPE la verificación DKIM porque CF intercepta las consultas DNS. '
                . 'Cambia estos registros a DNS-only (nube gris).',
                'dns')];
        }

        return [];
    }

    /**
     * Check CF Managed Headers — recommend enabling useful ones
     */
    private function check_managed_headers(array $mh): array {
        if (isset($mh['_error'])) {
            return [$this->make_check('managed_headers', 'Managed Headers', 'info', 'N/A',
                'No se pudieron leer Managed Headers.', 'performance')];
        }

        $managed  = $mh['result']['managed_request_headers'] ?? [];
        $response = $mh['result']['managed_response_headers'] ?? [];
        $all_headers = array_merge($managed, $response);

        $enabled = 0;
        $total   = count($all_headers);
        $useful_disabled = [];

        // Headers we recommend enabling
        $recommended = [
            'add_true_client_ip_headers'  => 'True-Client-IP (útil para logs de origen)',
            'add_visitor_location_headers' => 'Visitor Location (geo-IP en headers)',
        ];

        foreach ($all_headers as $h) {
            $id = $h['id'] ?? '';
            $is_enabled = $h['enabled'] ?? false;

            if ($is_enabled) {
                $enabled++;
            } elseif (isset($recommended[$id])) {
                $useful_disabled[] = $recommended[$id];
            }
        }

        if ($total === 0) {
            return [$this->make_check('managed_headers', 'Managed Headers', 'info', '0',
                'No hay Managed Headers disponibles.', 'performance')];
        }

        if ($enabled === 0 && !empty($useful_disabled)) {
            return [$this->make_check('managed_headers', 'Managed Headers', 'info',
                "{$enabled}/{$total}",
                "Ningún Managed Header activo. Recomendamos activar: " . implode(', ', $useful_disabled) 
                . ". CF Dashboard → Rules → Transform Rules → Managed Transforms.", 'performance')];
        }

        return [$this->make_check('managed_headers', 'Managed Headers', 'pass',
            "{$enabled}/{$total} activos",
            "{$enabled} de {$total} Managed Headers habilitados.", 'performance')];
    }

    /* ═════════════════════════ NEW SECURITY CHECKS ═════════════════════════ */

    /**
     * Get security analytics for the last 24 hours
     */
    private function get_security_analytics(string $zone_id): array {
        // CF Analytics API - get firewall events
        $since = date('Y-m-d\TH:i:s\Z', strtotime('-24 hours'));
        $until = date('Y-m-d\TH:i:s\Z');
        
        // Try the newer GraphQL analytics
        $query = [
            'query' => '{
                viewer {
                    zones(filter: {zoneTag: "' . $zone_id . '"}) {
                        firewallEventsAdaptiveGroups(
                            filter: {datetime_gt: "' . $since . '", datetime_lt: "' . $until . '"}
                            limit: 100
                            orderBy: [count_DESC]
                        ) {
                            count
                            dimensions {
                                action
                                ruleId
                                source
                            }
                        }
                    }
                }
            }'
        ];
        
        try {
            $result = $this->cf->api_post('/graphql', $query);
        } catch (\Throwable $e) {
            $result = new \WP_Error('cf_graphql', $e->getMessage());
        }

        if (!is_wp_error($result) && isset($result['data']['viewer']['zones'][0])) {
            return $result['data']['viewer']['zones'][0]['firewallEventsAdaptiveGroups'] ?? [];
        }

        // Fallback: try the REST API for firewall events
        $events = $this->safe_get("/zones/{$zone_id}/security/events", [
            'since'    => $since,
            'until'    => $until,
            'per_page' => 100,
        ]);

        return $events['result'] ?? [];
    }

    /**
     * Analyze security analytics to detect blocking issues
     */
    private function check_security_analytics(array $analytics): array {
        if (empty($analytics)) {
            return [$this->make_check('cf_analytics', 'Analytics Seguridad', 'info', 'No disponible',
                'No se pudieron obtener analytics de seguridad. Verifica en CF Dashboard → Security → Events.')];
        }

        $total_blocked = 0;
        $total_challenged = 0;
        $by_action = [];
        $by_source = [];

        foreach ($analytics as $event) {
            $count = $event['count'] ?? 1;
            $action = $event['dimensions']['action'] ?? $event['action'] ?? 'unknown';
            $source = $event['dimensions']['source'] ?? $event['source'] ?? 'unknown';

            $by_action[$action] = ($by_action[$action] ?? 0) + $count;
            $by_source[$source] = ($by_source[$source] ?? 0) + $count;

            if (in_array($action, ['block', 'drop'])) {
                $total_blocked += $count;
            } elseif (in_array($action, ['challenge', 'jschallenge', 'managed_challenge'])) {
                $total_challenged += $count;
            }
        }

        $checks = [];

        // High block rate is concerning
        if ($total_blocked > 100) {
            arsort($by_source);
            $top_sources = array_slice($by_source, 0, 3, true);
            $sources_str = implode(', ', array_map(fn($k, $v) => "$k: $v", array_keys($top_sources), $top_sources));
            
            $checks[] = $this->make_check('cf_blocks', 'Requests Bloqueadas (24h)', 'warning',
                number_format($total_blocked),
                "{$total_blocked} requests bloqueadas en 24h. Fuentes: {$sources_str}. "
                . "Si es tráfico legítimo, revisar reglas de firewall.",
                'cf_security_medium', 'Revisar seguridad');
        } elseif ($total_blocked > 0) {
            $checks[] = $this->make_check('cf_blocks', 'Requests Bloqueadas (24h)', 'info',
                number_format($total_blocked),
                "{$total_blocked} requests bloqueadas. Normal si son ataques.");
        }

        // High challenge rate is very concerning for user access
        if ($total_challenged > 500) {
            $checks[] = $this->make_check('cf_challenges', 'Challenges Servidos (24h)', 'critical',
                number_format($total_challenged),
                "{$total_challenged} challenges en 24h. ESTO PUEDE EXPLICAR LA CAIDA DE CLICS. "
                . "Usuarios legítimos están viendo captchas/challenges.",
                'cf_security_medium', 'Reducir seguridad');
        } elseif ($total_challenged > 50) {
            $checks[] = $this->make_check('cf_challenges', 'Challenges Servidos (24h)', 'warning',
                number_format($total_challenged),
                "{$total_challenged} challenges. Puede afectar UX si incluye usuarios legítimos.",
                'cf_security_medium', 'Verificar reglas');
        }

        // Show action breakdown
        if (!empty($by_action)) {
            arsort($by_action);
            $actions_str = implode(', ', array_map(fn($k, $v) => "$k: $v", array_keys($by_action), $by_action));
            $checks[] = $this->make_check('cf_actions', 'Acciones CF (24h)', 'info',
                count($analytics) . ' eventos',
                "Desglose: {$actions_str}");
        }

        return $checks;
    }

    /**
     * Check WAF managed rules configuration
     */
    private function check_waf_rules(array $waf): array {
        if (isset($waf['_error'])) {
            return [$this->make_check('waf', 'WAF Rules', 'info', 'N/A', 
                'WAF no disponible o sin permisos. Verifica en CF Dashboard.')];
        }

        $packages = $waf['result'] ?? [];
        if (empty($packages)) {
            return [$this->make_check('waf', 'WAF Rules', 'info', 'No configurado',
                'Sin paquetes WAF activos.')];
        }

        $active = 0;
        $issues = [];

        foreach ($packages as $pkg) {
            $status = $pkg['status'] ?? 'unknown';
            $sensitivity = $pkg['sensitivity'] ?? 'unknown';
            $mode = $pkg['action_mode'] ?? 'unknown';

            if ($status === 'active') {
                $active++;
                
                // Very high sensitivity can block legitimate traffic
                if ($sensitivity === 'high' && $mode === 'block') {
                    $issues[] = "Paquete '{$pkg['name']}' en sensibilidad ALTA + BLOCK. Puede bloquear tráfico legítimo.";
                }
            }
        }

        if (!empty($issues)) {
            return [$this->make_check('waf', 'WAF Rules', 'warning', "{$active} activos",
                implode(' ', $issues) . " Considera reducir sensibilidad.",
                'cf_security_medium', 'Revisar WAF')];
        }

        return [$this->make_check('waf', 'WAF Rules', 'pass', "{$active} activos",
            'WAF configurado correctamente.')];
    }

    /**
     * Check rate limiting rules
     */
    private function check_rate_limiting(array $rl): array {
        if (isset($rl['_error'])) {
            return [$this->make_check('rate_limit', 'Rate Limiting', 'info', 'N/A',
                'Rate limiting no disponible.')];
        }

        $rules = $rl['result'] ?? [];
        if (empty($rules)) {
            return [$this->make_check('rate_limit', 'Rate Limiting', 'info', 'Sin reglas',
                'No hay rate limiting configurado.')];
        }

        $aggressive = [];
        foreach ($rules as $rule) {
            $threshold = $rule['threshold'] ?? 100;
            $period = $rule['period'] ?? 60;
            $action = $rule['action']['mode'] ?? 'unknown';
            
            // Less than 10 req/min is very aggressive
            $rpm = ($threshold / $period) * 60;
            if ($rpm < 10 && in_array($action, ['block', 'challenge'])) {
                $aggressive[] = "'{$rule['description']}': {$threshold} req/{$period}s → {$action}";
            }
        }

        if (!empty($aggressive)) {
            return [$this->make_check('rate_limit', 'Rate Limiting', 'warning', count($rules) . ' reglas',
                'Reglas muy restrictivas: ' . implode('; ', $aggressive) .
                '. Usuarios navegando rápido pueden ser bloqueados.')];
        }

        return [$this->make_check('rate_limit', 'Rate Limiting', 'pass', count($rules) . ' reglas',
            'Rate limiting configurado.')];
    }

    /**
     * Check IP access rules (whitelist/blacklist)
     */
    private function check_ip_access_rules(array $rules): array {
        if (isset($rules['_error'])) {
            return [$this->make_check('ip_access', 'IP Access Rules', 'info', 'N/A',
                'No se pudieron leer las reglas de acceso IP.')];
        }

        $items = $rules['result'] ?? [];
        if (empty($items)) {
            return [];  // No rules is fine
        }

        $blocks = 0;
        $challenges = 0;
        $whitelists = 0;
        $country_blocks = [];

        foreach ($items as $item) {
            $mode = $item['mode'] ?? 'unknown';
            $target = $item['configuration']['target'] ?? 'unknown';
            $value = $item['configuration']['value'] ?? '';

            switch ($mode) {
                case 'block':
                    $blocks++;
                    if ($target === 'country') {
                        $country_blocks[] = $value;
                    }
                    break;
                case 'challenge':
                case 'managed_challenge':
                case 'js_challenge':
                    $challenges++;
                    if ($target === 'country') {
                        $country_blocks[] = $value . ' (challenge)';
                    }
                    break;
                case 'whitelist':
                    $whitelists++;
                    break;
            }
        }

        $checks = [];

        if (!empty($country_blocks)) {
            $checks[] = $this->make_check('ip_country_block', 'Bloqueo por País', 'warning',
                count($country_blocks) . ' países',
                "Países bloqueados/desafiados: " . implode(', ', $country_blocks) .
                ". Verifica que no incluya tu audiencia objetivo.",
                'cf_security_medium', 'Revisar bloqueos');
        }

        if ($blocks > 0 || $challenges > 0) {
            $checks[] = $this->make_check('ip_access', 'IP Access Rules', 'info',
                "{$blocks} block, {$challenges} challenge, {$whitelists} allow",
                'Reglas de acceso IP configuradas.');
        }

        return $checks;
    }

    /* ════════════════════ v2.6: CACHE PERFORMANCE CHECKS ════════════════════ */

    /**
     * Check Cloudflare Cache Rules (Ruleset API)
     * Verifies wp-admin bypass + HTML caching rules exist.
     */
    private function check_cache_rules(array $ruleset): array {
        if (isset($ruleset['_error'])) {
            return [$this->make_check('cf_cache_rules', 'CF Cache Rules', 'info', '?',
                'No se pudieron leer Cache Rules. Puede requerir plan CF Pro o token con permisos de Zone.Cache Rules.', 'cache')];
        }

        $rules = $ruleset['result']['rules'] ?? [];

        if (empty($rules)) {
            return [$this->make_check('cf_cache_rules', 'CF Cache Rules', 'critical', 'Sin reglas',
                'No hay Cache Rules configuradas. Sin ellas CF re-valida cada request al servidor, '
                . 'reduciendo el hit ratio y aumentando TTFB. LiteSpeed y CF deben coordinarse.',
                'cache', 'cf_create_cache_rules', 'Crear Cache Rules básicas')];
        }

        $has_admin_bypass = false;
        $has_cache_html   = false;
        foreach ($rules as $rule) {
            if (!($rule['enabled'] ?? true)) continue;
            $action = $rule['action'] ?? '';
            $expr   = $rule['expression'] ?? '';
            $params = $rule['action_parameters'] ?? [];
            // Bypass detectado como: accion bypass_cache (planes legacy)
            // O set_cache_settings con cache:false (Rulesets API moderno)
            $is_bypass = $action === 'bypass_cache'
                         || ($action === 'set_cache_settings' && isset($params['cache']) && $params['cache'] === false);
            if ($is_bypass && stripos($expr, 'wp-admin') !== false) {
                $has_admin_bypass = true;
            }
            if ($action === 'set_cache_settings' && ($params['cache'] ?? false) === true) {
                $has_cache_html = true;
            }
            // Regla tipo 'cache_everything' (Page Rules legacy)
            if ($action === 'cache_everything') {
                $has_cache_html = true;
            }
        }

        $issues = [];
        if (!$has_admin_bypass) $issues[] = 'wp-admin no excluido del caché';
        if (!$has_cache_html)   $issues[] = 'sin regla de caché HTML explícita';

        if (!empty($issues)) {
            return [$this->make_check('cf_cache_rules', 'CF Cache Rules', 'warning',
                count($rules) . ' reglas',
                'Cache Rules incompletas: ' . implode(', ', $issues) . '. El fix añade bypass wp-admin + caché HTML básico.',
                'cache', 'cf_create_cache_rules', 'Completar Cache Rules')];
        }

        return [$this->make_check('cf_cache_rules', 'CF Cache Rules', 'pass',
            count($rules) . ' reglas', 'Cache Rules correctamente configuradas.', 'cache')];
    }

    /**
     * Fetch cache analytics via CF GraphQL API (replaces sunset REST analytics/dashboard).
     * Returns normalized array compatible with check_cache_analytics().
     */
    private function get_cache_analytics_graphql(string $zone_id): array {
        $since = date('Y-m-d', strtotime('-7 days'));
        $until = date('Y-m-d');

        $query = '{
            viewer {
                zones(filter: {zoneTag: "' . $zone_id . '"}) {
                    httpRequests1dGroups(
                        filter: {date_geq: "' . $since . '", date_lt: "' . $until . '"}
                        limit: 7
                        orderBy: [date_ASC]
                    ) {
                        sum {
                            requests
                            cachedRequests
                            bytes
                            cachedBytes
                        }
                    }
                }
            }
        }';

        try {
            $result = $this->cf->api_post('/graphql', ['query' => $query]);
        } catch (\Throwable $e) {
            return ['_error' => $e->getMessage()];
        }

        if (is_wp_error($result)) {
            return ['_error' => $result->get_error_message()];
        }

        $zones = $result['data']['viewer']['zones'] ?? [];
        if (empty($zones) || empty($zones[0]['httpRequests1dGroups'])) {
            return ['_error' => 'Sin datos de analytics GraphQL'];
        }

        // Agregar los totales de los 7 días
        $total_requests = 0;
        $total_cached   = 0;
        $total_bytes    = 0;
        $cached_bytes   = 0;

        foreach ($zones[0]['httpRequests1dGroups'] as $day) {
            $s = $day['sum'] ?? [];
            $total_requests += (int) ($s['requests'] ?? 0);
            $total_cached   += (int) ($s['cachedRequests'] ?? 0);
            $total_bytes    += (int) ($s['bytes'] ?? 0);
            $cached_bytes   += (int) ($s['cachedBytes'] ?? 0);
        }

        return [
            'ok' => true,
            'requests'        => $total_requests,
            'cached_requests' => $total_cached,
            'bytes'           => $total_bytes,
            'cached_bytes'    => $cached_bytes,
        ];
    }

    /**
     * Check Cloudflare cache hit ratio from GraphQL Analytics API (last 7 days).
     * Returns info (no fix) — purely diagnostic.
     */
    private function check_cache_analytics(array $data): array {
        if (isset($data['_error'])) {
            return [$this->make_check('cf_cache_ratio', 'CF Cache Hit Ratio', 'info', '?',
                'Analytics no disponible: ' . $data['_error'] . '. '
                . 'Verifica el ratio en CF Dashboard → Analytics → Traffic.', 'cache')];
        }

        $all     = (int) ($data['requests'] ?? 0);
        $cached  = (int) ($data['cached_requests'] ?? 0);

        if ($all === 0) {
            return [$this->make_check('cf_cache_ratio', 'CF Cache Hit Ratio', 'info', 'Sin datos',
                'Sin datos de tráfico en los últimos 7 días.', 'cache')];
        }

        $ratio = round(($cached / $all) * 100, 1);

        if ($ratio >= 85) {
            return [$this->make_check('cf_cache_ratio', 'CF Cache Hit Ratio', 'pass', $ratio . '%',
                "Hit ratio: {$ratio}% (7 días, {$cached}/{$all} requests). CF sirve la mayoría desde caché. Excelente.", 'cache')];
        }
        if ($ratio >= 50) {
            return [$this->make_check('cf_cache_ratio', 'CF Cache Hit Ratio', 'warning', $ratio . '%',
                "Hit ratio: {$ratio}% (7 días). Debería ser >85%. Revisa Cache Rules y que LiteSpeed envíe Cache-Control: public en páginas estáticas.",
                'cache', 'cf_create_cache_rules', 'Mejorar Cache Rules')];
        }
        return [$this->make_check('cf_cache_ratio', 'CF Cache Hit Ratio', 'critical', $ratio . '%',
            "Hit ratio: {$ratio}% (7 días). CF prácticamente no cachéa. Configura Cache Rules + verifica cabeceras Cache-Control de LiteSpeed.",
            'cache', 'cf_create_cache_rules', 'Crear Cache Rules')];
    }
}
