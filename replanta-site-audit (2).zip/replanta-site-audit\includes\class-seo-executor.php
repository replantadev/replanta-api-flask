<?php
/**
 * RSA_SEO_Executor
 *
 * Applies approved SEO proposals:
 *  - meta_title / meta_desc / focus_kw  → update RankMath post meta
 *  - schema_add / schema_fix            → RSA_Schema_Audit::save_custom_schema()
 *  - interlink                          → inject <a> into post content
 *  - new_draft                          → wp_insert_post() as draft
 *
 * Backs up the previous value before each change and purges caches afterwards.
 * All writes are logged to rsa_seo_execution_log for audit / rollback.
 *
 * The daily cron hook 'rsa_seo_execute_approved' is a safety net for any
 * proposals that were approved via email but not yet executed.
 *
 * @package Replanta_Site_Audit
 * @since   3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class RSA_SEO_Executor {

	const CRON_HOOK  = 'rsa_seo_execute_approved';
	const TABLE_LOG  = 'rsa_seo_execution_log';

	/* ─────────────────────────────────────────
	 * Daily cron: safety-net runner
	 * ───────────────────────────────────────── */

	/**
	 * Processes every proposal still in 'approved' status.
	 * Called by the 'rsa_seo_execute_approved' cron hook.
	 */
	public static function run(): void {
		$approved = RSA_SEO_Proposal_Engine::get_all( 'approved', 50 );
		foreach ( $approved as $proposal ) {
			$result = self::apply( $proposal );
			RSA_SEO_Proposal_Engine::update_status(
				(int) $proposal['id'],
				$result['success'] ? 'applied' : 'failed'
			);
		}
	}

	/* ─────────────────────────────────────────
	 * Public entry point
	 * ───────────────────────────────────────── */

	/**
	 * Apply a single proposal.
	 *
	 * @param  array $proposal  Row from rsa_seo_proposals.
	 * @return array{success: bool, message: string}
	 */
	public static function apply( array $proposal ): array {
		$type    = $proposal['type']    ?? '';
		$post_id = (int) ( $proposal['post_id'] ?? 0 );

		$backup = [
			'field_key'    => $proposal['field_key']    ?? '',
			'value_before' => $proposal['value_before'] ?? '',
			'captured_at'  => current_time( 'mysql' ),
		];

		// Snapshot Elementor blob or post content/title before the change for rollback.
		if ( in_array( $type, [ 'interlink', 'h1', 'intro_text', 'body_text' ], true ) && $post_id ) {
			$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );
			if ( $el_raw ) {
				$backup['elementor_data'] = $el_raw;
			} else {
				$current_post = get_post( $post_id );
				if ( $current_post ) {
					if ( $type === 'h1' ) {
						$backup['post_title_before'] = $current_post->post_title;
					} else {
						$backup['post_content_before'] = $current_post->post_content;
					}
				}
			}
		}

		// Snapshot existing custom schema so it can be restored on rollback.
		if ( in_array( $type, [ 'schema_add', 'schema_fix' ], true ) && $post_id ) {
			$prev_schema = RSA_Schema_Audit::get_instance()->get_custom_schema( $post_id );
			if ( $prev_schema !== null ) {
				$backup['schema_before'] = $prev_schema;
			}
		}

		try {
			$result = match( $type ) {
				'meta_title'            => self::apply_meta(
					$post_id, 'rank_math_title', $proposal['value_after']
				),
				'meta_desc'             => self::apply_meta(
					$post_id, 'rank_math_description', $proposal['value_after']
				),
				'focus_kw'              => self::apply_meta(
					$post_id, 'rank_math_focus_keyword', $proposal['value_after']
				),
				'schema_add',
				'schema_fix'            => self::apply_schema( $post_id, $proposal['value_after'] ),
				'interlink'             => self::apply_interlink( $post_id, $proposal['value_after'] ),
				'h1'                    => self::apply_h1( $post_id, $proposal['value_after'] ),
				'intro_text'            => self::apply_intro_text( $post_id, $proposal['value_after'] ),
				'body_text'             => self::apply_body_text( $post_id, $proposal['value_after'] ),
				'alt_text'              => self::apply_alt_text( $post_id, $proposal['value_after'] ),
				'new_draft'             => self::create_draft( $proposal ),
				default                 => [
					'success' => false,
					'message' => "Tipo de propuesta desconocido: {$type}",
				],
			};
		} catch ( \Throwable $e ) {
			$result = [ 'success' => false, 'message' => $e->getMessage() ];
		}

		self::log_execution( (int) $proposal['id'], $type, $backup, $result );

		// Stamp applied_at on success (update_status handles status; we set the timestamp here)
		if ( $result['success'] ) {
			global $wpdb;
			$wpdb->update(
				$wpdb->prefix . RSA_SEO_Proposal_Engine::TABLE,
				[ 'applied_at' => current_time( 'mysql' ) ],
				[ 'id'         => (int) $proposal['id'] ],
				[ '%s' ],
				[ '%d' ]
			);

			// Purge caches for post-level changes
			if ( $post_id && $type !== 'new_draft' ) {
				self::purge_post_cache( $post_id );
			}

			// Schedule async Polylang propagation for meta-type changes (non-blocking)
			if (
				in_array( $type, [ 'meta_title', 'meta_desc', 'focus_kw' ], true )
				&& $post_id
				&& ! empty( $proposal['lang'] )
				&& function_exists( 'pll_get_post_translations' )
			) {
				wp_schedule_single_event(
					time() + 5,
					'rsa_propagate_meta_translation',
					[
						(int)    $proposal['id'],
						$post_id,
						(string) $proposal['lang'],
						$type,
						(string) ( $proposal['value_after'] ?? '' ),
					]
				);
			}
		}

		return $result;
	}

	/* ─────────────────────────────────────────
	 * Type handlers
	 * ───────────────────────────────────────── */

	/** RankMath meta (title / description / focus keyword). */
	private static function apply_meta( int $post_id, string $meta_key, string $value ): array {
		if ( ! $post_id ) {
			return [ 'success' => false, 'message' => 'post_id requerido para actualizar meta.' ];
		}
		update_post_meta( $post_id, $meta_key, sanitize_text_field( $value ) );
		return [ 'success' => true, 'message' => "Actualizado {$meta_key} en post #{$post_id}." ];
	}

	/** Save a JSON schema object via RSA_Schema_Audit. */
	private static function apply_schema( int $post_id, string $json_value ): array {
		if ( ! $post_id ) {
			return [ 'success' => false, 'message' => 'post_id requerido para schema.' ];
		}

		$schema = json_decode( $json_value, true );
		if ( ! is_array( $schema ) ) {
			return [ 'success' => false, 'message' => 'JSON de schema inválido.' ];
		}

		$ok = RSA_Schema_Audit::get_instance()->save_custom_schema( $post_id, $schema );
		delete_transient( 'rsa_schema_' . $post_id );

		return [
			'success' => (bool) $ok,
			'message' => $ok
				? "Schema guardado en post #{$post_id}."
				: 'Error al guardar el schema.',
		];
	}

	/**
	 * Insert an inline link into an existing post.
	 *
	 * Expected value_after JSON:
	 * {"anchor":"texto del enlace","href":"/url-destino/","insert_after":"frase del contenido"}
	 *
	 * Automatically detects Elementor pages (by the presence of _elementor_data meta) and
	 * traverses the widget tree instead of touching post_content.
	 */
	private static function apply_interlink( int $post_id, string $link_json ): array {
		if ( ! $post_id ) {
			return [ 'success' => false, 'message' => 'post_id requerido para interlink.' ];
		}

		$data = json_decode( $link_json, true );
		if (
			! is_array( $data )
			|| empty( $data['anchor'] )
			|| empty( $data['href'] )
			|| empty( $data['insert_after'] )
		) {
			return [ 'success' => false, 'message' => 'Datos de interlink incompletos (anchor/href/insert_after).' ];
		}

		// ── Elementor page ────────────────────────────────────────────────
		$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );
		if ( $el_raw ) {
			return self::apply_elementor_interlink( $post_id, $data, $el_raw );
		}

		// ── Classic post_content ──────────────────────────────────────────
		$post = get_post( $post_id );
		if ( ! $post ) {
			return [ 'success' => false, 'message' => "Post #{$post_id} no encontrado." ];
		}

		$needle = $data['insert_after'];
		if ( strpos( $post->post_content, $needle ) === false ) {
			return [ 'success' => false, 'message' => 'Texto de referencia no encontrado en el contenido.' ];
		}

		$link        = sprintf( ' <a href="%s">%s</a>', esc_url( $data['href'] ), esc_html( $data['anchor'] ) );
		$new_content = str_replace( $needle, $needle . $link, $post->post_content, $count );

		if ( ! $count ) {
			return [ 'success' => false, 'message' => 'No se pudo insertar el enlace.' ];
		}

		wp_update_post( [ 'ID' => $post_id, 'post_content' => $new_content ] );
		return [ 'success' => true, 'message' => "Interlink añadido en post #{$post_id}." ];
	}

	/**
	 * Insert a link inside Elementor's _elementor_data JSON widget tree.
	 *
	 * Searches text-editor (settings.editor) and html (settings.html_code) widgets
	 * for insert_after and appends the <a> tag right after it.
	 * The caller in apply() has already stored the original _elementor_data in the backup.
	 *
	 * @param int    $post_id   Target post.
	 * @param array  $data      Decoded link_json with anchor, href, insert_after.
	 * @param string $el_raw    Current _elementor_data JSON string.
	 */
	private static function apply_elementor_interlink( int $post_id, array $data, string $el_raw ): array {
		$elements = json_decode( $el_raw, true );

		if ( ! is_array( $elements ) || json_last_error() !== JSON_ERROR_NONE ) {
			return [ 'success' => false, 'message' => 'JSON de Elementor inválido o vacío.' ];
		}

		$needle = $data['insert_after'];
		$link   = sprintf( ' <a href="%s">%s</a>', esc_url( $data['href'] ), esc_html( $data['anchor'] ) );

		if ( ! self::traverse_elementor_insert_link( $elements, $needle, $link ) ) {
			return [
				'success' => false,
				'message' => "Texto de referencia no encontrado en widgets Elementor del post #{$post_id}. "
							. "Verifica que insert_after coincide exactamente con texto del editor.",
			];
		}

		$new_json = wp_json_encode( $elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		if ( ! $new_json ) {
			return [ 'success' => false, 'message' => 'Error al codificar JSON de Elementor.' ];
		}

		// wp_slash needed: update_post_meta internally calls wp_unslash before storing
		update_post_meta( $post_id, '_elementor_data', wp_slash( $new_json ) );

		// Force Elementor to regenerate its CSS on next page load
		delete_post_meta( $post_id, '_elementor_css' );

		return [
			'success' => true,
			'message' => "Interlink insertado en Elementor post #{$post_id} (anchor: \"{$data['anchor']}\").",
		];
	}

	/**
	 * Recursively traverse an Elementor elements array looking for the first
	 * text-editor or html widget whose content contains $needle.
	 * Replaces the first occurrence with $needle.$link.
	 *
	 * @param  array  &$elements  Elementor elements array (modified in place).
	 * @param  string  $needle    Phrase to locate (from insert_after).
	 * @param  string  $link      HTML anchor tag to append after the needle.
	 * @return bool               True if a replacement was made.
	 */
	private static function traverse_elementor_insert_link(
		array  &$elements,
		string $needle,
		string $link
	): bool {
		foreach ( $elements as &$element ) {
			// Recurse into nested sections / columns / containers
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				if ( self::traverse_elementor_insert_link( $element['elements'], $needle, $link ) ) {
					return true;
				}
			}

			if ( ( $element['elType'] ?? '' ) !== 'widget' ) {
				continue;
			}

			// Map widget type to the setting key that holds HTML content
			$content_key = match ( $element['widgetType'] ?? '' ) {
				'text-editor' => 'editor',
				'html'        => 'html_code',
				default       => null,
			};

			if ( $content_key === null ) {
				continue;
			}

			$content = $element['settings'][ $content_key ] ?? '';
			if ( strpos( $content, $needle ) === false ) {
				continue;
			}

			$count = 0;
			$element['settings'][ $content_key ] = str_replace(
				$needle,
				$needle . $link,
				$content,
				$count
			);

			if ( $count > 0 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Create a WordPress draft post.
	 *
	 * Expected value_after JSON:
	 * {"title":"Título","outline":"## H2\n...","focus_kw":"keyword","post_type":"post"}
	 */
	private static function create_draft( array $proposal ): array {
		$data = json_decode( $proposal['value_after'], true );

		if ( ! is_array( $data ) || empty( $data['title'] ) ) {
			return [ 'success' => false, 'message' => 'Datos de borrador incompletos (title requerido).' ];
		}

		$post_id = wp_insert_post( [
			'post_title'   => sanitize_text_field( $data['title'] ),
			'post_content' => wp_kses_post( $data['outline'] ?? '' ),
			'post_status'  => 'draft',
			'post_type'    => sanitize_key( $data['post_type'] ?? 'post' ),
			'meta_input'   => [
				'rank_math_focus_keyword' => sanitize_text_field( $data['focus_kw'] ?? '' ),
				'_rsa_autopilot_draft'    => '1',
			],
		], true );

		if ( is_wp_error( $post_id ) ) {
			return [ 'success' => false, 'message' => $post_id->get_error_message() ];
		}

		return [
			'success' => true,
			'message' => "Borrador creado: #{$post_id} — «" . esc_html( $data['title'] ) . '».',
		];
	}

	/**
	 * Update the H1 heading of a post.
	 *
	 * Elementor pages: finds the first heading widget with header_size=h1 and updates its title.
	 * Classic pages: updates post_title (which most themes render as H1).
	 */
	private static function apply_h1( int $post_id, string $new_h1 ): array {
		if ( ! $post_id ) {
			return [ 'success' => false, 'message' => 'post_id requerido para actualizar H1.' ];
		}

		$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );

		// ── Elementor page ──────────────────────────────────────────────
		if ( $el_raw ) {
			$elements = json_decode( $el_raw, true );
			if ( ! is_array( $elements ) || json_last_error() !== JSON_ERROR_NONE ) {
				return [ 'success' => false, 'message' => 'JSON de Elementor inválido.' ];
			}

			$modified = false;
			self::traverse_elementor_h1( $elements, sanitize_text_field( $new_h1 ), $modified );

			if ( ! $modified ) {
				return [
					'success' => false,
					'message' => "No se encontró widget H1 (heading con header_size=h1) en Elementor post #{$post_id}.",
				];
			}

			$new_json = wp_json_encode( $elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			if ( ! $new_json ) {
				return [ 'success' => false, 'message' => 'Error al codificar JSON de Elementor.' ];
			}

			update_post_meta( $post_id, '_elementor_data', wp_slash( $new_json ) );
			delete_post_meta( $post_id, '_elementor_css' );

			return [ 'success' => true, 'message' => "H1 actualizado en Elementor post #{$post_id}." ];
		}

		// ── Classic WP — H1 = post_title ────────────────────────────────
		$result = wp_update_post(
			[ 'ID' => $post_id, 'post_title' => sanitize_text_field( $new_h1 ) ],
			true
		);

		if ( is_wp_error( $result ) ) {
			return [ 'success' => false, 'message' => $result->get_error_message() ];
		}

		return [ 'success' => true, 'message' => "Título (H1) actualizado en post #{$post_id}." ];
	}

	/**
	 * Traverse Elementor elements recursively and update the first H1 heading widget found.
	 */
	private static function traverse_elementor_h1( array &$elements, string $new_h1, bool &$modified ): void {
		foreach ( $elements as &$element ) {
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				self::traverse_elementor_h1( $element['elements'], $new_h1, $modified );
				if ( $modified ) {
					return;
				}
			}

			if ( ( $element['elType'] ?? '' ) !== 'widget' ) {
				continue;
			}
			if ( ( $element['widgetType'] ?? '' ) !== 'heading' ) {
				continue;
			}
			if ( ( $element['settings']['header_size'] ?? 'h2' ) !== 'h1' ) {
				continue;
			}

			$element['settings']['title'] = $new_h1;
			$modified                     = true;
			return;
		}
	}

	/**
	 * Update the alt text of a media library attachment.
	 * post_id must be the attachment post ID (not the parent page post ID).
	 */
	private static function apply_alt_text( int $attachment_id, string $new_alt ): array {
		if ( ! $attachment_id ) {
			return [ 'success' => false, 'message' => 'attachment_id (post_id) requerido para actualizar alt text.' ];
		}

		$post = get_post( $attachment_id );
		if ( ! $post || $post->post_type !== 'attachment' ) {
			return [
				'success' => false,
				'message' => "Post #{$attachment_id} no es un adjunto (attachment). Verifica el post_id.",
			];
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $new_alt ) );

		return [
			'success' => true,
			'message' => "Alt text actualizado en imagen #{$attachment_id}: \"{$new_alt}\".",
		];
	}

	/**
	 * Update the intro (first) text-editor widget or first <p> of a post.
	 * Elementor: updates settings.editor of the first text-editor widget found.
	 * Classic WP: replaces the first <p> block in post_content.
	 */
	private static function apply_intro_text( int $post_id, string $new_text ): array {
		if ( ! $post_id ) {
			return [ 'success' => false, 'message' => 'post_id requerido para actualizar intro text.' ];
		}

		$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );

		if ( $el_raw ) {
			$elements = json_decode( $el_raw, true );
			if ( ! is_array( $elements ) || json_last_error() !== JSON_ERROR_NONE ) {
				return [ 'success' => false, 'message' => 'JSON de Elementor inválido.' ];
			}

			$current = 0;
			if ( ! self::traverse_elementor_text_widget( $elements, wp_kses_post( $new_text ), 0, $current ) ) {
				return [ 'success' => false, 'message' => "No se encontró widget text-editor en Elementor post #{$post_id}." ];
			}

			$new_json = wp_json_encode( $elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			if ( ! $new_json ) {
				return [ 'success' => false, 'message' => 'Error al codificar JSON de Elementor.' ];
			}

			update_post_meta( $post_id, '_elementor_data', wp_slash( $new_json ) );
			delete_post_meta( $post_id, '_elementor_css' );
			return [ 'success' => true, 'message' => "Intro text actualizado en Elementor post #{$post_id}." ];
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return [ 'success' => false, 'message' => "Post #{$post_id} no encontrado." ];
		}

		$new_p       = '<p>' . wp_kses_post( $new_text ) . '</p>';
		$replaced    = 0;
		$new_content = preg_replace( '/<p[^>]*>[\s\S]+?<\/p>/i', $new_p, $post->post_content, 1, $replaced );
		if ( ! $replaced ) {
			$new_content = $new_p . "\n\n" . $post->post_content;
		}

		wp_update_post( [ 'ID' => $post_id, 'post_content' => $new_content ] );
		return [ 'success' => true, 'message' => "Intro text actualizado en post #{$post_id}." ];
	}

	/**
	 * Update a specific text-editor widget by 0-based index.
	 * value_after must be JSON: {"text_index": N, "content": "new text"}.
	 * Falls back to treating value_after as plain text at index 0.
	 */
	private static function apply_body_text( int $post_id, string $json_value ): array {
		if ( ! $post_id ) {
			return [ 'success' => false, 'message' => 'post_id requerido para actualizar body text.' ];
		}

		$data       = json_decode( $json_value, true );
		$text_index = isset( $data['text_index'] ) ? (int) $data['text_index'] : 0;
		$new_text   = isset( $data['content'] )    ? (string) $data['content'] : $json_value;

		$el_raw = (string) get_post_meta( $post_id, '_elementor_data', true );

		if ( $el_raw ) {
			$elements = json_decode( $el_raw, true );
			if ( ! is_array( $elements ) || json_last_error() !== JSON_ERROR_NONE ) {
				return [ 'success' => false, 'message' => 'JSON de Elementor inválido.' ];
			}

			$current = 0;
			if ( ! self::traverse_elementor_text_widget( $elements, wp_kses_post( $new_text ), $text_index, $current ) ) {
				return [ 'success' => false, 'message' => "Widget text-editor #{$text_index} no encontrado en Elementor post #{$post_id}." ];
			}

			$new_json = wp_json_encode( $elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			if ( ! $new_json ) {
				return [ 'success' => false, 'message' => 'Error al codificar JSON de Elementor.' ];
			}

			update_post_meta( $post_id, '_elementor_data', wp_slash( $new_json ) );
			delete_post_meta( $post_id, '_elementor_css' );
			return [ 'success' => true, 'message' => "Body text #{$text_index} actualizado en Elementor post #{$post_id}." ];
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return [ 'success' => false, 'message' => "Post #{$post_id} no encontrado." ];
		}

		$new_p    = '<p>' . wp_kses_post( $new_text ) . '</p>';
		$count    = 0;
		$replaced = false;
		$new_content = preg_replace_callback(
			'/<p[^>]*>[\s\S]+?<\/p>/i',
			static function ( $match ) use ( &$count, $text_index, $new_p, &$replaced ) {
				if ( $count === $text_index ) {
					$replaced = true;
					$count++;
					return $new_p;
				}
				$count++;
				return $match[0];
			},
			$post->post_content
		);

		if ( ! $replaced ) {
			return [ 'success' => false, 'message' => "Párrafo #{$text_index} no encontrado en post #{$post_id} (contiene {$count} párrafos)." ];
		}

		wp_update_post( [ 'ID' => $post_id, 'post_content' => $new_content ] );
		return [ 'success' => true, 'message' => "Body text #{$text_index} actualizado en post #{$post_id}." ];
	}

	/**
	 * Traverse an Elementor element tree and update settings.editor of the
	 * text-editor widget at position $target_index (0-based, tree order).
	 *
	 * @param  array  &$elements      Element tree (modified in place).
	 * @param  string  $new_text      New HTML content.
	 * @param  int     $target_index  Which text-editor widget to update.
	 * @param  int    &$current_index Running counter across recursive calls.
	 * @return bool                   True when the target widget was updated.
	 */
	private static function traverse_elementor_text_widget(
		array  &$elements,
		string  $new_text,
		int     $target_index,
		int    &$current_index
	): bool {
		foreach ( $elements as &$element ) {
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				if ( self::traverse_elementor_text_widget( $element['elements'], $new_text, $target_index, $current_index ) ) {
					return true;
				}
			}

			if ( ( $element['elType'] ?? '' ) !== 'widget' ) {
				continue;
			}
			if ( ( $element['widgetType'] ?? '' ) !== 'text-editor' ) {
				continue;
			}

			if ( $current_index === $target_index ) {
				$element['settings']['editor'] = $new_text;
				$current_index++;
				return true;
			}
			$current_index++;
		}

		return false;
	}

	/* ─────────────────────────────────────────
	 * Cache purge (best-effort, non-fatal)
	 * ───────────────────────────────────────── */

	private static function purge_post_cache( int $post_id ): void {
		// LiteSpeed Cache
		if ( has_action( 'litespeed_purge_post' ) ) {
			do_action( 'litespeed_purge_post', $post_id );
		}

		// WP Super Cache
		if ( function_exists( 'wp_cache_post_change' ) ) {
			wp_cache_post_change( $post_id );
		}

		// W3 Total Cache
		if ( function_exists( 'w3tc_pgcache_flush_post' ) ) {
			w3tc_pgcache_flush_post( $post_id );
		}

		// Elementor CSS file cache (force regeneration on next page load)
		delete_post_meta( $post_id, '_elementor_css' );
		if ( did_action( 'elementor/loaded' ) ) {
			do_action( 'elementor/core/files/clear_cache' );
		}

		// Cloudflare via DR Bridge (best-effort)
		if ( class_exists( 'RSA_DR_Bridge' ) && method_exists( 'RSA_DR_Bridge', 'is_configured' ) ) {
			try {
				if ( RSA_DR_Bridge::is_configured() ) {
					$url     = get_permalink( $post_id );
					$service = RSA_DR_Bridge::get_service();
					if ( $url && $service && method_exists( $service, 'purge_url' ) ) {
						$service->purge_url( $url );
					}
				}
			} catch ( \Throwable $e ) {
				// Non-fatal: cache purge is best-effort
			}
		}
	}

	/* ─────────────────────────────────────────
	 * Execution log
	 * ───────────────────────────────────────── */

	private static function log_execution(
		int    $proposal_id,
		string $action,
		array  $backup,
		array  $result
	): void {
		global $wpdb;
		// Suppress DB errors so a missing table never corrupts the AJAX JSON response.
		$prev = $wpdb->suppress_errors( true );
		$wpdb->insert(
			$wpdb->prefix . self::TABLE_LOG,
			[
				'proposal_id' => $proposal_id,
				'action'      => $action,
				'backup_data' => wp_json_encode( $backup ),
				'result'      => wp_json_encode( $result ),
				'executed_at' => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%s', '%s' ]
		);
		$wpdb->suppress_errors( $prev );
	}

	/* ─────────────────────────────────────────
	 * Rollback
	 * ───────────────────────────────────────── */

	/**
	 * Restores the previous value for an applied meta proposal.
	 * Supports: meta_title, meta_desc, focus_kw.
	 * Marks the proposal as 'rejected' to signal the change was undone.
	 *
	 * @param  int   $proposal_id  Row ID in rsa_seo_proposals.
	 * @return array{success: bool, message: string}
	 */
	public static function rollback( int $proposal_id ): array {
		global $wpdb;
		$log_table = $wpdb->prefix . self::TABLE_LOG;

		// Find the most recent execution log entry for this proposal
		$log = $wpdb->get_row(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT * FROM `{$log_table}` WHERE proposal_id = %d ORDER BY executed_at DESC LIMIT 1",
				$proposal_id
			),
			ARRAY_A
		);

		if ( ! $log ) {
			return [ 'success' => false, 'message' => 'No hay registro de ejecución para esta propuesta.' ];
		}

		$backup = json_decode( (string) $log['backup_data'], true );
		if ( ! is_array( $backup ) || ! array_key_exists( 'value_before', $backup ) ) {
			return [ 'success' => false, 'message' => 'Sin datos de backup para revertir.' ];
		}

		$proposal = RSA_SEO_Proposal_Engine::get_by_id( $proposal_id );
		if ( ! $proposal ) {
			return [ 'success' => false, 'message' => 'Propuesta no encontrada.' ];
		}

		$post_id = (int) $proposal['post_id'];
		$type    = (string) $log['action'];

		// Helper to mark proposal as rejected after successful rollback
		$mark_rejected = static function () use ( $wpdb, $proposal_id ): void {
			$wpdb->update(
				$wpdb->prefix . RSA_SEO_Proposal_Engine::TABLE,
				[ 'status' => 'rejected', 'decided_at' => current_time( 'mysql' ) ],
				[ 'id'     => $proposal_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
		};

		// ── Content rollback: interlink / intro_text / body_text ─────────
		if ( in_array( $type, [ 'interlink', 'intro_text', 'body_text' ], true ) ) {
			if ( ! $post_id ) {
				return [ 'success' => false, 'message' => "post_id requerido para revertir {$type}." ];
			}

			if ( ! empty( $backup['elementor_data'] ) ) {
				update_post_meta( $post_id, '_elementor_data', wp_slash( (string) $backup['elementor_data'] ) );
				delete_post_meta( $post_id, '_elementor_css' );
				self::purge_post_cache( $post_id );
			} elseif ( array_key_exists( 'post_content_before', $backup ) ) {
				wp_update_post( [ 'ID' => $post_id, 'post_content' => $backup['post_content_before'] ] );
				self::purge_post_cache( $post_id );
			} else {
				return [ 'success' => false, 'message' => "Sin datos de backup para revertir {$type}." ];
			}

			$mark_rejected();
			return [ 'success' => true, 'message' => "Revertido {$type} en post #{$post_id}." ];
		}

		// ── H1 rollback (Elementor blob or classic post_title) ───────────
		if ( $type === 'h1' ) {
			if ( ! $post_id ) {
				return [ 'success' => false, 'message' => 'post_id requerido para revertir H1.' ];
			}

			if ( ! empty( $backup['elementor_data'] ) ) {
				update_post_meta( $post_id, '_elementor_data', wp_slash( (string) $backup['elementor_data'] ) );
				delete_post_meta( $post_id, '_elementor_css' );
				self::purge_post_cache( $post_id );
			} elseif ( array_key_exists( 'post_title_before', $backup ) ) {
				wp_update_post( [ 'ID' => $post_id, 'post_title' => $backup['post_title_before'] ] );
				self::purge_post_cache( $post_id );
			} else {
				return [ 'success' => false, 'message' => 'Sin datos de backup para revertir H1.' ];
			}

			$mark_rejected();
			return [ 'success' => true, 'message' => "Revertido H1 en post #{$post_id}." ];
		}

		// ── Schema rollback ───────────────────────────────────────────────
		if ( in_array( $type, [ 'schema_add', 'schema_fix' ], true ) ) {
			if ( ! $post_id ) {
				return [ 'success' => false, 'message' => 'post_id requerido para revertir schema.' ];
			}

			if ( array_key_exists( 'schema_before', $backup ) ) {
				RSA_Schema_Audit::get_instance()->save_custom_schema( $post_id, $backup['schema_before'] );
			} else {
				delete_post_meta( $post_id, RSA_Schema_Audit::META_KEY );
			}
			delete_transient( 'rsa_schema_' . $post_id );
			self::purge_post_cache( $post_id );
			$mark_rejected();
			return [ 'success' => true, 'message' => "Revertido schema en post #{$post_id}." ];
		}

		// ── Meta / alt_text rollback ──────────────────────────────────────
		$meta_key = match( $type ) {
			'meta_title' => 'rank_math_title',
			'meta_desc'  => 'rank_math_description',
			'focus_kw'   => 'rank_math_focus_keyword',
			'alt_text'   => '_wp_attachment_image_alt',
			default      => '',
		};

		if ( ! $meta_key || ! $post_id ) {
			return [
				'success' => false,
				'message' => "Rollback no disponible para tipo '{$type}'.",
			];
		}

		update_post_meta( $post_id, $meta_key, sanitize_text_field( (string) $backup['value_before'] ) );
		self::purge_post_cache( $post_id );
		$mark_rejected();

		return [
			'success' => true,
			'message' => "Revertido {$meta_key} en post #{$post_id}.",
		];
	}

	/* ─────────────────────────────────────────
	 * Polylang propagation (async cron callback)
	 * ───────────────────────────────────────── */

	/**
	 * Translates an approved meta value to all Polylang post translations.
	 *
	 * Called by the 'rsa_propagate_meta_translation' WP-Cron event (async, non-blocking).
	 * Requires both Polylang and Replanta_Auto_Translate_Translator to be active.
	 *
	 * @param int    $proposal_id  Row ID in rsa_seo_proposals — updated with propagated langs.
	 * @param int    $post_id      Source post ID (in the source language).
	 * @param string $source_lang  Polylang language slug of the source post (e.g. 'es').
	 * @param string $type         meta_title | meta_desc | focus_kw
	 * @param string $value        The value that was already applied to the source post.
	 */
	public static function propagate_meta_translation(
		int    $proposal_id,
		int    $post_id,
		string $source_lang,
		string $type,
		string $value
	): void {
		if ( ! $post_id || ! $source_lang || ! $value ) {
			return;
		}
		if ( ! function_exists( 'pll_get_post_translations' ) ) {
			return;
		}
		if ( ! class_exists( 'Replanta_Auto_Translate_Translator' ) ) {
			return;
		}

		$meta_key = match( $type ) {
			'meta_title' => 'rank_math_title',
			'meta_desc'  => 'rank_math_description',
			'focus_kw'   => 'rank_math_focus_keyword',
			default      => '',
		};
		if ( ! $meta_key ) {
			return;
		}

		$translations = pll_get_post_translations( $post_id );
		unset( $translations[ $source_lang ] );

		if ( empty( $translations ) ) {
			return;
		}

		$translator = Replanta_Auto_Translate_Translator::instance();
		$propagated = [];

		foreach ( $translations as $target_lang => $target_id ) {
			if ( ! $target_id ) {
				continue;
			}

			try {
				$translated = $translator->translate( $value, $source_lang, (string) $target_lang );
				if ( ! $translated || is_wp_error( $translated ) ) {
					continue;
				}

				update_post_meta( (int) $target_id, $meta_key, sanitize_text_field( $translated ) );
				self::purge_post_cache( (int) $target_id );
				$propagated[] = $target_lang;

			} catch ( \Throwable $e ) {
				error_log( sprintf(
					'[RSA Autopilot] Translation propagation failed for post #%d → %s: %s',
					$target_id,
					$target_lang,
					$e->getMessage()
				) );
			}
		}

		if ( ! empty( $propagated ) ) {
			global $wpdb;
			$wpdb->update(
				$wpdb->prefix . RSA_SEO_Proposal_Engine::TABLE,
				[ 'propagated_langs' => wp_json_encode( $propagated ) ],
				[ 'id'               => $proposal_id ],
				[ '%s' ],
				[ '%d' ]
			);
		}
	}
}
