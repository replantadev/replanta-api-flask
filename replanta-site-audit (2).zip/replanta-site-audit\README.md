# Replanta Site Audit

Plugin WordPress de auditoría SEO y rendimiento para replanta.net.

## Requisitos

- **Dominios Reseller** plugin activo (reutiliza su token de Cloudflare)
- PHP 8.0+
- WordPress 6.0+

## Estructura

```
replanta-site-audit/
├── replanta-site-audit.php          # Plugin principal
├── includes/
│   ├── class-cloudflare-audit.php   # 21 checks de config CF
│   ├── class-seo-audit.php          # SEO: robots, hreflang, sitemap, RankMath, Polylang
│   ├── class-performance-audit.php  # TTFB, compression, LiteSpeed, headers, PHP
│   ├── class-audit-engine.php       # Orquestador + cache + historial
│   └── class-admin-page.php         # Dashboard premium
└── assets/
    ├── css/audit-dashboard.css      # UI styling
    └── js/audit-dashboard.js        # Interacciones
```

## Módulos de Auditoría

### ☁️ Cloudflare (21 checks)
| Check | Impacto SEO |
|-------|-------------|
| Security Level | `under_attack` bloquea Googlebot |
| Bot Fight Mode / SBFM | Causa #1 de caída orgánica |
| SSL Mode | `off`/`flexible` = problemas |
| Firewall Rules | Reglas que bloquean por UA/país |
| Page Rules | Redirects 302, cache bypass |
| Rocket Loader | Puede romper JS de terceros |
| Hotlink Protection | Bloquea Google Images |
| Dev Mode | Desactiva cache |
| DNS Records | A, CNAME www, TXT verificación |
| + 12 más | Minify, Brotli, HTTP/3, Early Hints... |

### 🔎 SEO (15+ checks)
- robots.txt (Disallow: /, Sitemap, Crawl-delay)
- Sitemap XML (existencia, sub-sitemaps por idioma)
- RankMath (noindex global, post types, schema)
- Hreflang tags (ES, EN, x-default)
- Canonical URL
- Meta robots + X-Robots-Tag header
- WordPress "Discourage Search Engines"
- Open Graph tags
- Polylang config (URL format, traducciones)
- Google Search Console verification
- Google Analytics/GTM detection

### ⚡ Rendimiento (12+ checks)
- HTTP status y headers de seguridad
- HSTS, CF-Cache-Status
- LiteSpeed Cache (activo, optimizations, lazy load)
- TTFB interno
- Compresión HTTP (Brotli/Gzip)
- PHP version
- WP_DEBUG en producción
- Object Cache persistente
- Plugins activos (cantidad)
- Autoloaded options (tamaño)
- WP-Cron

## Instalación

1. Subir la carpeta `replanta-site-audit` a `wp-content/plugins/`
2. Activar en WordPress → Plugins
3. Ir a **🔍 Site Audit** en el menú de admin
4. Clic en **Ejecutar Auditoría**

## Nota sobre permisos CF

El token de Cloudflare (de Dominios Reseller) necesita permiso **Zone → Zone Settings → Read** para leer la configuración de la zona. Si solo tiene `Zone → Zone → Read`, los checks de settings devolverán "unknown".

Permisos recomendados para auditoría completa:
- Zone → Zone → Read
- Zone → Zone Settings → Read  
- Zone → DNS → Read
- Zone → Firewall Services → Read
- Zone → Page Rules → Read

## Cambio en Dominios Reseller

Se cambió `api_get()` de `private` a `public` para permitir que plugins externos puedan consultar la API de CF reutilizando el token ya configurado.
