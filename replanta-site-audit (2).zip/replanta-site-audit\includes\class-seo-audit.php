<?php
/**
 * SEO Audit Module — v2.0
 *
 * Comprueba configuración SEO on-site: robots.txt, meta tags,
 * RankMath, hreflang, canonical, indexación, structured data.
 * Ahora con auto-fix metadata y checks adicionales.
 *
 * @package Replanta_Site_Audit
 * @version 2.7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_SEO_Audit {

    private string $site_url;
    private ?array $home_html_cache = null; // Avoid re-fetching homepage

    public function __construct() {
        $this->site_url = home_url();
    }

    public function run(): array {
        // Extend execution time for this audit only — won't affect visitor requests
        // The audit is triggered via AJAX so only the admin doing the check is affected
        @set_time_limit(180);

        $checks = array_merge(
            $this->check_robots_txt(),
            $this->check_sitemap(),
            $this->check_rankmath(),
            $this->check_hreflang(),
            $this->check_canonical(),
            $this->check_canonical_cross_language(),
            $this->check_meta_robots(),
            $this->check_open_graph(),
            $this->check_polylang(),
            $this->check_indexing_api(),
            // ── NEW in v2.0 ──
            $this->check_title_tag(),
            $this->check_meta_description(),
            $this->check_structured_data(),
            $this->check_viewport(),
            $this->check_favicon(),
            $this->check_h1_tag(),
            $this->check_mixed_content(),
            // ── Bot Healer ──
            $this->check_posts_without_meta(),
            // ── Translation Sync ──
            $this->check_outdated_translations(),
            // ── NEW in v2.5 ──
            $this->check_duplicate_titles(),
            $this->check_broken_links(),
            $this->check_sitemap_pages(),
            $this->check_schema_validity(),
            // ── NEW in v2.6 ──
            $this->check_sitemap_hreflang(),
            // ── NEW in v2.7: NAP + Organization completeness + SoftwareApplication ──
            $this->check_nap_consistency(),
            $this->check_organization_sameas(),
            $this->check_organization_areaserved(),
            $this->check_software_schema_pages(),
        );

        $total  = count($checks);
        $passed = count(array_filter($checks, fn($c) => $c['status'] === 'pass'));

        return [
            'score'   => $total > 0 ? round(($passed / $total) * 100) : 0,
            'summary' => ['total' => $total, 'passed' => $passed],
            'checks'  => $checks,
        ];
    }

    /* ─────────────────────── helpers ─────────────────────── */

    private function make_check(
        string  $id,
        string  $label,
        string  $status,
        string  $value,
        string  $detail,
        ?string $fix_id    = null,
        ?string $fix_label = null
    ): array {
        $c = [
            'id' => $id, 'label' => $label, 'status' => $status,
            'value' => $value, 'detail' => $detail, 'category' => 'seo',
        ];
        if ($fix_id && in_array($status, ['warning', 'critical', 'info'], true)) {
            $c['fixable']   = true;
            $c['fix_id']    = $fix_id;
            $c['fix_label'] = $fix_label ?? 'Corregir';
        }
        return $c;
    }

    /**
     * Fetch multiple URLs in parallel using curl_multi.
     * Returns array keyed by URL => ['code'=>int, 'body'=>string] or ['error'=>string].
     * Falls back to sequential wp_remote_get if curl_multi is unavailable.
     *
     * @param string[] $urls
     * @param int      $timeout  Per-request timeout in seconds
     * @return array<string, array>
     */
    private function fetch_urls_parallel(array $urls, int $timeout = 6): array {
        if (empty($urls)) return [];

        $results = array_fill_keys($urls, ['error' => 'not_fetched']);

        if (!function_exists('curl_multi_init')) {
            // Fallback: sequential
            foreach ($urls as $url) {
                $results[$url] = $this->fetch_url($url, $timeout);
            }
            return $results;
        }

        $multi   = curl_multi_init();
        $handles = [];

        if ($multi === false) {
            // curl_multi_init failed — fall back to sequential
            foreach ($urls as $url) {
                $results[$url] = $this->fetch_url($url, $timeout);
            }
            return $results;
        }

        foreach ($urls as $url) {
            $bust = strpos($url, '?') !== false ? '&' : '?';
            $ch   = curl_init($url . $bust . '_rsa_nc=' . time());
            if ($ch === false) {
                $results[$url] = ['error' => 'curl_init failed'];
                continue;
            }
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 4,
                CURLOPT_TIMEOUT        => $timeout,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_USERAGENT      => 'Replanta-Site-Audit/2.5 (WordPress)',
                CURLOPT_HTTPHEADER     => ['Cache-Control: no-cache'],
                CURLOPT_HEADER         => false,
            ]);
            curl_multi_add_handle($multi, $ch);
            $handles[$url] = $ch;
        }

        // Execute all in parallel
        $multi_status = CURLM_OK;
        do {
            $multi_status = curl_multi_exec($multi, $active);
            if ($active) {
                curl_multi_select($multi, 0.1);
            }
        } while ($active && $multi_status === CURLM_OK);

        // If the multi loop aborted due to error, fall back sequentially for remaining URLs
        if ($multi_status !== CURLM_OK) {
            foreach ($handles as $url => $ch) {
                curl_multi_remove_handle($multi, $ch);
                curl_close($ch);
                if ($results[$url] === ['error' => 'not_fetched']) {
                    $results[$url] = $this->fetch_url($url, $timeout);
                }
            }
            curl_multi_close($multi);
            return $results;
        }

        foreach ($handles as $url => $ch) {
            $err = curl_error($ch);
            if ($err) {
                $results[$url] = ['error' => $err];
            } else {
                $results[$url] = [
                    'code' => (int) curl_getinfo($ch, CURLINFO_HTTP_CODE),
                    'body' => curl_multi_getcontent($ch) ?: '',
                ];
            }
            curl_multi_remove_handle($multi, $ch);
            // curl_close() is deprecated since PHP 8.5 (no-op since PHP 8.0)
        }

        curl_multi_close($multi);
        return $results;
    }

    /**
     * Fetch URL — tries CF first, falls back to internal bypass on 403/503.
     * Adds cache-busting headers to avoid getting stale cached content.
     */
    private function fetch_url(string $url, int $timeout = 10): array {
        // Add timestamp to bypass CDN/LiteSpeed cache
        $bust = strpos($url, '?') !== false ? '&' : '?';
        $fresh_url = $url . $bust . '_rsa_nocache=' . time();
        
        $resp = wp_remote_get($fresh_url, [
            'timeout' => $timeout, 'sslverify' => false,
            'user-agent' => 'Replanta-Site-Audit/2.0 (WordPress)',
            'redirection' => 5,
            'headers' => [
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
                'Pragma' => 'no-cache',
                'X-LiteSpeed-Purge' => '*', // LiteSpeed bypass hint
            ],
        ]);
        if (is_wp_error($resp)) {
            $internal = $this->fetch_internal($url, $timeout);
            return isset($internal['error']) ? ['error' => $resp->get_error_message()] : $internal;
        }
        $code = wp_remote_retrieve_response_code($resp);
        if (in_array($code, [403, 503], true)) {
            $internal = $this->fetch_internal($url, $timeout);
            if (!isset($internal['error']) && $internal['code'] === 200) {
                $internal['cf_blocked'] = true;
                $internal['cf_code']    = $code;
                return $internal;
            }
        }
        return ['code' => $code, 'body' => wp_remote_retrieve_body($resp), 'headers' => wp_remote_retrieve_headers($resp)];
    }

    private function fetch_internal(string $url, int $timeout = 10): array {
        $parsed = wp_parse_url($url);
        $host   = $parsed['host'] ?? RSA_DOMAIN;
        $path   = ($parsed['path'] ?? '/') . (isset($parsed['query']) ? '?' . $parsed['query'] : '');
        $resp   = wp_remote_get('http://127.0.0.1' . $path, [
            'timeout' => $timeout, 'sslverify' => false,
            'user-agent' => 'Replanta-Site-Audit/2.0 (Internal)',
            'headers' => ['Host' => $host], 'redirection' => 3,
        ]);
        if (is_wp_error($resp)) return ['error' => $resp->get_error_message()];
        return ['code' => wp_remote_retrieve_response_code($resp), 'body' => wp_remote_retrieve_body($resp),
            'headers' => wp_remote_retrieve_headers($resp)];
    }

    /** Cached homepage HTML */
    private function get_home_html(): ?string {
        if ($this->home_html_cache !== null) return $this->home_html_cache['body'] ?? null;
        $this->home_html_cache = $this->fetch_url($this->site_url);
        if (isset($this->home_html_cache['error']) || ($this->home_html_cache['code'] ?? 0) !== 200) return null;
        return $this->home_html_cache['body'] ?? null;
    }

    /* ─────────────── schema entity helpers ─────────────── */

    /**
     * Parse all JSON-LD blocks on the homepage and return a flat list of schema entities.
     * Handles both @graph arrays and top-level single-entity blocks.
     * Result is statically cached — safe to call from multiple checks.
     */
    private function get_homepage_schema_entities(): array {
        static $cache = null;
        if ($cache !== null) return $cache;

        $html = $this->get_home_html();
        if (!$html) return $cache = [];

        preg_match_all(
            '/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is',
            $html, $scripts
        );

        $entities = [];
        foreach ($scripts[1] ?? [] as $raw) {
            $data = @json_decode(trim($raw), true);
            if (!$data) continue;
            if (isset($data['@graph'])) {
                foreach ($data['@graph'] as $entity) {
                    if (isset($entity['@type'])) $entities[] = $entity;
                }
            } elseif (isset($data['@type'])) {
                $entities[] = $data;
            }
        }

        return $cache = $entities;
    }

    /**
     * Return first entity whose @type matches any of the given types.
     *
     * @param array<array<string,mixed>> $entities
     * @param string[]                   $types
     * @return array<string,mixed>|null
     */
    private function find_schema_entity(array $entities, array $types): ?array {
        foreach ($entities as $entity) {
            $t = (array)($entity['@type'] ?? []);
            foreach ($types as $type) {
                if (in_array($type, $t, true)) return $entity;
            }
        }
        return null;
    }

    /* ═══════════════════════════ CHECKS ═══════════════════════════ */

    private function check_robots_txt(): array {
        $checks = [];
        $resp = $this->fetch_url($this->site_url . '/robots.txt');
        if (isset($resp['error'])) return [$this->make_check('robots_txt', 'robots.txt', 'warning', 'Error', $resp['error'])];
        if ($resp['code'] !== 200)  return [$this->make_check('robots_txt', 'robots.txt', 'warning', 'HTTP ' . $resp['code'], 'No devuelve 200.')];
        $body = $resp['body'];

        $checks[] = preg_match('/Disallow:\s*\/\s*$/m', $body)
            ? $this->make_check('robots_disallow', 'robots.txt', 'critical', 'Disallow: /', 'Bloquea TODO el sitio.')
            : $this->make_check('robots_disallow', 'robots.txt', 'pass', 'OK', 'No bloquea el sitio.');

        $checks[] = stripos($body, 'Sitemap:') !== false
            ? $this->make_check('robots_sitemap', 'Sitemap en robots.txt', 'pass', 'Presente', 'Correcto.')
            : $this->make_check('robots_sitemap', 'Sitemap en robots.txt', 'warning', 'Ausente', 'Añade directiva Sitemap.');

        return $checks;
    }

    private function check_sitemap(): array {
        $checks = [];
        $urls = [$this->site_url . '/sitemap_index.xml', $this->site_url . '/sitemap.xml', $this->site_url . '/wp-sitemap.xml'];
        $found = false; $sitemap_url = ''; $sitemap_body = '';

        foreach ($urls as $url) {
            $r = $this->fetch_url($url, 8);
            if (!isset($r['error']) && ($r['code'] ?? 0) === 200
                && (stripos($r['body'] ?? '', '<urlset') !== false || stripos($r['body'] ?? '', '<sitemapindex') !== false)) {
                $found = true; $sitemap_url = $url; $sitemap_body = $r['body']; break;
            }
        }

        if (!$found)
            return [$this->make_check('sitemap', 'Sitemap XML', 'critical', 'No encontrado', 'Configura RankMath → Sitemap.')];

        $checks[] = $this->make_check('sitemap', 'Sitemap XML', 'pass', basename($sitemap_url), 'Sitemap: ' . $sitemap_url);

        if (stripos($sitemap_body, '<sitemapindex') !== false) {
            preg_match_all('/<loc>([^<]+)<\/loc>/', $sitemap_body, $locs);
            $subs = $locs[1] ?? [];
            $checks[] = $this->make_check('sitemap_count', 'Sub-Sitemaps', 'info', count($subs) . ' archivos', 'Sitemap index con ' . count($subs) . ' sub-sitemaps.');

            // Check for EN content
            $has_en = false;
            foreach ($subs as $loc) {
                if (preg_match('/\/en\/|[-_]en[-_.]/', strtolower($loc))) { $has_en = true; break; }
            }
            if (!$has_en) {
                foreach ($subs as $sub) {
                    $sr = $this->fetch_url($sub, 8);
                    if (!isset($sr['error']) && ($sr['code'] ?? 0) === 200 && strpos($sr['body'], '/en/') !== false) {
                        $has_en = true; break;
                    }
                }
            }
            $checks[] = $has_en
                ? $this->make_check('sitemap_en', 'Sitemap Inglés', 'pass', 'Encontrado', 'URLs EN detectadas en sitemap.')
                : $this->make_check('sitemap_en', 'Sitemap Inglés', 'warning', 'No encontrado',
                    'Sin URLs /en/ en sitemaps. Verifica RankMath + Polylang. Subs: ' . implode(', ', array_map('basename', $subs)));
        }
        return $checks;
    }

    private function check_rankmath(): array {
        $checks = [];
        if (!function_exists('rank_math') && !class_exists('RankMath'))
            return [$this->make_check('rankmath', 'RankMath SEO', 'warning', 'No detectado', '¿Tienes otro plugin SEO?')];

        $checks[] = $this->make_check('rankmath', 'RankMath SEO', 'pass', 'Activo', 'RankMath activo.');

        $rm_titles = get_option('rank-math-options-titles');
        if ($rm_titles && !empty($rm_titles['noindex']))
            $checks[] = $this->make_check('rm_noindex', 'RankMath NoIndex Global', 'critical', 'ACTIVADO', 'NoIndex global → nada se indexará.');

        $rm_general = get_option('rank-math-options-general');
        if ($rm_general && !empty($rm_general['breadcrumbs']))
            $checks[] = $this->make_check('rm_breadcrumbs', 'Breadcrumbs Schema', 'pass', 'Activo', 'Mejora SERPs.');

        return $checks;
    }

    private function check_hreflang(): array {
        $html = $this->get_home_html();
        if (!$html) return [$this->make_check('hreflang', 'Hreflang Tags', 'warning', 'Error', 'No se pudo acceder a la portada.')];

        // Try both attribute orderings
        preg_match_all('/<link[^>]*hreflang=["\']([^"\']+)["\'][^>]*href=["\']([^"\']+)["\'][^>]*\/?>/i', $html, $m1, PREG_SET_ORDER);
        preg_match_all('/<link[^>]*href=["\']([^"\']+)["\'][^>]*hreflang=["\']([^"\']+)["\'][^>]*\/?>/i', $html, $m2, PREG_SET_ORDER);
        $matches = $m1;
        foreach ($m2 as $m) $matches[] = [0 => $m[0], 1 => $m[2], 2 => $m[1]]; // swap href/hreflang

        if (empty($matches))
            return [$this->make_check('hreflang', 'Hreflang Tags', 'critical', 'No encontrados',
                'Sin hreflang en portada. FUNDAMENTAL para SEO internacional con sitio bilingüe. Verifica Polylang → Settings → URL modifications.',
                'pll_hreflang', 'Activar hreflang')];

        $langs = [];
        foreach ($matches as $m) $langs[strtolower($m[1])] = $m[2];

        $checks = [$this->make_check('hreflang', 'Hreflang Tags', 'pass', count($langs) . ' idiomas',
            'Encontrados: ' . implode(', ', array_keys($langs)))];

        if (!isset($langs['x-default']))
            $checks[] = $this->make_check('hreflang_xdefault', 'x-default hreflang', 'critical', 'Ausente',
                'Falta hreflang="x-default". Sin él Google no sabe qué URL mostrar a usuarios fuera de tus regiones objetivo (ej. usuario en EE.UU. buscando en español). '
                . 'Para LATAM+España apuntar x-default a la versión ES. Configura en Polylang → Languages → Default language.');

        if (!isset($langs['es']) && !isset($langs['es-es']))
            $checks[] = $this->make_check('hreflang_es', 'Hreflang ES', 'warning', 'Ausente', 'Sin hreflang para español.');
        if (!isset($langs['en']) && !isset($langs['en-us']) && !isset($langs['en-gb']))
            $checks[] = $this->make_check('hreflang_en', 'Hreflang EN', 'warning', 'Ausente', 'Sin hreflang para inglés.');

        return $checks;
    }

    private function check_canonical(): array {
        $html = $this->get_home_html();
        if (!$html) return [$this->make_check('canonical', 'Canonical Tag', 'warning', 'Error', 'No se pudo acceder.')];

        if (preg_match('/<link[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']+)["\'][^>]*\/?>/i', $html, $m)) {
            $canonical = $m[1];
            if (strpos($canonical, RSA_DOMAIN) !== false)
                return [$this->make_check('canonical', 'Canonical Tag', 'pass', $canonical, 'Apunta al dominio correcto.')];
            return [$this->make_check('canonical', 'Canonical Tag', 'warning', $canonical, 'Apunta a otro dominio: ' . $canonical)];
        }
        return [$this->make_check('canonical', 'Canonical Tag', 'warning', 'No encontrada',
            'Sin canonical en portada. Causa contenido duplicado.', 'rm_canonical', 'Configurar canonical')];
    }

    private function check_meta_robots(): array {
        $checks = [];
        $html = $this->get_home_html();

        if ($html) {
            if (preg_match('/<meta[^>]*name=["\']robots["\'][^>]*content=["\']([^"\']+)["\'][^>]*>/i', $html, $m)) {
                $content = strtolower($m[1]);
                if (strpos($content, 'noindex') !== false)
                    $checks[] = $this->make_check('meta_robots', 'Meta Robots', 'critical', $content, 'Portada con "noindex".');
                elseif (strpos($content, 'nofollow') !== false)
                    $checks[] = $this->make_check('meta_robots', 'Meta Robots', 'warning', $content, 'Portada con "nofollow".');
            }

            // X-Robots-Tag header
            $headers = $this->home_html_cache['headers'] ?? [];
            $xr = is_array($headers) ? ($headers['x-robots-tag'] ?? '') : ($headers['x-robots-tag'] ?? '');
            if (!empty($xr) && stripos($xr, 'noindex') !== false)
                $checks[] = $this->make_check('x_robots', 'X-Robots-Tag', 'critical', $xr, 'Servidor envía noindex por header.');
        }

        // WP setting
        $checks[] = (get_option('blog_public') == '0')
            ? $this->make_check('wp_discourage', 'Visibilidad Buscadores', 'critical', 'BLOQUEADO', '"Disuadir motores de búsqueda" activado en WP.')
            : $this->make_check('wp_discourage', 'Visibilidad Buscadores', 'pass', 'Permitido', 'WordPress permite indexación.');

        return $checks;
    }

    private function check_open_graph(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        $has_title = (bool)preg_match('/<meta[^>]*property=["\']og:title["\'][^>]*>/i', $html);
        $has_desc  = (bool)preg_match('/<meta[^>]*property=["\']og:description["\'][^>]*>/i', $html);
        $has_image = (bool)preg_match('/<meta[^>]*property=["\']og:image["\'][^>]*>/i', $html);

        $missing = [];
        if (!$has_title) $missing[] = 'og:title';
        if (!$has_desc)  $missing[] = 'og:description';
        if (!$has_image) $missing[] = 'og:image';

        if (empty($missing))
            return [$this->make_check('open_graph', 'Open Graph Tags', 'pass', 'Completo', 'Social sharing optimizado.')];

        return [$this->make_check('open_graph', 'Open Graph Tags', 'warning', 'Faltan ' . count($missing),
            'Faltan: ' . implode(', ', $missing) . '. Afecta compartir en redes.',
            'rm_opengraph', 'Activar OG en RankMath')];
    }

    private function check_polylang(): array {
        $checks = [];
        if (!function_exists('pll_languages_list'))
            return [$this->make_check('polylang', 'Polylang', 'info', 'No detectado', 'Polylang no activo.')];

        $languages = pll_languages_list(['fields' => 'slug']);
        $checks[] = $this->make_check('polylang', 'Polylang', 'pass', count($languages) . ' idiomas', 'Idiomas: ' . implode(', ', $languages));

        $options = get_option('polylang');
        if ($options) {
            $fl = $options['force_lang'] ?? 0;
            $types = [1 => 'Subdirectorio', 2 => 'Subdominio', 3 => 'Dominio'];
            if ($fl == 0)
                $checks[] = $this->make_check('pll_url', 'Polylang URL Format', 'warning', 'Sin modificar',
                    'Usa subdirectorios (/en/) para mejor SEO.', 'pll_hreflang', 'Configurar');
            else
                $checks[] = $this->make_check('pll_url', 'Polylang URL Format', 'pass', $types[$fl] ?? "Tipo $fl", 'URLs de idioma configuradas.');
        }

        $front_id = get_option('page_on_front');
        if ($front_id) {
            $translations = pll_get_post_translations($front_id);
            $missing = array_diff($languages, array_keys($translations));
            $checks[] = empty($missing)
                ? $this->make_check('pll_home', 'Traducción Home', 'pass', 'Completa', 'Home traducida a todos los idiomas.')
                : $this->make_check('pll_home', 'Traducción Home', 'warning', 'Incompleta', 'Falta traducción: ' . implode(', ', $missing));
        }
        return $checks;
    }

    private function check_indexing_api(): array {
        $checks = [];
        $html = $this->get_home_html();
        if (!$html) return [];

        // GSC verification
        $checks[] = preg_match('/<meta[^>]*name=["\']google-site-verification["\'][^>]*>/i', $html)
            ? $this->make_check('gsc_meta', 'Google Search Console', 'pass', 'Verificado', 'Meta tag GSC encontrada.')
            : $this->make_check('gsc_meta', 'Google Search Console', 'info', 'No via meta', 'Sin meta tag GSC. Puede estar por DNS.');

        // Analytics/GTM
        $checks[] = preg_match('/gtag|googletagmanager|G-[A-Z0-9]+|UA-\d+/i', $html)
            ? $this->make_check('ga', 'Google Analytics/GTM', 'pass', 'Detectado', 'Analytics/GTM activo.')
            : $this->make_check('ga', 'Google Analytics/GTM', 'info', 'No detectado', 
                'Sin Analytics ni Tag Manager. Configura en RankMath → General Settings → Analytics o instala plugin GTM.');

        return $checks;
    }

    /* ═══════════════════ NEW CHECKS v2.0 ═══════════════════ */

    private function check_title_tag(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        if (!preg_match('/<title[^>]*>([^<]+)<\/title>/i', $html, $m))
            return [$this->make_check('title_tag', 'Title Tag', 'warning', 'No encontrado', 
                'Sin <title> en portada. RankMath debería generarlo. Revisa RankMath → Titles & Meta → Homepage.')];

        $title = trim($m[1]);
        $len = mb_strlen($title);

        if ($len < 10)
            return [$this->make_check('title_tag', 'Title Tag', 'warning', "$len chars", "Título muy corto: \"{$title}\". Recomendado: 30-60 chars.")];
        if ($len > 70)
            return [$this->make_check('title_tag', 'Title Tag', 'info', "$len chars", "Título largo ({$len} chars). Google puede truncarlo. Recomendado: ≤60.")];

        return [$this->make_check('title_tag', 'Title Tag', 'pass', "$len chars", "Título: \"{$title}\"")];
    }

    private function check_meta_description(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        if (!preg_match('/<meta[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\'][^>]*>/i', $html, $m))
            return [$this->make_check('meta_desc', 'Meta Description', 'warning', 'No encontrada',
                'Sin meta description. Configura en RankMath → Titles & Meta → Homepage → Meta Description.')];

        $desc = trim($m[1]);
        $len = mb_strlen($desc);

        if ($len < 50)
            return [$this->make_check('meta_desc', 'Meta Description', 'warning', "$len chars", "Muy corta. Recomendado: 120-160 chars.")];
        if ($len > 170)
            return [$this->make_check('meta_desc', 'Meta Description', 'info', "$len chars", "Larga ($len chars). Google puede truncar. Recomendado: ≤160.")];

        return [$this->make_check('meta_desc', 'Meta Description', 'pass', "$len chars", 'Longitud correcta.')];
    }

    private function check_structured_data(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        $checks = [];

        // JSON-LD
        preg_match_all('/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', $html, $ld);
        $ld_count = count($ld[1] ?? []);

        if ($ld_count > 0) {
            $types = [];
            foreach ($ld[1] as $json_str) {
                $data = @json_decode($json_str, true);
                if ($data) {
                    if (isset($data['@type'])) $types[] = $data['@type'];
                    if (isset($data['@graph'])) {
                        foreach ($data['@graph'] as $item) {
                            if (isset($item['@type'])) $types[] = $item['@type'];
                        }
                    }
                }
            }
            $types = array_unique($types);
            $checks[] = $this->make_check('structured_data', 'Datos Estructurados', 'pass',
                $ld_count . ' JSON-LD', 'Tipos: ' . implode(', ', array_slice($types, 0, 8)));
        } else {
            $checks[] = $this->make_check('structured_data', 'Datos Estructurados', 'info', 'No encontrados',
                'Sin JSON-LD. RankMath los genera automáticamente. Revisa RankMath → Titles & Meta → Local SEO / Social.');
        }

        return $checks;
    }

    private function check_viewport(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        if (preg_match('/<meta[^>]*name=["\']viewport["\'][^>]*>/i', $html))
            return [$this->make_check('viewport', 'Viewport Meta', 'pass', 'Presente', 'Mobile-friendly.')];

        return [$this->make_check('viewport', 'Viewport Meta', 'critical', 'Ausente',
            'Sin viewport meta. Tu tema debería incluirlo en wp_head(). Problema grave de mobile.')];
    }

    private function check_favicon(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        // Check <link rel="icon"> or <link rel="shortcut icon">
        if (preg_match('/<link[^>]*rel=["\'](?:shortcut )?icon["\'][^>]*>/i', $html))
            return [$this->make_check('favicon', 'Favicon', 'pass', 'Presente', 'Favicon detectado.')];

        // Also check WP site icon
        if (get_option('site_icon'))
            return [$this->make_check('favicon', 'Favicon', 'pass', 'WP Site Icon', 'Configurado en WP Personalizar.')];

        return [$this->make_check('favicon', 'Favicon', 'info', 'No encontrado', 'Sin favicon. Afecta branding en tabs y bookmarks.')];
    }

    private function check_h1_tag(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        preg_match_all('/<h1[^>]*>(.*?)<\/h1>/is', $html, $h1s);
        $count = count($h1s[1] ?? []);

        if ($count === 0)
            return [$this->make_check('h1_tag', 'H1 Tag', 'warning', 'No encontrado', 
                'Sin H1 en portada. Añade un H1 al contenido de la página o verifica que tu tema lo incluya.')];
        if ($count === 1)
            return [$this->make_check('h1_tag', 'H1 Tag', 'pass', '1 H1', 'Un H1 encontrado. Correcto.')];

        return [$this->make_check('h1_tag', 'H1 Tag', 'info', "$count H1s",
            "Se encontraron $count etiquetas H1. Idealmente solo debería haber una.")];
    }

    private function check_mixed_content(): array {
        $html = $this->get_home_html();
        if (!$html) return [];

        // Look for http:// in src/href attributes (excluding localhost/127)
        preg_match_all('/(src|href)=["\']http:\/\/(?!localhost|127\.0\.0\.1)([^"\']+)["\']/i', $html, $m);
        $count = count($m[0] ?? []);

        if ($count === 0)
            return [$this->make_check('mixed_content', 'Mixed Content', 'pass', 'Limpio', 'Sin contenido HTTP en página HTTPS.')];

        $examples = array_slice(array_map(fn($url) => 'http://' . $url, $m[2] ?? []), 0, 3);
        return [$this->make_check('mixed_content', 'Mixed Content', 'warning', "$count recursos HTTP",
            "Se encontraron $count recursos cargados por HTTP inseguro. Ejemplos: " . implode(', ', $examples))];
    }
    private function check_outdated_translations(): array {
        if ( ! class_exists( 'RSA_Translation_Sync' ) || ! RSA_Translation_Sync::is_available() ) {
            return [];
        }

        $outdated = RSA_Translation_Sync::get_instance()->get_outdated_translations( [ 'page', 'post' ], 50 );
        $count    = count( $outdated );

        if ( $count === 0 ) {
            return [ $this->make_check(
                'outdated_translations', 'Traducciones EN', 'pass',
                'Todas actualizadas',
                'Las traducciones al ingles estan sincronizadas con el contenido en espanol.'
            ) ];
        }

        $titles = array_slice( array_column( $outdated, 'title' ), 0, 3 );
        return [ $this->make_check(
            'outdated_translations', 'Traducciones EN', 'warning',
            "$count paginas desactualizadas",
            "$count paginas en ingles estan desactualizadas respecto al espanol: " . implode( ', ', $titles ) . ( $count > 3 ? '...' : '' ) . '. El Bot puede sincronizarlas automaticamente.',
            'sync_outdated_translations',
            "Sincronizar con IA ($count paginas)"
        ) ];
    }

    /* ═══════════════════ NEW CHECKS v2.5 ═══════════════════ */

    /**
     * Detect duplicate <title> tags on individual pages AND pages with identical SEO titles.
     * Two causes: (1) theme outputs <title> AND RankMath also does → double tag in HTML.
     *             (2) Multiple posts share the exact same RankMath/SEO title → duplicate pages.
     */
    private function check_duplicate_titles(): array {
        $checks = [];

        // ── Check 1: Multiple <title> elements in homepage HTML ──
        $html = $this->get_home_html();
        if ($html) {
            preg_match_all('/<title[^>]*>([^<]*)<\/title>/i', $html, $m);
            $tag_count = count($m[0] ?? []);
            if ($tag_count > 1) {
                $checks[] = $this->make_check(
                    'dup_title_tag', 'Etiqueta <title> duplicada',
                    'critical', $tag_count . ' etiquetas',
                    "La portada tiene {$tag_count} etiquetas <title> en el HTML. Es un conflicto entre el tema y RankMath/Yoast que ambos generan el título. Solución: el tema debe usar add_theme_support('title-tag') y no imprimir <title> manualmente.",
                    'fix_theme_title_tag', 'Activar title-tag en tema'
                );
            }
        }

        // ── Check 2: Multiple pages with identical SEO title (DB query, no HTTP) ──
        $posts = get_posts([
            'post_type'      => ['post', 'page'],
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'no_found_rows'  => true,
            'fields'         => 'ids',
        ]);

        $titles_map = [];
        foreach ($posts as $post_id) {
            // RankMath stores custom title in rank_math_title; fall back to post_title
            $seo_title = get_post_meta($post_id, 'rank_math_title', true);
            if (empty($seo_title)) {
                $seo_title = get_the_title($post_id);
            }
            $key = strtolower(trim(strip_tags($seo_title)));
            if (empty($key)) continue;
            $titles_map[$key][] = $post_id;
        }

        $dup_groups = array_filter($titles_map, fn($ids) => count($ids) > 1);
        $dup_count  = array_sum(array_map(fn($ids) => count($ids) - 1, $dup_groups)); // extra copies

        if (!empty($dup_groups)) {
            $examples = array_map(
                fn($t) => '"' . mb_strimwidth($t, 0, 50, '…') . '"',
                array_slice(array_keys($dup_groups), 0, 3)
            );
            $checks[] = $this->make_check(
                'dup_title_pages', 'Títulos SEO duplicados entre páginas',
                'warning', count($dup_groups) . ' grupos',
                count($dup_groups) . ' grupos de páginas comparten el mismo título SEO (' . $dup_count . ' páginas afectadas). Ejemplos: ' . implode(', ', $examples) . '. Personaliza cada título en RankMath → Edit Post → Meta Box Title.'
            );
        }

        if (empty($checks)) {
            $checks[] = $this->make_check(
                'dup_titles', 'Títulos duplicados', 'pass', '0 duplicados',
                'Sin etiquetas <title> duplicadas en HTML ni títulos SEO repetidos entre páginas.'
            );
        }

        return $checks;
    }

    /**
     * Crawl internal links on the homepage and check which return 4XX.
     * Checks up to 25 unique internal hrefs (skips assets, anchors, query strings).
     */
    /**
     * Crawl internal links on the homepage and check which return 4XX.
     * All requests are made IN PARALLEL (curl_multi) — ~6s max regardless of link count.
     */
    private function check_broken_links(): array {
        $html = $this->get_home_html();
        if (!$html) {
            return [$this->make_check('broken_links', 'Enlaces Internos Rotos', 'info', 'Sin datos', 'No se pudo acceder a la portada para analizar enlaces.')];
        }

        $domain_pattern = preg_quote(RSA_DOMAIN, '/');
        preg_match_all(
            '/<a[^>]+href=["\']((https?:\/\/' . $domain_pattern . '|(?<!http)(?<!https)\/)[^"\'#][^"\']*)["\'][^>]*>/i',
            $html, $m
        );
        $links = array_unique($m[1] ?? []);

        $links = array_filter($links, fn($l) =>
            !preg_match('/\.(jpg|jpeg|png|gif|webp|svg|pdf|zip|css|js|woff2?|ico|xml)(\?.*)?$/i', $l)
            && strpos($l, '/wp-admin') === false
            && strpos($l, '/wp-login') === false
            && strpos($l, 'mailto:') === false
        );
        $links = array_slice(array_values($links), 0, 30);

        if (empty($links)) {
            return [$this->make_check('broken_links', 'Enlaces Internos Rotos', 'pass', '0 rotos', 'No se encontraron enlaces internos en la portada para verificar.')];
        }

        // Build absolute URL → original path map
        $url_map = [];
        foreach ($links as $link) {
            $abs = str_starts_with($link, '/') ? rtrim($this->site_url, '/') . $link : $link;
            $url_map[$abs] = $link;
        }

        // Fetch ALL in parallel — takes ~6s max regardless of link count
        $responses = $this->fetch_urls_parallel(array_keys($url_map), 6);

        $broken  = [];
        $checked = count($responses);
        foreach ($responses as $abs_url => $r) {
            $code = $r['code'] ?? 0;
            $orig = $url_map[$abs_url] ?? $abs_url;
            $path = str_starts_with($orig, '/') ? $orig : (parse_url($orig, PHP_URL_PATH) ?? $orig);
            if ($code >= 400) {
                $broken[] = $path . " ($code)";
            }
        }

        if (empty($broken)) {
            return [$this->make_check('broken_links', 'Enlaces Internos Rotos', 'pass', "0 rotos ($checked verificados)", "Se verificaron $checked enlaces internos en paralelo. Ninguno roto.")];
        }

        return [$this->make_check(
            'broken_links', 'Enlaces Internos Rotos',
            'critical', count($broken) . ' rotos de ' . $checked . ' verificados',
            'Los siguientes enlaces internos devuelven error 4XX: ' . implode(', ', array_slice($broken, 0, 5)) . (count($broken) > 5 ? '…' : '') . '. Actualiza o elimina esos enlaces en el editor de WordPress.'
        )];
    }

    /**
     * Sample URLs from the sitemap and verify they: (a) return 200, (b) are not noindex, (c) don't redirect.
     * All URL checks are made IN PARALLEL (curl_multi).
     */
    private function check_sitemap_pages(): array {
        $sample = $this->get_sitemap_sample_urls(15);

        if (empty($sample)) {
            return [$this->make_check('sitemap_pages', 'URLs en Sitemap', 'info', 'Sin sitemap', 'No se encontró sitemap para verificar las URLs incluidas.')];
        }

        // Fetch all sampled URLs in parallel — ~6s max regardless of count
        $responses = $this->fetch_urls_parallel($sample, 6);

        $errors = [];
        $ok     = 0;
        foreach ($responses as $url => $r) {
            $code = $r['code'] ?? 0;
            $path = parse_url($url, PHP_URL_PATH) ?: $url;

            if (isset($r['error'])) {
                $errors[] = $path . ' (sin respuesta)';
            } elseif ($code >= 400) {
                $errors[] = $path . " (HTTP $code)";
            } elseif ($code >= 300 && $code < 400) {
                $errors[] = $path . " (redirige $code — no debería estar en sitemap)";
            } elseif ($code === 200 && !empty($r['body'])) {
                if (preg_match('/<meta[^>]*name=["\']robots["\'][^>]*content=["\'][^"\']*noindex/i', $r['body'])) {
                    $errors[] = $path . ' (noindex — excluir del sitemap)';
                } else {
                    $ok++;
                }
            } else {
                $ok++;
            }
        }

        if (empty($errors)) {
            return [$this->make_check(
                'sitemap_pages', 'URLs en Sitemap', 'pass',
                count($sample) . ' OK',
                'Muestra de ' . count($sample) . ' URLs del sitemap verificada en paralelo. Sin errores.'
            )];
        }

        return [$this->make_check(
            'sitemap_pages', 'Páginas incorrectas en Sitemap',
            count($errors) >= 3 ? 'critical' : 'warning',
            count($errors) . ' con errores de ' . count($sample) . ' verificadas',
            'URLs del sitemap con problemas: ' . implode(', ', array_slice($errors, 0, 6)) . (count($errors) > 6 ? '…' : '') . '. Solución: en RankMath → Sitemap, excluye estas páginas o corrige su estado.',
            'sitemap_regenerate', 'Limpiar y Regenerar Sitemap'
        )];
    }

    /** Helper: get a flat list of page-URLs from the active sitemap (max $max entries). */
    private function get_sitemap_sample_urls(int $max = 15): array {
        $candidates = [
            $this->site_url . '/sitemap_index.xml',
            $this->site_url . '/sitemap.xml',
            $this->site_url . '/wp-sitemap.xml',
        ];

        foreach ($candidates as $sitemap_url) {
            $r = $this->fetch_url($sitemap_url, 8);
            if (isset($r['error']) || ($r['code'] ?? 0) !== 200) continue;
            $body = $r['body'] ?? '';

            if (stripos($body, '<sitemapindex') !== false) {
                // Index: iterate sub-sitemaps and collect page URLs
                preg_match_all('/<loc>([^<]+)<\/loc>/', $body, $idx);
                $collected = [];
                foreach (array_slice($idx[1] ?? [], 0, 4) as $sub_url) {
                    $sr = $this->fetch_url(trim($sub_url), 8);
                    if (!isset($sr['error']) && ($sr['code'] ?? 0) === 200) {
                        preg_match_all('/<loc>([^<]+)<\/loc>/', $sr['body'] ?? '', $sub_locs);
                        $collected = array_merge($collected, $sub_locs[1] ?? []);
                    }
                    if (count($collected) >= $max * 2) break;
                }
                // Sample evenly across the collected list
                if (!empty($collected)) {
                    $step = max(1, (int) floor(count($collected) / $max));
                    $result = [];
                    for ($i = 0; $i < count($collected) && count($result) < $max; $i += $step) {
                        $result[] = trim($collected[$i]);
                    }
                    return $result;
                }
            } elseif (stripos($body, '<urlset') !== false) {
                preg_match_all('/<loc>([^<]+)<\/loc>/', $body, $locs);
                $all = $locs[1] ?? [];
                $step = max(1, (int) floor(count($all) / $max));
                $result = [];
                for ($i = 0; $i < count($all) && count($result) < $max; $i += $step) {
                    $result[] = trim($all[$i]);
                }
                return $result;
            }
        }

        return [];
    }

    /**
     * Validate all JSON-LD blocks on the homepage:
     * - JSON must parse correctly
     * - Must contain @type and @context
     * - Common required fields per type (Organization, WebSite, etc.)
     */
    private function check_schema_validity(): array {        $html = $this->get_home_html();
        if (!$html) return [];

        preg_match_all(
            '/<script[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is',
            $html, $scripts
        );

        $blocks = $scripts[1] ?? [];
        if (empty($blocks)) {
            return [$this->make_check(
                'schema_valid', 'Datos Estructurados (validez)', 'info',
                'Sin JSON-LD', 'No se encontraron bloques JSON-LD. RankMath puede generarlos automáticamente.'
            )];
        }

        $invalid = [];
        $valid   = 0;

        foreach ($blocks as $i => $raw) {
            $raw = trim($raw);
            $data = json_decode($raw, true);
            $block_num = $i + 1;

            if (json_last_error() !== JSON_ERROR_NONE) {
                $invalid[] = "Bloque $block_num: JSON inválido (" . json_last_error_msg() . ')';
                continue;
            }

            // Unwrap @graph arrays
            $entities = isset($data['@graph']) ? $data['@graph'] : [$data];

            foreach ($entities as $entity) {
                $type = $entity['@type'] ?? null;

                if (!isset($entity['@context']) && !isset($data['@context'])) {
                    $invalid[] = ($type ?? "Entidad") . ': falta @context';
                    continue;
                }
                if (empty($type)) {
                    $invalid[] = "Entidad sin @type";
                    continue;
                }

                // Type-specific required fields
                $required = match (is_array($type) ? $type[0] : $type) {
                    'Organization', 'LocalBusiness' => ['name', 'url'],
                    'WebSite'                       => ['name', 'url'],
                    'WebPage', 'AboutPage'          => ['name', 'url'],
                    'Article', 'BlogPosting',
                    'NewsArticle', 'TechArticle'    => ['headline', 'author'],
                    'BreadcrumbList'                => ['itemListElement'],
                    'Product'                       => ['name', 'offers'],
                    'FAQPage'                       => ['mainEntity'],
                    'Event'                         => ['name', 'startDate', 'location'],
                    'Recipe'                        => ['name', 'recipeIngredient', 'recipeInstructions'],
                    'VideoObject'                   => ['name', 'description', 'thumbnailUrl', 'uploadDate'],
                    'HowTo'                         => ['name', 'step'],
                    'Service'                       => ['name', 'provider'],
                    'Review'                        => ['itemReviewed', 'reviewRating'],
                    'AggregateRating'               => ['ratingValue', 'reviewCount'],
                    'SoftwareApplication'           => ['name', 'applicationCategory', 'operatingSystem'],
                    'JobPosting'                    => ['title', 'hiringOrganization', 'jobLocation'],
                    default                         => [],
                };

                $missing_fields = array_filter($required, fn($f) => empty($entity[$f]));
                if (!empty($missing_fields)) {
                    $invalid[] = (is_array($type) ? $type[0] : $type) . ': falta ' . implode(', ', $missing_fields);
                } else {
                    $valid++;
                }
            }
        }

        if (empty($invalid)) {
            return [$this->make_check(
                'schema_valid', 'Datos Estructurados (validez)', 'pass',
                $valid . ' entidades válidas',
                $valid . ' entidades JSON-LD correctamente estructuradas.'
            )];
        }

        return [$this->make_check(
            'schema_valid', 'Datos Estructurados (validez)',
            'critical', count($invalid) . ' entidad(es) inválida(s)',
            'Problemas en datos estructurados: ' . implode('; ', array_slice($invalid, 0, 4)) . (count($invalid) > 4 ? '…' : '') . '. Revisa RankMath → Titles & Meta → Schema o las meta boxes de cada post.',
            'rm_schema_enable', 'Verificar configuración Schema'
        )];
    }

    private function check_posts_without_meta(): array {
        // Count published posts (post + page) without any meta description
        if (!class_exists('RSA_Bot_Healer')) {
            return [];
        }

        $post_types = ['post', 'page'];

        // Look at up to 200 posts to get a realistic count
        $posts = get_posts([
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => 200,
            'no_found_rows'  => true,
        ]);

        $without = array_filter($posts, fn($p) => empty(trim(RSA_Bot_Healer::get_post_meta_desc($p->ID))));
        $count   = count($without);
        $total   = count($posts);

        if ($count === 0) {
            return [$this->make_check(
                'posts_without_meta', 'Metas de contenido', 'pass',
                "$total/$total con meta",
                'Todos los posts y páginas tienen meta descripción. ¡Perfecto!'
            )];
        }

        $has_meta_fill = class_exists('Replanta_Meta_Fill_OpenAI_Handler');
        $fix_id    = $has_meta_fill ? 'fill_empty_metas' : null;
        $fix_label = $has_meta_fill ? "Generar con IA ($count posts)" : null;

        return [$this->make_check(
            'posts_without_meta', 'Metas de contenido', 'warning',
            "$count/$total sin meta",
            "$count posts/páginas sin meta descripción. " .
            ($has_meta_fill
                ? 'El Bot de Salud puede rellenarlas automáticamente con IA.'
                : 'Activa replanta-meta-fill para auto-rellenar con IA.'),
            $fix_id,
            $fix_label
        )];
    }

    /* ══════════════════════════ v2.6: SITEMAP HREFLANG ══════════════════════════ */

    /**
     * Verifica que el sitemap XML incluye <xhtml:link hreflang=…> para ES↔EN.
     * Requiere el plugin replanta-sitemap-hreflang.
     */
    /**
     * Verifica que cada idioma de Polylang tiene su canonical apuntando a sí mismo,
     * no al otro idioma. Un canonical cross-idioma (ES apunta a EN o viceversa)
     * hace que Google ignore el contenido alternativo y solo indexe un idioma.
     */
    private function check_canonical_cross_language(): array {
        if (!function_exists('pll_languages_list') || !function_exists('pll_home_url')) {
            return [];
        }

        $langs = pll_languages_list(['fields' => 'slug']);
        if (count($langs) < 2) {
            return [];
        }

        $issues   = [];
        $ok_langs = [];

        foreach ($langs as $lang) {
            $lang_home = pll_home_url($lang);
            if (!$lang_home) {
                continue;
            }

            $resp = wp_remote_get($lang_home, [
                'timeout'    => 8,
                'sslverify'  => false,
                'user-agent' => 'Replanta-Site-Audit/2.0 (WordPress)',
            ]);

            if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) {
                continue;
            }

            $html = wp_remote_retrieve_body($resp);

            if (!preg_match('/<link[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']+)["\'][^>]*\/?>/i', $html, $m)) {
                $issues[] = strtoupper($lang) . ': sin canonical';
                continue;
            }

            $canonical = rtrim($m[1], '/');

            // Comprobar si el canonical apunta a la URL de otro idioma
            foreach ($langs as $other_lang) {
                if ($other_lang === $lang) {
                    continue;
                }
                $other_home = pll_home_url($other_lang);
                if (!$other_home) {
                    continue;
                }
                $other_base = rtrim($other_home, '/');
                if ($canonical === $other_base || str_starts_with($canonical, $other_base . '/')) {
                    $issues[] = strtoupper($lang) . ' → canonical apunta a ' . strtoupper($other_lang) . " ({$canonical})";
                }
            }

            if (empty($issues) || !in_array(strtoupper($lang), array_map(fn($i) => substr($i, 0, 2), $issues), true)) {
                $ok_langs[] = strtoupper($lang);
            }
        }

        if (empty($issues)) {
            return [$this->make_check(
                'canonical_cross_lang', 'Canonical cross-idioma', 'pass',
                implode('+', $ok_langs) ?: 'OK',
                'Cada versión de idioma tiene su canonical correcto. Google puede indexar ambos idiomas sin conflictos.'
            )];
        }

        return [$this->make_check(
            'canonical_cross_lang', 'Canonical cross-idioma', 'critical',
            count($issues) . ' conflicto(s)',
            'Conflictos de canonical entre idiomas: ' . implode('; ', $issues) . '. '
            . 'Cuando el canonical de un idioma apunta al otro, Google ignora el contenido alternativo y solo indexa un idioma — '
            . 'pérdida directa de tráfico orgánico. Corrige en RankMath → Titles & Meta o revisa la configuración de Polylang.',
            'rm_canonical', 'Revisar canonical en RankMath'
        )];
    }

    private function check_sitemap_hreflang(): array {
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugin_file = 'replanta-sitemap-hreflang/replanta-sitemap-hreflang.php';

        // 1. Plugin no activo → crítico
        if (!is_plugin_active($plugin_file)) {
            return [$this->make_check('sitemap_hreflang', 'Hreflang en Sitemap XML', 'critical',
                'Plugin inactivo',
                'replanta-sitemap-hreflang no activo. Sin él el sitemap XML no incluye <xhtml:link> '
                . 'y Google puede indexar solo un idioma, ignorando las páginas EN o ES.',
                'activate_hreflang_plugin', 'Activar plugin hreflang')];
        }

        // 2. Plugin activo: intentar verificar que el sitemap emite xhtml:link
        $sitemap_index = home_url('/sitemap_index.xml');
        $resp = wp_remote_get($sitemap_index, ['timeout' => 10, 'sslverify' => false]);

        if (is_wp_error($resp)) {
            return [$this->make_check('sitemap_hreflang', 'Hreflang en Sitemap XML', 'pass',
                'Plugin activo', 'Plugin replanta-sitemap-hreflang activo (sitemap no verificable externamente).')];
        }

        // Buscar primera sub-sitemap de posts en el índice
        $index_body    = wp_remote_retrieve_body($resp);
        $post_sitemap  = null;
        if (preg_match('#<loc>(https?://[^<]+post[^<]*\.xml[^<]*)</loc>#i', $index_body, $m)) {
            $post_sitemap = $m[1];
        } elseif (preg_match('#<loc>(https?://[^<]+/sitemap[0-9_-]*\.xml[^<]*)</loc>#i', $index_body, $m)) {
            $post_sitemap = $m[1];
        }

        $check_url = $post_sitemap ?: $sitemap_index;
        $resp2     = ($post_sitemap)
            ? wp_remote_get($check_url, ['timeout' => 10, 'sslverify' => false])
            : ['body' => $index_body]; // reuse index body if no sub-sitemap found

        $body = is_array($resp2) ? ($resp2['body'] ?? '') : wp_remote_retrieve_body($resp2);
        if (is_wp_error($resp2)) $body = '';

        $has_xhtml_ns  = stripos($body, 'xmlns:xhtml') !== false;
        $has_xhtml_lnk = stripos($body, 'xhtml:link') !== false;

        if ($has_xhtml_ns && $has_xhtml_lnk) {
            preg_match_all('/hreflang=["\']([^"\']+)["\']/', $body, $langs);
            $unique = array_unique($langs[1] ?? []);
            sort($unique);
            return [$this->make_check('sitemap_hreflang', 'Hreflang en Sitemap XML', 'pass',
                implode(', ', $unique) ?: 'OK',
                'Sitemap XML incluye <xhtml:link hreflang>. Idiomas detectados: '
                . (implode(', ', $unique) ?: 'presentes') . '.')];
        }

        // Plugin activo pero sin xhtml:link → cache vieja
        return [$this->make_check('sitemap_hreflang', 'Hreflang en Sitemap XML', 'warning',
            'Sin xhtml:link',
            'Plugin activo pero no se detectan <xhtml:link> en el sitemap. '
            . 'Limpia la caché del sitemap: RankMath → Ajustes → Sitemap → Limpiar caché.',
            'sitemap_regenerate', 'Regenerar sitemap')];
    }

    /* ══════════════════════════ v2.7: NAP + ORGANIZATION CHECKS ══════════════════════════ */

    /**
     * Verifica que Organization.name y Organization.url en el JSON-LD coinciden
     * con el título del sitio y la home URL de WordPress (consistencia NAP).
     */
    private function check_nap_consistency(): array {
        $entities   = $this->get_homepage_schema_entities();
        $org_types  = ['Organization', 'LocalBusiness', 'Corporation', 'SoftwareOrganization', 'NGO'];
        $org        = $this->find_schema_entity($entities, $org_types);

        if (!$org) {
            return [$this->make_check(
                'nap_consistency', 'NAP — Schema vs. WordPress',
                'info', 'Sin entidad Organization',
                'No se encontró entidad Organization en el JSON-LD de la portada. '
                . 'Configura en RankMath → Titles & Meta → Knowledge Graph para habilitar esta verificación.'
            )];
        }

        $schema_name = trim($org['name'] ?? '');
        $schema_url  = rtrim($org['url'] ?? '', '/');
        $site_name   = trim(get_bloginfo('name'));
        $site_url    = rtrim(home_url(), '/');

        $issues = [];
        if ($schema_name && $site_name && strtolower($schema_name) !== strtolower($site_name)) {
            $issues[] = "Nombre: schema=\"{$schema_name}\" vs WP=\"{$site_name}\"";
        }
        if ($schema_url && $site_url && rtrim(strtolower($schema_url), '/') !== rtrim(strtolower($site_url), '/')) {
            $issues[] = "URL: schema=\"{$schema_url}\" vs home=\"{$site_url}\"";
        }

        if (empty($issues)) {
            return [$this->make_check(
                'nap_consistency', 'NAP — Schema vs. WordPress',
                'pass', 'Consistente',
                "Organization.name y Organization.url coinciden con la configuración de WordPress."
            )];
        }

        return [$this->make_check(
            'nap_consistency', 'NAP — Schema vs. WordPress',
            'warning', count($issues) . ' discrepancia(s)',
            'El schema Organization no coincide con WordPress: ' . implode('; ', $issues) . '. '
            . 'La inconsistencia NAP confunde a Google y puede afectar rankings y Knowledge Panels. '
            . 'Corrige en RankMath → Titles & Meta → Knowledge Graph.',
            'rm_schema_enable', 'Revisar Knowledge Graph'
        )];
    }

    /**
     * Verifica que el schema Organization incluye el campo sameAs con al menos
     * un perfil externo (LinkedIn, redes sociales, ficha GMB, etc.).
     */
    private function check_organization_sameas(): array {
        $entities  = $this->get_homepage_schema_entities();
        $org_types = ['Organization', 'LocalBusiness', 'Corporation', 'SoftwareOrganization'];
        $org       = $this->find_schema_entity($entities, $org_types);

        if (!$org) {
            return [$this->make_check(
                'org_sameas', 'Organization.sameAs',
                'info', 'Sin entidad Organization',
                'Añade el schema Organization en RankMath → Knowledge Graph para habilitar esta verificación.'
            )];
        }

        $sameas = $org['sameAs'] ?? null;

        if (!empty($sameas)) {
            $count    = is_array($sameas) ? count($sameas) : 1;
            $examples = is_array($sameas)
                ? implode(', ', array_slice($sameas, 0, 2))
                : (string)$sameas;
            return [$this->make_check(
                'org_sameas', 'Organization.sameAs',
                'pass', $count . ' perfil(es)',
                "sameAs incluye {$count} referencia(s): {$examples}."
            )];
        }

        return [$this->make_check(
            'org_sameas', 'Organization.sameAs',
            'warning', 'Ausente',
            'El schema Organization no incluye sameAs. '
            . 'Añade las URLs de LinkedIn, Twitter/X, GitHub y tu ficha de Google Business Profile. '
            . 'sameAs refuerza la autoridad de entidad y mejora los Knowledge Panels de Google. '
            . 'Configura en RankMath → Titles & Meta → Knowledge Graph → Social Profiles.',
            'rm_schema_enable', 'Configurar Knowledge Graph'
        )];
    }

    /**
     * Verifica que el schema Organization declara areaServed.
     * Para un negocio digital con cobertura internacional es especialmente relevante.
     */
    private function check_organization_areaserved(): array {
        $entities  = $this->get_homepage_schema_entities();
        $org_types = ['Organization', 'LocalBusiness', 'Service', 'SoftwareOrganization'];
        $org       = $this->find_schema_entity($entities, $org_types);

        if (!$org) {
            return [$this->make_check(
                'org_areaserved', 'Organization.areaServed',
                'info', 'Sin entidad Organization',
                'Añade el schema Organization en RankMath para habilitar esta verificación.'
            )];
        }

        $area = $org['areaServed'] ?? null;

        if (!empty($area)) {
            $count   = is_array($area) ? count($area) : 1;
            $display = is_array($area)
                ? implode(', ', array_slice((array)$area, 0, 5))
                : (string)$area;
            return [$this->make_check(
                'org_areaserved', 'Organization.areaServed',
                'pass', $count . ' área(s)',
                "areaServed definido: {$display}."
            )];
        }

        // Si el sitio tiene hreflang es claramente internacional → warning, si no → info
        $html           = $this->get_home_html();
        $is_intl        = $html && (bool)preg_match('/<link[^>]*hreflang=/i', $html);
        $severity       = $is_intl ? 'warning' : 'info';

        return [$this->make_check(
            'org_areaserved', 'Organization.areaServed',
            $severity, 'Ausente',
            'El schema Organization no declara areaServed. '
            . 'Para cobertura LATAM + España añade: "areaServed": ["ES","MX","AR","CO","CL","PE"]. '
            . 'Ayuda a Google a entender tu cobertura geográfica sin un perfil GMB por cada país. '
            . 'RankMath no lo genera automáticamente — añádelo en la pestaña Schema de este audit '
            . 'o mediante un JSON-LD personalizado en la home.'
        )];
    }

    /**
     * Detecta páginas cuyo título sugiere que describen software/herramientas
     * y verifica que alguna de ellas (o la home) tiene schema SoftwareApplication.
     */
    private function check_software_schema_pages(): array {
        $software_kw = ['plugin', 'software', 'herramienta', 'tool', 'app', 'dashboard',
                        'module', 'extension', 'suite', 'addon', 'módulo'];

        $posts = get_posts([
            'post_type'      => ['post', 'page'],
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'no_found_rows'  => true,
            'fields'         => 'ids',
        ]);

        if (empty($posts)) return [];

        // Identify pages whose title contains a software keyword
        $candidate_ids = [];
        foreach ($posts as $pid) {
            $title = strtolower(get_the_title($pid));
            foreach ($software_kw as $kw) {
                if (strpos($title, $kw) !== false) {
                    $candidate_ids[] = $pid;
                    break;
                }
            }
        }

        // Check homepage JSON-LD for SoftwareApplication
        $entities          = $this->get_homepage_schema_entities();
        $has_software_home = (bool)$this->find_schema_entity(
            $entities, ['SoftwareApplication', 'SoftwareSourceCode']
        );

        if (empty($candidate_ids)) {
            // No software-looking pages — only report if home has the schema
            if ($has_software_home) {
                return [$this->make_check(
                    'software_schema', 'Schema SoftwareApplication',
                    'pass', 'Presente en home',
                    'Se encontró SoftwareApplication en el JSON-LD de la portada.'
                )];
            }
            return []; // Sin contexto de software — omitir check
        }

        // Check RankMath rich snippet meta + RSA custom schema on candidate pages (DB, sin HTTP)
        $pages_with_schema = 0;
        foreach (array_slice($candidate_ids, 0, 10) as $pid) {
            if (get_post_meta($pid, 'rank_math_rich_snippet', true) === 'software') {
                $pages_with_schema++;
                continue;
            }
            $custom = get_post_meta($pid, RSA_Schema_Audit::META_KEY, true);
            if (is_array($custom)) {
                $encoded = json_encode($custom);
                $custom_str = is_string($encoded) ? $encoded : '';
            } else {
                $custom_str = (string) $custom;
            }
            if ($custom_str !== '' && stripos($custom_str, 'SoftwareApplication') !== false) {
                $pages_with_schema++;
            }
        }

        if ($has_software_home || $pages_with_schema > 0) {
            $found_in = $has_software_home
                ? 'portada'
                : $pages_with_schema . ' página(s) de producto';
            return [$this->make_check(
                'software_schema', 'Schema SoftwareApplication',
                'pass', "Detectado en {$found_in}",
                'SoftwareApplication schema presente. '
                . count($candidate_ids) . ' páginas de software detectadas, '
                . $pages_with_schema . ' con schema explícito.'
            )];
        }

        $example_titles = array_map(
            fn($pid) => '"' . mb_strimwidth(get_the_title($pid), 0, 35, '…') . '"',
            array_slice($candidate_ids, 0, 3)
        );

        return [$this->make_check(
            'software_schema', 'Schema SoftwareApplication',
            'warning', count($candidate_ids) . ' página(s) sin schema',
            'Se detectaron ' . count($candidate_ids) . ' páginas de software/herramientas ('
            . implode(', ', $example_titles) . ') sin schema SoftwareApplication. '
            . 'Google puede mostrar rich results (nombre, SO, rating) para software. '
            . 'Añade en RankMath → Edit Post → Rich Snippet → Software o usa la pestaña Schema de este audit.',
            'rm_schema_enable', 'Configurar Schema en RankMath'
        )];
    }
}
