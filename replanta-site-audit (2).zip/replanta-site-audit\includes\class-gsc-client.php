<?php
/**
 * Google Search Console Client — OAuth2 + Search Analytics API
 *
 * Gestiona el flujo OAuth2 completo y las llamadas a la API de GSC
 * para obtener datos de palabras clave, páginas y rendimiento.
 *
 * @package Replanta_Site_Audit
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RSA_GSC_Client {

	const OPTION_TOKENS      = 'rsa_gsc_tokens';
	const OPTION_CREDENTIALS = 'rsa_gsc_credentials';
	const OAUTH_STATE_OPTION = 'rsa_gsc_oauth_state';

	const AUTH_URL  = 'https://accounts.google.com/o/oauth2/v2/auth';
	const TOKEN_URL = 'https://oauth2.googleapis.com/token';
	const API_BASE  = 'https://www.googleapis.com/webmasters/v3';
	const SCOPE     = 'https://www.googleapis.com/auth/webmasters.readonly';

	private static ?RSA_GSC_Client $instance = null;

	public static function get_instance(): RSA_GSC_Client {
		return self::$instance ??= new self();
	}

	private function __construct() {
		add_action( 'admin_init', [ $this, 'handle_oauth_callback' ] );
	}

	/* ─────────── Credenciales ─────────── */

	public function get_credentials(): array {
		return get_option( self::OPTION_CREDENTIALS, [
			'client_id'     => '',
			'client_secret' => '',
		] );
	}

	public function save_credentials( string $client_id, string $client_secret ): void {
		update_option( self::OPTION_CREDENTIALS, [
			'client_id'     => sanitize_text_field( $client_id ),
			'client_secret' => sanitize_text_field( $client_secret ),
		], false );
	}

	/* ─────────── OAuth2 Flow ─────────── */

	/**
	 * Genera la URL de autorización de Google.
	 */
	public function get_auth_url(): string {
		$creds = $this->get_credentials();
		if ( empty( $creds['client_id'] ) ) {
			return '';
		}

		$state = wp_generate_password( 32, false );
		update_option( self::OAUTH_STATE_OPTION, $state, false );

		return add_query_arg( [
			'client_id'             => rawurlencode( $creds['client_id'] ),
			'redirect_uri'          => rawurlencode( $this->get_redirect_uri() ),
			'response_type'         => 'code',
			'scope'                 => rawurlencode( self::SCOPE ),
			'access_type'           => 'offline',
			'prompt'                => 'consent',
			'state'                 => rawurlencode( $state ),
		], self::AUTH_URL );
	}

	/**
	 * URI de redirección registrada en Google Cloud Console.
	 */
	public function get_redirect_uri(): string {
		return add_query_arg( [
			'page'        => 'replanta-site-audit',
			'rsa_tab'     => 'seo',
			'rsa_gsc_cb'  => '1',
		], admin_url( 'admin.php' ) );
	}

	/**
	 * Maneja el callback OAuth2. Intercepta el code y lo intercambia por tokens.
	 */
	public function handle_oauth_callback(): void {
		if ( empty( $_GET['rsa_gsc_cb'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Verificar state CSRF
		$state          = sanitize_text_field( $_GET['state'] ?? '' );
		$expected_state = get_option( self::OAUTH_STATE_OPTION, '' );
		if ( empty( $state ) || ! hash_equals( $expected_state, $state ) ) {
			add_action( 'admin_notices', static function () {
				echo '<div class="notice notice-error"><p>[RSA GSC] Error de seguridad OAuth: state inválido.</p></div>';
			} );
			return;
		}
		delete_option( self::OAUTH_STATE_OPTION );

		$code = sanitize_text_field( $_GET['code'] ?? '' );
		if ( empty( $code ) ) {
			return;
		}

		$result = $this->exchange_code( $code );

		if ( is_wp_error( $result ) ) {
			$msg = esc_html( $result->get_error_message() );
			add_action( 'admin_notices', static function () use ( $msg ) {
				echo "<div class='notice notice-error'><p>[RSA GSC] Error al obtener tokens: {$msg}</p></div>";
			} );
			return;
		}

		$this->save_tokens( $result );

		// Redirigir limpiando parámetros OAuth de la URL
		wp_safe_redirect( add_query_arg( [
			'page'    => 'replanta-site-audit',
			'rsa_tab' => 'seo',
			'gsc_ok'  => '1',
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Intercambia el authorization code por access + refresh token.
	 */
	private function exchange_code( string $code ): array|\WP_Error {
		$creds = $this->get_credentials();

		$response = wp_remote_post( self::TOKEN_URL, [
			'headers' => [ 'Content-Type' => 'application/x-www-form-urlencoded' ],
			'body'    => [
				'code'          => $code,
				'client_id'     => $creds['client_id'],
				'client_secret' => $creds['client_secret'],
				'redirect_uri'  => $this->get_redirect_uri(),
				'grant_type'    => 'authorization_code',
			],
			'timeout'   => 15,
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $body['error'] ) ) {
			return new WP_Error( 'gsc_token_error', $body['error_description'] ?? $body['error'] );
		}

		if ( empty( $body['access_token'] ) ) {
			return new WP_Error( 'gsc_no_token', 'Respuesta inesperada de Google OAuth' );
		}

		return $body;
	}

	/* ─────────── Token Storage ─────────── */

	private function save_tokens( array $tokens ): void {
		$existing = $this->get_tokens();

		// Conservar el refresh_token si Google no devuelve uno nuevo
		if ( empty( $tokens['refresh_token'] ) && ! empty( $existing['refresh_token'] ) ) {
			$tokens['refresh_token'] = $existing['refresh_token'];
		}

		$tokens['saved_at'] = time();
		update_option( self::OPTION_TOKENS, $tokens, false );
	}

	public function get_tokens(): array {
		return get_option( self::OPTION_TOKENS, [] );
	}

	public function is_connected(): bool {
		$t = $this->get_tokens();
		return ! empty( $t['access_token'] );
	}

	public function disconnect(): void {
		delete_option( self::OPTION_TOKENS );
	}

	/**
	 * Devuelve un access_token válido, refrescando si ha expirado.
	 */
	private function get_valid_access_token(): string|\WP_Error {
		$tokens = $this->get_tokens();

		if ( empty( $tokens['access_token'] ) ) {
			return new WP_Error( 'gsc_not_connected', 'Google Search Console no está conectado.' );
		}

		$expires_in  = (int) ( $tokens['expires_in'] ?? 3600 );
		$saved_at    = (int) ( $tokens['saved_at'] ?? 0 );
		$needs_refresh = ( time() - $saved_at ) >= ( $expires_in - 60 );

		if ( $needs_refresh ) {
			if ( empty( $tokens['refresh_token'] ) ) {
				return new WP_Error( 'gsc_no_refresh', 'Sesión expirada. Vuelve a conectar Google Search Console.' );
			}

			$refreshed = $this->refresh_access_token( $tokens['refresh_token'] );
			if ( is_wp_error( $refreshed ) ) {
				return $refreshed;
			}

			$this->save_tokens( $refreshed );
			return $refreshed['access_token'];
		}

		return $tokens['access_token'];
	}

	private function refresh_access_token( string $refresh_token ): array|\WP_Error {
		$creds = $this->get_credentials();

		$response = wp_remote_post( self::TOKEN_URL, [
			'headers' => [ 'Content-Type' => 'application/x-www-form-urlencoded' ],
			'body'    => [
				'refresh_token' => $refresh_token,
				'client_id'     => $creds['client_id'],
				'client_secret' => $creds['client_secret'],
				'grant_type'    => 'refresh_token',
			],
			'timeout'   => 15,
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $body['error'] ) ) {
			return new WP_Error( 'gsc_refresh_error', $body['error_description'] ?? $body['error'] );
		}

		return $body;
	}

	/* ─────────── API Calls ─────────── */

	/**
	 * Lista las propiedades/sitios disponibles en la cuenta.
	 *
	 * @return array|\WP_Error
	 */
	public function list_sites(): array|\WP_Error {
		$token = $this->get_valid_access_token();
		if ( is_wp_error( $token ) ) return $token;

		$response = wp_remote_get( self::API_BASE . '/sites', [
			'headers' => [ 'Authorization' => 'Bearer ' . $token ],
			'timeout' => 15,
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) return $response;

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		return $body['siteEntry'] ?? [];
	}

	/**
	 * Obtiene datos de Search Analytics para un rango de fechas.
	 *
	 * @param string $site_url  URL de la propiedad (ej: "sc-domain:replanta.net")
	 * @param string $start_date Formato YYYY-MM-DD
	 * @param string $end_date   Formato YYYY-MM-DD
	 * @param array  $dimensions ['query', 'page', 'country', 'device']
	 * @param int    $row_limit  Máx 25000
	 *
	 * @return array|\WP_Error
	 */
	public function search_analytics(
		string $site_url,
		string $start_date,
		string $end_date,
		array  $dimensions = [ 'query' ],
		int    $row_limit  = 1000
	): array|\WP_Error {

		$token = $this->get_valid_access_token();
		if ( is_wp_error( $token ) ) return $token;

		$body = [
			'startDate'  => $start_date,
			'endDate'    => $end_date,
			'dimensions' => $dimensions,
			'rowLimit'   => min( $row_limit, 25000 ),
		];

		$endpoint = self::API_BASE . '/sites/' . rawurlencode( $site_url ) . '/searchAnalytics/query';

		$response = wp_remote_post( $endpoint, [
			'headers' => [
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			],
			'body'      => wp_json_encode( $body ),
			'timeout'   => 30,
			'sslverify' => true,
		] );

		if ( is_wp_error( $response ) ) return $response;

		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $decoded['error'] ) ) {
			return new WP_Error( 'gsc_api_error', $decoded['error']['message'] ?? 'Error GSC API' );
		}

		return $decoded['rows'] ?? [];
	}

	/**
	 * Obtiene oportunidades rápidas: queries en posiciones 8-20
	 * con impresiones decentes en los últimos 90 días.
	 *
	 * @param string $site_url
	 * @param int    $min_impressions Filtro mínimo de impresiones
	 *
	 * @return array
	 */
	public function get_quick_wins( string $site_url, int $min_impressions = 50 ): array|\WP_Error {
		$end   = gmdate( 'Y-m-d' );
		$start = gmdate( 'Y-m-d', strtotime( '-90 days' ) );

		$rows = $this->search_analytics( $site_url, $start, $end, [ 'query', 'page' ], 5000 );

		if ( is_wp_error( $rows ) ) return $rows;

		$wins = [];
		foreach ( $rows as $row ) {
			$pos = (float) ( $row['position'] ?? 100 );
			$imp = (int)   ( $row['impressions'] ?? 0 );

			if ( $pos >= 8 && $pos <= 20 && $imp >= $min_impressions ) {
				$wins[] = [
					'query'       => $row['keys'][0] ?? '',
					'page'        => $row['keys'][1] ?? '',
					'position'    => round( $pos, 1 ),
					'clicks'      => (int) ( $row['clicks'] ?? 0 ),
					'impressions' => $imp,
					'ctr'         => round( (float) ( $row['ctr'] ?? 0 ) * 100, 2 ),
				];
			}
		}

		// Ordenar por impresiones desc
		usort( $wins, fn( $a, $b ) => $b['impressions'] <=> $a['impressions'] );

		return array_slice( $wins, 0, 100 );
	}

	/**
	 * Detecta páginas con decaimiento de tráfico:
	 * páginas que tenían clicks los primeros 45d pero no en los últimos 45d.
	 *
	 * @param string $site_url
	 * @return array|\WP_Error
	 */
	public function get_decaying_pages( string $site_url ): array|\WP_Error {
		$now           = strtotime( 'today' );
		$mid_date      = gmdate( 'Y-m-d', $now - 45 * DAY_IN_SECONDS );
		$start_old     = gmdate( 'Y-m-d', $now - 90 * DAY_IN_SECONDS );
		$end_recent    = gmdate( 'Y-m-d', $now );

		$old    = $this->search_analytics( $site_url, $start_old, $mid_date, [ 'page' ], 2000 );
		$recent = $this->search_analytics( $site_url, $mid_date,  $end_recent, [ 'page' ], 2000 );

		if ( is_wp_error( $old ) )    return $old;
		if ( is_wp_error( $recent ) ) return $recent;

		$old_map    = [];
		$recent_map = [];

		foreach ( $old    as $r ) $old_map[    $r['keys'][0] ] = (int) $r['clicks'];
		foreach ( $recent as $r ) $recent_map[ $r['keys'][0] ] = (int) $r['clicks'];

		$decaying = [];
		foreach ( $old_map as $page => $old_clicks ) {
			$recent_clicks = $recent_map[ $page ] ?? 0;
			$drop_pct      = $old_clicks > 0 ? round( ( $old_clicks - $recent_clicks ) / $old_clicks * 100, 1 ) : 0;

			if ( $drop_pct >= 30 && $old_clicks >= 10 ) {
				$decaying[] = [
					'page'          => $page,
					'clicks_before' => $old_clicks,
					'clicks_after'  => $recent_clicks,
					'drop_percent'  => $drop_pct,
				];
			}
		}

		usort( $decaying, fn( $a, $b ) => $b['drop_percent'] <=> $a['drop_percent'] );

		return array_slice( $decaying, 0, 50 );
	}

	/**
	 * Resumen de rendimiento global: últimos 28 días vs 28 días anteriores.
	 *
	 * @param string $site_url
	 * @return array|\WP_Error
	 */
	public function get_performance_summary( string $site_url ): array|\WP_Error {
		$now          = strtotime( 'today' );
		$recent_start = gmdate( 'Y-m-d', $now - 28 * DAY_IN_SECONDS );
		$recent_end   = gmdate( 'Y-m-d', $now );
		$prev_start   = gmdate( 'Y-m-d', $now - 56 * DAY_IN_SECONDS );
		$prev_end     = gmdate( 'Y-m-d', $now - 28 * DAY_IN_SECONDS );

		$recent = $this->search_analytics( $site_url, $recent_start, $recent_end, [], 1 );
		$prev   = $this->search_analytics( $site_url, $prev_start,   $prev_end,   [], 1 );

		if ( is_wp_error( $recent ) ) return $recent;
		if ( is_wp_error( $prev ) )   return $prev;

		// Sin dimensiones, GSC devuelve totales en rows[0]
		$r = $recent[0] ?? [];
		$p = $prev[0]   ?? [];

		$delta = fn( $new, $old ) => $old > 0 ? round( ( $new - $old ) / $old * 100, 1 ) : 0;

		return [
			'recent' => [
				'clicks'      => (int) ( $r['clicks']      ?? 0 ),
				'impressions' => (int) ( $r['impressions'] ?? 0 ),
				'ctr'         => round( (float) ( $r['ctr']      ?? 0 ) * 100, 2 ),
				'position'    => round( (float) ( $r['position'] ?? 0 ), 1 ),
			],
			'prev' => [
				'clicks'      => (int) ( $p['clicks']      ?? 0 ),
				'impressions' => (int) ( $p['impressions'] ?? 0 ),
				'ctr'         => round( (float) ( $p['ctr']      ?? 0 ) * 100, 2 ),
				'position'    => round( (float) ( $p['position'] ?? 0 ), 1 ),
			],
			'delta' => [
				'clicks'      => $delta( $r['clicks'] ?? 0,      $p['clicks']      ?? 0 ),
				'impressions' => $delta( $r['impressions'] ?? 0, $p['impressions'] ?? 0 ),
				'position'    => $delta( $r['position'] ?? 0,    $p['position']    ?? 0 ),
			],
		];
	}
}
