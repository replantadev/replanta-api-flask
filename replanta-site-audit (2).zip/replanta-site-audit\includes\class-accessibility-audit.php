<?php
/**
 * Accessibility Audit Module — v2.1.0
 *
 * Diagnóstico de accesibilidad del sitio desde diferentes perspectivas:
 * - Acceso como usuario normal
 * - Acceso como Googlebot
 * - Verificación de challenges CF
 * - Detección de bloqueos
 *
 * @package Replanta_Site_Audit
 * @version 2.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class RSA_Accessibility_Audit {

    private string $site_url;
    private string $domain;

    public function __construct() {
        $this->site_url = home_url();
        $this->domain = RSA_DOMAIN;
    }

    public function run(): array {
        $checks = array_merge(
            $this->check_external_access(),
            $this->check_googlebot_access(),
            $this->check_mobile_access(),
            $this->check_cf_challenge_detection(),
            $this->check_response_time(),
            $this->check_redirect_chain(),
            $this->check_blocked_resources()
        );

        $total  = count($checks);
        $passed = count(array_filter($checks, fn($c) => $c['status'] === 'pass'));
        $critical = count(array_filter($checks, fn($c) => $c['status'] === 'critical'));

        return [
            'score'   => $total > 0 ? round(($passed / $total) * 100) : 0,
            'summary' => ['total' => $total, 'passed' => $passed, 'critical' => $critical],
            'checks'  => $checks,
        ];
    }

    /* ─────────────────────── helpers ─────────────────────── */

    private function make_check(
        string  $id,
        string  $label,
        string  $status,
        string  $value,
        string  $detail,
        ?string $fix_id    = null,
        ?string $fix_label = null
    ): array {
        $c = [
            'id' => $id, 'label' => $label, 'status' => $status,
            'value' => $value, 'detail' => $detail, 'category' => 'accessibility',
        ];
        if ($fix_id && in_array($status, ['warning', 'critical'], true)) {
            $c['fixable']   = true;
            $c['fix_id']    = $fix_id;
            $c['fix_label'] = $fix_label ?? 'Corregir';
        }
        return $c;
    }

    /**
     * Get server IP and country for diagnostics
     */
    private function get_server_info(): array {
        static $cache = null;
        if ($cache !== null) return $cache;

        $info = ['ip' => null, 'country' => null, 'country_name' => null];

        // Get server IP via ipify
        $resp = wp_remote_get('https://api.ipify.org?format=json', [
            'timeout' => 5, 'sslverify' => true
        ]);
        if (!is_wp_error($resp)) {
            $body = json_decode(wp_remote_retrieve_body($resp), true);
            if (!empty($body['ip'])) {
                $info['ip'] = $body['ip'];
                
                // Get geolocation (HTTP endpoint — no SSL needed)
                $geo = wp_remote_get("http://ip-api.com/json/{$info['ip']}?fields=country,countryCode", [
                    'timeout' => 5
                ]);
                if (!is_wp_error($geo)) {
                    $geo_data = json_decode(wp_remote_retrieve_body($geo), true);
                    $info['country'] = $geo_data['countryCode'] ?? null;
                    $info['country_name'] = $geo_data['country'] ?? null;
                }
            }
        }

        $cache = $info;
        return $info;
    }

    /**
     * Test URL with specific user-agent and detect challenges
     */
    private function test_access(string $url, string $user_agent, array $extra_headers = []): array {
        $headers = array_merge([
            'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language' => 'es-ES,es;q=0.9,en;q=0.8',
            'Cache-Control' => 'no-cache',
        ], $extra_headers);

        $start = microtime(true);
        $resp = wp_remote_get($url . '?_t=' . time(), [
            'timeout' => 15,
            'sslverify' => false,
            'user-agent' => $user_agent,
            'headers' => $headers,
            'redirection' => 5,
        ]);
        $time = round((microtime(true) - $start) * 1000);

        if (is_wp_error($resp)) {
            return [
                'success' => false,
                'error' => $resp->get_error_message(),
                'time' => $time,
            ];
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        $headers_resp = wp_remote_retrieve_headers($resp);

        // Detect CF challenge
        $is_challenge = false;
        $challenge_type = null;

        if ($code === 403) {
            $is_challenge = true;
            $challenge_type = 'blocked';
        } elseif ($code === 503 && strpos($body, 'cf-browser-verification') !== false) {
            $is_challenge = true;
            $challenge_type = 'js_challenge';
        } elseif (strpos($body, 'cf-challenge') !== false || strpos($body, 'cf_chl') !== false) {
            $is_challenge = true;
            $challenge_type = 'managed_challenge';
        } elseif (strpos($body, 'hCaptcha') !== false || strpos($body, 'g-recaptcha') !== false) {
            $is_challenge = true;
            $challenge_type = 'captcha';
        } elseif (preg_match('/challenge-platform|challenge-form/i', $body)) {
            $is_challenge = true;
            $challenge_type = 'turnstile';
        }

        // Detect if page loaded correctly
        $has_content = strlen($body) > 5000 && 
                       (strpos($body, '</html>') !== false || strpos($body, '</body>') !== false);

        return [
            'success' => $code === 200 && $has_content && !$is_challenge,
            'code' => $code,
            'time' => $time,
            'size' => strlen($body),
            'is_challenge' => $is_challenge,
            'challenge_type' => $challenge_type,
            'has_content' => $has_content,
            'cf_ray' => $headers_resp['cf-ray'] ?? null,
            'cf_cache' => $headers_resp['cf-cache-status'] ?? null,
            'server' => $headers_resp['server'] ?? null,
        ];
    }

    /* ═══════════════════════════ CHECKS ═══════════════════════════ */

    /**
     * Test access as a normal user from Spain
     */
    private function check_external_access(): array {
        $checks = [];
        
        // Simulate normal Chrome user
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
        
        $result = $this->test_access($this->site_url, $ua);

        if (!$result['success'] && $result['is_challenge']) {
            $type_messages = [
                'blocked' => 'BLOQUEADO (403). Cloudflare esta bloqueando el acceso.',
                'js_challenge' => 'JS Challenge activo. Usuarios sin JavaScript no pueden entrar.',
                'managed_challenge' => 'Managed Challenge (Turnstile) activo.',
                'captcha' => 'CAPTCHA activo. Usuarios deben resolver captcha para entrar.',
                'turnstile' => 'Turnstile Challenge activo.',
            ];
            
            $msg = $type_messages[$result['challenge_type']] ?? 'Challenge CF detectado.';
            
            // Get server info for better diagnosis
            $server = $this->get_server_info();
            $diagnosis = '';
            if ($server['ip'] && $server['country']) {
                $diagnosis = "\n\nDIAGNOSTICO: Tu servidor esta en {$server['country_name']} ({$server['country']}), IP: {$server['ip']}. "
                           . "Si tienes reglas de geo-blocking en CF que no incluyen {$server['country']}, el servidor se auto-bloquea al hacer requests.\n\n"
                           . "SOLUCION: Anade a tu regla de firewall en CF:\n"
                           . "- or http.user_agent contains \"Replanta-Site-Audit\"\n"
                           . "- O anade la IP: ip.src in {{$server['ip']}}";
            }
            
            $checks[] = $this->make_check(
                'user_access', 'Acceso Usuario Normal', 'critical',
                $result['challenge_type'] ?? 'Challenge',
                "PROBLEMA DETECTADO: {$msg}{$diagnosis}",
                'cf_whitelist_server', 'Whitelist servidor'
            );
        } elseif (!$result['success']) {
            $checks[] = $this->make_check(
                'user_access', 'Acceso Usuario Normal', 'critical',
                'HTTP ' . ($result['code'] ?? 'Error'),
                'Error al acceder: ' . ($result['error'] ?? 'Codigo ' . $result['code']),
                'cf_unblock_access', 'Desbloquear acceso'
            );
        } else {
            $checks[] = $this->make_check(
                'user_access', 'Acceso Usuario Normal', 'pass',
                'OK (' . $result['time'] . 'ms)',
                'Acceso correcto. Pagina cargada en ' . $result['time'] . 'ms.'
            );
        }

        return $checks;
    }

    /**
     * Test access as Googlebot
     */
    private function check_googlebot_access(): array {
        $checks = [];
        
        // Googlebot user-agent
        $ua = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)';
        
        $result = $this->test_access($this->site_url, $ua);

        if (!$result['success'] && $result['is_challenge']) {
            $checks[] = $this->make_check(
                'googlebot_access', 'Acceso Googlebot', 'critical',
                $result['challenge_type'] ?? 'Bloqueado',
                'CRITICO: Googlebot esta siendo bloqueado/desafiado por Cloudflare. Esto DESTRUYE tu SEO. Verifica que tu regla tenga: or cf.client.bot',
                'cf_firewall_bot_exception', 'Permitir bots verificados'
            );
        } elseif (!$result['success']) {
            $checks[] = $this->make_check(
                'googlebot_access', 'Acceso Googlebot', 'warning',
                'HTTP ' . ($result['code'] ?? 'Error'),
                'Posible problema de acceso para Googlebot.'
            );
        } else {
            $checks[] = $this->make_check(
                'googlebot_access', 'Acceso Googlebot', 'pass',
                'OK',
                'Googlebot puede acceder correctamente.'
            );
        }

        return $checks;
    }

    /**
     * Test access from mobile device
     */
    private function check_mobile_access(): array {
        $checks = [];
        
        // Mobile user-agent
        $ua = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
        
        $result = $this->test_access($this->site_url, $ua);

        if (!$result['success'] && $result['is_challenge']) {
            $checks[] = $this->make_check(
                'mobile_access', 'Acceso Movil', 'critical',
                $result['challenge_type'] ?? 'Challenge',
                'Usuarios moviles ven challenge CF. El 60%+ del trafico es movil. Mismo problema que acceso normal.',
                'cf_whitelist_server', 'Whitelist servidor'
            );
        } elseif (!$result['success']) {
            $checks[] = $this->make_check(
                'mobile_access', 'Acceso Móvil', 'warning',
                'Error',
                'Problema de acceso móvil: ' . ($result['error'] ?? 'HTTP ' . $result['code'])
            );
        } else {
            $checks[] = $this->make_check(
                'mobile_access', 'Acceso Móvil', 'pass',
                'OK (' . $result['time'] . 'ms)',
                'Acceso móvil correcto.'
            );
        }

        return $checks;
    }

    /**
     * Deep check for CF challenge markers in the page
     */
    private function check_cf_challenge_detection(): array {
        $checks = [];
        
        // Fetch page and analyze for challenge markers
        $resp = wp_remote_get($this->site_url . '?_check=' . time(), [
            'timeout' => 15,
            'sslverify' => false,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',
        ]);

        if (is_wp_error($resp)) {
            return $checks;
        }

        $body = wp_remote_retrieve_body($resp);
        $headers = wp_remote_retrieve_headers($resp);

        // Check CF-specific headers that indicate protection is active
        $cf_headers_to_check = [
            'cf-mitigated' => 'CF Mitigation header presente - puede indicar bloqueo activo',
            'cf-chl-bypass' => 'Challenge bypass header detectado',
        ];

        foreach ($cf_headers_to_check as $header => $message) {
            if (isset($headers[$header])) {
                $checks[] = $this->make_check(
                    'cf_' . str_replace('-', '_', $header), 'CF Header: ' . $header, 'warning',
                    $headers[$header],
                    $message
                );
            }
        }

        // Check for WAF block page indicators
        $waf_indicators = [
            'Access denied' => 'Página de "Access Denied" detectada',
            'blocked by' => 'Texto de bloqueo detectado',
            'security check' => 'Security check page detectada',
            'ray ID' => 'CF Ray ID en contenido (normal si hay error)',
        ];

        foreach ($waf_indicators as $pattern => $message) {
            if (stripos($body, $pattern) !== false && strlen($body) < 10000) {
                $checks[] = $this->make_check(
                    'waf_indicator', 'Indicador WAF', 'warning',
                    $pattern,
                    $message . '. Página puede estar siendo bloqueada intermitentemente.'
                );
                break;
            }
        }

        // If page is very small, might be a block page
        if (strlen($body) < 2000 && strlen($body) > 100) {
            $checks[] = $this->make_check(
                'small_response', 'Respuesta Pequeña', 'warning',
                strlen($body) . ' bytes',
                'Respuesta muy pequeña. Podría ser una página de error/challenge de CF.'
            );
        }

        return $checks;
    }

    /**
     * Check response time (slow = might be under heavy CF processing)
     */
    private function check_response_time(): array {
        $checks = [];
        
        $times = [];
        for ($i = 0; $i < 3; $i++) {
            $start = microtime(true);
            $resp = wp_remote_get($this->site_url . '?_perf=' . time() . $i, [
                'timeout' => 10,
                'sslverify' => false,
            ]);
            $times[] = round((microtime(true) - $start) * 1000);
            if ($i < 2) usleep(100000); // 100ms between requests
        }

        $avg = round(array_sum($times) / count($times));

        if ($avg > 5000) {
            $checks[] = $this->make_check(
                'response_time', 'Tiempo de Respuesta', 'critical',
                $avg . 'ms',
                'Respuesta MUY lenta (>' . $avg . 'ms). Posible problema de servidor o CF procesando challenges.'
            );
        } elseif ($avg > 2000) {
            $checks[] = $this->make_check(
                'response_time', 'Tiempo de Respuesta', 'warning',
                $avg . 'ms',
                'Respuesta lenta. Usuarios pueden abandonar antes de cargar.'
            );
        } else {
            $checks[] = $this->make_check(
                'response_time', 'Tiempo de Respuesta', 'pass',
                $avg . 'ms',
                'Tiempo de respuesta aceptable.'
            );
        }

        return $checks;
    }

    /**
     * Check for redirect loops or chains
     */
    private function check_redirect_chain(): array {
        $checks = [];
        
        $resp = wp_remote_get($this->site_url, [
            'timeout' => 10,
            'sslverify' => false,
            'redirection' => 0, // Don't follow redirects
        ]);

        if (is_wp_error($resp)) {
            return $checks;
        }

        $code = wp_remote_retrieve_response_code($resp);
        
        if (in_array($code, [301, 302, 303, 307, 308])) {
            $location = wp_remote_retrieve_header($resp, 'location');
            
            // Check if redirecting to challenge page
            if (strpos($location, 'challenge') !== false || strpos($location, 'cdn-cgi') !== false) {
                $checks[] = $this->make_check(
                    'redirect_challenge', 'Redirección a Challenge', 'critical',
                    'Redirect → Challenge',
                    "Redirigiendo a: {$location}. CF está forzando un challenge."
                );
            } else {
                $checks[] = $this->make_check(
                    'redirect', 'Redirección Inicial', 'info',
                    $code . ' → ' . parse_url($location, PHP_URL_PATH),
                    'Redirección configurada. Verifica que sea correcta.'
                );
            }
        }

        return $checks;
    }

    /**
     * Check if critical resources are being blocked
     */
    private function check_blocked_resources(): array {
        $checks = [];
        
        // Check robots.txt accessibility
        $robots = wp_remote_get($this->site_url . '/robots.txt', [
            'timeout' => 5,
            'sslverify' => false,
        ]);

        if (is_wp_error($robots) || wp_remote_retrieve_response_code($robots) !== 200) {
            $checks[] = $this->make_check(
                'robots_blocked', 'robots.txt Acceso', 'warning',
                'Bloqueado/Error',
                'robots.txt no accesible. Puede afectar indexación.'
            );
        }

        // Check sitemap accessibility
        $sitemap_urls = [
            $this->site_url . '/sitemap_index.xml',
            $this->site_url . '/sitemap.xml',
            $this->site_url . '/wp-sitemap.xml',
        ];

        $sitemap_ok = false;
        foreach ($sitemap_urls as $url) {
            $sitemap = wp_remote_get($url, ['timeout' => 5, 'sslverify' => false]);
            if (!is_wp_error($sitemap) && wp_remote_retrieve_response_code($sitemap) === 200) {
                $sitemap_ok = true;
                break;
            }
        }

        if (!$sitemap_ok) {
            $checks[] = $this->make_check(
                'sitemap_blocked', 'Sitemap Acceso', 'warning',
                'No accesible',
                'Ningún sitemap accesible públicamente.'
            );
        }

        return $checks;
    }
}
