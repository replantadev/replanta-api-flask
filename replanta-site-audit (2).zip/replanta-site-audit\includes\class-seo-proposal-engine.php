<?php
/**
 * RSA_SEO_Proposal_Engine
 *
 * Calls Claude with a structured prompt to generate actionable SEO proposals,
 * then persists them to the rsa_seo_proposals table.
 *
 * Reuses RSA_Claude_SEO_Agent::call_claude() and ::get_system_prompt()
 * (both made public in v3.0.0) — no duplication of the HTTP layer.
 *
 * @package Replanta_Site_Audit
 * @since   3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class RSA_SEO_Proposal_Engine {

	const TABLE = 'rsa_seo_proposals';

	/* ─────────────────────────────────────────
	 * Proposal generation via Claude
	 * ───────────────────────────────────────── */

	/**
	 * Receives a batch of up to 8 snapshot rows, sends them to Claude,
	 * parses the JSON response and stores individual proposals.
	 *
	 * @param array $batch  Each element: url, keyword, clicks, position,
	 *                      rank_math_title, rank_math_desc, rank_math_focus_kw,
	 *                      schema_types, schema_issues, post_id, snapshot_id
	 */
	public static function generate_from_snapshot( array $batch ): void {
		if ( empty( $batch ) ) return;

		$agent = RSA_Claude_SEO_Agent::get_instance();
		if ( ! $agent->is_configured() ) return;

		// Build context table
		$context  = "Analiza estas páginas de replanta.net y propón mejoras SEO concretas.\n\n";
		$context .= "| # | URL | Tipo | Lang | Pos | Clicks | Vol/KD | Keyword | Meta Title | Schema | Issues |\n";
		$context .= "|---|-----|------|------|-----|--------|--------|---------|-----------|--------|--------|\n";

		$page_refs = [];
		foreach ( $batch as $i => $page ) {
			$n      = $i + 1;
			$pos    = $page['position']     ?? '?';
			$clicks = $page['clicks']       ?? 0;
			$kw     = $page['keyword']      ?? '';
			$title  = mb_substr( (string) ( $page['rank_math_title'] ?? '(vacío)' ), 0, 70 );
			$schema = $page['schema_types'] ?? '(ninguno)';
			$lang   = $page['lang']         ?: '?';
			$pt     = $page['post_type']    ?: 'page';
			$vol    = isset( $page['dfs_volume'] ) && $page['dfs_volume'] !== null ? (int) $page['dfs_volume'] : '—';
			$kd     = isset( $page['dfs_kd'] )     && $page['dfs_kd']     !== null ? (int) $page['dfs_kd']    : '—';
			$vol_kd = "{$vol}/{$kd}";
			$issues = ! empty( $page['schema_issues'] )
				? mb_substr( implode( ' / ', (array) json_decode( $page['schema_issues'], true ) ), 0, 60 )
				: 'OK';

			$context .= "| {$n} | {$page['url']} | {$pt} | {$lang} | {$pos} | {$clicks} | {$vol_kd} | {$kw} | {$title} | {$schema} | {$issues} |\n";
			$page_refs[ $n ] = $page;
		}

		$n_max = count( $batch );

		// Content excerpts section — gives Claude real phrases for interlink insert_after
		$excerpt_lines = '';
		foreach ( $batch as $i => $page ) {
			if ( ! empty( $page['post_content_excerpt'] ) ) {
				$n             = $i + 1;
				$excerpt_lines .= "\n**#{$n}** `{$page['url']}`:\n> "
					. mb_substr( (string) $page['post_content_excerpt'], 0, 400 ) . "\n";
			}
		}
		if ( $excerpt_lines ) {
			$context .= "\n\n## Extractos de contenido (usa frases reales para `insert_after` en interlinks):{$excerpt_lines}";
		}

		$context .= <<<INSTRUCTIONS

**INSTRUCCIONES PARA TU RESPUESTA:**
Devuelve ÚNICAMENTE un bloque de código JSON válido, sin ningún texto antes ni después.
Formato:

```json
[
  {
    "type":       "meta_title | meta_desc | focus_kw | schema_add | schema_fix | interlink | new_draft",
    "page_index": <número de fila, 1 a {$n_max}>,
    "field_key":  "rank_math_title | rank_math_description | rank_math_focus_keyword | _rsa_custom_schema | post_content | post_title",
    "value_after": "<valor propuesto; para interlink JSON con anchor/href/insert_after; para new_draft JSON con title/outline/focus_kw>",
    "reasoning":  "<explica el impacto SEO en ≤100 chars>"
  }
]
```

Reglas:
- meta_title: máx 60 chars, incluye keyword + diferenciador Replanta.
- meta_desc: máx 155 chars, CTA claro.
- Para schema_add/schema_fix: value_after es el objeto JSON del schema completo.
- Schema según Tipo: `betterdocs_doc` → TechArticle o HowTo (si hay pasos); `page` servicio → Service+FAQPage; `post` → Article+BreadcrumbList; `product` → verifica que Product+Review existan (WooCommerce los genera, solo corrige si faltan).
- Para interlink: value_after = `{"anchor":"texto enlace","href":"/url-destino/","insert_after":"frase literal tomada del extracto de contenido provisto"}`.
- Para new_draft: solo si detectas keyword clara sin página existente. value_after = `{"title":"Título","outline":"## Introducción\\n...","focus_kw":"keyword","post_type":"post"}`.
- Máx 3 propuestas por página. Prioriza impacto/esfuerzo.
- NUNCA inventes datos; basa los cambios en las keywords y URLs del contexto.
INSTRUCTIONS;

		$raw = $agent->call_claude( $agent->get_system_prompt(), $context );
		if ( is_wp_error( $raw ) ) return;

		$proposals = self::extract_json( $raw );
		if ( ! is_array( $proposals ) ) return;

		foreach ( $proposals as $prop ) {
			$type  = sanitize_key( $prop['type']  ?? '' );
			$after = trim( $prop['value_after']    ?? '' );
			$idx   = (int) ( $prop['page_index']  ?? 0 );
			$page  = $page_refs[ $idx ]            ?? null;

			if ( ! $type || ! $after || ! $page ) continue;

			// Skip if an identical pending proposal already exists (prevents duplicates across weekly runs)
			if ( self::has_pending( $type, $page['url'] ) ) continue;

			// value_before: pull from snapshot data
			$value_before = match( $type ) {
				'meta_title'              => $page['rank_math_title']   ?? '',
				'meta_desc'               => $page['rank_math_desc']    ?? '',
				'focus_kw'                => $page['rank_math_focus_kw'] ?? '',
				'schema_add', 'schema_fix' => $page['schema_types']     ?? '',
				default                   => '',
			};

			self::save( [
				'type'             => $type,
				'post_id'          => (int) ( $page['post_id']     ?? 0 ),
				'url'              => $page['url'],
				'field_key'        => sanitize_key( $prop['field_key']  ?? '' ),
				'lang'             => (string) ( $page['lang'] ?? '' ),
				'value_before'     => (string) $value_before,
				'value_after'      => $after,
				'status'           => 'pending',
				'claude_reasoning' => mb_substr( sanitize_text_field( $prop['reasoning'] ?? '' ), 0, 255 ),
				'snapshot_id'      => (int) ( $page['snapshot_id'] ?? 0 ),
				'approval_token'   => wp_generate_password( 32, false ),
				'created_at'       => current_time( 'mysql' ),
			] );
		}
	}

	/* ─────────────────────────────────────────
	 * CRUD helpers
	 * ───────────────────────────────────────── */

	public static function save( array $data ): int {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . self::TABLE, $data );
		return (int) $wpdb->insert_id;
	}

	/**
	 * @param string|null $status  Filter by status, or null for all.
	 * @param int         $limit
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_all( ?string $status = null, int $limit = 200 ): array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;

		if ( $status !== null ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM `{$table}` WHERE status = %s ORDER BY created_at DESC LIMIT %d",
					$status,
					$limit
				),
				ARRAY_A
			) ?: [];
		}

		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY created_at DESC LIMIT %d", $limit ),
			ARRAY_A
		) ?: [];
	}

	public static function get_by_id( int $id ): ?array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ),
			ARRAY_A
		);
		return $row ?: null;
	}

	public static function get_by_token( string $token ): ?array {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM `{$table}` WHERE approval_token = %s", $token ),
			ARRAY_A
		);
		return $row ?: null;
	}

	public static function update_status( int $id, string $status ): void {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		$data  = [ 'status' => $status ];

		if ( in_array( $status, [ 'approved', 'rejected' ], true ) ) {
			$data['decided_at'] = current_time( 'mysql' );
		}

		$wpdb->update( $table, $data, [ 'id' => $id ] );
	}

	/** Returns counts indexed by status + 'total'. */
	public static function get_counts(): array {
		global $wpdb;
		$table  = $wpdb->prefix . self::TABLE;
		$rows   = $wpdb->get_results(
			"SELECT status, COUNT(*) AS cnt FROM `{$table}` GROUP BY status",
			ARRAY_A
		) ?: [];

		$counts = [ 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'applied' => 0, 'failed' => 0, 'total' => 0 ];
		foreach ( $rows as $row ) {
			$s = $row['status'];
			if ( isset( $counts[ $s ] ) ) {
				$counts[ $s ] = (int) $row['cnt'];
			}
			$counts['total'] += (int) $row['cnt'];
		}
		return $counts;
	}

	/* ─────────────────────────────────────────
	 * Internal helpers
	 * ───────────────────────────────────────── */

	/**
	 * Extracts and decodes the first JSON array from a Claude response.
	 * Handles both fenced (```json ... ```) and bare JSON arrays.
	 */
	private static function extract_json( string $text ): ?array {
		// Try fenced code block first
		if ( preg_match( '/```(?:json)?\s*([\s\S]+?)\s*```/i', $text, $m ) ) {
			$decoded = json_decode( trim( $m[1] ), true );
			if ( is_array( $decoded ) ) return $decoded;
		}
		// Try bare JSON array
		if ( preg_match( '/(\[\s*\{[\s\S]+\}\s*\])/s', $text, $m ) ) {
			$decoded = json_decode( $m[1], true );
			if ( is_array( $decoded ) ) return $decoded;
		}
		return null;
	}

	/**
	 * Returns true if a pending proposal already exists for the given type + URL.
	 * Prevents duplicate proposals accumulating across weekly snapshot runs.
	 */
	public static function has_pending( string $type, string $url ): bool {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE;
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT 1 FROM `{$table}` WHERE type = %s AND url = %s AND status = 'pending' LIMIT 1",
				$type,
				$url
			)
		);
	}
}
