# Changelog - Plugin Dominios Reseller

## [1.5.7] - 2025-12-20

### 🔧 Sistema de Onboarding Mejorado - Compatibilidad Cloudflare API v4

#### 🆕 Nuevas Funcionalidades
- **ADDED**: Diagnóstico completo de Openprovider en Debug Hub
- **ADDED**: Validación previa de nameservers antes de actualizar
- **ADDED**: Manejo robusto de errores específicos para dominios .es
- **ADDED**: Logging detallado para errores de NS rechazados
- **ADDED**: Estado "parcial" para onboarding cuando NS requieren configuración manual

#### 🔄 Mejoras en Preset de Cloudflare
- **FIXED**: Eliminados settings obsoletos de Cloudflare (0rtt, polish, mirage, challenge_ttl, etc.)
- **UPDATED**: Preset compatible con Cloudflare API v4 actual
- **IMPROVED**: Validación de settings antes de aplicar

#### � Sistema de Autenticación Cloudflare
- **CHANGED**: Prioridad cambiada - API Token primero, Global API Key como fallback
- **IMPROVED**: Interfaz de administración clarificada con prioridades
- **UPDATED**: Logging de autenticación para mostrar método usado
- **FIXED**: Sistema ahora usa Bearer Token (API Token) como método principal

#### �🛠️ Sistema de Diagnóstico Openprovider
- **ADDED**: Test "🔍 Diagnóstico Openprovider" en Debug Hub
- **ADDED**: Verificación detallada de estado de dominio
- **ADDED**: Instrucciones específicas para dominios .es
- **ADDED**: Detección de restricciones de registro español

#### 🐛 Correcciones de Errores
- **FIXED**: Error "Setting no reconocido" en aplicación de preset
- **FIXED**: Manejo de "Invalid request" para NS de Cloudflare en .es
- **FIXED**: Logging mejorado para debugging de problemas de NS

#### 📋 Documentación
- **ADDED**: `SOLUCION-NS-ES.md` - Guía completa para problemas de NS en .es
- **UPDATED**: Instrucciones de configuración manual de NS
- **ADDED**: Contactos de soporte para autorización de NS

---

## [1.5.0] - 2025-12-19

### 🔧 Configuración Dinámica de Servidores WHM
Eliminación de IPs hardcodeadas - ahora los servidores son completamente configurables desde el panel de administración.

#### 🆕 Nuevas Funcionalidades
- **ADDED**: Campo "IP/Hostname Servidor" para servidor UK en la pestaña de configuración
- **ADDED**: Campo "IP/Hostname Servidor" para servidor USA en la pestaña de configuración
- **ADDED**: Función helper `dominios_reseller_get_server_ip()` para obtener la IP configurada
- **ADDED**: Validación de IP vacía antes de realizar conexiones WHM
- **ADDED**: Mensajes de error claros cuando la IP no está configurada

#### 🔄 Cambios
- **CHANGED**: `test_whm_connection()` ahora usa IPs dinámicas de las opciones
- **CHANGED**: `obtener_cuentas_whm()` ahora usa IPs dinámicas
- **CHANGED**: `obtener_addons_de_usuario()` ahora usa IPs dinámicas
- **CHANGED**: `obtener_trafico_real()` ahora usa IPs dinámicas
- **CHANGED**: `mostrar_servidor_dominios()` ya no requiere parámetro IP
- **REMOVED**: IPs hardcodeadas (198.38.92.238, 192.250.227.159)

#### 🗄️ Nuevas Opciones
- `uk_server_ip` - IP o hostname del servidor WHM de UK
- `usa_server_ip` - IP o hostname del servidor WHM de USA

---

## [1.4.0] - 2025-12-16

### ☁️ FASE 2: Cloudflare Onboarding Automatizado
Automatización completa del proceso de alta de dominios en Cloudflare con aplicación de presets y actualización de nameservers.

#### 🆕 Nuevas Funcionalidades
- **ADDED**: Sistema de cola asíncrona para onboarding (no bloquea admin)
- **ADDED**: Creación automática de zonas en Cloudflare
- **ADDED**: Presets configurables (WordPress, WooCommerce) con settings óptimos
- **ADDED**: Integración con Openprovider para actualización automática de NS
- **ADDED**: Panel de administración "CF Onboarding" con cards por dominio
- **ADDED**: Logs detallados de cada paso del proceso
- **ADDED**: Soporte para dominios con TLDs compuestos (co.uk, com.es, etc.)

#### 🔄 Workflow de Onboarding
1. **ensure_zone**: Crea zona en CF si no existe (idempotente)
2. **apply_preset**: Aplica configuración de seguridad, SSL, cache
3. **update_ns**: Actualiza nameservers en Openprovider (opcional)

#### 📁 Nuevos Archivos
- `includes/class-onboarding-db.php` - Esquema de DB y gestión de presets
- `includes/class-onboarding-worker.php` - Worker de cola con locking
- `includes/class-openprovider-service.php` - Integración API Openprovider
- `includes/class-onboarding-admin.php` - UI de administración

#### 🗄️ Nuevas Tablas
- `{prefix}_dominios_reseller_cf_onboarding` - Estado por dominio
- `{prefix}_dominios_reseller_cf_onboarding_logs` - Logs de ejecución
- `{prefix}_dominios_reseller_cf_presets` - Presets almacenados

#### ⚙️ Presets Incluidos
- **wp**: WordPress optimizado (SSL Full, TLS 1.2, WAF, cache bypass admin)
- **woo**: WooCommerce optimizado (WP + bypass checkout/cart/account)

#### 🔐 API Token Cloudflare - Permisos Requeridos
Para Fase 2, el token necesita:
- `Zone:Read` - Listar y leer zonas
- `Zone:Edit` - Crear zonas y modificar settings
- `Zone Settings:Edit` - Modificar configuración SSL, TLS, etc.
- `Cache Rules:Edit` - Crear reglas de cache (Rulesets API)

#### 🔄 Estrategia de Idempotencia
- Antes de crear zona: verificar si ya existe por nombre
- Antes de aplicar preset: comparar valores actuales vs deseados
- Antes de actualizar NS: verificar si ya están configurados
- Safe to run multiple times without side effects

#### ⏱️ Manejo de Rate Limits
- Cloudflare: 1200 req/5min → Backoff exponencial si 429
- Openprovider: 60 req/min → Transient-based throttling
- Token de OP cacheado 23h (expira a las 24h)

---

## [1.3.0] - 2025-12-16

### ☁️ Integración Cloudflare
- **ADDED**: Nueva tabla `{prefix}_dominios_reseller_cf_zones` para almacenar zonas de Cloudflare
- **ADDED**: Clase `Dominios_Reseller_Cloudflare_Service` para gestionar sincronización con CF API
- **ADDED**: Panel de configuración de Cloudflare en pestaña Settings
- **ADDED**: Columna "CF" en el listado de dominios mostrando ✅/❌/❓
- **ADDED**: Sincronización manual con botón y automática via WP-Cron (cada 8h)
- **ADDED**: Matching inteligente: exacto (`example.com`) y subdominio (`tienda.example.com`)
- **ADDED**: El matching usa `primary_domain` (no `domain`) para evitar falsos positivos

### 🚀 Optimizaciones de Rendimiento
- **ADDED**: Cache de índice de zonas en transient (1 hora)
- **ADDED**: Batch matching para listados (1 query a DB, 0 a CF API)
- **ADDED**: Upsert incremental con `INSERT ... ON DUPLICATE KEY UPDATE`
- **ADDED**: Rate limit backoff automático si CF devuelve 429
- **ADDED**: Zonas eliminadas se marcan con `deleted_at` (soft delete)

### 🔐 Seguridad
- **ADDED**: Token de API enmascarado en UI (solo últimos 4 caracteres)
- **ADDED**: Verificación de capacidad `manage_options` en todas las acciones
- **ADDED**: Nonces en todos los formularios AJAX
- **ADDED**: Sanitización y escape de todos los datos

### 📁 Nuevos Archivos
- `includes/class-cloudflare-service.php` - Servicio principal CF
- `includes/cloudflare-admin.php` - UI de administración
- `includes/cloudflare-cron.php` - Sincronización automática

## [1.2.1] - 2025-11-10

### 🎯 CRÍTICO - API REST para Plugin Sello-Replanta
- **ADDED**: Endpoint REST API `/wp-json/replanta/v1/check_domain` para verificación de dominios
- **ADDED**: Archivo `includes/rest-api.php` con endpoints REST
- **ADDED**: Endpoint `/wp-json/replanta/v1/stats` para estadísticas (solo admin)
- **FIXED**: Integración completa entre plugin `sello-replanta` y `dominios-reseller`
- **FIXED**: Problema "El dominio no está en replanta" en webs de clientes

### 🔌 Funcionalidad de API
- **ADDED**: Verificación pública de dominios vía POST
- **ADDED**: Búsqueda automática en ambos servidores (UK y USA)
- **ADDED**: Priorización de dominios Activos sobre Suspendidos
- **ADDED**: Respuesta JSON con datos completos (árboles, CO2, fechas, estado)
- **ADDED**: Validación de formato de dominio antes de búsqueda
- **ADDED**: Protección SQL injection con `$wpdb->prepare()`

### 🛠️ Herramientas de Diagnóstico
- **ADDED**: Script de prueba PHP `test-api-endpoint.php`
- **ADDED**: Script de prueba PowerShell `test-api-endpoint.ps1`
- **ADDED**: Documentación completa en `SOLUCION-API-REST.md`
- **ADDED**: Logs detallados para debug (si WP_DEBUG activo)

### 📊 Detalles Técnicos
- **COMPATIBILITY**: 100% compatible con versiones anteriores
- **SECURITY**: Endpoint público pero solo expone info ecológica
- **PERFORMANCE**: Consultas optimizadas con índices existentes
- **SCALABILITY**: Soporta múltiples servidores automáticamente

## [1.0.1] - 2025-09-07

### 🚨 CRÍTICO - Error Fatal Resuelto
- **FIXED**: Error fatal "Cannot access offset of type string on string" en línea 79
- **FIXED**: Validación robusta de tipos de datos en APIs WHM
- **FIXED**: Manejo seguro de respuestas de addon domains

### 🛡️ Mejoras de Seguridad y Estabilidad
- **ADDED**: Validaciones de tipo array antes de foreach
- **ADDED**: Timeouts en llamadas cURL (30s conexión, 10s timeout)
- **ADDED**: Códigos de estado HTTP en validaciones
- **ADDED**: Logging mejorado con prefijos identificables
- **ADDED**: Manejo de errores en estructura de respuesta API

### 🔧 Mejoras Técnicas
- **IMPROVED**: Función `obtener_addons_de_usuario()` con validaciones completas
- **IMPROVED**: Función `obtener_cuentas_whm()` con manejo robusto de errores
- **IMPROVED**: Función `obtener_trafico_real()` con validaciones de datos
- **IMPROVED**: Logging consistente con formato "[Dominios Reseller]"

### 🚀 Optimizaciones
- **OPTIMIZED**: Reducción de llamadas API fallidas
- **OPTIMIZED**: Mejor handling de respuestas malformadas
- **OPTIMIZED**: Skip automático de addon domains inválidos

## [1.0.0] - 2025-09-06
- **INITIAL**: Versión inicial del plugin
- **ADDED**: Integración con APIs WHM
- **ADDED**: Cálculo de huella de carbono por dominio
- **ADDED**: Gestión de addon domains
- **ADDED**: Interface de administración WordPress
