<?php
/**
 * Debug Hub para el sistema de onboarding
 * Página de administración con tests integrados
 */

if (!defined('ABSPATH')) {
    exit;
}

class Dominios_Reseller_Debug_Hub {

    /**
     * Instancia singleton
     */
    private static $instance = null;

    /**
     * Obtener instancia
     */
    public static function get_instance(): Dominios_Reseller_Debug_Hub {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', [$this, 'add_debug_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Añadir menú de debug
     */
    public function add_debug_menu(): void {
        add_submenu_page(
            'dominios-reseller', // Parent slug correcto
            'Debug Hub - Onboarding', // Page title
            '🔧 Debug Hub', // Menu title
            'manage_options', // Capability
            'dominios-reseller-debug', // Menu slug
            [$this, 'render_debug_page'] // Callback
        );
    }

    /**
     * Encolar scripts y estilos
     */
    public function enqueue_scripts($hook): void {
        if ($hook !== 'dominios-reseller_page_dominios-reseller-debug') {
            return;
        }

        // Ruta correcta del plugin desde el archivo principal
        $plugin_file = dirname(dirname(__FILE__)) . '/dominios-reseller.php';
        $plugin_url = plugin_dir_url($plugin_file);

        wp_enqueue_style('dominios-reseller-debug', $plugin_url . 'assets/css/debug-hub.css', [], '1.0.0');
        wp_enqueue_script('dominios-reseller-debug', $plugin_url . 'assets/js/debug-hub.js', ['jquery'], '1.0.0', true);

        wp_localize_script('dominios-reseller-debug', 'dr_debug_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dr_debug_nonce'),
            'strings' => [
                'running_test' => 'Ejecutando test...',
                'test_completed' => 'Test completado',
                'error' => 'Error',
                'success' => 'Éxito'
            ]
        ]);

        // Debug: verificar que se está localizando correctamente
        error_log('🔧 Debug Hub: Scripts enqueued for page: ' . $hook . ' - Plugin URL: ' . $plugin_url);
    }

    /**
     * Renderizar página de debug
     */
    public function render_debug_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('No tienes permisos para acceder a esta página.'));
        }

        ?>
        <div class="wrap">
            <h1>🔧 Debug Hub - Sistema de Onboarding Asíncrono</h1>

            <div class="notice notice-info">
                <p><strong>ℹ️ Información:</strong> Esta página te permite ejecutar tests del sistema de onboarding directamente desde el admin panel.</p>
            </div>

            <div class="dr-debug-container">
                <!-- Tests Rápidos -->
                <div class="dr-debug-section">
                    <h2>🧪 Tests Rápidos</h2>
                    <div class="dr-debug-grid">
                        <div class="dr-debug-card">
                            <h3>📊 Estado del Sistema</h3>
                            <p>Verifica tablas, presets y configuración básica</p>
                            <button class="button button-primary" onclick="runTest('system_status')">Ejecutar Test</button>
                            <div id="system_status_result" class="dr-test-result"></div>
                        </div>

                        <div class="dr-debug-card">
                            <h3>🎯 Test de Encolado</h3>
                            <p>Prueba encolar un dominio de ejemplo</p>
                            <button class="button button-primary" onclick="runTest('enqueue_test')">Ejecutar Test</button>
                            <div id="enqueue_test_result" class="dr-test-result"></div>
                        </div>

                        <div class="dr-debug-card">
                            <h3>⚡ Eventos Programados</h3>
                            <p>Verifica eventos de WordPress programados</p>
                            <button class="button button-primary" onclick="runTest('cron_events')">Ejecutar Test</button>
                            <div id="cron_events_result" class="dr-test-result"></div>
                        </div>
                    </div>
                </div>

                <!-- Encolado Manual de Dominios -->
                <div class="dr-debug-section">
                    <h2>🚀 Encolado Manual de Dominios</h2>
                    <div class="dr-manual-enqueue">
                        <div class="dr-enqueue-form">
                            <div class="dr-form-row">
                                <label for="enqueue_domain">Dominio:</label>
                                <input type="text" id="enqueue_domain" placeholder="ejemplo.com" style="width: 200px;">
                            </div>
                            <div class="dr-form-row">
                                <label for="enqueue_preset">Preset:</label>
                                <select id="enqueue_preset" style="width: 150px;">
                                    <option value="wp">WordPress</option>
                                    <option value="basic">Básico</option>
                                    <option value="custom">Personalizado</option>
                                </select>
                            </div>
                            <div class="dr-form-row">
                                <label for="enqueue_auto_ns">
                                    <input type="checkbox" id="enqueue_auto_ns"> Actualizar NS automáticamente
                                </label>
                            </div>
                            <div class="dr-form-row">
                                <button class="button button-primary" onclick="manualEnqueue()">Encolar Dominio</button>
                                <div id="manual_enqueue_result" class="dr-test-result" style="margin-top: 10px;"></div>
                            </div>
                        </div>

                        <div class="dr-enqueue-actions">
                            <h3>🔄 Acciones para Dominios Existentes</h3>
                            <div class="dr-form-row">
                                <label for="existing_domain">Dominio existente:</label>
                                <input type="text" id="existing_domain" placeholder="dominio.com" style="width: 200px;">
                                <button class="button" onclick="checkDomainStatus()">Ver Estado</button>
                            </div>
                            <div id="domain_status_result" class="dr-test-result" style="margin-top: 10px;"></div>
                            <div id="domain_actions" class="dr-domain-actions" style="display: none; margin-top: 15px;">
                                <button class="button button-secondary" id="retry_domain_btn" onclick="retryDomain()" style="display: none;">Reintentar</button>
                                <button class="button button-secondary" id="update_config_btn" onclick="updateDomainConfig()" style="display: none;">Actualizar Config</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dr-debug-section">
                    <h2>🗄️ Gestión de Datos</h2>
                    <div class="dr-debug-grid">
                        <div class="dr-debug-card">
                            <h3>� Diagnóstico Openprovider</h3>
                            <p>Verifica estado de dominio en Openprovider</p>
                            <button class="button button-secondary" onclick="runTest('openprovider_diagnostic')">Diagnosticar</button>
                            <div id="openprovider_diagnostic_result" class="dr-test-result"></div>
                        </div>

                        <div class="dr-debug-card">                            <h3>🔄 Actualizar Presets</h3>
                            <p>Actualizar presets a versiones más recientes</p>
                            <button class="button button-secondary" onclick="runTest('update_presets')">Actualizar</button>
                            <div id="update_presets_result" class="dr-test-result"></div>
                        </div>

                        <div class="dr-debug-card">                            <h3>�📋 Crear Preset de Test</h3>
                            <p>Crea un preset básico para pruebas</p>
                            <button class="button button-secondary" onclick="runTest('create_preset')">Crear Preset</button>
                            <div id="create_preset_result" class="dr-test-result"></div>
                        </div>

                        <div class="dr-debug-card">
                            <h3>🧹 Limpiar Datos de Test</h3>
                            <p>Elimina runs y logs de testing</p>
                            <button class="button button-secondary" onclick="runTest('cleanup_test_data')">Limpiar</button>
                            <div id="cleanup_test_data_result" class="dr-test-result"></div>
                        </div>

                        <div class="dr-debug-card">
                            <h3>�️ Crear Tablas Faltantes</h3>
                            <p>Crea las tablas de onboarding si faltan</p>
                            <button class="button button-secondary" onclick="runTest('create_tables')">Crear Tablas</button>
                            <div id="create_tables_result" class="dr-test-result"></div>
                        </div>
                    </div>
                </div>

                <!-- Información del Sistema -->
                <div class="dr-debug-section">
                    <h2>ℹ️ Información del Sistema</h2>
                    <div class="dr-debug-info-grid">
                        <div class="dr-info-card">
                            <h4>📊 Base de Datos</h4>
                            <ul>
                                <li><strong>Prefix:</strong> <?php echo $GLOBALS['wpdb']->prefix; ?></li>
                                <li><strong>Versión MySQL:</strong> <?php echo $GLOBALS['wpdb']->db_version(); ?></li>
                                <li><strong>Charset:</strong> <?php echo $GLOBALS['wpdb']->charset; ?></li>
                            </ul>
                        </div>

                        <div class="dr-info-card">
                            <h4>🔧 WordPress</h4>
                            <ul>
                                <li><strong>Versión:</strong> <?php echo get_bloginfo('version'); ?></li>
                                <li><strong>PHP:</strong> <?php echo PHP_VERSION; ?></li>
                                <li><strong>Memoria límite:</strong> <?php echo ini_get('memory_limit'); ?></li>
                            </ul>
                        </div>

                        <div class="dr-info-card">
                            <h4>⏰ Cron</h4>
                            <ul>
                                <li><strong>Cron activo:</strong> <?php echo defined('DISABLE_WP_CRON') && DISABLE_WP_CRON ? '❌ Desactivado' : '✅ Activo'; ?></li>
                                <li><strong>Próximo evento:</strong> <?php echo date('H:i:s', wp_next_scheduled('wp_version_check')); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Logs Recientes -->
                <div class="dr-debug-section">
                    <h2>📝 Logs Recientes</h2>
                    <div id="recent_logs_container">
                        <button class="button" onclick="runTest('recent_logs')">Cargar Logs Recientes</button>
                        <div id="recent_logs_result" class="dr-test-result"></div>
                    </div>
                </div>
            </div>
        </div>

        <style>
        .dr-debug-container {
            margin-top: 20px;
        }

        .dr-debug-section {
            margin-bottom: 30px;
            padding: 20px;
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }

        .dr-debug-section h2 {
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .dr-debug-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .dr-debug-card {
            padding: 20px;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            background: #fafafa;
        }

        .dr-debug-card h3 {
            margin-top: 0;
            color: #23282d;
        }

        .dr-debug-card p {
            color: #666;
            margin-bottom: 15px;
        }

        .dr-test-result {
            margin-top: 15px;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            max-height: 300px;
            overflow-y: auto;
            white-space: pre-wrap;
        }

        .dr-test-result.success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }

        .dr-test-result.error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        .dr-test-result.info {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
        }

        .dr-debug-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .dr-info-card {
            padding: 15px;
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 4px;
        }

        .dr-info-card h4 {
            margin-top: 0;
            color: #495057;
        }

        .dr-info-card ul {
            margin: 0;
            padding-left: 20px;
        }

        .dr-info-card li {
            margin-bottom: 5px;
        }
        </style>

        <script>
        function runTest(testType) {
            const resultDiv = document.getElementById(testType + '_result');
            const button = resultDiv.previousElementSibling;

            // Limpiar resultado anterior
            resultDiv.innerHTML = '';
            resultDiv.className = 'dr-test-result';

            // Desactivar botón
            button.disabled = true;
            button.textContent = dr_debug_ajax.strings.running_test;

            // Ejecutar test via AJAX
            jQuery.ajax({
                url: dr_debug_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dr_debug_test',
                    test_type: testType,
                    nonce: dr_debug_ajax.nonce
                },
                success: function(response) {
                    resultDiv.className = 'dr-test-result ' + (response.success ? 'success' : 'error');
                    resultDiv.innerHTML = response.data;
                },
                error: function() {
                    resultDiv.className = 'dr-test-result error';
                    resultDiv.innerHTML = '❌ Error de conexión';
                },
                complete: function() {
                    button.disabled = false;
                    button.textContent = button.textContent.replace(dr_debug_ajax.strings.running_test, 'Ejecutar Test');
                }
            });
        }
        </script>
        <?php
    }

    /**
     * Ejecutar test via AJAX
     */
    public function run_ajax_test(): void {
        // Verificar nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'dr_debug_nonce')) {
            wp_send_json_error('Nonce inválido');
            return;
        }

        $test_type = sanitize_text_field($_POST['test_type'] ?? '');

        try {
            ob_start();
            $result = $this->execute_test($test_type);
            $output = ob_get_clean();

            wp_send_json_success($result . $output);
        } catch (Exception $e) {
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }

    /**
     * Ejecutar test específico
     */
    private function execute_test(string $test_type): string {
        switch ($test_type) {
            case 'system_status':
                return $this->test_system_status();

            case 'enqueue_test':
                return $this->test_enqueue();

            case 'cron_events':
                return $this->test_cron_events();

            case 'create_preset':
                return $this->test_create_preset();

            case 'update_presets':
                return $this->test_update_presets();

            case 'cleanup_test_data':
                return $this->test_cleanup();

            case 'system_stats':
                return $this->test_system_stats();

            case 'create_tables':
                return $this->test_create_tables();

            case 'recent_logs':
                return $this->test_recent_logs();

            case 'openprovider_diagnostic':
                return $this->test_openprovider_diagnostic();

            default:
                return '❌ Test no reconocido';
        }
    }

    /**
     * Test: Estado del sistema
     */
    private function test_system_status(): string {
        $output = "=== ESTADO DEL SISTEMA ===\n\n";

        // Verificar tablas
        $output .= "1. TABLAS DE BD:\n";
        global $wpdb;
        $tables = [
            'dominios_reseller_cf_onboarding',
            'dominios_reseller_cf_runs',
            'dominios_reseller_cf_presets',
            'dominios_reseller_cf_onboarding_logs'
        ];

        foreach ($tables as $table) {
            $table_name = $wpdb->prefix . $table;
            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
            $output .= "   - $table: " . ($exists ? "✅" : "❌") . "\n";
        }

        $output .= "\n";

        // Verificar presets
        $output .= "2. PRESETS DISPONIBLES:\n";
        try {
            $presets = Dominios_Reseller_Onboarding_DB::get_all_presets();
            $output .= "   - Total presets: " . count($presets) . "\n";
            foreach ($presets as $preset) {
                $output .= "     * {$preset['preset_key']}: {$preset['name']}\n";
            }
        } catch (Exception $e) {
            $output .= "   ❌ Error obteniendo presets: " . $e->getMessage() . "\n";
        }

        $output .= "\n";

        // Verificar clases
        $output .= "3. CLASES DISPONIBLES:\n";
        $classes = [
            'Dominios_Reseller_Onboarding_DB',
            'Dominios_Reseller_Onboarding_Worker'
        ];

        foreach ($classes as $class) {
            $output .= "   - $class: " . (class_exists($class) ? "✅" : "❌") . "\n";
        }

        return $output;
    }

    /**
     * Test: Encolado
     */
    private function test_enqueue(): string {
        $output = "=== TEST DE ENCOLADO ===\n\n";

        $test_domain = 'test-' . time() . '.com';
        $test_preset = 'wp'; // Usar preset por defecto

        try {
            $worker = Dominios_Reseller_Onboarding_Worker::get_instance();
            $result = $worker->enqueue($test_domain, $test_preset, false);

            $output .= "Dominio: $test_domain\n";
            $output .= "Preset: $test_preset\n";
            $output .= "Resultado: " . ($result['success'] ? "✅ ÉXITO" : "❌ ERROR") . "\n";

            if ($result['success']) {
                $output .= "Run ID: {$result['run_id']}\n";
                $output .= "Mensaje: {$result['message']}\n";
            } else {
                $output .= "Error: {$result['error']}\n";
            }
        } catch (Exception $e) {
            $output .= "❌ Excepción: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Eventos cron
     */
    private function test_cron_events(): string {
        $output = "=== EVENTOS PROGRAMADOS ===\n\n";

        try {
            $events = _get_cron_array();
            $onboarding_events = [];

            foreach ($events as $timestamp => $hooks) {
                foreach ($hooks as $hook => $hook_events) {
                    if (strpos($hook, 'dr_onboarding') !== false) {
                        foreach ($hook_events as $event) {
                            $onboarding_events[] = [
                                'hook' => $hook,
                                'timestamp' => $timestamp,
                                'args' => $event['args'] ?? []
                            ];
                        }
                    }
                }
            }

            $output .= "Eventos de onboarding encontrados: " . count($onboarding_events) . "\n\n";

            foreach ($onboarding_events as $event) {
                $time_diff = $event['timestamp'] - time();
                $output .= "• {$event['hook']}\n";
                $output .= "  Programado: " . ($time_diff > 0 ? "+{$time_diff}s" : "{$time_diff}s") . "\n";
                if (!empty($event['args'])) {
                    $output .= "  Args: " . implode(', ', $event['args']) . "\n";
                }
                $output .= "\n";
            }

            if (empty($onboarding_events)) {
                $output .= "❌ No se encontraron eventos de onboarding programados\n";
            }

        } catch (Exception $e) {
            $output .= "❌ Error obteniendo eventos: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Crear preset
     */
    private function test_create_preset(): string {
        $output = "=== CREAR PRESET DE TEST ===\n\n";

        // Payload simplificado
        $payload = [
            'version' => '3.0',
            'settings' => [
                'ssl' => 'full',
                'cache_level' => 'aggressive'
            ]
        ];

        try {
            global $wpdb;
            $table = Dominios_Reseller_Onboarding_DB::get_presets_table();

            $result = $wpdb->insert($table, [
                'preset_key' => 'debug-test',
                'name' => 'Preset de Debug',
                'description' => 'Preset creado desde debug hub',
                'payload' => json_encode($payload),
                'is_default' => 0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ]);

            if ($result) {
                $output .= "✅ Preset 'debug-test' creado exitosamente\n";
            } else {
                $output .= "❌ Error creando preset: " . $wpdb->last_error . "\n";
            }

        } catch (Exception $e) {
            $output .= "❌ Excepción: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Limpiar datos de test
     */
    private function test_cleanup(): string {
        $output = "=== LIMPIAR DATOS DE TEST ===\n\n";

        try {
            global $wpdb;

            // Limpiar runs de test
            $runs_table = Dominios_Reseller_Onboarding_DB::get_runs_table();
            $deleted_runs = $wpdb->query("DELETE FROM $runs_table WHERE primary_domain LIKE 'test-%'");

            // Limpiar logs de test
            $logs_table = Dominios_Reseller_Onboarding_DB::get_logs_table();
            $deleted_logs = $wpdb->query("DELETE FROM $logs_table WHERE primary_domain LIKE 'test-%'");

            $output .= "✅ Runs eliminados: $deleted_runs\n";
            $output .= "✅ Logs eliminados: $deleted_logs\n";

        } catch (Exception $e) {
            $output .= "❌ Error limpiando: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Estadísticas del sistema
     */
    private function test_system_stats(): string {
        $output = "=== ESTADÍSTICAS DEL SISTEMA ===\n\n";

        try {
            global $wpdb;

            // Contar runs por estado
            $runs_table = Dominios_Reseller_Onboarding_DB::get_runs_table();
            $run_stats = $wpdb->get_results("SELECT state, COUNT(*) as count FROM $runs_table GROUP BY state");

            $output .= "RUNS POR ESTADO:\n";
            foreach ($run_stats as $stat) {
                $output .= "   - {$stat->state}: {$stat->count}\n";
            }

            $output .= "\n";

            // Contar logs recientes
            $logs_table = Dominios_Reseller_Onboarding_DB::get_logs_table();
            $log_count = $wpdb->get_var("SELECT COUNT(*) FROM $logs_table WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
            $output .= "LOGS ÚLTIMA HORA: $log_count\n";

            // Eventos programados
            $events = _get_cron_array();
            $event_count = 0;
            foreach ($events as $hooks) {
                foreach ($hooks as $hook_events) {
                    $event_count += count($hook_events);
                }
            }
            $output .= "EVENTOS PROGRAMADOS: $event_count\n";

        } catch (Exception $e) {
            $output .= "❌ Error obteniendo stats: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Crear tablas faltantes
     */
    private function test_create_tables(): string {
        $output = "=== CREANDO TABLAS DE ONBOARDING ===\n\n";

        try {
            Dominios_Reseller_Onboarding_DB::create_tables();
            $output .= "✅ Tablas creadas exitosamente\n\n";

            // Verificar que existen
            global $wpdb;

            $tables = [
                'onboarding' => Dominios_Reseller_Onboarding_DB::get_onboarding_table(),
                'runs' => Dominios_Reseller_Onboarding_DB::get_runs_table(),
                'presets' => Dominios_Reseller_Onboarding_DB::get_presets_table(),
                'logs' => Dominios_Reseller_Onboarding_DB::get_logs_table()
            ];

            $output .= "=== VERIFICACIÓN DE TABLAS ===\n";
            foreach ($tables as $name => $table) {
                $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
                $output .= "$name: " . ($exists ? "✅ EXISTE" : "❌ NO EXISTE") . " ($table)\n";
            }

            // Verificar presets
            $presets = Dominios_Reseller_Onboarding_DB::get_all_presets();
            $output .= "\n=== PRESETS INSTALADOS ===\n";
            $output .= "Total presets: " . count($presets) . "\n";
            foreach ($presets as $preset) {
                $output .= "- {$preset['preset_key']}: {$preset['name']}\n";
            }

        } catch (Exception $e) {
            $output .= "❌ Error creando tablas: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Logs recientes
     */
    private function test_recent_logs(): string {
        $output = "=== LOGS RECIENTES ===\n\n";

        try {
            global $wpdb;
            $logs_table = Dominios_Reseller_Onboarding_DB::get_logs_table();

            $logs = $wpdb->get_results(
                "SELECT * FROM $logs_table ORDER BY created_at DESC LIMIT 10",
                ARRAY_A
            );

            if (empty($logs)) {
                $output .= "❌ No se encontraron logs\n";
            } else {
                foreach ($logs as $log) {
                    $output .= "[" . date('H:i:s', strtotime($log['created_at'])) . "] ";
                    $output .= strtoupper($log['level']) . ": ";
                    $output .= "{$log['step']} - {$log['message']}\n";
                    $output .= "   Dominio: {$log['primary_domain']}\n";
                    if (!empty($log['data'])) {
                        $data = json_decode($log['data'], true);
                        if ($data) {
                            $output .= "   Datos: " . json_encode($data, JSON_PRETTY_PRINT) . "\n";
                        }
                    }
                    $output .= "\n";
                }
            }

        } catch (Exception $e) {
            $output .= "❌ Error obteniendo logs: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Diagnóstico Openprovider
     */
    private function test_openprovider_diagnostic(): string {
        $output = "=== DIAGNÓSTICO OPENPROVIDER ===\n\n";

        try {
            if (!class_exists('Dominios_Reseller_Openprovider_Service')) {
                $output .= "❌ Servicio Openprovider no disponible\n";
                return $output;
            }

            $op_service = Dominios_Reseller_Openprovider_Service::get_instance();

            // Verificar configuración
            $configured = $op_service->is_configured();
            $output .= "Configurado: " . ($configured ? "✅ Sí" : "❌ No") . "\n";

            if (!$configured) {
                $output .= "❌ Openprovider no configurado - verifica credenciales\n";
                return $output;
            }

            // Verificar dominio carani.es
            $domain_check = $op_service->domain_exists('carani.es');
            $output .= "\n=== ESTADO DOMINIO carani.es ===\n";
            $output .= "Existe: " . ($domain_check['exists'] ? "✅ Sí" : "❌ No") . "\n";

            if ($domain_check['exists'] && isset($domain_check['info'])) {
                $info = $domain_check['info'];
                $output .= "ID: " . ($info['id'] ?? 'N/A') . "\n";
                $output .= "Estado: " . ($info['status'] ?? 'N/A') . "\n";
                $output .= "Bloqueado: " . (($info['is_locked'] ?? false) ? "✅ Sí" : "❌ No") . "\n";
                $output .= "Puede cambiar NS: " . (($info['can_change_ns'] ?? true) ? "✅ Sí" : "❌ No") . "\n";

                if (isset($info['name_servers']) && is_array($info['name_servers'])) {
                    $output .= "NS actuales:\n";
                    foreach ($info['name_servers'] as $ns) {
                        $output .= "  - " . ($ns['name'] ?? 'N/A') . "\n";
                    }
                }

                // Advertencia específica para .es
                if (strpos('carani.es', '.es') !== false) {
                    $output .= "\n⚠️  IMPORTANTE PARA .ES:\n";
                    $output .= "Los NS de Cloudflare pueden requerir autorización especial del registro español (Red.es).\n";
                    $output .= "Si la actualización automática falla, configura manualmente:\n";
                    $output .= "  - doug.ns.cloudflare.com\n";
                    $output .= "  - nia.ns.cloudflare.com\n";
                    $output .= "O contacta a Openprovider para autorizar estos NS.\n";
                }
            } elseif ($domain_check['error']) {
                $output .= "Error: " . $domain_check['error'] . "\n";
            }

            // Intentar obtener info detallada
            $domain_info = $op_service->get_domain_info('carani.es');
            if (!is_wp_error($domain_info)) {
                $output .= "\n=== INFO DETALLADA ===\n";
                $output .= json_encode($domain_info, JSON_PRETTY_PRINT) . "\n";
            } else {
                $output .= "\n❌ Error obteniendo info detallada: " . $domain_info->get_error_message() . "\n";
            }

        } catch (Exception $e) {
            $output .= "❌ Error en diagnóstico: " . $e->getMessage() . "\n";
        }

        return $output;
    }

    /**
     * Test: Actualizar presets existentes
     */
    private function test_update_presets(): string {
        $output = "=== ACTUALIZAR PRESETS ===\n\n";

        try {
            if (!class_exists('Dominios_Reseller_Onboarding_DB')) {
                $output .= "❌ Clase Dominios_Reseller_Onboarding_DB no disponible\n";
                return $output;
            }

            Dominios_Reseller_Onboarding_DB::update_existing_presets();
            $output .= "✅ Presets actualizados correctamente\n";

            // Verificar presets después de la actualización
            $presets = Dominios_Reseller_Onboarding_DB::get_all_presets();
            $output .= "\n=== PRESETS DESPUÉS DE ACTUALIZACIÓN ===\n";
            foreach ($presets as $preset) {
                $payload = json_decode($preset['payload'], true);
                $version = $payload['version'] ?? 'N/A';
                $output .= "- {$preset['preset_key']}: {$preset['name']} (v{$version})\n";
            }

        } catch (Exception $e) {
            $output .= "❌ Error actualizando presets: " . $e->getMessage() . "\n";
        }

        return $output;
    }

// Inicializar
add_action('plugins_loaded', function() {
    if (class_exists('Dominios_Reseller_Onboarding_DB')) {
        Dominios_Reseller_Debug_Hub::get_instance();
    }
});

// AJAX handler
add_action('wp_ajax_dr_debug_test', function() {
    Dominios_Reseller_Debug_Hub::get_instance()->run_ajax_test();
});

// AJAX handler para encolado manual
add_action('wp_ajax_dr_debug_manual_enqueue', function() {
    check_ajax_referer('dr_debug_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die('No tienes permisos');
    }

    $domain = sanitize_text_field($_POST['domain'] ?? '');
    $preset = sanitize_text_field($_POST['preset'] ?? 'wp');
    $auto_ns = (int) ($_POST['auto_ns'] ?? 0);

    if (empty($domain)) {
        wp_send_json_error('Dominio requerido');
        return;
    }

    try {
        $worker = Dominios_Reseller_Onboarding_Worker::get_instance();
        $result = $worker->enqueue($domain, $preset, (bool) $auto_ns);

        if ($result['success']) {
            wp_send_json_success("✅ Dominio encolado exitosamente\nRun ID: {$result['run_id']}\nMensaje: {$result['message']}");
        } else {
            wp_send_json_error("❌ Error al encolar dominio\n{$result['error']}");
        }
    } catch (Exception $e) {
        wp_send_json_error('❌ Excepción: ' . $e->getMessage());
    }
});

// AJAX handler para verificar estado de dominio
add_action('wp_ajax_dr_debug_check_status', function() {
    check_ajax_referer('dr_debug_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die('No tienes permisos');
    }

    $domain = sanitize_text_field($_POST['domain'] ?? '');

    if (empty($domain)) {
        wp_send_json_error('Dominio requerido');
        return;
    }

    try {
        $state = Dominios_Reseller_Onboarding_DB::get_onboarding_state($domain);

        if (!$state) {
            wp_send_json_error("❌ Dominio no encontrado en el sistema de onboarding");
            return;
        }

        $output = "📊 Estado del dominio: {$domain}\n\n";
        $output .= "Estado actual: {$state['state']}\n";
        $output .= "Preset: {$state['preset_key']}\n";
        $output .= "NS Automático: " . ($state['auto_update_ns'] ? 'Sí' : 'No') . "\n";
        $output .= "Última actualización: {$state['updated_at']}\n";

        if (!empty($state['last_error'])) {
            $output .= "Último error: {$state['last_error']}\n";
        }

        // Determinar acciones disponibles
        $actions = ['can_retry' => false, 'can_update' => false];

        if (in_array($state['state'], ['error', 'failed', 'needs_manual_ns', 'partial'])) {
            $actions['can_retry'] = true;
        }

        if (in_array($state['state'], ['onboarded', 'completed'])) {
            $actions['can_update'] = true;
        }

        wp_send_json_success($output, $actions);
    } catch (Exception $e) {
        wp_send_json_error('❌ Excepción: ' . $e->getMessage());
    }
});

// AJAX handler para reintentar dominio
add_action('wp_ajax_dr_debug_retry_domain', function() {
    check_ajax_referer('dr_debug_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die('No tienes permisos');
    }

    $domain = sanitize_text_field($_POST['domain'] ?? '');

    if (empty($domain)) {
        wp_send_json_error('Dominio requerido');
        return;
    }

    try {
        $worker = Dominios_Reseller_Onboarding_Worker::get_instance();
        $result = $worker->retry($domain);

        if ($result['success']) {
            wp_send_json_success("✅ Dominio re-encolado exitosamente\nRun ID: {$result['run_id']}\nMensaje: {$result['message']}");
        } else {
            wp_send_json_error("❌ Error al re-encolar dominio\n{$result['error']}");
        }
    } catch (Exception $e) {
        wp_send_json_error('❌ Excepción: ' . $e->getMessage());
    }
});

// AJAX handler para actualizar configuración
add_action('wp_ajax_dr_debug_update_config', function() {
    check_ajax_referer('dr_debug_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_die('No tienes permisos');
    }

    $domain = sanitize_text_field($_POST['domain'] ?? '');
    $preset = sanitize_text_field($_POST['preset'] ?? 'wp');

    if (empty($domain)) {
        wp_send_json_error('Dominio requerido');
        return;
    }

    try {
        $worker = Dominios_Reseller_Onboarding_Worker::get_instance();
        $result = $worker->update_config($domain, $preset, false); // Por defecto no auto-update NS en updates

        if ($result['success']) {
            wp_send_json_success("✅ Configuración actualizada exitosamente\nRun ID: {$result['run_id']}\nMensaje: {$result['message']}");
        } else {
            wp_send_json_error("❌ Error al actualizar configuración\n{$result['error']}");
        }
    } catch (Exception $e) {
        wp_send_json_error('❌ Excepción: ' . $e->getMessage());
    }
});