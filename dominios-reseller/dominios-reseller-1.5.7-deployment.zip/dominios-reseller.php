<?php
/*
Plugin Name: Dominios Reseller
Description: Certifica dominios ecológicos desde WHM, muestra árboles plantados y CO2 evitado. Integración con Cloudflare.
Version: 1.5.7
Author: Replanta
*/

define('DOMINIOS_RESELLER_VERSION', '1.5.7');

// Activar plugin: crear tabla si no existe
register_activation_hook(__FILE__, 'dominios_reseller_create_table');
function dominios_reseller_create_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'dominios_reseller';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        domain varchar(255) NOT NULL,
        server varchar(10) NOT NULL DEFAULT 'uk',
        trees_planted int(11) DEFAULT 0,
        co2_evaded decimal(10,2) DEFAULT 0,
        fecha_emision DATE DEFAULT NULL,
        validez DATE DEFAULT NULL,
        status varchar(20) DEFAULT 'Activo',
        primary_domain varchar(255) NOT NULL,
        is_primary tinyint(1) DEFAULT 1,
        startdate bigint(20) DEFAULT NULL,
        last_sync TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY domain_server (domain, server),
        KEY idx_domain (domain),
        KEY idx_server (server),
        KEY idx_status (status),
        KEY idx_primary (is_primary)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Actualizar tabla existente si es necesario
    dominios_reseller_upgrade_table();
    
    // Crear tabla de zonas Cloudflare
    dominios_reseller_create_cloudflare_table();
}

/**
 * Crear tabla de zonas Cloudflare
 */
function dominios_reseller_create_cloudflare_table() {
    // Cargar clase si no está cargada
    $class_file = plugin_dir_path(__FILE__) . 'includes/class-cloudflare-service.php';
    if (file_exists($class_file) && !class_exists('Dominios_Reseller_Cloudflare_Service')) {
        require_once $class_file;
    }
    if (class_exists('Dominios_Reseller_Cloudflare_Service')) {
        Dominios_Reseller_Cloudflare_Service::create_table();
    }
    
    // Crear tablas de onboarding
    dominios_reseller_create_onboarding_tables();
}

/**
 * Crear tablas de onboarding (Fase 2)
 */
function dominios_reseller_create_onboarding_tables() {
    $class_file = plugin_dir_path(__FILE__) . 'includes/class-onboarding-db.php';
    if (file_exists($class_file) && !class_exists('Dominios_Reseller_Onboarding_DB')) {
        require_once $class_file;
    }
    if (class_exists('Dominios_Reseller_Onboarding_DB')) {
        Dominios_Reseller_Onboarding_DB::create_tables();
        // Actualizar presets existentes con nuevas versiones
        Dominios_Reseller_Onboarding_DB::update_existing_presets();
    }
}

// Función para actualizar tabla en versiones existentes
function dominios_reseller_upgrade_table() {
    global $wpdb;
    $table = $wpdb->prefix . 'dominios_reseller';
    
    // Añadir columna server si no existe
    $row = $wpdb->get_results("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
                                WHERE table_name = '$table' AND column_name = 'server'");
    if(empty($row)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN server varchar(10) NOT NULL DEFAULT 'uk' AFTER domain");
        
        // Eliminar índice UNIQUE anterior si existe
        $wpdb->query("ALTER TABLE $table DROP INDEX domain, ADD KEY idx_domain_old (domain)");
        
        // Añadir nuevo índice único compuesto (domain + server)
        // Primero verificar que no haya duplicados
        $duplicates = $wpdb->get_results("
            SELECT domain, server, COUNT(*) as count 
            FROM $table 
            GROUP BY domain, server 
            HAVING count > 1
        ");
        
        if (!empty($duplicates)) {
            // Eliminar duplicados dejando el más reciente
            foreach ($duplicates as $dup) {
                $wpdb->query($wpdb->prepare("
                    DELETE t1 FROM $table t1
                    INNER JOIN $table t2 
                    WHERE t1.id < t2.id 
                    AND t1.domain = %s 
                    AND t1.server = %s
                ", $dup->domain, $dup->server));
            }
        }
        
        // Ahora sí añadir el índice único
        $wpdb->query("ALTER TABLE $table ADD UNIQUE KEY domain_server (domain, server)");
        $wpdb->query("ALTER TABLE $table ADD KEY idx_server (server)");
    }
    
    // Cambiar co2_evaded a DECIMAL para mayor precisión
    $wpdb->query("ALTER TABLE $table MODIFY co2_evaded decimal(10,2) DEFAULT 0");
    
    // Añadir last_sync si no existe
    $row = $wpdb->get_results("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
                                WHERE table_name = '$table' AND column_name = 'last_sync'");
    if(empty($row)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN last_sync TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER startdate");
    }
}

// ✅ OPTIMIZACIÓN: Upgrade solo en admin (evita ejecución en frontend)
add_action('admin_init', function() {
    $current_version = get_option('dominios_reseller_db_version', '0');
    if (version_compare($current_version, '1.2.0', '<')) {
        dominios_reseller_upgrade_table();
        update_option('dominios_reseller_db_version', '1.2.0');
    }
});

// AJAX handler para guardar cambios de árboles y CO2
add_action('wp_ajax_dr_save_domain_data', function() {
    check_ajax_referer('dr_admin_nonce', '_nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permisos insuficientes');
    }
    
    $domain = sanitize_text_field($_POST['domain'] ?? '');
    $server = sanitize_text_field($_POST['server'] ?? '');
    $trees = intval($_POST['trees'] ?? 0);
    $co2 = floatval($_POST['co2'] ?? 0);
    
    if (empty($domain) || empty($server)) {
        wp_send_json_error('Datos incompletos');
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'dominios_reseller';
    
    $result = $wpdb->update(
        $table,
        [
            'trees_planted' => $trees,
            'co2_evaded' => $co2
        ],
        [
            'domain' => $domain,
            'server' => $server
        ],
        ['%d', '%f'],
        ['%s', '%s']
    );
    
    if ($result === false) {
        wp_send_json_error('Error al guardar: ' . $wpdb->last_error);
    }
    
    wp_send_json_success(['message' => 'Datos guardados correctamente']);
});

// AJAX handler para guardar múltiples cambios
add_action('wp_ajax_dr_save_bulk_domain_data', function() {
    check_ajax_referer('dr_admin_nonce', '_nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permisos insuficientes');
    }
    
    $changes = $_POST['changes'] ?? [];
    if (empty($changes) || !is_array($changes)) {
        wp_send_json_error('No hay cambios para guardar');
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'dominios_reseller';
    $updated = 0;
    $errors = [];
    
    foreach ($changes as $change) {
        $domain = sanitize_text_field($change['domain'] ?? '');
        $server = sanitize_text_field($change['server'] ?? '');
        $trees = intval($change['trees'] ?? 0);
        $co2 = floatval($change['co2'] ?? 0);
        
        if (empty($domain) || empty($server)) {
            $errors[] = "Datos incompletos para $domain";
            continue;
        }
        
        $result = $wpdb->update(
            $table,
            [
                'trees_planted' => $trees,
                'co2_evaded' => $co2
            ],
            [
                'domain' => $domain,
                'server' => $server
            ],
            ['%d', '%f'],
            ['%s', '%s']
        );
        
        if ($result === false) {
            $errors[] = "Error al guardar $domain: " . $wpdb->last_error;
        } else {
            $updated++;
        }
    }
    
    wp_send_json_success([
        'message' => "Guardados $updated dominios correctamente" . (count($errors) > 0 ? '. Errores: ' . count($errors) : ''),
        'updated' => $updated,
        'errors' => $errors
    ]);
});

/**
 * Función PRO: Sincroniza dominios desde WHM a base de datos local
 * Esta es la función CENTRAL que reemplaza todas las consultas directas a WHM
 * @param string $server 'uk' o 'usa'
 * @param string $token Token de WHM
 * @return array Resultado de la sincronización
 */
function dominios_reseller_sync_from_whm($server, $token) {
    if (empty($token)) {
        return ['success' => false, 'error' => 'Token vacío'];
    }
    
    global $wpdb;
    $tabla = $wpdb->prefix . 'dominios_reseller';
    
    // Obtener cuentas desde WHM
    $cuentas = obtener_cuentas_whm($token, $server);
    if (!$cuentas || empty($cuentas['data']['acct'])) {
        return ['success' => false, 'error' => 'No se obtuvieron cuentas de WHM'];
    }
    
    $inserted = 0;
    $updated = 0;
    $deleted = 0;
    
    // Recopilar todos los dominios que existen en WHM (principales + addons)
    $dominios_en_whm = [];
    
    foreach ($cuentas['data']['acct'] as $cuenta) {
        $dominio = sanitize_text_field($cuenta['domain']);
        $dominios_en_whm[] = $dominio;
        
        $startdate = intval($cuenta['unix_startdate']);
        $status = $cuenta['suspended'] ? 'Suspendido' : 'Activo';
        $fecha_emision = date('Y-m-d', $startdate);
        $validez = date('Y-m-d', strtotime("$fecha_emision +1 year"));
        
        // Verificar si existe (por domain + server)
        $existe = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $tabla WHERE domain = %s AND server = %s",
            $dominio, $server
        ));
        
        if ($existe) {
            // Actualizar solo campos de WHM (no tocar trees_planted ni co2_evaded)
            $wpdb->update($tabla, [
                'status' => $status,
                'startdate' => $startdate,
                'fecha_emision' => $fecha_emision,
                'validez' => $validez
            ], [
                'domain' => $dominio,
                'server' => $server
            ]);
            $updated++;
        } else {
            // Insertar nuevo dominio
            $wpdb->insert($tabla, [
                'domain' => $dominio,
                'server' => $server,
                'status' => $status,
                'startdate' => $startdate,
                'fecha_emision' => $fecha_emision,
                'validez' => $validez,
                'primary_domain' => $dominio,
                'is_primary' => 1,
                'trees_planted' => 0,
                'co2_evaded' => 0
            ]);
            $inserted++;
        }
        
        // Procesar addons
        $addons = obtener_addons_de_usuario($cuenta['user'], $token, $server);
        if (is_array($addons)) {
            foreach ($addons as $addon) {
                if (!is_array($addon) || !isset($addon['domain'])) continue;
                
                $addon_domain = sanitize_text_field($addon['domain']);
                $dominios_en_whm[] = $addon_domain; // Añadir addon a la lista
                
                $existe_addon = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $tabla WHERE domain = %s AND server = %s",
                    $addon_domain, $server
                ));
                
                if ($existe_addon) {
                    $wpdb->update($tabla, [
                        'status' => 'Addon',
                        'startdate' => $startdate,
                        'fecha_emision' => $fecha_emision,
                        'validez' => $validez
                    ], [
                        'domain' => $addon_domain,
                        'server' => $server
                    ]);
                    $updated++;
                } else {
                    $wpdb->insert($tabla, [
                        'domain' => $addon_domain,
                        'server' => $server,
                        'status' => 'Addon',
                        'startdate' => $startdate,
                        'fecha_emision' => $fecha_emision,
                        'validez' => $validez,
                        'primary_domain' => $dominio,
                        'is_primary' => 0,
                        'trees_planted' => 0,
                        'co2_evaded' => 0
                    ]);
                    $inserted++;
                }
            }
        }
    }
    
    // LIMPIEZA: Eliminar dominios de este servidor que ya no existen en WHM
    $dominios_en_db = $wpdb->get_col($wpdb->prepare(
        "SELECT domain FROM $tabla WHERE server = %s",
        $server
    ));
    
    $dominios_a_eliminar = array_diff($dominios_en_db, $dominios_en_whm);
    
    foreach ($dominios_a_eliminar as $dominio_borrar) {
        $wpdb->delete($tabla, [
            'domain' => $dominio_borrar,
            'server' => $server
        ]);
        $deleted++;
        error_log("[Dominios Reseller] Dominio eliminado de DB (ya no existe en WHM): $dominio_borrar ($server)");
    }
    
    return [
        'success' => true,
        'inserted' => $inserted,
        'updated' => $updated,
        'deleted' => $deleted,
        'total' => count($cuentas['data']['acct'])
    ];
}

// Incluir archivos del plugin
foreach ([
    'includes/whm-functions.php',
    'includes/emisiones-functions.php',
    'includes/ajax-handlers.php',
    'includes/shortcodes.php',
    'includes/scripts.php',
    'includes/rest-api.php',
    'includes/class-cloudflare-service.php',
    'includes/cloudflare-admin.php',
    'includes/cloudflare-cron.php',
    // Fase 2: Onboarding Cloudflare
    'includes/class-onboarding-db.php',
    'includes/class-onboarding-worker.php',
    'includes/class-openprovider-service.php',
    'includes/class-onboarding-admin.php',
    'includes/class-presets-admin.php',
    'includes/class-debug-hub.php',
] as $file) {
    $path = plugin_dir_path(__FILE__) . $file;
    if (file_exists($path)) require_once $path;
}

// Registrar página del plugin en el admin
add_action('admin_menu', function () {
    add_menu_page(
        'Dominios Reseller',
        'Dominios Reseller',
        'manage_options',
        'dominios-reseller',
        'dominios_reseller_admin_page',
        'dashicons-cloud',
        56
    );
    
    // Submenu de diagnóstico (oculto, solo accesible por URL)
    add_submenu_page(
        null, // No aparece en menú
        'Diagnóstico',
        'Diagnóstico',
        'manage_options',
        'dominios-reseller-diagnostic',
        'dominios_reseller_diagnostic_page'
    );
});

// Cargar assets inline como fallback - SIEMPRE
function dominios_reseller_inline_assets() {
    // Generar nonce para AJAX
    $dr_nonce = wp_create_nonce('dr_admin_nonce');
    
    // Forzar carga inline para desarrollo rápido
    echo '<style id="dominios-reseller-inline-css">
    /* Dominios Reseller Inline CSS v1.5.0 - Estilo Replanta */
    .dominios-reseller-admin {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, sans-serif;
        max-width: none;
        margin: 20px 20px 20px 0;
    }
    
    /* Notices fuera de la cabecera */
    .dominios-reseller-admin .dr-notices {
        margin-bottom: 15px;
    }
    .dominios-reseller-admin .dr-notices .notice {
        margin: 0 0 10px 0;
    }
    
    /* Header Replanta Style */
    .dr-header {
        background: linear-gradient(135deg, #166534 0%, #15803d 50%, #22c55e 100%);
        border-radius: 16px 16px 0 0;
        padding: 0;
        position: relative;
        overflow: hidden;
    }
    .dr-header::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.05\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        opacity: 0.5;
    }
    .dr-header-content {
        position: relative;
        z-index: 1;
        padding: 30px 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 20px;
    }
    .dr-header-left {
        display: flex;
        align-items: center;
        gap: 20px;
    }
    .dr-logo {
        width: 60px;
        height: 60px;
        background: rgba(255,255,255,0.15);
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(10px);
    }
    .dr-logo svg {
        width: 36px;
        height: 36px;
        fill: white;
    }
    .dr-header-text h1 {
        margin: 0 0 5px 0;
        font-size: 1.8em;
        font-weight: 700;
        color: white;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .dr-header-text .dr-tagline {
        margin: 0;
        font-size: 0.95em;
        color: rgba(255,255,255,0.9);
        font-weight: 400;
    }
    .dr-header-stats {
        display: flex;
        gap: 25px;
    }
    .dr-stat {
        text-align: center;
        background: rgba(255,255,255,0.1);
        padding: 12px 20px;
        border-radius: 12px;
        backdrop-filter: blur(10px);
    }
    .dr-stat-value {
        font-size: 1.6em;
        font-weight: 700;
        color: white;
        line-height: 1.2;
    }
    .dr-stat-label {
        font-size: 0.75em;
        color: rgba(255,255,255,0.8);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    /* Main container */
    .dr-main {
        background: #f8fafc;
        border-radius: 0 0 16px 16px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        overflow: hidden;
    }
    
    .server-tabs {
        background: white;
        min-height: 600px;
    }
    .tab-buttons {
        display: flex;
        background: white;
        border-bottom: 1px solid #e2e8f0;
        margin: 0;
        padding: 0 20px;
        gap: 5px;
    }
    .tab-button {
        background: transparent;
        border: none;
        border-bottom: 3px solid transparent;
        color: #64748b;
        cursor: pointer;
        font-size: 14px;
        font-weight: 600;
        padding: 16px 20px;
        transition: all 0.2s ease;
        white-space: nowrap;
        margin-bottom: -1px;
    }
    .tab-button:hover {
        background: #f1f5f9;
        color: #166534;
    }
    .tab-button.active {
        background: transparent;
        border-bottom-color: #22c55e;
        color: #166534;
    }
    .tab-pane {
        display: none;
        min-height: 500px;
        padding: 30px;
    }
    .tab-pane.active {
        display: block;
    }
    .unified-domains-table,
    .domains-table {
        background: white;
        border-collapse: collapse;
        border-radius: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        overflow: hidden;
        width: 100%;
    }
    .unified-domains-table thead,
    .domains-table thead {
        background: linear-gradient(135deg, #166534 0%, #15803d 100%);
        color: white;
    }
    .unified-domains-table th,
    .domains-table th {
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.5px;
        padding: 14px 12px;
        text-align: left;
        text-transform: uppercase;
    }
    .unified-domains-table td,
    .domains-table td {
        border-bottom: 1px solid #f1f5f9;
        padding: 12px;
        vertical-align: middle;
    }
    .suspended-row {
        background-color: #fef2f2 !important;
        border-left: 4px solid #ef4444 !important;
    }
    .server-badge {
        border-radius: 6px;
        display: inline-block;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.5px;
        padding: 4px 10px;
        text-transform: uppercase;
    }
    .server-uk {
        background: #dbeafe;
        color: #1e40af;
    }
    .server-usa {
        background: #fee2e2;
        color: #991b1b;
    }
    .status-badge {
        border-radius: 6px;
        display: inline-block;
        font-size: 11px;
        font-weight: 600;
        padding: 4px 10px;
        text-transform: uppercase;
    }
    .status-active {
        background: #dcfce7;
        color: #166534;
    }
    .status-suspended {
        background: #fee2e2;
        color: #991b1b;
    }
    .filter-controls {
        align-items: center;
        display: flex;
        gap: 15px;
        margin-bottom: 20px;
        flex-wrap: wrap;
    }
    .filter-select {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 14px;
        min-width: 150px;
        padding: 10px 14px;
        transition: border-color 0.2s;
    }
    .filter-select:focus {
        border-color: #22c55e;
        outline: none;
    }
    .save-all-unified, .refresh-unified {
        border: none;
        border-radius: 8px;
        color: white;
        cursor: pointer;
        font-weight: 600;
        margin-right: 10px;
        padding: 12px 24px;
        transition: transform 0.1s, box-shadow 0.2s;
    }
    .save-all-unified:hover, .refresh-unified:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .save-all-unified {
        background: linear-gradient(135deg, #166534 0%, #22c55e 100%);
    }
    .refresh-unified {
        background: #64748b;
    }
    
    /* Server section headers */
    .server-section .server-header h3 {
        color: #166534;
        font-size: 1.2em;
        margin: 0 0 15px 0;
    }
    .server-section .server-header h3 small {
        color: #64748b;
        font-weight: 400;
    }
    
    /* Form settings estilo */
    .form-table th {
        color: #334155;
        font-weight: 600;
    }
    .form-table input[type="text"],
    .form-table input[type="password"] {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 10px 14px;
    }
    .form-table input[type="text"]:focus,
    .form-table input[type="password"]:focus {
        border-color: #22c55e;
        box-shadow: 0 0 0 3px rgba(34,197,94,0.1);
        outline: none;
    }
    </style>';
    
    // JavaScript con nonce
    ?>
    <script id="dominios-reseller-inline-js">
    jQuery(document).ready(function($) {
        console.log("Dominios Reseller Inline JS v1.1.3 loaded");
        
        var drNonce = "<?php echo esc_js($dr_nonce); ?>";
        
        // Tabs functionality
        $(".tab-button").on("click", function() {
            var targetTab = $(this).data("tab");
            $(".tab-button").removeClass("active");
            $(".tab-pane").removeClass("active");
            $(this).addClass("active");
            $("#" + targetTab + "-tab").addClass("active");
        });
        
        // Filter functionality
        $("#server-filter, #status-filter").on("change", function() {
            var serverFilter = $("#server-filter").val();
            var statusFilter = $("#status-filter").val();
            
            // Filtrar tabla
            $("#unified-domains-table tbody tr").each(function() {
                var $row = $(this);
                var server = $row.data("server");
                var status = $row.data("status");
                var showRow = true;
                
                if (serverFilter && server !== serverFilter.toLowerCase()) {
                    showRow = false;
                }
                if (statusFilter && status !== statusFilter) {
                    showRow = false;
                }
                
                if (showRow) {
                    $row.show();
                } else {
                    $row.hide();
                }
            });
            
            // Filtrar cards
            $(".domain-card-pro").each(function() {
                var $card = $(this);
                var server = $card.data("server");
                var status = $card.data("status");
                var showCard = true;
                
                if (serverFilter && server !== serverFilter.toLowerCase()) {
                    showCard = false;
                }
                if (statusFilter && status !== statusFilter) {
                    showCard = false;
                }
                
                if (showCard) {
                    $card.show();
                } else {
                    $card.hide();
                }
            });
        });
        
        // View toggle functionality
        $("#view-table, #view-cards").on("click", function() {
            var view = $(this).attr("id").replace("view-", "");
            $(".view-btn").removeClass("active");
            $(this).addClass("active");
            
            if (view === "table") {
                $("#unified-domains-table").show();
                $(".unified-actions").show();
                $("#cards-view").hide();
            } else {
                $("#unified-domains-table").hide();
                $(".unified-actions").hide();
                $("#cards-view").show();
            }
        });
        
        // Refresh functionality
        $(".refresh-unified, .refresh-cards").on("click", function() {
            location.reload();
        });
        
        // Save functionality for unified table
        $(".save-all-unified").on("click", function() {
            var $btn = $(this);
            var changes = [];
            
            $("#unified-domains-table .trees-input, #unified-domains-table .co2-input").each(function() {
                var $input = $(this);
                var domain = $input.data("domain");
                var server = $input.data("server");
                var field = $input.hasClass("trees-input") ? "trees" : "co2";
                var value = field === "trees" ? parseInt($input.val()) : parseFloat($input.val());
                
                // Find existing change or create new one
                var existing = changes.find(function(c) { return c.domain === domain && c.server === server; });
                if (!existing) {
                    existing = { domain: domain, server: server, trees: 0, co2: 0 };
                    changes.push(existing);
                }
                existing[field] = value;
            });
            
            if (changes.length === 0) {
                alert("No hay cambios para guardar");
                return;
            }
            
            $btn.prop("disabled", true).text("💾 Guardando...");
            
            $.post(ajaxurl, {
                action: "dr_save_bulk_domain_data",
                _nonce: drNonce,
                changes: changes
            }, function(response) {
                $btn.prop("disabled", false).text("💾 Guardar todos los cambios");
                
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert("Error: " + (response.data || "Error desconocido"));
                }
            }).fail(function() {
                $btn.prop("disabled", false).text("💾 Guardar todos los cambios");
                alert("Error de conexión");
            });
        });
        
        // Save functionality for cards
        $(".save-all-cards").on("click", function() {
            var $btn = $(this);
            var changes = [];
            
            $(".domain-card-pro .trees-input-card, .domain-card-pro .co2-input-card").each(function() {
                var $input = $(this);
                var domain = $input.data("domain");
                var server = $input.data("server");
                var field = $input.hasClass("trees-input-card") ? "trees" : "co2";
                var value = field === "trees" ? parseInt($input.val()) : parseFloat($input.val());
                
                // Find existing change or create new one
                var existing = changes.find(function(c) { return c.domain === domain && c.server === server; });
                if (!existing) {
                    existing = { domain: domain, server: server, trees: 0, co2: 0 };
                    changes.push(existing);
                }
                existing[field] = value;
            });
            
            if (changes.length === 0) {
                alert("No hay cambios para guardar");
                return;
            }
            
            $btn.prop("disabled", true).text("💾 Guardando...");
            
            $.post(ajaxurl, {
                action: "dr_save_bulk_domain_data",
                _nonce: drNonce,
                changes: changes
            }, function(response) {
                $btn.prop("disabled", false).text("💾 Guardar todos los cambios");
                
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert("Error: " + (response.data || "Error desconocido"));
                }
            }).fail(function() {
                $btn.prop("disabled", false).text("💾 Guardar todos los cambios");
                alert("Error de conexión");
            });
        });
    });
    </script>
    <?php
}

function dominios_reseller_admin_page() {
    // Inyectar CSS y JS inline como fallback si los archivos no existen
    dominios_reseller_inline_assets();
    
    // Obtener estadísticas para la cabecera
    global $wpdb;
    $tabla = $wpdb->prefix . 'dominios_reseller';
    $total_domains = $wpdb->get_var("SELECT COUNT(*) FROM $tabla");
    $active_domains = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE status = 'Activo'");
    $uk_count = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE server = 'uk'");
    $usa_count = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE server = 'usa'");

    echo '<div class="wrap dominios-reseller-admin">';
    
    // Zona de notices (FUERA de la cabecera)
    echo '<div class="dr-notices">';
    
    // FIX TEMPORAL: Reparar registros con primary_domain NULL
    if (isset($_POST['fix_primary_domain'])) {
        $updated_primary = $wpdb->query("
            UPDATE $tabla 
            SET primary_domain = domain 
            WHERE primary_domain IS NULL 
            AND (status != 'Addon' OR status IS NULL)
        ");
        
        echo '<div class="notice notice-success"><p>✅ Se repararon ' . $updated_primary . ' dominios principales</p></div>';
        
        $remaining = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE primary_domain IS NULL");
        if ($remaining > 0) {
            echo '<div class="notice notice-warning"><p>⚠️ Quedan ' . $remaining . ' registros addon sin parent_domain asignado</p></div>';
        }
    }

    // Mostrar botón de reparación si hay registros con primary_domain NULL
    $null_count = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE primary_domain IS NULL");
    if ($null_count > 0) {
        echo '<div class="notice notice-error">';
        echo '<p><strong>⚠️ PROBLEMA DETECTADO:</strong> Hay ' . $null_count . ' dominios con primary_domain NULL que impiden el registro correcto.</p>';
        echo '<form method="post" style="display:inline;">';
        echo '<input type="hidden" name="fix_primary_domain" value="1">';
        echo '<button type="submit" class="button button-primary">🔧 Reparar Ahora</button>';
        echo '</form>';
        echo '</div>';
    }

    // Manejar test de conexión
    if (isset($_POST['test_whm_connection'])) {
        $server = sanitize_text_field($_POST['server'] ?? 'uk');
        $options = get_option('dominios_reseller_options');
        $token_key = $server . '_whm_token';
        $token = $options[$token_key] ?? '';

        if (empty($token)) {
            echo '<div class="notice notice-error"><p>❌ Error: Debes configurar primero el API Token de WHM para el servidor ' . strtoupper($server) . '.</p></div>';
        } else {
            echo '<div class="notice notice-info"><p>🔄 Probando conexión con WHM (' . strtoupper($server) . ')...</p></div>';
            $test_result = test_whm_connection($token, $server);

            if ($test_result['success']) {
                echo '<div class="notice notice-success"><p>✅ Conexión exitosa! Se encontraron ' . $test_result['count'] . ' cuentas en WHM (' . strtoupper($server) . ').</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>❌ Error de conexión: ' . esc_html($test_result['error']) . '</p></div>';
            }
        }
    }
    
    echo '</div>'; // Fin dr-notices
    
    // Nueva cabecera estilo Replanta
    echo '<div class="dr-header">';
    echo '<div class="dr-header-content">';
    echo '<div class="dr-header-left">';
    echo '<div class="dr-logo">';
    echo '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z"/></svg>';
    echo '</div>';
    echo '<div class="dr-header-text">';
    echo '<h1>Dominios Reseller</h1>';
    echo '<p class="dr-tagline">Gestión de dominios certificados ecológicos 🌱</p>';
    echo '</div>';
    echo '</div>';
    echo '<div class="dr-header-stats">';
    echo '<div class="dr-stat"><div class="dr-stat-value">' . intval($total_domains) . '</div><div class="dr-stat-label">Total Dominios</div></div>';
    echo '<div class="dr-stat"><div class="dr-stat-value">' . intval($active_domains) . '</div><div class="dr-stat-label">Activos</div></div>';
    echo '<div class="dr-stat"><div class="dr-stat-value">🇬🇧 ' . intval($uk_count) . '</div><div class="dr-stat-label">UK</div></div>';
    echo '<div class="dr-stat"><div class="dr-stat-value">🇺🇸 ' . intval($usa_count) . '</div><div class="dr-stat-label">USA</div></div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Main container
    echo '<div class="dr-main">';

    // Interfaz con pestañas
    echo '<div class="server-tabs">';
    echo '<div class="tab-buttons">';
    echo '<button class="tab-button active" data-tab="all">📊 Todos los Dominios</button>';
    echo '<button class="tab-button" data-tab="uk">🇬🇧 Servidor UK</button>';
    echo '<button class="tab-button" data-tab="usa">🇺🇸 Servidor USA</button>';
    echo '<button class="tab-button" data-tab="settings">⚙️ Configuración</button>';
    echo '</div>';

    // Contenido de pestañas
    echo '<div class="tab-content">';

    // Pestaña Todos los Dominios
    echo '<div id="all-tab" class="tab-pane active">';
    mostrar_todos_los_dominios_unificados();
    echo '</div>';

    // Pestaña UK
    echo '<div id="uk-tab" class="tab-pane">';
    mostrar_servidor_dominios('uk', 'UK (Europa)');
    echo '</div>';

    // Pestaña USA
    echo '<div id="usa-tab" class="tab-pane">';
    mostrar_servidor_dominios('usa', 'USA');
    echo '</div>';

    // Pestaña Configuración
    echo '<div id="settings-tab" class="tab-pane">';
    echo '<form method="post" action="options.php">';
    settings_fields('dominios_reseller_options_group');
    do_settings_sections('dominios-reseller');
    submit_button('Guardar configuración');
    echo '</form>';
    
    // Script para verificar conexión Openprovider
    $op_nonce = wp_create_nonce('dr_onboarding_admin');
    ?>
    <script>
    jQuery(document).ready(function($) {
        // Toggle cambio password Openprovider
        $('#dr-op-change-password').on('change', function() {
            var show = $(this).is(':checked');
            $('#dr-op-new-password-wrapper').toggle(show);
            if (show) {
                $('#dr-op-current-password').prop('disabled', true);
            } else {
                $('#dr-op-current-password').prop('disabled', false);
            }
        });
        
        // Verificar conexión Openprovider
        $('#dr-verify-openprovider').on('click', function() {
            var $btn = $(this);
            var $result = $('#dr-op-verify-result');
            
            $btn.prop('disabled', true);
            $result.html('⏳ Verificando...');
            
            $.post(ajaxurl, {
                action: 'dr_verify_openprovider',
                _nonce: '<?php echo $op_nonce; ?>'
            }, function(response) {
                $btn.prop('disabled', false);
                if (response.success) {
                    $result.html('<span style="color:green;">✅ ' + (response.data || 'Conexión exitosa') + '</span>');
                } else {
                    $result.html('<span style="color:red;">❌ ' + (response.data || 'Error desconocido') + '</span>');
                }
            }).fail(function(xhr, status, error) {
                $btn.prop('disabled', false);
                $result.html('<span style="color:red;">❌ Error de conexión: ' + error + '</span>');
            });
        });
    });
    </script>
    <?php
    echo '</div>';

    echo '</div>'; // Fin tab-content
    echo '</div>'; // Fin server-tabs
    echo '</div>'; // Fin dr-main
    echo '</div>'; // Fin wrap
}

// Función para mostrar tabla unificada de todos los dominios
function mostrar_todos_los_dominios_unificados() {
    global $wpdb;
    $tabla = $wpdb->prefix . 'dominios_reseller';
    $options = get_option('dominios_reseller_options');
    $uk_token = $options['uk_whm_token'] ?? '';
    $usa_token = $options['usa_whm_token'] ?? '';

    // Sincronizar dominios desde WHM si hay tokens configurados
    $sync_results = [];
    $total_deleted = 0;
    
    if (!empty($uk_token)) {
        $result = dominios_reseller_sync_from_whm('uk', $uk_token);
        $sync_results[] = 'UK';
        if ($result['success'] && isset($result['deleted'])) {
            $total_deleted += $result['deleted'];
        }
    }
    if (!empty($usa_token)) {
        $result = dominios_reseller_sync_from_whm('usa', $usa_token);
        $sync_results[] = 'USA';
        if ($result['success'] && isset($result['deleted'])) {
            $total_deleted += $result['deleted'];
        }
    }
    
    if (!empty($sync_results)) {
        $msg = '✅ Sincronizados servidores: ' . implode(', ', $sync_results);
        if ($total_deleted > 0) {
            $msg .= ' | <strong>🗑️ ' . $total_deleted . ' dominio(s) eliminado(s)</strong> (ya no existen en WHM)';
        }
        echo '<div class="notice notice-success"><p>' . $msg . '</p></div>';
    } else {
        echo '<div class="notice notice-warning"><p>⚠️ No hay tokens WHM configurados. Ve a Configuración para añadirlos.</p></div>';
        return;
    }

    // Obtener TODOS los dominios desde la base de datos local (objetos stdClass)
    $all_domains = $wpdb->get_results("SELECT * FROM $tabla ORDER BY server, domain");

    if (empty($all_domains)) {
        echo '<div class="notice notice-warning"><p>⚠️ No hay dominios en la base de datos. Los dominios se sincronizarán automáticamente al cargar esta página.</p></div>';
        return;
    }

    // Contar por servidor
    $uk_count = 0;
    $usa_count = 0;
    foreach ($all_domains as $d) {
        if (strtolower($d->server) === 'uk') $uk_count++;
        if (strtolower($d->server) === 'usa') $usa_count++;
    }
    
    echo '<div class="notice notice-info"><p>� Total: ' . count($all_domains) . ' dominios (UK: ' . $uk_count . ' | USA: ' . $usa_count . ')</p></div>';

    echo '<div class="domains-unified-container">';
    echo '<div class="unified-header">';
    echo '<h3>📊 Todos los Dominios (' . count($all_domains) . ' total)</h3>';
    echo '<div class="view-controls">';
    echo '<div class="view-toggle">';
    echo '<button id="view-table" class="view-btn active" title="Vista de tabla">📋 Tabla</button>';
    echo '<button id="view-cards" class="view-btn" title="Vista de cards PRO">🎴 Cards PRO</button>';
    echo '</div>';
    echo '<div class="filter-controls">';
    echo '<select id="server-filter" class="filter-select">';
    echo '<option value="">Todos los servidores</option>';
    echo '<option value="UK">🇬🇧 UK (Europa)</option>';
    echo '<option value="USA">🇺🇸 USA (América)</option>';
    echo '</select>';
    echo '<select id="status-filter" class="filter-select">';
    echo '<option value="">Todos los estados</option>';
    echo '<option value="Activo">✅ Activos</option>';
    echo '<option value="Suspendido">❌ Suspendidos</option>';
    echo '<option value="Addon">🔗 Addon Domains</option>';
    echo '</select>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

    // =====================================================
    // CLOUDFLARE: Preparar matching en batch (optimizado)
    // =====================================================
    $cf_service = class_exists('Dominios_Reseller_Cloudflare_Service') 
        ? Dominios_Reseller_Cloudflare_Service::get_instance() 
        : null;
    
    $has_cf_sync = $cf_service && $cf_service->has_sync_data();
    $cf_matches = [];
    
    if ($has_cf_sync) {
        // Extraer todos los primary_domain para batch matching
        $primary_domains = array_map(function($d) { 
            return $d->primary_domain ?? $d->domain; 
        }, $all_domains);
        $cf_matches = $cf_service->batch_match_domains($primary_domains);
    }
    
    // Estilos CSS para columna Cloudflare
    if (class_exists('Dominios_Reseller_Cloudflare_Admin')) {
        echo '<style>' . Dominios_Reseller_Cloudflare_Admin::get_cloudflare_styles() . '</style>';
    }

    // =====================================================
    // ESTILOS PARA VISTA DE CARDS PRO Y TOGGLE
    // =====================================================
    echo '<style>
    .view-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    .view-toggle {
        display: flex;
        gap: 5px;
        background: #f1f1f1;
        border-radius: 6px;
        padding: 3px;
    }
    .view-btn {
        padding: 8px 16px;
        border: none;
        background: transparent;
        border-radius: 4px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.2s;
    }
    .view-btn.active {
        background: #007cba;
        color: white;
        box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    }
    .view-btn:hover:not(.active) {
        background: #e0e0e0;
    }

    /* Cards PRO */
    .cards-view-container {
        margin-top: 20px;
    }
    .cards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 15px;
        margin-bottom: 20px;
    }
    .domain-card-pro {
        background: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        transition: all 0.2s;
    }
    .domain-card-pro:hover {
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        transform: translateY(-1px);
    }
    .domain-card-pro.status-active { border-left: 4px solid #28a745; }
    .domain-card-pro.status-suspended { border-left: 4px solid #dc3545; }
    .domain-card-pro.status-addon { border-left: 4px solid #ffc107; }

    .card-header {
        padding: 15px 15px 10px;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
    }
    .card-domain {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: #333;
        word-break: break-all;
    }
    .card-badges {
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
    }
    .badge {
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
    }
    .server-badge.server-uk { background: #007cba; color: white; }
    .server-badge.server-usa { background: #28a745; color: white; }
    .status-badge.status-activo { background: #28a745; color: white; }
    .status-badge.status-suspendido { background: #dc3545; color: white; }
    .status-badge.status-addon { background: #ffc107; color: black; }
    .cf-badge { background: #f39c12; color: white; }

    .card-body {
        padding: 15px;
    }
    .card-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
        font-size: 13px;
    }
    .card-row label {
        font-weight: 600;
        color: #666;
        min-width: 100px;
    }
    .card-row input {
        width: 80px;
        text-align: right;
        padding: 2px 4px;
        border: 1px solid #ddd;
        border-radius: 3px;
    }

    .card-actions {
        padding: 10px 15px 15px;
        border-top: 1px solid #eee;
        text-align: center;
    }
    .cards-actions {
        text-align: center;
        margin-top: 20px;
        padding-top: 15px;
        border-top: 1px solid #ddd;
    }
    </style>';
    // =====================================================

    echo '<table class="widefat fixed striped unified-domains-table" id="unified-domains-table">';
    echo '<thead><tr>';
    echo '<th class="domain-col">Dominio</th>';
    echo '<th class="server-col">Servidor</th>';
    echo '<th class="cf-col" title="Estado en Cloudflare">☁️ CF</th>';
    echo '<th class="status-col">Estado</th>';
    echo '<th class="startdate-col">Inicio WHM</th>';
    echo '<th class="registered-col">Alta en Replanta</th>';
    echo '<th class="trees-col">Árboles</th>';
    echo '<th class="co2-col">CO2 Evitado (g)</th>';
    echo '<th class="actions-col">Acciones</th>';
    echo '</tr></thead><tbody>';

    foreach ($all_domains as $row) {
        // $row es un objeto stdClass de la base de datos
        $dominio = esc_html($row->domain);
        $server = strtoupper($row->server ?? 'UK');
        $server_lower = strtolower($server);
        $status = $row->status ?? 'Activo';
        $startdate = $row->startdate;
        $trees = (int)($row->trees_planted ?? 0);
        $co2 = (float)($row->co2_evaded ?? 0);
        $primary_domain = $row->primary_domain ?? $dominio;
        $is_addon = ($status === 'Addon');
        
        // Obtener match de Cloudflare para este dominio (usando primary_domain)
        $cf_match = $cf_matches[$primary_domain] ?? null;

        // Clases CSS para diferentes estados
        $status_class = '';
        $row_class = 'unified-domain-row';
        
        switch($status) {
            case 'Activo':
                $status_class = 'status-active';
                break;
            case 'Suspendido':
                $status_class = 'status-suspended';
                $row_class .= ' suspended-row';
                break;
            case 'Addon':
                $status_class = 'status-addon';
                $row_class .= ' addon-row';
                break;
        }

        echo '<tr class="' . $row_class . '" data-domain="' . esc_attr($dominio) . '" data-server="' . esc_attr($server_lower) . '" data-status="' . esc_attr($status) . '">';
        
        // Columna dominio
        if ($is_addon && $primary_domain !== $dominio) {
            echo "<td class='domain-cell addon-domain'>└─ $dominio <small>(addon de $primary_domain)</small></td>";
        } else {
            echo "<td class='domain-cell'><strong>$dominio</strong></td>";
        }
        
        echo "<td class='server-cell'><span class='server-badge server-{$server_lower}'>$server</span></td>";
        
        // Columna Cloudflare (usando primary_domain para el match)
        echo '<td class="cf-col">';
        if (class_exists('Dominios_Reseller_Cloudflare_Admin')) {
            echo Dominios_Reseller_Cloudflare_Admin::render_cloudflare_cell($primary_domain, $cf_match, $has_cf_sync);
        } else {
            echo '<span title="Módulo CF no disponible">-</span>';
        }
        echo '</td>';
        
        echo "<td class='status-cell'><span class='status-badge $status_class'>$status</span></td>";
        echo '<td class="startdate-cell">' . ($startdate ? date('Y-m-d', $startdate) : 'N/A') . '</td>';
        echo '<td class="registered-cell">' . esc_html($row->fecha_emision ?? '(No reg.)') . '</td>';
        echo "<td class='trees-cell'><input type='number' class='trees-input' data-domain='$dominio' data-server='$server_lower' value='$trees' min='0' /></td>";
        echo "<td class='co2-cell'><input type='number' class='co2-input' data-domain='$dominio' data-server='$server_lower' value='$co2' step='0.01' /></td>";
        echo "<td class='actions-cell'><button class='button button-small calculate-emissions' data-domain='$dominio' data-server='$server_lower'>Calcular</button></td>";
        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '<div class="unified-actions">';
    echo '<button class="button button-primary save-all-unified" data-table="unified">💾 Guardar todos los cambios</button>';
    echo '<button class="button refresh-unified" data-table="unified">🔄 Actualizar datos</button>';
    echo '</div>';

    // =====================================================
    // VISTA DE CARDS PRO
    // =====================================================
    echo '<div id="cards-view" class="cards-view-container" style="display:none;">';
    echo '<div class="cards-grid">';

    foreach ($all_domains as $row) {
        $dominio = esc_html($row->domain);
        $server = strtoupper($row->server ?? 'UK');
        $server_lower = strtolower($server);
        $status = $row->status ?? 'Activo';
        $startdate = $row->startdate;
        $trees = (int)($row->trees_planted ?? 0);
        $co2 = (float)($row->co2_evaded ?? 0);
        $primary_domain = $row->primary_domain ?? $dominio;
        $is_addon = ($status === 'Addon');

        // Obtener match de Cloudflare para este dominio
        $cf_match = $cf_matches[$primary_domain] ?? null;

        // Clases CSS para diferentes estados
        $card_class = 'domain-card-pro';
        switch($status) {
            case 'Activo':
                $card_class .= ' status-active';
                break;
            case 'Suspendido':
                $card_class .= ' status-suspended';
                break;
            case 'Addon':
                $card_class .= ' status-addon';
                break;
        }

        echo '<div class="' . $card_class . '" data-domain="' . esc_attr($dominio) . '" data-server="' . esc_attr($server_lower) . '" data-status="' . esc_attr($status) . '">';
        echo '<div class="card-header">';
        echo '<h4 class="card-domain">' . ($is_addon && $primary_domain !== $dominio ? '└─ ' : '') . $dominio . '</h4>';
        echo '<div class="card-badges">';
        echo '<span class="badge server-badge server-' . $server_lower . '">' . $server . '</span>';
        echo '<span class="badge status-badge status-' . strtolower($status) . '">' . $status . '</span>';
        if ($cf_match) {
            echo '<span class="badge cf-badge">☁️ CF</span>';
        }
        echo '</div>';
        echo '</div>';

        echo '<div class="card-body">';
        echo '<div class="card-row">';
        echo '<label>Inicio WHM:</label>';
        echo '<span>' . esc_html($startdate) . '</span>';
        echo '</div>';
        echo '<div class="card-row">';
        echo '<label>Alta Replanta:</label>';
        echo '<span>' . esc_html($row->fecha_emision ?? '(No reg.)') . '</span>';
        echo '</div>';
        echo '<div class="card-row">';
        echo '<label>Árboles:</label>';
        echo '<input type="number" class="trees-input-card" data-domain="' . $dominio . '" data-server="' . $server_lower . '" value="' . $trees . '" min="0" />';
        echo '</div>';
        echo '<div class="card-row">';
        echo '<label>CO2 Evitado:</label>';
        echo '<input type="number" class="co2-input-card" data-domain="' . $dominio . '" data-server="' . $server_lower . '" value="' . $co2 . '" step="0.01" />';
        echo '</div>';
        echo '</div>';

        echo '<div class="card-actions">';
        echo '<button class="button button-small calculate-emissions-card" data-domain="' . $dominio . '" data-server="' . $server_lower . '">Calcular</button>';
        echo '</div>';
        echo '</div>';
    }

    echo '</div>'; // Fin cards-grid
    echo '<div class="cards-actions">';
    echo '<button class="button button-primary save-all-cards">💾 Guardar todos los cambios</button>';
    echo '<button class="button refresh-cards">🔄 Actualizar datos</button>';
    echo '</div>';
    echo '</div>'; // Fin cards-view-container

    echo '</div>'; // Fin domains-unified-container
}

add_action('admin_init', function () {
    register_setting('dominios_reseller_options_group', 'dominios_reseller_options', 'dominios_reseller_validate_options');

    // Configuración servidor UK (existente)
    add_settings_section('dominios_reseller_uk', 'Servidor UK (Europa)', function () {
        echo '<p>Configuración del servidor WHM en Reino Unido.</p>';
    }, 'dominios-reseller');

    add_settings_field('uk_server_ip', 'IP/Hostname Servidor (UK)', function () {
        $opts = get_option('dominios_reseller_options');
        $ip = isset($opts['uk_server_ip']) ? esc_attr($opts['uk_server_ip']) : '';
        echo "<input type='text' name='dominios_reseller_options[uk_server_ip]' value='$ip' class='regular-text' placeholder='ej: 198.38.92.238 o servidor.ejemplo.com'>";
        echo "<p class='description'>IP o nombre del servidor WHM de UK (puerto 2087)</p>";
    }, 'dominios-reseller', 'dominios_reseller_uk');

    add_settings_field('uk_whm_token', 'API Token WHM (UK)', function () {
        $opts = get_option('dominios_reseller_options');
        $token = isset($opts['uk_whm_token']) ? esc_attr($opts['uk_whm_token']) : '';
        echo "<input type='password' name='dominios_reseller_options[uk_whm_token]' value='$token' class='regular-text' autocomplete='off' placeholder='Token del servidor UK...'>";
        echo "<p class='description'>Token de autenticación para el servidor WHM de UK</p>";
    }, 'dominios-reseller', 'dominios_reseller_uk');

    // Configuración servidor USA (nuevo)
    add_settings_section('dominios_reseller_usa', 'Servidor USA', function () {
        echo '<p>Configuración del servidor WHM en Estados Unidos.</p>';
    }, 'dominios-reseller');

    add_settings_field('usa_server_ip', 'IP/Hostname Servidor (USA)', function () {
        $opts = get_option('dominios_reseller_options');
        $ip = isset($opts['usa_server_ip']) ? esc_attr($opts['usa_server_ip']) : '';
        echo "<input type='text' name='dominios_reseller_options[usa_server_ip]' value='$ip' class='regular-text' placeholder='ej: 192.250.227.159 o servidor.ejemplo.com'>";
        echo "<p class='description'>IP o nombre del servidor WHM de USA (puerto 2087)</p>";
    }, 'dominios-reseller', 'dominios_reseller_usa');

    add_settings_field('usa_whm_token', 'API Token WHM (USA)', function () {
        $opts = get_option('dominios_reseller_options');
        $token = isset($opts['usa_whm_token']) ? esc_attr($opts['usa_whm_token']) : '';
        echo "<input type='password' name='dominios_reseller_options[usa_whm_token]' value='$token' class='regular-text' autocomplete='off' placeholder='Token del servidor USA...'>";
        echo "<p class='description'>Token de autenticación para el servidor WHM de USA</p>";
    }, 'dominios-reseller', 'dominios_reseller_usa');

    // Sección para configuración de mensajes
    add_settings_section('dominios_reseller_messages', 'Mensajes para Shortcodes', function () {
        echo '<p>Configura los mensajes que se mostrarán cuando no se detecte un dominio específico</p>';
    }, 'dominios-reseller');

    add_settings_field('hero_title', 'Título Hero (H1)', function () {
        $opts = get_option('dominios_reseller_options');
        $title = isset($opts['hero_title']) ? esc_attr($opts['hero_title']) : 'Hosting Ecológico con Impacto Positivo';
        echo "<input type='text' name='dominios_reseller_options[hero_title]' value='$title' class='large-text' placeholder='Título principal cuando no hay dominio específico...'>";
        echo "<p class='description'>Este título aparecerá como H1 cuando no se pueda detectar el dominio</p>";
    }, 'dominios-reseller', 'dominios_reseller_messages');

    add_settings_field('hero_description', 'Descripción Hero', function () {
        $opts = get_option('dominios_reseller_options');
        $description = isset($opts['hero_description']) ? esc_textarea($opts['hero_description']) : 'Nuestro hosting funciona con energía 100% renovable y contribuye activamente a la reforestación del planeta. Cada sitio web alojado con nosotros ayuda a plantar árboles y reducir la huella de carbono.';
        echo "<textarea name='dominios_reseller_options[hero_description]' class='large-text' rows='4' placeholder='Descripción cuando no hay dominio específico...'>$description</textarea>";
        echo "<p class='description'>Esta descripción aparecerá debajo del título cuando no se pueda detectar el dominio</p>";
    }, 'dominios-reseller', 'dominios_reseller_messages');

    add_settings_field('new_domain_message', 'Mensaje para Dominios Nuevos', function () {
        $opts = get_option('dominios_reseller_options');
        $message = isset($opts['new_domain_message']) ? esc_textarea($opts['new_domain_message']) : '🌱 ¡Acabamos de comenzar este emocionante viaje juntos! Tu sitio web ya funciona con energía 100% renovable. Los árboles se plantan automáticamente cuando cumplimos nuestro primer año de colaboración. ¡Gracias por elegir un hosting que cuida el planeta!';
        echo "<textarea name='dominios_reseller_options[new_domain_message]' class='large-text' rows='3' placeholder='Mensaje para dominios sin árboles...'>$message</textarea>";
        echo "<p class='description'>Este mensaje aparece en lugar de '0 árboles plantados' para dominios nuevos</p>";
    }, 'dominios-reseller', 'dominios_reseller_messages');
});

function dominios_reseller_validate_options($input) {
    $old_opts = get_option('dominios_reseller_options', []);
    
    return [
        // IPs de servidores WHM
        'uk_server_ip' => sanitize_text_field($input['uk_server_ip'] ?? ''),
        'usa_server_ip' => sanitize_text_field($input['usa_server_ip'] ?? ''),
        // Tokens WHM
        'uk_whm_token' => sanitize_text_field($input['uk_whm_token'] ?? ''),
        'usa_whm_token' => sanitize_text_field($input['usa_whm_token'] ?? ''),
        // Cloudflare Auth (Token o Global Key)
        'cf_api_token' => sanitize_text_field($input['cf_api_token'] ?? ''),
        'cf_email' => sanitize_email($input['cf_email'] ?? ''),
        'cf_global_key' => sanitize_text_field($input['cf_global_key'] ?? ''),
        'hero_title' => sanitize_text_field($input['hero_title'] ?? ''),
        'hero_description' => sanitize_textarea_field($input['hero_description'] ?? ''),
        'new_domain_message' => sanitize_textarea_field($input['new_domain_message'] ?? ''),
        // Openprovider (Fase 2)
        'op_username' => sanitize_text_field($input['op_username'] ?? ''),
        // Mantener password anterior si no se envía una nueva
        'op_password' => !empty($input['op_password']) 
            ? sanitize_text_field($input['op_password']) 
            : ($old_opts['op_password'] ?? ''),
    ];
}

/**
 * Función helper para obtener la IP del servidor desde las opciones
 * @param string $server 'uk' o 'usa'
 * @return string IP o hostname del servidor
 */
function dominios_reseller_get_server_ip($server) {
    $options = get_option('dominios_reseller_options', []);
    $key = $server . '_server_ip';
    return $options[$key] ?? '';
}

// Función para probar conexión WHM
function test_whm_connection($token, $server = 'uk') {
    if (empty($token)) {
        return [
            'success' => false,
            'error' => 'Token WHM no configurado'
        ];
    }

    $server_ip = dominios_reseller_get_server_ip($server);
    
    if (empty($server_ip)) {
        return [
            'success' => false,
            'error' => 'IP/Hostname del servidor ' . strtoupper($server) . ' no configurado'
        ];
    }

    $whm_url = 'https://' . $server_ip . ':2087/json-api/listaccts?api.version=1';

    // ✅ OPTIMIZACIÓN: Cache con transient (1 hora) - Reduce 95% de API calls
    $cache_key = 'dr_whm_test_' . $server . '_' . md5($token);
    $cached_result = get_transient($cache_key);
    
    if ($cached_result !== false) {
        error_log('[Dominios Reseller] Cache HIT para test connection: ' . $server);
        return $cached_result;
    }

    $response = wp_remote_get($whm_url, [
        'headers' => [
            'Authorization' => 'whm replanta:' . $token,
            'Accept' => 'application/json',
            'User-Agent' => 'WordPress/Replanta-Plugin'
        ],
        'timeout' => 30,
        'sslverify' => false,
        'blocking' => true
    ]);

    if (is_wp_error($response)) {
        $error_msg = $response->get_error_message();
        error_log('[Dominios Reseller] WP Error: ' . $error_msg);
        $error_result = [
            'success' => false,
            'error' => 'Error de conexión: ' . $error_msg
        ];
        // Cache errores por 5 minutos para evitar reintentos constantes
        set_transient($cache_key, $error_result, 300);
        return $error_result;
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    error_log('[Dominios Reseller] Test Connection - Server: ' . $server . ' Status: ' . $status_code . ' Body: ' . substr($body, 0, 200));

    if ($status_code !== 200) {
        $error_result = [
            'success' => false,
            'error' => 'Código de respuesta HTTP: ' . $status_code . ' - ' . substr($body, 0, 100)
        ];
        // Cache errores por 5 minutos
        set_transient($cache_key, $error_result, 300);
        return $error_result;
    }

    $data = json_decode($body, true);

    if (!$data || !isset($data['data']['acct'])) {
        $error_result = [
            'success' => false,
            'error' => 'Respuesta inválida del servidor WHM'
        ];
        // Cache errores por 5 minutos
        set_transient($cache_key, $error_result, 300);
        return $error_result;
    }

    $success_result = [
        'success' => true,
        'count' => count($data['data']['acct']),
        'message' => 'Conexión exitosa con WHM'
    ];
    
    // ✅ Cache respuestas exitosas por 1 hora
    set_transient($cache_key, $success_result, 3600);
    
    return $success_result;
}

// Función para mostrar dominios de un servidor específico
function mostrar_servidor_dominios($server, $server_name) {
    $options = get_option('dominios_reseller_options');
    $token_key = $server . '_whm_token';
    $token = $options[$token_key] ?? '';
    $server_ip = dominios_reseller_get_server_ip($server);

    echo '<div class="server-section">';
    echo '<div class="server-header">';
    
    if (!empty($server_ip)) {
        echo '<h3>' . esc_html($server_name) . ' <small>(' . esc_html($server_ip) . ')</small></h3>';
    } else {
        echo '<h3>' . esc_html($server_name) . ' <small style="color:#dc3545;">(IP no configurada)</small></h3>';
    }

    if (!empty($token)) {
        echo '<form method="post" style="display: inline-block; margin-left: 10px;">';
        echo '<input type="hidden" name="test_whm_connection" value="1">';
        echo '<input type="hidden" name="server" value="' . esc_attr($server) . '">';
        submit_button('🔧 Probar Conexión', 'secondary', 'test_connection_' . $server, false);
        echo '</form>';
    } else {
        echo '<div class="notice notice-warning inline"><p>⚠️ Configura el token WHM en la pestaña de configuración</p></div>';
    }
    echo '</div>';

    // Verificar que tanto IP como token estén configurados
    if (empty($server_ip)) {
        echo '<div class="no-config-message">';
        echo '<p>⚠️ Configure la IP/Hostname del servidor ' . strtoupper($server) . ' en la pestaña de configuración.</p>';
        echo '</div>';
        echo '</div>';
        return;
    }

    if (empty($token)) {
        echo '<div class="no-config-message">';
        echo '<p>Configure el token WHM para este servidor en la pestaña de configuración.</p>';
        echo '</div>';
        echo '</div>';
        return;
    }

    $cuentas = obtener_cuentas_whm($token, $server);
    if (!$cuentas || empty($cuentas['data']['acct'])) {
        echo '<div class="error-message">';
        echo '<p>No se encontraron cuentas en WHM o hubo un error de conexión.</p>';
        echo '</div>';
        echo '</div>';
        return;
    }

    global $wpdb;
    $tabla = $wpdb->prefix . 'dominios_reseller';

    echo '<div class="domains-table-container">';
    echo '<table class="widefat fixed striped domains-table" id="domains-table-' . $server . '" data-server="' . $server . '">';
    echo '<thead><tr>';
    echo '<th class="domain-col">Dominio</th>';
    echo '<th class="status-col">Estado</th>';
    echo '<th class="startdate-col">Inicio WHM</th>';
    echo '<th class="registered-col">Alta en Replanta</th>';
    echo '<th class="traffic-col">Tráfico (GB)</th>';
    echo '<th class="trees-col">Árboles</th>';
    echo '<th class="co2-col">CO2 Evitado (g)</th>';
    echo '<th class="actions-col">Acciones</th>';
    echo '</tr></thead><tbody>';

    foreach ($cuentas['data']['acct'] as $cuenta) {
        $dominio = esc_html($cuenta['domain']);
        $startdate = intval($cuenta['unix_startdate']);
        $suspended = $cuenta['suspended'];
        $activo = $suspended ? 'Suspendido' : 'Activo';
        $status_class = $suspended ? 'status-suspended' : 'status-active';

        $existente = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE domain = %s", $dominio));

        $fecha_emision_calculada = date('Y-m-d', $startdate);
        $validez_calculada = date('Y-m-d', strtotime("$fecha_emision_calculada +1 year"));

        $needs_update = false;
        if ($existente) {
            if ($existente->fecha_emision !== $fecha_emision_calculada || $existente->validez !== $validez_calculada) {
                $wpdb->update($tabla, [
                    'fecha_emision' => $fecha_emision_calculada,
                    'validez'       => $validez_calculada,
                ], ['domain' => $dominio]);
                $existente->fecha_emision = $fecha_emision_calculada;
                $existente->validez = $validez_calculada;
            }
        }

        $trees = $existente->trees_planted ?? 0;
        $co2 = $existente->co2_evaded ?? 0;

        echo '<tr class="domain-row" data-domain="' . esc_attr($dominio) . '" data-server="' . $server . '">';
        echo "<td class='domain-cell'><strong>$dominio</strong></td>";
        echo "<td class='status-cell'><span class='status-badge $status_class'>$activo</span></td>";
        echo '<td class="startdate-cell">' . date('Y-m-d', $startdate) . '</td>';
        echo '<td class="registered-cell">' . esc_html($existente->fecha_emision ?? '(No reg.)') . '</td>';

        $trafico_bytes = obtener_trafico_real($dominio, $token, $server);
        $trafico_gb = $trafico_bytes ? round($trafico_bytes / (1024 ** 3), 2) : 'N/A';
        echo "<td class='traffic-cell'>$trafico_gb</td>";

        echo "<td class='trees-cell'><input type='number' class='trees-input' data-domain='$dominio' data-server='$server' value='$trees' min='0' /></td>";
        echo "<td class='co2-cell'><input type='number' class='co2-input' data-domain='$dominio' data-server='$server' value='$co2' step='0.01' /></td>";
        echo "<td class='actions-cell'><button class='button button-small calculate-emissions' data-domain='$dominio' data-server='$server'>Calcular</button></td>";
        echo '</tr>';

        // Añadir dominios adicionales (addon domains)
        $addons = obtener_addons_de_usuario($cuenta['user'], $token, $server);

        if (!is_array($addons) || empty($addons)) {
            continue;
        }

        foreach ($addons as $addon) {
            if (!is_array($addon) || !isset($addon['domain']) || empty($addon['domain'])) {
                error_log("[Dominios Reseller] Addon inválido para usuario {$cuenta['user']}: " . print_r($addon, true));
                continue;
            }

            $addon_domain = esc_html($addon['domain']);
            $addon_existente = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tabla WHERE domain = %s", $addon_domain));
            $trees_addon = $addon_existente->trees_planted ?? 0;
            $co2_addon = $addon_existente->co2_evaded ?? 0;
            $fecha_emision_addon = date('Y-m-d', $startdate);
            $validez_addon = date('Y-m-d', strtotime("$fecha_emision_addon +1 year"));

            if ($addon_existente) {
                if ($addon_existente->fecha_emision !== $fecha_emision_addon || $addon_existente->validez !== $validez_addon) {
                    $wpdb->update($tabla, [
                        'fecha_emision' => $fecha_emision_addon,
                        'validez' => $validez_addon
                    ], ['domain' => $addon_domain]);
                    $addon_existente->fecha_emision = $fecha_emision_addon;
                    $addon_existente->validez = $validez_addon;
                }
            }

            echo '<tr class="addon-row" data-domain="' . esc_attr($addon_domain) . '" data-server="' . $server . '">';
            echo "<td class='domain-cell addon-domain'>└─ $addon_domain</td>";
            echo "<td class='status-cell'><span class='status-badge status-addon'>Addon</span></td>";
            echo '<td class="startdate-cell">' . date('Y-m-d', $startdate) . '</td>';
            echo '<td class="registered-cell">' . esc_html($addon_existente->fecha_emision ?? '(No reg.)') . '</td>';
            echo "<td class='traffic-cell'>N/A</td>";
            echo "<td class='trees-cell'><input type='number' class='trees-input' data-domain='$addon_domain' data-server='$server' value='$trees_addon' min='0' /></td>";
            echo "<td class='co2-cell'><input type='number' class='co2-input' data-domain='$addon_domain' data-server='$server' value='$co2_addon' step='0.01' /></td>";
            echo "<td class='actions-cell'><button class='button button-small calculate-emissions' data-domain='$addon_domain' data-server='$server'>Calcular</button></td>";
            echo '</tr>';

            if (!$addon_existente) {
                $wpdb->insert($tabla, [
                    'domain' => $addon_domain,
                    'startdate' => $startdate,
                    'fecha_emision' => date('Y-m-d', $startdate),
                    'status' => 'Addon',
                    'trees_planted' => 0,
                    'co2_evaded' => 0,
                    'primary_domain' => $dominio
                ]);
            }
        }

        if (!$existente) {
            $wpdb->insert($tabla, [
                'domain'         => $dominio,
                'startdate'      => $startdate,
                'fecha_emision'  => $fecha_emision_calculada,
                'validez'        => $validez_calculada,
                'status'         => $activo,
                'trees_planted'  => 0,
                'co2_evaded'     => 0,
                'primary_domain' => $dominio,
                'is_primary'     => 1
            ]);
        }
    }
    echo '</tbody></table>';
    echo '<div class="table-actions">';
    echo '<button class="button button-primary save-all-changes" data-server="' . $server . '">💾 Guardar todos los cambios</button>';
    echo '<button class="button refresh-data" data-server="' . $server . '">🔄 Actualizar datos</button>';
    echo '</div>';
    echo '</div>'; // Fin domains-table-container
    echo '</div>'; // Fin server-section
}

/**
 * Página de Diagnóstico - Solo accesible por URL directa
 * URL: /wp-admin/admin.php?page=dominios-reseller-diagnostic
 */
function dominios_reseller_diagnostic_page() {
    global $wpdb;
    
    echo '<div class="wrap">';
    echo '<h1>🔍 Diagnóstico - Dominios Reseller</h1>';
    
    // 1. Versión del plugin
    echo '<div style="background:#fff; padding:20px; margin:20px 0; border-left:4px solid #2271b1;">';
    echo '<h2>📌 Versión del Plugin</h2>';
    if (defined('DOMINIOS_RESELLER_VERSION')) {
        $version = DOMINIOS_RESELLER_VERSION;
        echo '<p style="font-size:18px;"><strong>Versión actual:</strong> <span style="color:#2271b1; font-weight:bold;">' . $version . '</span></p>';
        
        if (version_compare($version, '1.2.0', '>=')) {
            echo '<p style="color:green; font-weight:bold;">✅ Versión correcta (1.2.0+)</p>';
        } else {
            echo '<p style="color:red; font-weight:bold;">❌ Versión antigua (' . $version . ') - Necesitas actualizar</p>';
        }
    } else {
        echo '<p style="color:red; font-weight:bold;">⚠️ Constante DOMINIOS_RESELLER_VERSION no definida (versión MUY antigua)</p>';
        echo '<p>Sube el nuevo archivo dominios-reseller.php</p>';
    }
    echo '</div>';
    
    // 2. Estructura de la Base de Datos
    echo '<div style="background:#fff; padding:20px; margin:20px 0; border-left:4px solid #2271b1;">';
    echo '<h2>💾 Estructura de Base de Datos</h2>';
    $tabla = $wpdb->prefix . 'dominios_reseller';
    
    $columns = $wpdb->get_results("SHOW COLUMNS FROM $tabla");
    if ($columns) {
        echo '<table class="widefat" style="margin-top:10px;"><thead><tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th></tr></thead><tbody>';
        $has_server = false;
        foreach ($columns as $col) {
            if ($col->Field === 'server') $has_server = true;
            $highlight = ($col->Field === 'server') ? ' style="background:#c6f6d5; font-weight:bold;"' : '';
            echo "<tr$highlight>";
            echo '<td>' . esc_html($col->Field) . '</td>';
            echo '<td>' . esc_html($col->Type) . '</td>';
            echo '<td>' . esc_html($col->Null) . '</td>';
            echo '<td>' . esc_html($col->Key) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        
        if ($has_server) {
            echo '<p style="color:green; font-weight:bold; font-size:16px;">✅ Campo <code>server</code> existe correctamente</p>';
        } else {
            echo '<p style="color:red; font-weight:bold; font-size:16px;">❌ Campo <code>server</code> NO existe</p>';
            echo '<p><strong>SOLUCIÓN:</strong> Ve a Plugins → Desactivar "Dominios Reseller" → Activar de nuevo</p>';
        }
    }
    echo '</div>';
    
    // 3. Contenido de la tabla
    echo '<div style="background:#fff; padding:20px; margin:20px 0; border-left:4px solid #2271b1;">';
    echo '<h2>📊 Datos en la Tabla</h2>';
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $tabla");
    echo '<p style="font-size:16px;"><strong>Total de registros:</strong> ' . $total . '</p>';
    
    if (isset($has_server) && $has_server) {
        $uk_count = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE server = 'uk'");
        $usa_count = $wpdb->get_var("SELECT COUNT(*) FROM $tabla WHERE server = 'usa'");
        echo '<p style="font-size:16px;">🇬🇧 UK: <strong>' . $uk_count . '</strong> dominios | 🇺🇸 USA: <strong>' . $usa_count . '</strong> dominios</p>';
        
        // Mostrar algunos dominios de ejemplo
        $examples = $wpdb->get_results("SELECT domain, server, status FROM $tabla LIMIT 5");
        if ($examples) {
            echo '<p><strong>Ejemplos de dominios:</strong></p>';
            echo '<ul>';
            foreach ($examples as $ex) {
                $flag = strtolower($ex->server) === 'usa' ? '🇺🇸' : '🇬🇧';
                echo '<li>' . $flag . ' ' . esc_html($ex->domain) . ' (' . esc_html($ex->status) . ')</li>';
            }
            echo '</ul>';
        }
    }
    echo '</div>';
    
    // 4. Funciones críticas
    echo '<div style="background:#fff; padding:20px; margin:20px 0; border-left:4px solid #2271b1;">';
    echo '<h2>⚙️ Funciones Críticas</h2>';
    $functions = [
        'dominios_reseller_sync_from_whm' => 'Sincronización WHM (v1.2.0+)',
        'obtener_cuentas_whm' => 'Obtener cuentas WHM',
        'obtener_datos_dominio_actual' => 'Datos de dominio para shortcode'
    ];
    
    echo '<ul style="list-style:none; padding:0;">';
    foreach ($functions as $func => $desc) {
        if (function_exists($func)) {
            echo '<li style="color:green; font-size:16px; padding:5px 0;">✅ <code>' . esc_html($func) . '</code> - ' . esc_html($desc) . '</li>';
        } else {
            echo '<li style="color:red; font-size:16px; padding:5px 0;">❌ <code>' . esc_html($func) . '</code> - ' . esc_html($desc) . ' <strong>(FALTA)</strong></li>';
        }
    }
    echo '</ul>';
    echo '</div>';
    
    // 5. Archivos modificados recientemente
    echo '<div style="background:#fff; padding:20px; margin:20px 0; border-left:4px solid #2271b1;">';
    echo '<h2>📁 Archivos del Plugin</h2>';
    $plugin_dir = plugin_dir_path(__FILE__);
    $files = [
        'dominios-reseller.php' => 'Archivo principal',
        'includes/shortcodes.php' => 'Shortcodes',
        'includes/whm-functions.php' => 'Funciones WHM',
        'includes/ajax-handlers.php' => 'Handlers AJAX'
    ];
    
    echo '<table class="widefat"><thead><tr><th>Archivo</th><th>Estado</th><th>Última modificación</th><th>Tamaño</th></tr></thead><tbody>';
    foreach ($files as $file => $desc) {
        $path = $plugin_dir . $file;
        if (file_exists($path)) {
            $mtime = filemtime($path);
            $date = date('Y-m-d H:i:s', $mtime);
            $size = round(filesize($path) / 1024, 2) . ' KB';
            
            // Resaltar si es muy antiguo (más de 7 días)
            $is_old = (time() - $mtime) > (7 * 24 * 60 * 60);
            $row_style = $is_old ? ' style="background:#fff3cd;"' : '';
            
            echo '<tr' . $row_style . '>';
            echo '<td><code>' . esc_html($file) . '</code><br><small>' . esc_html($desc) . '</small></td>';
            echo '<td style="color:green;">✅ Existe</td>';
            echo '<td>' . $date . ($is_old ? ' <span style="color:#856404;">(⚠️ Más de 7 días)</span>' : '') . '</td>';
            echo '<td>' . $size . '</td>';
            echo '</tr>';
        } else {
            echo '<tr>';
            echo '<td><code>' . esc_html($file) . '</code></td>';
            echo '<td style="color:red;">❌ No existe</td>';
            echo '<td colspan="2">-</td>';
            echo '</tr>';
        }
    }
    echo '</tbody></table>';
    echo '</div>';
    
    // 6. Recomendaciones finales
    echo '<div style="background:#fff; padding:20px; margin:20px 0; border-left:4px solid #00a32a;">';
    echo '<h2>💡 Recomendaciones</h2>';
    
    $all_ok = true;
    if (!defined('DOMINIOS_RESELLER_VERSION') || version_compare(DOMINIOS_RESELLER_VERSION, '1.2.0', '<')) {
        $all_ok = false;
        echo '<p style="color:red; font-weight:bold;">❌ Versión antigua del plugin</p>';
    }
    if (!isset($has_server) || !$has_server) {
        $all_ok = false;
        echo '<p style="color:red; font-weight:bold;">❌ Base de datos no actualizada (falta campo server)</p>';
    }
    if (!function_exists('dominios_reseller_sync_from_whm')) {
        $all_ok = false;
        echo '<p style="color:red; font-weight:bold;">❌ Función de sincronización no existe</p>';
    }
    
    if (!$all_ok) {
        echo '<div style="background:#f8d7da; padding:15px; border:1px solid #f5c6cb; border-radius:5px; margin-top:15px;">';
        echo '<h3 style="margin-top:0; color:#721c24;">⚠️ ACCIÓN REQUERIDA:</h3>';
        echo '<ol style="line-height:1.8;">';
        echo '<li><strong>Sube los nuevos archivos del plugin vía FTP</strong> (sobrescribe los existentes)</li>';
        echo '<li>Ve a <strong>Plugins → Desactivar "Dominios Reseller"</strong></li>';
        echo '<li>Ve a <strong>Plugins → Activar "Dominios Reseller"</strong></li>';
        echo '<li>Vuelve a esta página para verificar que todo esté en verde ✅</li>';
        echo '</ol>';
        echo '</div>';
    } else {
        echo '<div style="background:#d4edda; padding:15px; border:1px solid #c3e6cb; border-radius:5px;">';
        echo '<h3 style="margin-top:0; color:#155724;">✅ TODO CORRECTO</h3>';
        echo '<p style="margin:0;">El plugin está actualizado y funcionando correctamente. Puedes usar:</p>';
        echo '<ul style="line-height:1.8;">';
        echo '<li>📊 Admin: <a href="' . admin_url('admin.php?page=dominios-reseller') . '">Ver dominios</a></li>';
        echo '<li>🔄 Sincronizar datos desde WHM manualmente si es necesario</li>';
        echo '<li>📄 Shortcode: <code>[mostrar_dominio]</code> en páginas públicas</li>';
        echo '</ul>';
        echo '</div>';
    }
    echo '</div>';
    
    echo '</div>'; // Fin wrap
}

// Endpoint temporal para crear tablas (DEBUG)
add_action('wp_ajax_dr_create_tables', function() {
    if (!current_user_can('manage_options')) {
        wp_die('No permissions');
    }

    try {
        Dominios_Reseller_Onboarding_DB::create_tables();
        wp_send_json_success('Tablas creadas exitosamente');
    } catch (Exception $e) {
        wp_send_json_error('Error: ' . $e->getMessage());
    }
});