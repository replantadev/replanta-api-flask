/**
 * Debug Hub JavaScript
 */

(function($) {
    'use strict';

    console.log('🔧 Debug Hub JS loaded');

    // Ejecutar test
    window.runTest = function(testType) {
        console.log('🚀 Running test:', testType);
        console.log('📊 dr_debug_ajax available:', typeof dr_debug_ajax !== 'undefined');
        console.log('📊 dr_debug_ajax content:', dr_debug_ajax);

        const resultDiv = document.getElementById(testType + '_result');
        const button = resultDiv.previousElementSibling;

        // Limpiar resultado anterior
        resultDiv.innerHTML = '';
        resultDiv.className = 'dr-test-result loading';

        // Mostrar loading
        resultDiv.innerHTML = '<div class="dr-loading"></div>' + dr_debug_ajax.strings.running_test;

        // Desactivar botón
        button.disabled = true;
        const originalText = button.textContent;
        button.innerHTML = '<div class="dr-loading"></div>' + dr_debug_ajax.strings.running_test;

        // Ejecutar test via AJAX
        $.ajax({
            url: dr_debug_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'dr_debug_test',
                test_type: testType,
                nonce: dr_debug_ajax.nonce
            },
            success: function(response) {
                console.log('✅ AJAX success:', response);
                resultDiv.className = 'dr-test-result ' + (response.success ? 'success' : 'error');
                resultDiv.innerHTML = response.data;
            },
            error: function(xhr, status, error) {
                console.error('❌ AJAX error:', xhr, status, error);
                resultDiv.className = 'dr-test-result error';
                resultDiv.innerHTML = '❌ ' + dr_debug_ajax.strings.error + ': ' + error + '\n\nRespuesta del servidor:\n' + xhr.responseText;
            },
            complete: function() {
                // Restaurar botón
                button.disabled = false;
                button.innerHTML = originalText;
            }
        });
    };

    // Auto-refresh para algunos elementos
    $(document).ready(function() {
        console.log('📄 Debug Hub page ready');
        // Actualizar estadísticas cada 30 segundos
        setInterval(function() {
            // Podríamos actualizar algunas secciones automáticamente
        }, 30000);
    });

})(jQuery);